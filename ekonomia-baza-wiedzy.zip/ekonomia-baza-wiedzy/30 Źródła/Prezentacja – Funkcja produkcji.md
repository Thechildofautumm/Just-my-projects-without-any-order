---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** funkcja produkcji w krótkim i długim okresie, produkt przeciętny i marginalny, etapy produkcji, izokwanty, izokoszty, optimum producenta, efekty skali.

## Notatki oparte na tym źródle
[[Czynnik produkcji]], [[Funkcja produkcji]], [[Produkt przeciętny i marginalny]], [[Prawo malejących przychodów]], [[Etapy produkcji]], [[Efekty skali]], [[Izokwanta]], [[Krańcowa stopa technicznej substytucji]], [[Izokoszta]], [[Optimum producenta]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Produkt przeciętny i krańcowy z funkcji produkcji]], [[Firma Kowal – maksimum produktu przeciętnego]], [[Maksymalna produkcja przy jednym czynniku zmiennym]], [[Od którego pracownika działa prawo malejących przychodów]], [[Granice I i III etapu produkcji]], [[Gdzie działa racjonalny producent]], [[Granice II etapu produkcji]], [[Wytwórnia przetworów – II etap i powtórna wartość MP]], [[Efekty skali dwóch funkcji produkcji]], [[Krańcowa stopa substytucji technicznej na izokwancie]], [[Pracownia ceramiki – maksymalna produkcja przy danym budżecie]], [[Piekarnia – minimalny koszt produkcji]].
