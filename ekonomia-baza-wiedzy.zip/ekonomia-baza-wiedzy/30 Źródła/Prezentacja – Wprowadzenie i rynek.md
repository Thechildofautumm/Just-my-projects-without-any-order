---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** istota mikroekonomii, rzadkość, koszt alternatywny, granica możliwości produkcyjnych, rynek, popyt, podaż i równowaga.

## Notatki oparte na tym źródle
[[Mikroekonomia]], [[Rzadkość zasobów]], [[Czynnik produkcji]], [[Koszt alternatywny]], [[Granica możliwości produkcyjnych]], [[Analiza marginalna]], [[Rynek]], [[Popyt]], [[Podaż]], [[Równowaga rynkowa]], [[Nierównowaga rynkowa]], [[Pozacenowa determinanta popytu]], [[Pozacenowa determinanta podaży]], [[Interwencja państwa na rynku]], [[Substytucyjność i komplementarność dóbr]].

