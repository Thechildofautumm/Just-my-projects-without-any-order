---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** Samuelson W.F., Marks S.G. (2009), Ekonomia menedżerska, PWE, Warszawa
> **Rodzaj:** podręcznik

**Zawartość:** optymalizacja zysku, reklama i segmentacja rynku, struktury rynkowe – zadania w bazie to własne warianty z innymi danymi.

## Notatki oparte na tym źródle
[[Analiza marginalna]], [[Struktura rynkowa]], [[Koncentracja rynku]], [[Zysk marginalny]], [[Optymalizacja funkcji dwóch zmiennych]], [[Metoda mnożników Lagrange'a]], [[Analiza wrażliwości]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Producent dronów – funkcja zysku]], [[Producent dronów – analiza wrażliwości]], [[Cena i budżet reklamowy – zysk z dwiema zmiennymi]], [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]].
