---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** Solek A. (2017), Optymalne decyzje. Ekonomia menedżerska w zadaniach, Wydawnictwo UE w Krakowie
> **Rodzaj:** zbiór zadań

**Zawartość:** typy zadań, na których wzorowane są **własne** zadania z ekonomii menedżerskiej (inne dane, własne treści i rozwiązania).

## Notatki oparte na tym źródle
[[Popyt]], [[Pozacenowa determinanta popytu]], [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność a przychód]], [[Prawo malejących przychodów]], [[Etapy produkcji]], [[Optimum producenta]], [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koncentracja rynku]], [[Konkurencja doskonała]], [[Maksymalizacja zysku]], [[Próg rentowności]], [[Zysk marginalny]], [[Optymalizacja funkcji dwóch zmiennych]], [[Metoda mnożników Lagrange'a]], [[Funkcja popytu wielu zmiennych]], [[Funkcja popytu o stałej elastyczności]], [[Maksymalizacja przychodu]], [[Narzut ceny na koszt krańcowy]], [[Krańcowy przychód z pracy]], [[Model firmy dominującej]], [[Model Cournota]], [[Model Stackelberga]], [[Koszt relewantny]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Optymalna produkcja – dwa warianty funkcji]], [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]], [[Praca i kapitał przy liniowej funkcji produkcji]], [[Truskawki – różniczka zupełna popytu]], [[Krem z filtrem – łączny wpływ determinant popytu]], [[Olej napędowy – łączny wpływ ceny i dochodu]], [[Miesięcznik podróżniczy – elastyczności mieszane]], [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]], [[Cena maksymalizująca utarg – dwa rynki]], [[Linia promowa – podnieść czy obniżyć cenę]], [[Kubki z nadrukiem – cena z narzutem na koszt krańcowy]], [[Puzzle – wysoki narzut przy słabo elastycznym popycie]], [[Kawa mrożona – potęgowa funkcja popytu]], [[Słuchawki bezprzewodowe – stała elastyczność i narzut]], [[Sprzedaż na dwóch rynkach z łączną funkcją kosztów]], [[Prawo malejących przychodów dla Q = 2√(KL)]], [[Kawiarnia – optymalne zatrudnienie]], [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]], [[Najtańsza technika dla funkcji Cobba-Douglasa]], [[Najtańsza kombinacja nakładów dla Q = 50√(LK)]], [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]], [[Food truck – przy jakiej stopie procentowej się opłaca]], [[Wzrost kosztów stałych a decyzja o produkcji]], [[Rynek pralek – CR4 i HHI]], [[HHI dla modelowych struktur rynku]], [[Cena, przy której ustaje wejście do gałęzi]], [[Cena wyjścia z gałęzi w długim okresie]], [[Próg rentowności przy liniowych kosztach]], [[Próg rentowności ilościowy, wartościowy i procentowy]], [[Model firmy dominującej – cena i podział rynku]], [[Rynek gazu płynnego – firma dominująca]], [[Dwa kamieniołomy – duopol Cournota z kosztami stałymi]], [[Duopol Cournota – porównanie z konkurencją i monopolem]], [[Model Stackelberga – przewaga pierwszego ruchu]], [[Producenci autobusów – Cournot i Stackelberg]].
