---
typ: przewodnik
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/przewodnik"]
---
Ekonomia menedżerska powtarza zagadnienia mikroekonomii, ale nacisk kładzie na rachunek: optymalizację funkcji zysku, ustalanie ceny, optymalne zatrudnienie i decyzje w różnych strukturach rynku. Zadania obliczeniowe są własnymi wariantami typowych zadań (inne dane).

## Wykłady i ćwiczenia w kolejności
### [[EM – Wprowadzenie, analiza marginalna]]
Pojęcia: [[Analiza marginalna]], [[Maksymalizacja zysku]], [[Zysk marginalny]].

Zadania: [[Kategorie marginalne i warunki maksimum zysku]].

### [[EM – Metody optymalizacji]]
Pojęcia: [[Optymalizacja funkcji dwóch zmiennych]], [[Metoda mnożników Lagrange'a]], [[Analiza wrażliwości]].

Zadania: [[Producent dronów – funkcja zysku]], [[Producent dronów – analiza wrażliwości]], [[Optymalna produkcja – dwa warianty funkcji]], [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]], [[Cena i budżet reklamowy – zysk z dwiema zmiennymi]], [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]], [[Praca i kapitał przy liniowej funkcji produkcji]].

### [[EM – Popyt, elastyczność, polityka cenowa]]
Pojęcia: [[Popyt]], [[Pozacenowa determinanta popytu]], [[Substytucyjność i komplementarność dóbr]], [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność mieszana popytu]], [[Elastyczność dochodowa popytu]], [[Przychód]], [[Elastyczność a przychód]], [[Funkcja popytu wielu zmiennych]], [[Funkcja popytu o stałej elastyczności]], [[Maksymalizacja przychodu]], [[Narzut ceny na koszt krańcowy]].

Zadania: [[Truskawki – różniczka zupełna popytu]], [[Krem z filtrem – łączny wpływ determinant popytu]], [[Olej napędowy – łączny wpływ ceny i dochodu]], [[Miesięcznik podróżniczy – elastyczności mieszane]], [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]], [[Cena maksymalizująca utarg – dwa rynki]], [[Linia promowa – podnieść czy obniżyć cenę]], [[Kubki z nadrukiem – cena z narzutem na koszt krańcowy]], [[Puzzle – wysoki narzut przy słabo elastycznym popycie]], [[Kawa mrożona – potęgowa funkcja popytu]], [[Słuchawki bezprzewodowe – stała elastyczność i narzut]], [[Sprzedaż na dwóch rynkach z łączną funkcją kosztów]].

### [[EM – Produkcja i koszty]]
Pojęcia: [[Czynnik produkcji]], [[Koszt alternatywny]], [[Funkcja produkcji]], [[Produkt przeciętny i marginalny]], [[Prawo malejących przychodów]], [[Etapy produkcji]], [[Izokwanta]], [[Izokoszta]], [[Optimum producenta]], [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koszt stały i zmienny]], [[Koszt przeciętny]], [[Koszt marginalny]], [[Koszty a produktywność]], [[Krańcowy przychód z pracy]], [[Koszt relewantny]].

Zadania: [[Prawo malejących przychodów dla Q = 2√(KL)]], [[Kawiarnia – optymalne zatrudnienie]], [[Optymalna liczba roboczogodzin z MRP]], [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]], [[Najtańsza technika dla funkcji Cobba-Douglasa]], [[Najtańsza kombinacja nakładów dla Q = 50√(LK)]], [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]], [[Food truck – przy jakiej stopie procentowej się opłaca]], [[Wzrost kosztów stałych a decyzja o produkcji]].

### [[EM – Struktury rynkowe I]]
Pojęcia: [[Struktura rynkowa]], [[Koncentracja rynku]], [[Konkurencja doskonała]], [[Próg rentowności]], [[Punkt zamknięcia]], [[Konkurencja monopolistyczna]], [[Oligopol]].

Zadania: [[Rynek pralek – CR4 i HHI]], [[HHI dla modelowych struktur rynku]], [[Cena, przy której ustaje wejście do gałęzi]], [[Cena wyjścia z gałęzi w długim okresie]], [[Próg rentowności przy liniowych kosztach]], [[Próg rentowności ilościowy, wartościowy i procentowy]].

### [[EM – Struktury rynkowe II]]
Pojęcia: [[Model firmy dominującej]], [[Model Cournota]], [[Model Stackelberga]].

Zadania: [[Model firmy dominującej – cena i podział rynku]], [[Rynek gazu płynnego – firma dominująca]], [[Dwa kamieniołomy – duopol Cournota z kosztami stałymi]], [[Duopol Cournota – porównanie z konkurencją i monopolem]], [[Model Stackelberga – przewaga pierwszego ruchu]], [[Producenci autobusów – Cournot i Stackelberg]].

### [[EM – Struktury rynkowe, zestawienie]]
Pojęcia: [[Monopol pełny]], [[Równowaga monopolu]].

## Podręczniki, zbiory zadań i dokumenty
- [[Solek – Optymalne decyzje]] – typy zadań, na których wzorowane są **własne** zadania z ekonomii menedżerskiej (inne dane, własne treści i rozwiązania).
- [[Samuelson i Marks – Ekonomia menedżerska]] – optymalizacja zysku, reklama i segmentacja rynku, struktury rynkowe – zadania w bazie to własne warianty z innymi danymi.
