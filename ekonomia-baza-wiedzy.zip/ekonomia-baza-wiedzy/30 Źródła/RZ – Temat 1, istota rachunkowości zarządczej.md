---
typ: źródło
up: "[[Przedmiot – Rachunkowość zarządcza]]"
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład akademicki

**Zawartość:** definicje, porównanie z rachunkowością finansową, ewolucja, funkcje, rola i etyka kontrolera.

## Notatki oparte na tym źródle
[[Koszt alternatywny]], [[Koszt księgowy a koszt ekonomiczny]], [[Próg rentowności]], [[Rachunkowość zarządcza]], [[Rachunkowość zarządcza a finansowa]], [[Ewolucja rachunkowości zarządczej]], [[Funkcja rachunkowości zarządczej]], [[Rola kontrolera]], [[Etyka kontrolera]], [[Cyfryzacja i ESG w rachunkowości zarządczej]], [[Klasyfikacja kosztów]], [[Koszt relewantny]], [[Rachunek kosztów zmiennych i pełnych]], [[Marża wkładu]], [[Rachunek kosztów działań]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Velomia – trzy marże roweru Urban 5]], [[Velomia – zamówienie specjalne na Urban 5]].
