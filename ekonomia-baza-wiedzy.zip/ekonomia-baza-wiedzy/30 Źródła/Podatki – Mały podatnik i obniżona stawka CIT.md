---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** źródła przychodów w CIT, status małego podatnika, warunki i pułapki stawki 9%.

## Notatki oparte na tym źródle
[[Unikanie i uchylanie się od opodatkowania]], [[Planowanie podatkowe]], [[Dochód podatkowy]], [[Źródło przychodów w CIT]], [[Mały podatnik]], [[Preferencyjna stawka CIT]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – czy spółka zapłaci 9% CIT]].
