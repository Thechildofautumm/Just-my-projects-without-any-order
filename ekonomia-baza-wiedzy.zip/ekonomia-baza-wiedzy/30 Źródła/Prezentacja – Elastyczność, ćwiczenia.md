---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** interpretacja współczynników elastyczności i zadania o przychodach.

## Notatki oparte na tym źródle
[[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność łukowa]], [[Elastyczność mieszana popytu]], [[Przychód]], [[Elastyczność a przychód]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Interpretacja współczynników elastyczności]], [[Masło, łosoś i ser – rodzaj dobra i polityka cenowa]], [[Ilość, przy której elastyczność wynosi −2]], [[Zeszyty – elastyczność łukowa i przychód marginalny]], [[Maksymalny przychód przy popycie liniowym]], [[Batony – przychód marginalny w punkcie i na odcinku]], [[Ekspresy do kawy – elastyczność przy maksymalnym przychodzie]], [[Elastyczność i przychód przy cenie 20]], [[Elastyczność wyznaczona z przychodu marginalnego]], [[Przychód przy cenie 4000]], [[Ilość przy zerowym przychodzie marginalnym]], [[Równania AR, MR i TR z dwóch informacji]], [[Masło i margaryna – elastyczność mieszana]].
