---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** maksymalizacja zysku z jedną zmienną, analiza wrażliwości, optymalizacja dwóch zmiennych, metoda Lagrange'a.

## Notatki oparte na tym źródle
[[Analiza marginalna]], [[Maksymalizacja zysku]], [[Zysk marginalny]], [[Optymalizacja funkcji dwóch zmiennych]], [[Metoda mnożników Lagrange'a]], [[Analiza wrażliwości]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Producent dronów – funkcja zysku]], [[Producent dronów – analiza wrażliwości]], [[Optymalna produkcja – dwa warianty funkcji]], [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]], [[Cena i budżet reklamowy – zysk z dwiema zmiennymi]], [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]], [[Praca i kapitał przy liniowej funkcji produkcji]].
