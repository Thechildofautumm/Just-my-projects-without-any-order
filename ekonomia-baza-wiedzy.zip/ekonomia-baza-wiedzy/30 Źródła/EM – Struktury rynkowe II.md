---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** monopol, konkurencja monopolistyczna, oligopol: firma dominująca, Cournot, Stackelberg.

## Notatki oparte na tym źródle
[[Oligopol]], [[Model firmy dominującej]], [[Model Cournota]], [[Model Stackelberga]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Model firmy dominującej – cena i podział rynku]], [[Rynek gazu płynnego – firma dominująca]], [[Dwa kamieniołomy – duopol Cournota z kosztami stałymi]], [[Duopol Cournota – porównanie z konkurencją i monopolem]], [[Model Stackelberga – przewaga pierwszego ruchu]], [[Producenci autobusów – Cournot i Stackelberg]].
