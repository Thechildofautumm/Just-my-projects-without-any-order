---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** Rekowski M. (2011), Mikroekonomia, Wydawnictwo Akademia, Poznań
> **Rodzaj:** podręcznik

**Zawartość:** podręcznik mikroekonomii – źródło definicji cytowanych z podaniem autora.

## Notatki oparte na tym źródle
[[Mikroekonomia]], [[Rzadkość zasobów]], [[Czynnik produkcji]], [[Koszt alternatywny]], [[Granica możliwości produkcyjnych]], [[Analiza marginalna]], [[Rynek]], [[Popyt]], [[Podaż]], [[Równowaga rynkowa]], [[Pozacenowa determinanta popytu]], [[Pozacenowa determinanta podaży]], [[Substytucyjność i komplementarność dóbr]], [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność dochodowa popytu]], [[Przychód]], [[Użyteczność]], [[Preferencje konsumenta]], [[Krzywa obojętności]], [[Krańcowa stopa substytucji]], [[Linia budżetowa]], [[Optimum konsumenta]], [[Krzywa dochód–konsumpcja]], [[Krzywa Engla]], [[Krzywa cena–konsumpcja]], [[Efekt substytucji i efekt dochodowy]], [[Dobro Giffena]], [[Funkcja produkcji]], [[Produkt przeciętny i marginalny]], [[Prawo malejących przychodów]], [[Efekty skali]], [[Izokwanta]], [[Izokoszta]], [[Optimum producenta]], [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koszt stały i zmienny]], [[Koszt przeciętny]], [[Koszt marginalny]], [[Koszty a produktywność]], [[Struktura rynkowa]], [[Konkurencja doskonała]], [[Maksymalizacja zysku]], [[Próg rentowności]], [[Punkt zamknięcia]], [[Krzywa podaży przedsiębiorstwa]], [[Monopol pełny]], [[Równowaga monopolu]], [[Dyskryminacja cenowa]], [[Nadwyżka konsumenta i producenta]], [[Strata społeczna monopolu]].

