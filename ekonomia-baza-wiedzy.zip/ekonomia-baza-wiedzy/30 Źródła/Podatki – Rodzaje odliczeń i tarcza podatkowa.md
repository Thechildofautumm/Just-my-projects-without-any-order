---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** odliczenia od dochodu i od podatku, tarcza podatkowa i czynniki jej wartości.

## Notatki oparte na tym źródle
[[Preferencja podatkowa]], [[Korzyść podatkowa]], [[Odliczenie podatkowe]], [[Tarcza podatkowa]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – tarcza przy stawce 9% i 19%]], [[Podatki – ulga prorodzinna jako odliczenie od podatku]].
