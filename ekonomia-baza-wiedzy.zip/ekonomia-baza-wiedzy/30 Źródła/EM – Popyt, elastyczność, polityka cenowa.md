---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** funkcja popytu wielu zmiennych, różniczka zupełna, elastyczności, maksymalizacja przychodu, narzut ceny na koszt.

## Notatki oparte na tym źródle
[[Popyt]], [[Pozacenowa determinanta popytu]], [[Substytucyjność i komplementarność dóbr]], [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność mieszana popytu]], [[Elastyczność dochodowa popytu]], [[Przychód]], [[Elastyczność a przychód]], [[Funkcja popytu wielu zmiennych]], [[Funkcja popytu o stałej elastyczności]], [[Maksymalizacja przychodu]], [[Narzut ceny na koszt krańcowy]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Truskawki – różniczka zupełna popytu]], [[Krem z filtrem – łączny wpływ determinant popytu]], [[Olej napędowy – łączny wpływ ceny i dochodu]], [[Miesięcznik podróżniczy – elastyczności mieszane]], [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]], [[Cena maksymalizująca utarg – dwa rynki]], [[Linia promowa – podnieść czy obniżyć cenę]], [[Kubki z nadrukiem – cena z narzutem na koszt krańcowy]], [[Puzzle – wysoki narzut przy słabo elastycznym popycie]], [[Kawa mrożona – potęgowa funkcja popytu]], [[Słuchawki bezprzewodowe – stała elastyczność i narzut]], [[Sprzedaż na dwóch rynkach z łączną funkcją kosztów]].
