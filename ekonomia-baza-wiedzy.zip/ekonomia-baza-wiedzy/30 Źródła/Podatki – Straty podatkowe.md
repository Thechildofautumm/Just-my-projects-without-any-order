---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** strata a źródła przychodów w CIT i PIT, metody rozliczania strat w czasie.

## Notatki oparte na tym źródle
[[Dochód podatkowy]], [[Źródło przychodów w CIT]], [[Strata podatkowa]], [[Rozliczanie straty podatkowej w czasie]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – strata operacyjna a zysk kapitałowy]], [[Podatki – strata spółki a dochód z JDG]], [[Podatki – rozliczenie straty 3 i 18 mln zł]].
