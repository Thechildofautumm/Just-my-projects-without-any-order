---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** istota i cechy podatku, źródła prawa podatkowego, daniny, funkcje, system i klasyfikacje podatków, elementy konstrukcji.

## Notatki oparte na tym źródle
[[Podatek]], [[Źródło prawa podatkowego]], [[Danina publiczna]], [[Funkcja podatku]], [[System podatkowy w Polsce]], [[Klasyfikacja podatków]], [[Element konstrukcji podatku]], [[Preferencja podatkowa]], [[Incydencja podatkowa]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – klasyfikacja wybranych podatków]].
