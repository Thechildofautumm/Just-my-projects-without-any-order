---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** asymetria długu i kapitału własnego, niedostateczna kapitalizacja, limit kosztów finansowania dłużnego, NID.

## Notatki oparte na tym źródle
[[Tarcza podatkowa]], [[Asymetria podatkowa finansowania]], [[Niedostateczna kapitalizacja]], [[Limit kosztów finansowania dłużnego]], [[Hipotetyczne odsetki od kapitału własnego]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – dług czy kapitał własny]], [[Podatki – limit kosztów finansowania dłużnego]], [[Podatki – hipotetyczne odsetki od kapitału zapasowego]].
