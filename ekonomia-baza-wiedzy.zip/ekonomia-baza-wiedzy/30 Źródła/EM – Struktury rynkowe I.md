---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** koncentracja rynku (CR4, HHI), konkurencja doskonała w krótkim i długim okresie, próg rentowności.

## Notatki oparte na tym źródle
[[Struktura rynkowa]], [[Koncentracja rynku]], [[Konkurencja doskonała]], [[Maksymalizacja zysku]], [[Próg rentowności]], [[Punkt zamknięcia]], [[Konkurencja monopolistyczna]], [[Oligopol]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Rynek pralek – CR4 i HHI]], [[HHI dla modelowych struktur rynku]], [[Cena, przy której ustaje wejście do gałęzi]], [[Cena wyjścia z gałęzi w długim okresie]], [[Próg rentowności przy liniowych kosztach]], [[Próg rentowności ilościowy, wartościowy i procentowy]].
