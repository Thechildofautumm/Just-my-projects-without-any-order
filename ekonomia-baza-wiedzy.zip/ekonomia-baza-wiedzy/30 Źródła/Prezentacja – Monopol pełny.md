---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** bariery wejścia, równowaga monopolu, dyskryminacja cenowa, porównanie z konkurencją doskonałą.

## Notatki oparte na tym źródle
[[Struktura rynkowa]], [[Koncentracja rynku]], [[Maksymalizacja zysku]], [[Punkt zamknięcia]], [[Monopol pełny]], [[Równowaga monopolu]], [[Dyskryminacja cenowa]], [[Strata społeczna monopolu]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Monopol – optymalna cena i zysk]], [[Monopol – strata większa od kosztów stałych]], [[Monopol – za duża produkcja]], [[Monopol – kiedy zamknąć mimo MR = MC]], [[Strata społeczna monopolu – porównanie z konkurencją]], [[Koncentracja rynku – CR4 i HHI]].
