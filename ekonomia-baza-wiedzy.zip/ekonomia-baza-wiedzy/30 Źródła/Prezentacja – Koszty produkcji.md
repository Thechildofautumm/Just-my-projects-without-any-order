---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** koszty księgowe i ekonomiczne, koszty stałe i zmienne, koszty przeciętne i marginalny, związek kosztów z produktywnością.

## Notatki oparte na tym źródle
[[Koszt alternatywny]], [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koszt stały i zmienny]], [[Koszt przeciętny]], [[Koszt marginalny]], [[Koszty a produktywność]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Funkcje kosztów przeciętnych i krańcowego]], [[Koszty stałe z położenia minimum ATC]], [[Pani Grażyna – czy zmniejszyć produkcję]], [[Najniższy koszt krańcowy z funkcji produkcji]], [[Od funkcji produkcji do funkcji kosztów]].
