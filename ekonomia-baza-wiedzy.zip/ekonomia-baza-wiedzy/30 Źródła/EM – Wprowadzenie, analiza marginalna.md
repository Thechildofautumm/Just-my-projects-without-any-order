---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład akademicki

**Zawartość:** istota analizy marginalnej i warunki optymalizacji.

## Notatki oparte na tym źródle
[[Analiza marginalna]], [[Maksymalizacja zysku]], [[Zysk marginalny]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Kategorie marginalne i warunki maksimum zysku]].
