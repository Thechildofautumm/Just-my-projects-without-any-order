---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** rodzaje elastyczności, elastyczność punktowa i łukowa, przychody całkowity, przeciętny i marginalny.

## Notatki oparte na tym źródle
[[Substytucyjność i komplementarność dóbr]], [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność łukowa]], [[Elastyczność mieszana popytu]], [[Elastyczność dochodowa popytu]], [[Przychód]], [[Elastyczność a przychód]].

