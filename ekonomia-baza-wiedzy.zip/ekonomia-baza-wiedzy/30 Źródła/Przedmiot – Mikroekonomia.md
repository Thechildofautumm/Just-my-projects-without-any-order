---
typ: przewodnik
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/przewodnik"]
---
Kurs przechodzi od rynku (popyt, podaż, elastyczność) przez decyzje konsumenta i producenta do struktur rynkowych. Zadania w bazie są własnymi wariantami typowych zadań ze zbiorów (inne dane, własne rozwiązania).

## Wykłady i ćwiczenia w kolejności
### [[Prezentacja – Wprowadzenie i rynek]]
Pojęcia: [[Mikroekonomia]], [[Rzadkość zasobów]], [[Czynnik produkcji]], [[Koszt alternatywny]], [[Granica możliwości produkcyjnych]], [[Analiza marginalna]], [[Rynek]], [[Popyt]], [[Podaż]], [[Równowaga rynkowa]], [[Nierównowaga rynkowa]], [[Pozacenowa determinanta popytu]], [[Pozacenowa determinanta podaży]], [[Interwencja państwa na rynku]], [[Substytucyjność i komplementarność dóbr]].

### [[Prezentacja – Rynek, ćwiczenia]]
Zadania: [[Rynek rowerów – równowaga i cena poniżej równowagi]], [[Rynek lodówek – cena administracyjna]], [[Napoje energetyczne – cena maksymalna i kampania społeczna]], [[Sok jabłkowy – dopłata dla konsumentów]], [[Rynek najmu – dopłata dla wynajmujących]], [[Kolonie letnie – subwencja dla organizatorów]], [[Elektronika – podatek procentowy od ceny]], [[Dopłata procentowa dla konsumentów]], [[Smartwatche – ta sama cena, mniejsza ilość]], [[Rynek pelletu – nowe tartaki i droższe kotły]], [[Samochody używane – droższy kredyt i niższe cło]], [[Rynek kawy – przymrozki i drogi fracht]].

### [[Prezentacja – Elastyczność popytu i przychody]]
Pojęcia: [[Elastyczność popytu]], [[Elastyczność cenowa popytu]], [[Elastyczność punktowa]], [[Elastyczność łukowa]], [[Elastyczność mieszana popytu]], [[Elastyczność dochodowa popytu]], [[Przychód]], [[Elastyczność a przychód]].

### [[Prezentacja – Elastyczność, ćwiczenia]]
Zadania: [[Interpretacja współczynników elastyczności]], [[Masło, łosoś i ser – rodzaj dobra i polityka cenowa]], [[Ilość, przy której elastyczność wynosi −2]], [[Zeszyty – elastyczność łukowa i przychód marginalny]], [[Maksymalny przychód przy popycie liniowym]], [[Batony – przychód marginalny w punkcie i na odcinku]], [[Ekspresy do kawy – elastyczność przy maksymalnym przychodzie]], [[Elastyczność i przychód przy cenie 20]], [[Elastyczność wyznaczona z przychodu marginalnego]], [[Przychód przy cenie 4000]], [[Ilość przy zerowym przychodzie marginalnym]], [[Równania AR, MR i TR z dwóch informacji]], [[Masło i margaryna – elastyczność mieszana]].

### [[Prezentacja – Decyzje konsumenta i popyt]]
Pojęcia: [[Użyteczność]], [[Preferencje konsumenta]], [[Krzywa obojętności]], [[Krańcowa stopa substytucji]], [[Linia budżetowa]], [[Optimum konsumenta]], [[Krzywa dochód–konsumpcja]], [[Krzywa Engla]], [[Krzywa cena–konsumpcja]], [[Efekt substytucji i efekt dochodowy]], [[Dobro Giffena]].

Zadania: [[Bilety do kina – użyteczność marginalna]], [[Herbata i ciastka – krańcowa stopa substytucji]], [[Książki i płyty – optymalny koszyk]], [[Kompensacja wzrostu ceny – utrzymanie użyteczności]], [[Funkcja popytu z dwóch optimów konsumenta]], [[Krzywa Engla dla funkcji Cobba-Douglasa]].

### [[Prezentacja – Funkcja produkcji]]
Pojęcia: [[Funkcja produkcji]], [[Produkt przeciętny i marginalny]], [[Prawo malejących przychodów]], [[Etapy produkcji]], [[Efekty skali]], [[Izokwanta]], [[Krańcowa stopa technicznej substytucji]], [[Izokoszta]], [[Optimum producenta]].

Zadania: [[Produkt przeciętny i krańcowy z funkcji produkcji]], [[Firma Kowal – maksimum produktu przeciętnego]], [[Maksymalna produkcja przy jednym czynniku zmiennym]], [[Od którego pracownika działa prawo malejących przychodów]], [[Granice I i III etapu produkcji]], [[Gdzie działa racjonalny producent]], [[Granice II etapu produkcji]], [[Wytwórnia przetworów – II etap i powtórna wartość MP]], [[Efekty skali dwóch funkcji produkcji]], [[Krańcowa stopa substytucji technicznej na izokwancie]], [[Pracownia ceramiki – maksymalna produkcja przy danym budżecie]], [[Piekarnia – minimalny koszt produkcji]].

### [[Prezentacja – Koszty produkcji]]
Pojęcia: [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koszt stały i zmienny]], [[Koszt przeciętny]], [[Koszt marginalny]], [[Koszty a produktywność]].

Zadania: [[Funkcje kosztów przeciętnych i krańcowego]], [[Koszty stałe z położenia minimum ATC]], [[Pani Grażyna – czy zmniejszyć produkcję]], [[Najniższy koszt krańcowy z funkcji produkcji]], [[Od funkcji produkcji do funkcji kosztów]].

### [[Prezentacja – Konkurencja doskonała]]
Pojęcia: [[Konkurencja doskonała]], [[Maksymalizacja zysku]], [[Próg rentowności]], [[Punkt zamknięcia]], [[Krzywa podaży przedsiębiorstwa]].

Zadania: [[Konkurencja doskonała – produkcja przy cenie 34]], [[Konkurencja doskonała – zysk zerowy]], [[Konkurencja doskonała – strata mniejsza od kosztów stałych]], [[Konkurencja doskonała – decyzja przy MR = 24]], [[Cena progu rentowności z funkcji kosztów]], [[Cena zamknięcia z funkcji kosztów]], [[Odtwarzanie tabeli kosztów trzech firm]].

### [[Prezentacja – Monopol pełny]]
Pojęcia: [[Struktura rynkowa]], [[Koncentracja rynku]], [[Monopol pełny]], [[Równowaga monopolu]], [[Dyskryminacja cenowa]], [[Strata społeczna monopolu]].

Zadania: [[Monopol – optymalna cena i zysk]], [[Monopol – strata większa od kosztów stałych]], [[Monopol – za duża produkcja]], [[Monopol – kiedy zamknąć mimo MR = MC]], [[Strata społeczna monopolu – porównanie z konkurencją]], [[Koncentracja rynku – CR4 i HHI]].

## Podręczniki, zbiory zadań i dokumenty
- [[Syllabus – Mikroekonomia]] – zakres tematyczny kursu mikroekonomii.
- [[Rekowski – Mikroekonomia]] – podręcznik mikroekonomii – źródło definicji cytowanych z podaniem autora.
- [[Kalinowski – Zbiór zadań z mikroekonomii]] – typy zadań, na których wzorowane są **własne** zadania z mikroekonomii w tej bazie (inne dane, własne treści i rozwiązania).
