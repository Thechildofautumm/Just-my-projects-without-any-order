---
typ: źródło
up: "[[Przedmiot – Rachunkowość zarządcza]]"
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** klasyfikacja i hierarchia kosztów, zachowanie i szacowanie kosztów, krzywa uczenia się, RKZ/RKP, wielostopniowy rachunek marż, ABC, TDABC, rentowność klientów.

## Notatki oparte na tym źródle
[[Koszt stały i zmienny]], [[Klasyfikacja kosztów]], [[Koszt relewantny]], [[Hierarchia kosztów]], [[Zachowanie kosztów]], [[Szacowanie funkcji kosztów]], [[Krzywa uczenia się]], [[Rachunek kosztów zmiennych i pełnych]], [[Marża wkładu]], [[Rachunek kosztów działań]], [[Rachunek kosztów działań sterowany czasem]], [[Rentowność klientów]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Velomia – regresja a metoda wielkości skrajnych]], [[Velomia – krzywa uczenia się roweru Urban 9]], [[Velomia – RKP i RKZ w dwóch kwartałach]], [[Velomia – wielostopniowy rachunek marż]], [[Velomia – ABC w zakładzie w Lesznie]], [[Velomia – TDABC działu wsparcia technicznego]], [[Velomia – zamówienie specjalne na Urban 5]], [[Velomia – koszty sztywne po spadku sprzedaży]].
