---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** użyteczność, krzywe obojętności, linia budżetowa, optimum konsumenta, krzywe dochód–konsumpcja i cena–konsumpcja, krzywa Engla, efekty substytucyjny i dochodowy.

## Notatki oparte na tym źródle
[[Elastyczność dochodowa popytu]], [[Użyteczność]], [[Preferencje konsumenta]], [[Krzywa obojętności]], [[Krańcowa stopa substytucji]], [[Linia budżetowa]], [[Optimum konsumenta]], [[Krzywa dochód–konsumpcja]], [[Krzywa Engla]], [[Krzywa cena–konsumpcja]], [[Efekt substytucji i efekt dochodowy]], [[Dobro Giffena]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Bilety do kina – użyteczność marginalna]], [[Herbata i ciastka – krańcowa stopa substytucji]], [[Książki i płyty – optymalny koszyk]], [[Kompensacja wzrostu ceny – utrzymanie użyteczności]], [[Funkcja popytu z dwóch optimów konsumenta]], [[Krzywa Engla dla funkcji Cobba-Douglasa]].
