---
typ: przewodnik
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/przewodnik"]
---
Kurs zaczyna od istoty i konstrukcji podatku, przechodzi przez zachowania podatników, a kończy na strategiach w podatku dochodowym przedsiębiorstw: odliczeniach, finansowaniu, stratach i stawce dla małych podatników.

## Wykłady i ćwiczenia w kolejności
### [[Podatki – Wprowadzenie do opodatkowania]]
Pojęcia: [[Podatek]], [[Źródło prawa podatkowego]], [[Danina publiczna]], [[Funkcja podatku]], [[System podatkowy w Polsce]], [[Klasyfikacja podatków]], [[Element konstrukcji podatku]], [[Preferencja podatkowa]], [[Incydencja podatkowa]].

Zadania: [[Podatki – klasyfikacja wybranych podatków]].

### [[Podatki – Reakcje na opodatkowanie]]
Pojęcia: [[Interwencja państwa na rynku]], [[Reakcja podatnika na opodatkowanie]], [[Unikanie i uchylanie się od opodatkowania]], [[Korzyść podatkowa]], [[Moralność podatkowa]], [[Arbitraż podatkowy]], [[Planowanie podatkowe]].

Zadania: [[Podatki – arbitraż przy stawkach 12% i 32%]].

### [[Podatki – Rodzaje odliczeń i tarcza podatkowa]]
Pojęcia: [[Odliczenie podatkowe]], [[Tarcza podatkowa]].

Zadania: [[Podatki – tarcza przy stawce 9% i 19%]], [[Podatki – ulga prorodzinna jako odliczenie od podatku]].

### [[Podatki – Źródła finansowania a podatek dochodowy]]
Pojęcia: [[Asymetria podatkowa finansowania]], [[Niedostateczna kapitalizacja]], [[Limit kosztów finansowania dłużnego]], [[Hipotetyczne odsetki od kapitału własnego]].

Zadania: [[Podatki – dług czy kapitał własny]], [[Podatki – limit kosztów finansowania dłużnego]], [[Podatki – hipotetyczne odsetki od kapitału zapasowego]].

### [[Podatki – Straty podatkowe]]
Pojęcia: [[Dochód podatkowy]], [[Źródło przychodów w CIT]], [[Strata podatkowa]], [[Rozliczanie straty podatkowej w czasie]].

Zadania: [[Podatki – strata operacyjna a zysk kapitałowy]], [[Podatki – strata spółki a dochód z JDG]], [[Podatki – rozliczenie straty 3 i 18 mln zł]].

### [[Podatki – Mały podatnik i obniżona stawka CIT]]
Pojęcia: [[Mały podatnik]], [[Preferencyjna stawka CIT]].

Zadania: [[Podatki – czy spółka zapłaci 9% CIT]].

