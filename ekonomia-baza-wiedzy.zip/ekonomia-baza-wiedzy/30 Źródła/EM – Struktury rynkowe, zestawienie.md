---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** porównanie struktur rynkowych i miar koncentracji wg Samuelsona i Marksa.

## Notatki oparte na tym źródle
[[Struktura rynkowa]], [[Koncentracja rynku]], [[Konkurencja doskonała]], [[Monopol pełny]], [[Równowaga monopolu]], [[Konkurencja monopolistyczna]], [[Oligopol]].

