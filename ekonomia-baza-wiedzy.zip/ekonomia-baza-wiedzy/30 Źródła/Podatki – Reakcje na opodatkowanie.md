---
typ: źródło
up: "[[Przedmiot – Podatki i strategie podatkowe]]"
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** opór podatkowy, reakcje podatników, unikanie i uchylanie się, moralność podatkowa, arbitraż i planowanie podatkowe.

## Notatki oparte na tym źródle
[[Interwencja państwa na rynku]], [[Podatek]], [[Incydencja podatkowa]], [[Reakcja podatnika na opodatkowanie]], [[Unikanie i uchylanie się od opodatkowania]], [[Korzyść podatkowa]], [[Moralność podatkowa]], [[Arbitraż podatkowy]], [[Planowanie podatkowe]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Podatki – arbitraż przy stawkach 12% i 32%]].
