---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** założenia konkurencji doskonałej, maksymalizacja zysku, próg rentowności, punkt zamknięcia, krzywa podaży firmy.

## Notatki oparte na tym źródle
[[Konkurencja doskonała]], [[Maksymalizacja zysku]], [[Próg rentowności]], [[Punkt zamknięcia]], [[Krzywa podaży przedsiębiorstwa]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Konkurencja doskonała – produkcja przy cenie 34]], [[Konkurencja doskonała – zysk zerowy]], [[Konkurencja doskonała – strata mniejsza od kosztów stałych]], [[Konkurencja doskonała – decyzja przy MR = 24]], [[Cena progu rentowności z funkcji kosztów]], [[Cena zamknięcia z funkcji kosztów]], [[Odtwarzanie tabeli kosztów trzech firm]].
