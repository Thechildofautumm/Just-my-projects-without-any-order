---
typ: przewodnik
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/przewodnik"]
---
Przykłady i zadania dotyczą jednej fikcyjnej firmy wymyślonej na potrzeby tej bazy – producenta rowerów elektrycznych Velomia S.A. Pytania kontrolne są w Banku pytań egzaminacyjnych.

## Wykłady i ćwiczenia w kolejności
### [[RZ – Temat 1, istota rachunkowości zarządczej]]
Pojęcia: [[Koszt alternatywny]], [[Koszt księgowy a koszt ekonomiczny]], [[Próg rentowności]], [[Rachunkowość zarządcza]], [[Rachunkowość zarządcza a finansowa]], [[Ewolucja rachunkowości zarządczej]], [[Funkcja rachunkowości zarządczej]], [[Rola kontrolera]], [[Etyka kontrolera]], [[Cyfryzacja i ESG w rachunkowości zarządczej]], [[Klasyfikacja kosztów]], [[Koszt relewantny]], [[Rachunek kosztów zmiennych i pełnych]], [[Marża wkładu]], [[Rachunek kosztów działań]].

Zadania: [[Velomia – trzy marże roweru Urban 5]], [[Velomia – zamówienie specjalne na Urban 5]].

### [[RZ – Temat 2, koszty w ujęciu zarządczym]]
Pojęcia: [[Koszt stały i zmienny]], [[Hierarchia kosztów]], [[Zachowanie kosztów]], [[Szacowanie funkcji kosztów]], [[Krzywa uczenia się]], [[Rachunek kosztów działań sterowany czasem]], [[Rentowność klientów]].

Zadania: [[Velomia – regresja a metoda wielkości skrajnych]], [[Velomia – krzywa uczenia się roweru Urban 9]], [[Velomia – RKP i RKZ w dwóch kwartałach]], [[Velomia – wielostopniowy rachunek marż]], [[Velomia – ABC w zakładzie w Lesznie]], [[Velomia – TDABC działu wsparcia technicznego]], [[Velomia – zamówienie specjalne na Urban 5]], [[Velomia – koszty sztywne po spadku sprzedaży]].

