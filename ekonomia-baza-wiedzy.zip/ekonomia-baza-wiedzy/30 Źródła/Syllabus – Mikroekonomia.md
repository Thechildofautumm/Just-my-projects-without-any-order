---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** karta przedmiotu (dokument uczelni – nie jest częścią repozytorium)
> **Rodzaj:** zakres kursu

**Zawartość:** zakres tematyczny kursu mikroekonomii.

## Zakres kursu i notatki
| Lp. | Temat | Notatki |
|---|---|---|
| 1 | Czym zajmuje się mikroekonomia; wybór w warunkach rzadkości | [[Mikroekonomia]], [[Rzadkość zasobów]], [[Analiza marginalna]] |
| 2 | Rynek: popyt, podaż i cena | [[Rynek]], [[Popyt]], [[Podaż]], [[Równowaga rynkowa]] |
| 3 | Elastyczność popytu w praktyce | [[Elastyczność popytu]], [[Elastyczność a przychód]] |
| 4 | Preferencje i optimum konsumenta | [[Preferencje konsumenta]], [[Krzywa obojętności]], [[Optimum konsumenta]] |
| 5 | Od optimum do krzywej popytu; efekt substytucyjny i dochodowy | [[Krzywa cena–konsumpcja]], [[Efekt substytucji i efekt dochodowy]] |
| 6 | Produkcja i wybór techniki | [[Funkcja produkcji]], [[Optimum producenta]] |
| 7 | Rodzaje kosztów | [[Koszt księgowy a koszt ekonomiczny]], [[Koszt stały i zmienny]] |
| 8 | Koszty a produktywność; prawo malejących przychodów | [[Koszty a produktywność]], [[Prawo malejących przychodów]] |
| 9 | Struktury rynkowe | [[Struktura rynkowa]] |
| 10 | Konkurencja doskonała | [[Konkurencja doskonała]], [[Maksymalizacja zysku]] |
| 11 | Monopol i dyskryminacja cenowa | [[Monopol pełny]], [[Równowaga monopolu]], [[Dyskryminacja cenowa]] |
| 12 | Efektywność: nadwyżki i strata społeczna monopolu | [[Nadwyżka konsumenta i producenta]], [[Strata społeczna monopolu]] |

## Notatki oparte na tym źródle
[[Mikroekonomia]], [[Nadwyżka konsumenta i producenta]], [[Strata społeczna monopolu]].

