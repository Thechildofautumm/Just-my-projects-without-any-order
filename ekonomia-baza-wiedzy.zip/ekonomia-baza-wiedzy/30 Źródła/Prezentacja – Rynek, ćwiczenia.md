---
typ: źródło
up: "[[Przedmiot – Mikroekonomia]]"
przedmiot: ["Mikroekonomia"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** zadania o równowadze, cenach narzuconych, podatkach, dotacjach i czynnikach pozacenowych.

## Notatki oparte na tym źródle
[[Popyt]], [[Podaż]], [[Równowaga rynkowa]], [[Nierównowaga rynkowa]], [[Pozacenowa determinanta popytu]], [[Pozacenowa determinanta podaży]], [[Interwencja państwa na rynku]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Rynek rowerów – równowaga i cena poniżej równowagi]], [[Rynek lodówek – cena administracyjna]], [[Napoje energetyczne – cena maksymalna i kampania społeczna]], [[Sok jabłkowy – dopłata dla konsumentów]], [[Rynek najmu – dopłata dla wynajmujących]], [[Kolonie letnie – subwencja dla organizatorów]], [[Elektronika – podatek procentowy od ceny]], [[Dopłata procentowa dla konsumentów]], [[Smartwatche – ta sama cena, mniejsza ilość]], [[Rynek pelletu – nowe tartaki i droższe kotły]], [[Samochody używane – droższy kredyt i niższe cło]], [[Rynek kawy – przymrozki i drogi fracht]].
