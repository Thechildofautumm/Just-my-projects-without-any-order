---
typ: źródło
up: "[[Przedmiot – Ekonomia menedżerska]]"
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/źródło"]
---
> [!info] Źródło
> **Plik / bibliografia:** materiały z zajęć (nie są częścią repozytorium)
> **Rodzaj:** wykład / ćwiczenia akademickie

**Zawartość:** prawo malejących przychodów, optymalne zatrudnienie, najtańsza technika produkcji, koszty jawne i niejawne, koszty krótkookresowe.

## Notatki oparte na tym źródle
[[Czynnik produkcji]], [[Koszt alternatywny]], [[Funkcja produkcji]], [[Produkt przeciętny i marginalny]], [[Prawo malejących przychodów]], [[Etapy produkcji]], [[Izokwanta]], [[Izokoszta]], [[Optimum producenta]], [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]], [[Koszt stały i zmienny]], [[Koszt przeciętny]], [[Koszt marginalny]], [[Koszty a produktywność]], [[Krańcowy przychód z pracy]], [[Koszt relewantny]].

## Zadania inspirowane tym źródłem (własne warianty)
[[Prawo malejących przychodów dla Q = 2√(KL)]], [[Kawiarnia – optymalne zatrudnienie]], [[Optymalna liczba roboczogodzin z MRP]], [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]], [[Najtańsza technika dla funkcji Cobba-Douglasa]], [[Najtańsza kombinacja nakładów dla Q = 50√(LK)]], [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]], [[Food truck – przy jakiej stopie procentowej się opłaca]], [[Wzrost kosztów stałych a decyzja o produkcji]].
