---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Pytania kontrolne"]
---
Kliknij pytanie, aby zobaczyć odpowiedź – najpierw odpowiedz na głos. Pełne wyjaśnienia są w notatkach pojęć (wyszukaj pojęcie z pytania).

## Mikroekonomia

### Podstawy
> [!question]- Czym zajmuje się ekonomia?
> Alokacją rzadkich zasobów o alternatywnych zastosowaniach w celu produkcji dóbr oraz podziałem tych dóbr między członków społeczeństwa.

> [!question]- Na czym polega problem rzadkości?
> Potrzeby są nieograniczone, a zasoby ograniczone – zapotrzebowanie przewyższa zdolność wytworzenia, więc trzeba wybierać.

> [!question]- Co to jest koszt alternatywny?
> Wartość najlepszej możliwości, z której rezygnujemy, dokonując wyboru (koszt utraconych korzyści).

> [!question]- Jaki jest uniwersalny warunek optimum w analizie marginalnej?
> Korzyść marginalna = koszt marginalny (MB = MC). Gdy MB > MC – zwiększaj działalność, gdy MB < MC – zmniejszaj.

> [!question]- Co oznacza punkt wewnątrz granicy możliwości produkcyjnych?
> Nieefektywne (niepełne) wykorzystanie zasobów.

### Rynek
> [!question]- Różnica między „popytem” a „wielkością popytu”?
> Popyt = cała funkcja (krzywa D); wielkość popytu = ilość przy konkretnej cenie (punkt na krzywej). Zmiana ceny → zmiana wielkości popytu (ruch po krzywej).

> [!question]- Prawo popytu i prawo podaży?
> Popyt: cena ↑ ⇒ wielkość popytu ↓ (ceteris paribus). Podaż: cena ↑ ⇒ oferowana ilość ↑.

> [!question]- Co dzieje się przy cenie niższej od równowagi?
> Niedobór: $Q_D > Q_S$ (nadwyżka wielkości popytu). Sprzedana ilość = $Q_S$.

> [!question]- Wymień 4 czynniki przesuwające krzywą popytu.
> Dochody, gusty/preferencje, ceny substytutów i dóbr komplementarnych, oczekiwania cenowe, liczba ludności, efekty naśladownictwa/demonstracji.

> [!question]- Wymień 4 czynniki przesuwające krzywą podaży.
> Ceny czynników produkcji, technologia, podatki i subsydia, oczekiwania cenowe, liczba firm w gałęzi.

> [!question]- Wzrost ceny dobra komplementarnego – co z popytem na dane dobro?
> Spada (D w lewo), np. droższe piece gazowe ⇒ mniejszy popyt na gaz.

> [!question]- D↓ i S↑ jednocześnie – co z ceną i ilością?
> Cena na pewno spada; ilość – niejednoznacznie (zależy od siły zmian).

> [!question]- Jak zapisać podatek 40% od ceny w funkcji podaży?
> $0{,}6P = f_S(Q)$ – producent otrzymuje 60% ceny.

### Elastyczność
> [!question]- Wzór na elastyczność łukową?
> $E_Ł = \frac{Q_2 - Q_1}{Q_2 + Q_1}\cdot\frac{P_2 + P_1}{P_2 - P_1}$

> [!question]- Wzór na elastyczność punktową dla liniowej krzywej popytu?
> $E_p = \frac{P}{P - P_{max}} = \frac{Q - Q_{max}}{Q}$

> [!question]- Gdzie na liniowej krzywej popytu $|E_p| = 1$?
> W połowie: $P = \frac12P_{max}$, $Q = \frac12Q_{max}$. Powyżej – elastyczny, poniżej – nieelastyczny.

> [!question]- $E_m = -2$ – co to znaczy?
> Dobra komplementarne: wzrost ceny Y o 1% ⇒ spadek popytu na X o 2%.

> [!question]- $E_M = 1{,}6$ – jakie to dobro?
> Normalne, luksusowe (wyższego rzędu).

> [!question]- $E_M = 0{,}3$ – jakie to dobro?
> Normalne, podstawowe (pierwszej potrzeby).

> [!question]- Determinanty elastyczności cenowej popytu?
> Dostępność substytutów, udział wydatków w dochodzie, czas.

> [!question]- Jaka jest elastyczność popytu na produkt firmy w konkurencji doskonałej?
> Doskonale elastyczny: $E_p = -\infty$ (pozioma krzywa).

### Przychody
> [!question]- Związek MR i elastyczności?
> $MR = P\left(1 + \frac{1}{E_p}\right)$. $|E_p| > 1 \Rightarrow MR > 0$; $|E_p| = 1 \Rightarrow MR = 0$; $|E_p| < 1 \Rightarrow MR < 0$.

> [!question]- Dla $P = aQ + b$ jaka jest funkcja MR?
> $MR = 2aQ + b$ – to samo przecięcie z osią P, dwa razy większe nachylenie.

> [!question]- Kiedy TR jest maksymalny?
> Gdy MR = 0, tj. $|E_p| = 1$; $TR_{max} = \frac12P_{max}\cdot\frac12Q_{max}$.

> [!question]- Popyt nieelastyczny – obniżka ceny a przychód?
> Przychód (wydatki konsumentów) spada. Dla zwiększenia TR należy podnieść cenę.

> [!question]- Jak liczyć MR dla łuku?
> $MR = P_{śr}(1 + 1/E_Ł)$ albo $MR = \Delta TR / \Delta Q$.

### Konsument
> [!question]- Prawo malejącej użyteczności marginalnej?
> Każda kolejna jednostka dobra daje coraz mniejszy przyrost zadowolenia.

> [!question]- Trzy założenia systemu preferencji?
> Kompletność, przechodniość, nienasycenie.

> [!question]- Cechy krzywych obojętności?
> Ujemne nachylenie, nie przecinają się, wypukłe do początku układu, nieskończenie wiele.

> [!question]- Definicja i wzór MRS?
> Ilość Y, z której konsument zrezygnuje dla dodatkowej jednostki X, zachowując TU: $MRS = -\frac{\Delta Q_y}{\Delta Q_x} = \frac{MU_x}{MU_y}$.

> [!question]- Warunek optimum konsumenta?
> $MRS = \frac{P_x}{P_y}$, czyli $\frac{MU_x}{P_x} = \frac{MU_y}{P_y}$ – styczność krzywej obojętności z linią budżetową.

> [!question]- Równanie linii budżetowej?
> $M = P_xQ_x + P_yQ_y$; $Q_y = \frac{M}{P_y} - \frac{P_x}{P_y}Q_x$.

> [!question]- Co się dzieje z linią budżetową, gdy rośnie dochód? A gdy spada $P_x$?
> Dochód: przesunięcie równoległe na zewnątrz. Spadek $P_x$: obrót wokół $M/P_y$ (przecięcie z osią X oddala się).

> [!question]- Co to jest krzywa Engla?
> Zależność optymalnej ilości dobra od dochodu (przy stałych cenach); wyprowadzana z krzywej dochód–konsumpcja.

> [!question]- Czym różni się efekt substytucji od dochodowego?
> Substytucji: zmiana relacji cen ⇒ zastępowanie droższego tańszym (zawsze przeciwnie do zmiany ceny). Dochodowy: zmiana dochodu realnego ⇒ kierunek zależy od tego, czy dobro jest normalne czy podrzędne.

> [!question]- Co to jest dobro Giffena?
> Silnie podrzędne dobro, na które popyt rośnie wraz z ceną, bo ujemny efekt dochodowy przewyższa efekt substytucji. Każde dobro Giffena jest podrzędne, nie odwrotnie.

> [!question]- Co to jest popyt rynkowy?
> Suma (pozioma) popytów indywidualnych wszystkich konsumentów przy danej cenie.

### Produkcja
> [!question]- Wzory na $AP_L$ i $MP_L$?
> $AP_L = Q/L$; $MP_L = \Delta Q/\Delta L = Q'(L)$.

> [!question]- Relacja MP–AP?
> MP > AP ⇒ AP rośnie; MP < AP ⇒ AP spada; MP = AP w maksimum AP.

> [!question]- Prawo malejących przychodów?
> Przy wzroście nakładu jednego czynnika (pozostałe stałe), od pewnego poziomu przyrosty produkcji (MP) maleją. Start: $MP_{max}$, przegięcie TP.

> [!question]- Granice II etapu produkcji?
> Od $AP_{max}$ (MP = AP) do MP = 0 ($Q_{max}$). Tylko II etap jest racjonalny.

> [!question]- Definicja i wzór MRTS?
> Ile K można zastąpić jednostką L przy stałej produkcji: $MRTS = -\frac{\Delta K}{\Delta L} = \frac{MP_L}{MP_K}$.

> [!question]- Warunek optimum producenta (zasada najmniejszego kosztu)?
> $MRTS = \frac{w}{r} \iff \frac{MP_L}{w} = \frac{MP_K}{r}$ – styczność izokwanty z izokosztą.

> [!question]- Jak rozpoznać efekty skali dla $Q = AL^{\alpha}K^{\beta}$?
> $\alpha + \beta > 1$ rosnące, $= 1$ stałe, $< 1$ malejące.

### Koszty
> [!question]- Koszty księgowe vs ekonomiczne?
> Księgowe – jawne, faktycznie poniesione (explicite). Ekonomiczne – jawne + ukryte (implicite, alternatywne), łącznie z zyskiem normalnym.

> [!question]- Gdzie MC przecina AVC i ATC?
> W ich minimach.

> [!question]- Czy koszty stałe wpływają na MC?
> Nie – MC i AFC nie są powiązane ($MC = \Delta VC/\Delta Q$).

> [!question]- Dlaczego AVC osiąga minimum wcześniej niż ATC?
> Bo $ATC = AVC + AFC$, a AFC stale maleje – „ciągnie” minimum ATC w prawo.

> [!question]- Związek kosztów z produkcją?
> $AVC = w/AP_L$, $MC = w/MP_L$; malejący MP (prawo malejących przychodów) ⇒ rosnący MC.

### Struktury rynku i konkurencja doskonała
> [!question]- Kryterium podziału struktur rynkowych?
> Stopień wpływu firmy na cenę (zdarzenia rynkowe).

> [!question]- Progi CR4?
> < 40% konkurencja; 40–60% luźny oligopol; > 60% ścisły oligopol; 90–100% (CR1 > 90%) efektywny monopol.

> [!question]- Założenia konkurencji doskonałej?
> Produkt jednorodny, pełna mobilność czynników, wielu kupujących i sprzedających, doskonała informacja, brak wpływu na cenę.

> [!question]- Warunek maksymalizacji zysku w KD?
> $P = MR = MC$, przy rosnącym MC.

> [!question]- Próg rentowności w KD?
> $P = ATC_{min} = MC$ → zysk ekonomiczny = 0 (TR = TC).

> [!question]- Punkt zamknięcia w KD?
> $P = AVC_{min} = MC$ → strata = FC (TR = VC). Poniżej – zamknąć.

> [!question]- Firma ma stratę, ale P > AVC. Co robić w krótkim okresie?
> Produkować – przychód pokrywa koszty zmienne i część stałych; strata < FC.

> [!question]- Czym jest krzywa podaży firmy w KD?
> Odcinek krzywej MC powyżej minimum AVC.

### Monopol i efektywność
> [!question]- Założenia monopolu pełnego?
> Jeden sprzedawca, wielu kupujących, brak bliskich substytutów, zablokowane wejście (bariery), doskonała informacja.

> [!question]- Źródła monopolu?
> Monopol naturalny, kontrola produkcji (np. spirytus, tytoń, zbrojenia), patenty, bariery administracyjno-prawne.

> [!question]- Jak monopol ustala Q i P?
> Q z warunku MR = MC; P – z krzywej popytu nad tym Q.

> [!question]- Dlaczego monopol nie ma krzywej podaży?
> Nie ma jednoznacznej zależności cena–ilość: ta sama ilość może iść po różnych cenach zależnie od popytu.

> [!question]- Dyskryminacja cenowa – definicja i warunki?
> Różne ceny tego samego produktu dla różnych nabywców/rynków. Warunki: siła rynkowa, rozdzielenie rynków (brak odsprzedaży), różne elastyczności popytu.

> [!question]- Monopol vs konkurencja doskonała (Q, P, zysk)?
> $Q_m < Q_k$, $P_m > P_k$, $Z_m > Z_k$.

> [!question]- Co to jest nadwyżka konsumenta?
> Różnica między ceną, jaką konsument byłby skłonny zapłacić, a ceną zapłaconą; pole pod D i nad ceną.

> [!question]- Co to jest strata społeczna (DWL) monopolu?
> Utracona nadwyżka z transakcji, do których nie dochodzi, bo monopol ogranicza produkcję poniżej $Q_k$; trójkąt między D i MC od $Q_m$ do $Q_k$.

## Ekonomia menedżerska

### Analiza marginalna i optymalizacja
> [!question]- Jaki jest warunek konieczny i wystarczający maksimum zysku z jedną zmienną?
> Konieczny: $M\Pi = 0$, czyli $MR = MC$. Wystarczający: $\Pi'' < 0$ (funkcja zysku wklęsła), czyli $MR' < MC'$.

> [!question]- Czy maksymalizacja przychodu oznacza maksymalizację zysku?
> Zwykle nie – firma maksymalizująca zysk produkuje mniej i drożej. Cele są tożsame tylko wtedy, gdy firma nie ponosi kosztów zmiennych (np. sprzedaje zapasy, organizuje koncert przy stałym koszcie hali).

> [!question]- Jak zmiana kosztów stałych wpływa na optymalną produkcję?
> Nie wpływa – nie zmienia zysku marginalnego. Zmienia tylko wysokość zysku (krzywa zysku przesuwa się w pionie).

> [!question]- Jakie trzy warunki musi spełnić maksimum funkcji dwóch zmiennych?
> Obie pochodne cząstkowe = 0; drugie pochodne cząstkowe < 0; wyznacznik macierzy drugich pochodnych > 0.

> [!question]- Co oznacza mnożnik Lagrange'a λ?
> O ile zmieni się wartość funkcji celu, gdy ograniczenie zostanie poluzowane o jednostkę (cena cienia zasobu).

### Popyt i cena
> [!question]- Jak policzyć łączny wpływ kilku determinant na popyt liniowy?
> Różniczką zupełną: $dQ = \sum Q'_z\cdot dz$ (suma iloczynów pochodnych cząstkowych i zmian zmiennych).

> [!question]- Ile wynosi elastyczność w funkcji $Q = kP^{\alpha}$?
> Jest stała i równa wykładnikowi $\alpha$ w każdym punkcie krzywej.

> [!question]- Jaki jest wzór na cenę maksymalizującą zysk przy znanej elastyczności?
> $P = MC\cdot\dfrac{E_p}{E_p + 1}$. Np. $E_p = -1{,}5$ → narzut 3 (cena trzykrotnością $MC$).

> [!question]- Czy firma, która maksymalizuje zysk, może działać w nieelastycznej części popytu?
> Nie – przy $|E_p| < 1$ podwyżka ceny zwiększa przychód i zmniejsza koszty, więc zawsze opłaca się podnieść cenę.

### Produkcja i koszty
> [!question]- Ile pracowników zatrudnia firma maksymalizująca zysk?
> Tylu, aby krańcowy przychód z pracy zrównał się z płacą: $MRP_L = P\cdot MP_L = w$.

> [!question]- Czym różnią się koszty jawne i niejawne?
> Jawne – faktyczne wydatki (opłaty za zasoby kupione na rynku). Niejawne – utracone korzyści z własnych zasobów (czynsz, odsetki, pensja).

> [!question]- Co oznacza zysk ekonomiczny równy zero?
> Zysk normalny: przedsiębiorca zarabia dokładnie tyle, ile w najlepszej alternatywie – nie ma bodźca ani do wejścia, ani do wyjścia.

### Struktury rynkowe
> [!question]- Jak policzyć HHI i jaka jest jego skala?
> Suma kwadratów udziałów wszystkich firm w procentach; od ≈ 0 (rozproszony rynek) do 10 000 (monopol). Przy n równych firmach $HHI = 10\,000/n$.

> [!question]- Przy jakiej cenie ustaje wchodzenie firm do gałęzi doskonale konkurencyjnej?
> Przy cenie równej minimum długookresowego kosztu przeciętnego ($P = AC_{min}$, zysk ekonomiczny = 0).

> [!question]- Czym różni się model Stackelberga od modelu Cournota?
> W Cournocie firmy decydują jednocześnie; w Stackelbergu przywódca decyduje pierwszy, uwzględniając funkcję reakcji naśladowcy – produkuje więcej i zarabia więcej niż w Cournocie.

> [!question]- Jak ustala cenę firma dominująca?
> Z warunku $MR = MC$ na swoim popycie (rezydualnym); pozostałe firmy przyjmują tę cenę i pokrywają resztę popytu rynkowego.

## Rachunkowość zarządcza

### Istota i organizacja
> [!question]- Jak CIMA i AICPA definiują rachunkowość zarządczą?
> Jako pozyskiwanie, analizę, komunikowanie i wykorzystanie istotnych dla decyzji informacji finansowych i niefinansowych w celu tworzenia i ochrony wartości organizacji.

> [!question]- Podaj trzy różnice między rachunkowością zarządczą a finansową.
> Adresat (menedżerowie vs inwestorzy, fiskus); regulacje (brak obowiązku vs ustawa, MSSF); orientacja w czasie (przyszłość vs przeszłość). Także: miary niepieniężne, częstotliwość, kryterium użyteczności.

> [!question]- Wymień cztery etapy rozwoju rachunkowości zarządczej wg IFAC.
> 1) ustalanie kosztów i kontrola finansowa, 2) informacja do planowania i kontroli, 3) ograniczanie marnotrawstwa zasobów, 4) tworzenie wartości.

> [!question]- Jakie trzy role informacji księgowej wyróżnił Simon?
> Rejestrowanie (score-keeping), kierowanie uwagi (attention-directing – wskazywanie odchyleń), rozwiązywanie problemów (problem-solving – wybór wariantu).

### Rachunek kosztów
> [!question]- Co oznacza zasada „różne koszty do różnych celów”?
> Nie istnieje jeden „prawdziwy” koszt produktu – koszt zależy od obiektu, celu i horyzontu decyzji (J.M. Clark, 1923).

> [!question]- Wymień poziomy hierarchii kosztów.
> Jednostki, partii, produktu, klienta/kanału (oraz poziom zakładu/organizacji). Klucz wolumenowy poprawnie rozlicza tylko poziom jednostki.

> [!question]- Co to są koszty sztywne (sticky costs)?
> Koszty, które rosną szybciej przy wzroście aktywności, niż spadają przy jej spadku.

> [!question]- Dlaczego regresja jest lepsza od metody wielkości skrajnych?
> Wykorzystuje wszystkie obserwacje, a nie dwie (często nietypowe), i daje miary jakości: $R^2$, błąd standardowy, statystykę t.

> [!question]- Ile wynosi różnica wyników RKP i RKZ?
> Zmiana zapasu (szt.) × stałe koszty produkcji na sztukę. Produkcja na zapas podnosi wynik RKP.

> [!question]- Co pokazuje wielostopniowy rachunek marż?
> Ile każdy produkt, zakład i segment wnosi do pokrycia kosztów stałych kolejnych poziomów; koszty stałe przypisuje się na najniższym poziomie, na którym da się ich uniknąć.

> [!question]- Czym TDABC różni się od ABC?
> Zamiast ankiet o podziale czasu używa dwóch parametrów: stawki kosztu zdolności i równań czasu; koszt niewykorzystanych mocy jest widoczny wprost.

> [!question]- Co pokazuje krzywa wieloryba?
> Skumulowaną rentowność klientów uszeregowanych od najbardziej rentownych: część najlepszych daje ponad 100% zysku, a reszta go „oddaje”.

## Podatki i strategie podatkowe

### Podatek i system podatkowy
> [!question]- Wymień cechy podatku.
> Świadczenie pieniężne, przymusowe, jednostronnie ustalane, nieodpłatne (nieekwiwalentne), bezzwrotne, ogólne, publicznoprawne.

> [!question]- Jakie są funkcje podatków?
> Fiskalna, redystrybucyjna, alokacyjna, stabilizująca, informacyjna.

> [!question]- Wymień elementy konstrukcji podatku.
> Podmiot, przedmiot, podstawa opodatkowania, stawka, ulgi i zwolnienia (preferencje), terminy i sposób zapłaty.

> [!question]- Czym różni się podatek bezpośredni od pośredniego?
> Bezpośredni ponosi sam podatnik (PIT, CIT); pośredni płaci sprzedawca, ale ciężar przerzuca na konsumenta w cenie (VAT, akcyza).

> [!question]- Od czego zależy, kto faktycznie ponosi ciężar podatku?
> Od elastyczności popytu i podaży: większy ciężar ponosi strona mniej elastyczna.

### Zachowania podatników
> [!question]- Czym różni się unikanie od uchylania się od opodatkowania?
> Unikanie – legalne lub na granicy prawa wykorzystanie przepisów, by zmniejszyć podatek; uchylanie się – nielegalne (oszustwo podatkowe).

> [!question]- Na czym polega arbitraż podatkowy?
> Na wykorzystywaniu różnic w opodatkowaniu (podatników, strumieni dochodu, krajów) w celu osiągnięcia korzyści podatkowych.

> [!question]- Czym jest planowanie podatkowe w wąskim znaczeniu?
> Prowadzeniem interesów tak, by wykorzystać dozwolone prawnie możliwości minimalizacji obciążenia podatkowego.

### Podatek dochodowy przedsiębiorstw
> [!question]- Jakie są źródła przychodów w CIT?
> Zyski kapitałowe i inne źródła (operacyjne). Straty rozlicza się tylko w obrębie źródła.

> [!question]- Kto jest małym podatnikiem i jakie ma korzyści?
> Podatnik, którego przychód ze sprzedaży brutto w poprzednim roku nie przekroczył 2 mln euro; ma kwartalne zaliczki, jednorazową amortyzację i (przy spełnieniu warunków) 9% CIT.

> [!question]- Czym różni się odliczenie od dochodu od odliczenia od podatku?
> Od dochodu: oszczędność = odliczenie × stawka. Od podatku: oszczędność = odliczenie (złotówka za złotówkę).

> [!question]- Od czego zależy wartość tarczy podatkowej?
> Od wartości odliczenia, wysokości dochodu, stawki podatku i ewentualnych limitów.

> [!question]- Dlaczego CIT faworyzuje dług względem kapitału własnego?
> Odsetki są kosztem uzyskania przychodów, a dywidendy wypłaca się z zysku po opodatkowaniu (debt–equity bias).

> [!question]- Jak państwa ograniczają asymetrię finansowania?
> Limitami kosztów finansowania dłużnego (30% EBITDA / 3 mln zł), przepisami o niedostatecznej kapitalizacji, hipotetycznymi odsetkami od kapitału własnego (NID), estońskim CIT, koncepcją CBIT.

> [!question]- Jak można rozliczyć stratę w CIT?
> Przez 5 kolejnych lat: albo do 50% straty rocznie, albo jednorazowo do 5 mln zł, a resztę do 50% rocznie.
