---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Pytania egzaminacyjne"]
---
Pytania z sekcji „Na egzaminie” wszystkich notatek, pogrupowane według obszarów (osadzone – zmiana w notatce od razu jest widoczna tutaj). Zadania obliczeniowe są w MOC-ach poszczególnych obszarów.

## Rachunkowość zarządcza – przykładowe pytania (własne)
> [!question]- Teoretyczne: Kontroler, który w raporcie miesięcznym wskazuje odchylenia od budżetu i obszary wymagające reakcji, pełni przede wszystkim rolę: a) ewidencyjną, b) kierowania uwagi, c) rozwiązywania problemów, d) sprawozdawczą.
> **b)** – zob. [[Rola kontrolera]].

> [!question]- Problemowe: Oceniając jednorazowe zamówienie po obniżonej cenie przy wolnych mocach, należy porównać cenę z: a) kosztem wytworzenia według UoR, b) pełnym kosztem sprzedanego produktu, c) przyszłymi kosztami różnicowymi zamówienia, d) średnim kosztem z ubiegłego roku.
> **c)** – zob. [[Koszt relewantny]].

> [!question]- Obliczeniowe: Rower kosztuje 9600 zł, koszty zmienne wynoszą 5800 zł, a koszt wytworzenia 7400 zł. Marża wkładu na sztuce to: a) 2200, b) 3800, c) 1600, d) 5800.
> **b)** – zob. [[Velomia – trzy marże roweru Urban 5]].

## Podstawy gospodarowania i optymalizacja
### Mikroekonomia
![[Mikroekonomia#Na egzaminie]]

### Rzadkość zasobów
![[Rzadkość zasobów#Na egzaminie]]

### Czynnik produkcji
![[Czynnik produkcji#Na egzaminie]]

### Koszt alternatywny
![[Koszt alternatywny#Na egzaminie]]

### Granica możliwości produkcyjnych
![[Granica możliwości produkcyjnych#Na egzaminie]]

### Analiza marginalna
![[Analiza marginalna#Na egzaminie]]

### Zysk marginalny
![[Zysk marginalny#Na egzaminie]]

### Optymalizacja funkcji dwóch zmiennych
![[Optymalizacja funkcji dwóch zmiennych#Na egzaminie]]

### Metoda mnożników Lagrange'a
![[Metoda mnożników Lagrange'a#Na egzaminie]]

### Analiza wrażliwości
![[Analiza wrażliwości#Na egzaminie]]

## Rynek, popyt i elastyczność
### Rynek
![[Rynek#Na egzaminie]]

### Popyt
![[Popyt#Na egzaminie]]

### Podaż
![[Podaż#Na egzaminie]]

### Równowaga rynkowa
![[Równowaga rynkowa#Na egzaminie]]

### Nierównowaga rynkowa
![[Nierównowaga rynkowa#Na egzaminie]]

### Pozacenowa determinanta popytu
![[Pozacenowa determinanta popytu#Na egzaminie]]

### Pozacenowa determinanta podaży
![[Pozacenowa determinanta podaży#Na egzaminie]]

### Interwencja państwa na rynku
![[Interwencja państwa na rynku#Na egzaminie]]

### Substytucyjność i komplementarność dóbr
![[Substytucyjność i komplementarność dóbr#Na egzaminie]]

### Elastyczność popytu
![[Elastyczność popytu#Na egzaminie]]

### Elastyczność cenowa popytu
![[Elastyczność cenowa popytu#Na egzaminie]]

### Elastyczność punktowa
![[Elastyczność punktowa#Na egzaminie]]

### Elastyczność łukowa
![[Elastyczność łukowa#Na egzaminie]]

### Elastyczność mieszana popytu
![[Elastyczność mieszana popytu#Na egzaminie]]

### Elastyczność dochodowa popytu
![[Elastyczność dochodowa popytu#Na egzaminie]]

### Przychód
![[Przychód#Na egzaminie]]

### Elastyczność a przychód
![[Elastyczność a przychód#Na egzaminie]]

### Funkcja popytu wielu zmiennych
![[Funkcja popytu wielu zmiennych#Na egzaminie]]

### Funkcja popytu o stałej elastyczności
![[Funkcja popytu o stałej elastyczności#Na egzaminie]]

### Maksymalizacja przychodu
![[Maksymalizacja przychodu#Na egzaminie]]

### Narzut ceny na koszt krańcowy
![[Narzut ceny na koszt krańcowy#Na egzaminie]]

## Wybór konsumenta
### Użyteczność
![[Użyteczność#Na egzaminie]]

### Preferencje konsumenta
![[Preferencje konsumenta#Na egzaminie]]

### Krzywa obojętności
![[Krzywa obojętności#Na egzaminie]]

### Krańcowa stopa substytucji
![[Krańcowa stopa substytucji#Na egzaminie]]

### Linia budżetowa
![[Linia budżetowa#Na egzaminie]]

### Optimum konsumenta
![[Optimum konsumenta#Na egzaminie]]

### Krzywa dochód–konsumpcja
![[Krzywa dochód–konsumpcja#Na egzaminie]]

### Krzywa Engla
![[Krzywa Engla#Na egzaminie]]

### Krzywa cena–konsumpcja
![[Krzywa cena–konsumpcja#Na egzaminie]]

### Efekt substytucji i efekt dochodowy
![[Efekt substytucji i efekt dochodowy#Na egzaminie]]

### Dobro Giffena
![[Dobro Giffena#Na egzaminie]]

## Produkcja i koszty
### Funkcja produkcji
![[Funkcja produkcji#Na egzaminie]]

### Produkt przeciętny i marginalny
![[Produkt przeciętny i marginalny#Na egzaminie]]

### Prawo malejących przychodów
![[Prawo malejących przychodów#Na egzaminie]]

### Etapy produkcji
![[Etapy produkcji#Na egzaminie]]

### Efekty skali
![[Efekty skali#Na egzaminie]]

### Izokwanta
![[Izokwanta#Na egzaminie]]

### Krańcowa stopa technicznej substytucji
![[Krańcowa stopa technicznej substytucji#Na egzaminie]]

### Izokoszta
![[Izokoszta#Na egzaminie]]

### Optimum producenta
![[Optimum producenta#Na egzaminie]]

### Koszt księgowy a koszt ekonomiczny
![[Koszt księgowy a koszt ekonomiczny#Na egzaminie]]

### Zysk ekonomiczny
![[Zysk ekonomiczny#Na egzaminie]]

### Koszt stały i zmienny
![[Koszt stały i zmienny#Na egzaminie]]

### Koszt przeciętny
![[Koszt przeciętny#Na egzaminie]]

### Koszt marginalny
![[Koszt marginalny#Na egzaminie]]

### Koszty a produktywność
![[Koszty a produktywność#Na egzaminie]]

### Krańcowy przychód z pracy
![[Krańcowy przychód z pracy#Na egzaminie]]

## Struktury rynkowe i decyzje firmy
### Struktura rynkowa
![[Struktura rynkowa#Na egzaminie]]

### Koncentracja rynku
![[Koncentracja rynku#Na egzaminie]]

### Konkurencja doskonała
![[Konkurencja doskonała#Na egzaminie]]

### Maksymalizacja zysku
![[Maksymalizacja zysku#Na egzaminie]]

### Próg rentowności
![[Próg rentowności#Na egzaminie]]

### Punkt zamknięcia
![[Punkt zamknięcia#Na egzaminie]]

### Krzywa podaży przedsiębiorstwa
![[Krzywa podaży przedsiębiorstwa#Na egzaminie]]

### Monopol pełny
![[Monopol pełny#Na egzaminie]]

### Równowaga monopolu
![[Równowaga monopolu#Na egzaminie]]

### Dyskryminacja cenowa
![[Dyskryminacja cenowa#Na egzaminie]]

### Nadwyżka konsumenta i producenta
![[Nadwyżka konsumenta i producenta#Na egzaminie]]

### Strata społeczna monopolu
![[Strata społeczna monopolu#Na egzaminie]]

### Konkurencja monopolistyczna
![[Konkurencja monopolistyczna#Na egzaminie]]

### Oligopol
![[Oligopol#Na egzaminie]]

### Model firmy dominującej
![[Model firmy dominującej#Na egzaminie]]

### Model Cournota
![[Model Cournota#Na egzaminie]]

### Model Stackelberga
![[Model Stackelberga#Na egzaminie]]

## Rachunkowość zarządcza
### Rachunkowość zarządcza
![[Rachunkowość zarządcza#Na egzaminie]]

### Rachunkowość zarządcza a finansowa
![[Rachunkowość zarządcza a finansowa#Na egzaminie]]

### Ewolucja rachunkowości zarządczej
![[Ewolucja rachunkowości zarządczej#Na egzaminie]]

### Funkcja rachunkowości zarządczej
![[Funkcja rachunkowości zarządczej#Na egzaminie]]

### Rola kontrolera
![[Rola kontrolera#Na egzaminie]]

### Etyka kontrolera
![[Etyka kontrolera#Na egzaminie]]

### Cyfryzacja i ESG w rachunkowości zarządczej
![[Cyfryzacja i ESG w rachunkowości zarządczej#Na egzaminie]]

## Rachunek kosztów
### Klasyfikacja kosztów
![[Klasyfikacja kosztów#Na egzaminie]]

### Koszt relewantny
![[Koszt relewantny#Na egzaminie]]

### Hierarchia kosztów
![[Hierarchia kosztów#Na egzaminie]]

### Zachowanie kosztów
![[Zachowanie kosztów#Na egzaminie]]

### Szacowanie funkcji kosztów
![[Szacowanie funkcji kosztów#Na egzaminie]]

### Krzywa uczenia się
![[Krzywa uczenia się#Na egzaminie]]

### Rachunek kosztów zmiennych i pełnych
![[Rachunek kosztów zmiennych i pełnych#Na egzaminie]]

### Marża wkładu
![[Marża wkładu#Na egzaminie]]

### Rachunek kosztów działań
![[Rachunek kosztów działań#Na egzaminie]]

### Rachunek kosztów działań sterowany czasem
![[Rachunek kosztów działań sterowany czasem#Na egzaminie]]

### Rentowność klientów
![[Rentowność klientów#Na egzaminie]]

## System podatkowy i zachowania podatników
### Podatek
![[Podatek#Na egzaminie]]

### Źródło prawa podatkowego
![[Źródło prawa podatkowego#Na egzaminie]]

### Danina publiczna
![[Danina publiczna#Na egzaminie]]

### Funkcja podatku
![[Funkcja podatku#Na egzaminie]]

### System podatkowy w Polsce
![[System podatkowy w Polsce#Na egzaminie]]

### Klasyfikacja podatków
![[Klasyfikacja podatków#Na egzaminie]]

### Element konstrukcji podatku
![[Element konstrukcji podatku#Na egzaminie]]

### Preferencja podatkowa
![[Preferencja podatkowa#Na egzaminie]]

### Incydencja podatkowa
![[Incydencja podatkowa#Na egzaminie]]

### Reakcja podatnika na opodatkowanie
![[Reakcja podatnika na opodatkowanie#Na egzaminie]]

### Unikanie i uchylanie się od opodatkowania
![[Unikanie i uchylanie się od opodatkowania#Na egzaminie]]

### Korzyść podatkowa
![[Korzyść podatkowa#Na egzaminie]]

### Moralność podatkowa
![[Moralność podatkowa#Na egzaminie]]

### Arbitraż podatkowy
![[Arbitraż podatkowy#Na egzaminie]]

### Planowanie podatkowe
![[Planowanie podatkowe#Na egzaminie]]

## Podatek dochodowy przedsiębiorstw
### Dochód podatkowy
![[Dochód podatkowy#Na egzaminie]]

### Źródło przychodów w CIT
![[Źródło przychodów w CIT#Na egzaminie]]

### Mały podatnik
![[Mały podatnik#Na egzaminie]]

### Preferencyjna stawka CIT
![[Preferencyjna stawka CIT#Na egzaminie]]

### Odliczenie podatkowe
![[Odliczenie podatkowe#Na egzaminie]]

### Tarcza podatkowa
![[Tarcza podatkowa#Na egzaminie]]

### Strata podatkowa
![[Strata podatkowa#Na egzaminie]]

### Rozliczanie straty podatkowej w czasie
![[Rozliczanie straty podatkowej w czasie#Na egzaminie]]

### Asymetria podatkowa finansowania
![[Asymetria podatkowa finansowania#Na egzaminie]]

### Niedostateczna kapitalizacja
![[Niedostateczna kapitalizacja#Na egzaminie]]

### Limit kosztów finansowania dłużnego
![[Limit kosztów finansowania dłużnego#Na egzaminie]]

### Hipotetyczne odsetki od kapitału własnego
![[Hipotetyczne odsetki od kapitału własnego#Na egzaminie]]

