---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Słownik", "Glosariusz"]
---
Krótkie definicje wszystkich pojęć. Pełne wyjaśnienie – po kliknięciu.

## A
- **[[Analiza marginalna]]** – Analiza marginalna to porównywanie korzyści i kosztów **ostatniej (dodatkowej) jednostki** działania; optimum osiąga się, gdy korzyść marginalna równa się kosztowi marginalnemu. *Też: Optimum MB = MC, Zasada marginalna, Równowaga podmiotu gospodarczego.*
- **[[Analiza wrażliwości]]** – Analiza wrażliwości bada, jak zmienia się optymalna decyzja i wynik, gdy zmieniają się parametry: koszty stałe, koszty zmienne albo popyt. *Też: Wrażliwość decyzji.*
- **[[Arbitraż podatkowy]]** – Arbitraż podatkowy to wykorzystywanie różnic w opodatkowaniu – między podatnikami lub między strumieniami dochodu – w celu osiągnięcia korzyści podatkowej. *Też: Arbitraż.*
- **[[Asymetria podatkowa finansowania]]** – Asymetria podatkowa finansowania (debt-equity bias) polega na tym, że odsetki od długu są kosztem uzyskania przychodu, a dywidendy dla właścicieli wypłaca się z zysku po opodatkowaniu – kapitał własny jest podatkowo dyskryminowany. *Też: Debt-equity bias, Dyskryminacja kapitału własnego, CBIT.*

## C
- **[[Cyfryzacja i ESG w rachunkowości zarządczej]]** – Współczesne kierunki rozwoju rachunkowości zarządczej to cyfryzacja (ERP, BI, planowanie oparte na czynnikach, AI) i zrównoważony rozwój (koszty środowiskowe, dane ESG, cena CO₂). *Też: Kierunki rozwoju RZ, ESG, Rachunek kosztów środowiskowych.*
- **[[Czynnik produkcji]]** – Czynnik produkcji to zasób służący jako nakład do wytwarzania dóbr: praca (L), ziemia/zasoby naturalne oraz kapitał (K). *Też: Czynniki produkcji, Zasoby, Praca, Kapitał, L, K.*

## D
- **[[Danina publiczna]]** – Danina publiczna to obowiązkowe świadczenie na rzecz władzy publicznej; obejmuje podatki, opłaty, cła i parapodatki – o charakterze daniny decyduje jej istota, a nie nazwa. *Też: Opłata, Cło, Parapodatek.*
- **[[Dobro Giffena]]** – Dobro Giffena to silnie podrzędne dobro, na które popyt rośnie wraz ze wzrostem jego ceny, bo ujemny efekt dochodowy przewyższa efekt substytucji. *Też: Paradoks Giffena.*
- **[[Dochód podatkowy]]** – Dochodem ze źródła przychodów jest nadwyżka sumy przychodów z tego źródła nad kosztami ich uzyskania (KUP) w roku podatkowym; gdy koszty przekraczają przychody, różnica jest stratą. *Też: Koszt uzyskania przychodu, KUP, NKUP, Podstawa opodatkowania CIT.*
- **[[Dyskryminacja cenowa]]** – Dyskryminacja cenowa to ustalanie różnych cen na ten sam produkt dla różnych nabywców lub rynków. *Też: Różnicowanie cen, Dyskryminacja cenowa III stopnia.*

## E
- **[[Efekt substytucji i efekt dochodowy]]** – Reakcję popytu na zmianę ceny rozkładamy na efekt substytucji (zastępowanie dobra relatywnie droższego tańszym) i efekt dochodowy (zmiana siły nabywczej dochodu). *Też: Efekt substytucyjny, Efekt dochodowy, Dekompozycja Hicksa.*
- **[[Efekty skali]]** – Efekty skali opisują, jak zmienia się produkcja, gdy wszystkie nakłady rosną proporcjonalnie (a-krotnie) w długim okresie. *Też: Korzyści skali, Rosnące efekty skali, Malejące efekty skali.*
- **[[Elastyczność a przychód]]** – Przychód marginalny zależy od ceny i elastyczności: MR = P(1 + 1/Ep), dlatego to elastyczność decyduje, czy obniżka ceny zwiększy przychód. *Też: MR a elastyczność, TR max.*
- **[[Elastyczność cenowa popytu]]** – Elastyczność cenowa popytu mierzy, o ile procent zmieni się wielkość popytu na dobro, gdy jego cena zmieni się o 1% (ceteris paribus). *Też: Ep, Popyt elastyczny, Popyt nieelastyczny.*
- **[[Elastyczność dochodowa popytu]]** – Elastyczność dochodowa mierzy, o ile procent zmieni się popyt na dobro, gdy dochód konsumenta wzrośnie o 1%; jej wartość wyznacza rodzaj dobra. *Też: Dobro normalne, Dobro podrzędne, Dobro luksusowe, Dobro podstawowe.*
- **[[Elastyczność łukowa]]** – Elastyczność łukowa mierzy reakcję popytu na odcinku (łuku) krzywej między dwoma punktami, licząc zmiany względem średnich wartości. *Też: Elastyczność odcinkowa, EŁ.*
- **[[Elastyczność mieszana popytu]]** – Elastyczność mieszana (krzyżowa) mierzy, o ile procent zmieni się popyt na dobro X, gdy cena dobra Y zmieni się o 1%. *Też: Em, Elastyczność krzyżowa.*
- **[[Elastyczność popytu]]** – Elastyczność popytu to miara względnej reakcji popytu: stosunek procentowej zmiany wielkości popytu do procentowej zmiany czynnika, który ją wywołał. *Też: Elastyczność, Współczynnik elastyczności.*
- **[[Elastyczność punktowa]]** – Elastyczność punktowa mierzy reakcję popytu w konkretnym punkcie krzywej popytu; dla liniowej krzywej zmienia się od −∞ do 0. *Też: Elastyczność w punkcie.*
- **[[Element konstrukcji podatku]]** – Elementy konstrukcji podatku to składniki, które musi określić ustawa: podmiot, przedmiot, podstawa opodatkowania, stawki (skala), preferencje oraz warunki zapłaty. *Też: Podmiot opodatkowania, Przedmiot opodatkowania, Podstawa opodatkowania, Stawka podatkowa, Skala podatkowa, Płatnik, Inkasent.*
- **[[Etapy produkcji]]** – Etapy produkcji to trzy przedziały nakładu czynnika zmiennego wyznaczone przez przebieg AP i MP; racjonalny producent działa tylko w II etapie. *Też: Etap II produkcji, Racjonalny obszar produkcji.*
- **[[Etyka kontrolera]]** – Etyka kontrolera to zasady i standardy zawodowe (kodeks IMA, CIMA, ACCA), które chronią wiarygodność informacji zarządczej – zwłaszcza gdy liczby „powinny” wyglądać inaczej. *Też: Kodeks IMA, Etyka zawodowa.*
- **[[Ewolucja rachunkowości zarządczej]]** – Rachunkowość zarządcza rozwijała się w czterech etapach (IFAC): od ustalania kosztów, przez informację do planowania i ograniczanie marnotrawstwa, do tworzenia wartości; jej kryzys opisała krytyka „Relevance Lost”. *Też: Relevance Lost, Etapy rozwoju RZ.*

## F
- **[[Funkcja podatku]]** – Funkcje podatków to cele, którym służy opodatkowanie: fiskalna, redystrybucyjna, alokacyjna, stabilizująca i informacyjna. *Też: Funkcje podatków.*
- **[[Funkcja popytu o stałej elastyczności]]** – Funkcja popytu o stałej elastyczności ma postać potęgową Q = k·P^α; w każdym jej punkcie elastyczność cenowa równa się wykładnikowi α. *Też: Potęgowa funkcja popytu, Stała elastyczność.*
- **[[Funkcja popytu wielu zmiennych]]** – Funkcja popytu wielu zmiennych opisuje ilość nabywaną jako funkcję wszystkich determinant: Q = f(P, I, Py, N, A, …); łączną zmianę popytu liczymy z różniczki zupełnej. *Też: Różniczka zupełna, Determinanty popytu – ujęcie analityczne.*
- **[[Funkcja produkcji]]** – Funkcja produkcji opisuje zależność między nakładami czynników produkcji a maksymalną wielkością produkcji przy danej technologii: Q = f(L, K). *Też: Q = f(L,K), Technologia produkcji, Krótki okres, Długi okres.*
- **[[Funkcja rachunkowości zarządczej]]** – Rachunkowość zarządcza pełni cztery funkcje – planowanie, wspomaganie decyzji, kontrolę oraz motywowanie i ocenę – a dobra informacja zarządcza spełnia cztery zasady CGMA. *Też: Zasady CGMA, Funkcje RZ.*

## G
- **[[Granica możliwości produkcyjnych]]** – Granica możliwości produkcyjnych (PPF) to zbiór wszystkich efektywnych kombinacji dwóch dóbr, które gospodarka może wytworzyć przy danych zasobach i technologii. *Też: PPF, Krzywa transformacji.*

## H
- **[[Hierarchia kosztów]]** – Hierarchia kosztów (Cooper, 1990) dzieli koszty według poziomu działalności, na którym powstają: jednostki, partii, produktu, klienta/kanału i organizacji. *Też: Poziomy kosztów.*
- **[[Hipotetyczne odsetki od kapitału własnego]]** – Hipotetyczne odsetki (NID, notional interest deduction) to odliczenie od podstawy opodatkowania „odsetek” od kapitału własnego – na wzór odsetek od długu – w celu zmniejszenia podatkowej dyskryminacji kapitału własnego. *Też: NID, Notional interest deduction, Allowance for corporate equity.*

## I
- **[[Incydencja podatkowa]]** – Incydencja podatkowa to faktyczny rozkład ciężaru podatku – kto naprawdę go ponosi; przerzucalność to możliwość przesunięcia ciężaru z podatnika formalnego na inne podmioty. *Też: Przerzucalność podatku, Podatnik w sensie materialnym.*
- **[[Interwencja państwa na rynku]]** – Interwencja państwa na rynku to działania zmieniające wynik mechanizmu rynkowego: podatki, dotacje (subwencje) oraz ceny administracyjne. *Też: Dotacja, Subwencja, Akcyza.*
- **[[Izokoszta]]** – Izokoszta (linia jednakowego kosztu) to zbiór kombinacji pracy i kapitału, które można kupić za daną kwotę: TC = wL + rK. *Też: Linia jednakowego kosztu.*
- **[[Izokwanta]]** – Izokwanta to zbiór wszystkich efektywnych kombinacji pracy i kapitału, które dają taką samą wielkość produkcji. *Też: Krzywa jednakowego produktu.*

## K
- **[[Klasyfikacja kosztów]]** – Klasyfikacja kosztów to podział kosztów według kryterium dobranego do celu – „różne koszty do różnych celów” (J.M. Clark, 1923): nie istnieje jeden „prawdziwy” koszt produktu. *Też: Koszty bezpośrednie i pośrednie, Układ rodzajowy, Obiekt kosztów.*
- **[[Klasyfikacja podatków]]** – Podatki klasyfikuje się według tego, co jest opodatkowane (przychodowe, dochodowe, majątkowe, konsumpcyjne), kto faktycznie ponosi ciężar (bezpośrednie, pośrednie) i komu przypadają wpływy (państwowe, samorządowe, wspólne). *Też: Podatek bezpośredni, Podatek pośredni, Podatek dochodowy, Podatek majątkowy, Podatek konsumpcyjny.*
- **[[Koncentracja rynku]]** – Koncentracja rynku to stopień, w jakim sprzedaż skupia się w rękach niewielu firm; mierzą ją współczynnik koncentracji CR4 i wskaźnik Herfindahla-Hirschmana HHI. *Też: CR4, CR1, HHI, Wskaźnik Herfindahla-Hirschmana, Współczynnik koncentracji.*
- **[[Konkurencja doskonała]]** – Konkurencja doskonała to struktura rynku z bardzo wieloma firmami sprzedającymi jednorodny produkt bez barier wejścia; każda firma jest cenobiorcą, więc P = AR = MR. *Też: KD, Rynek doskonale konkurencyjny, Cenobiorca.*
- **[[Konkurencja monopolistyczna]]** – Konkurencja monopolistyczna to rynek z dużą liczbą niewielkich firm sprzedających zróżnicowane produkty (bliskie substytuty) przy niewielkich barierach wejścia. *Też: Rynek konkurencji monopolistycznej.*
- **[[Korzyść podatkowa]]** – Korzyść podatkowa to efekt, na który liczy podatnik unikający lub uchylający się od opodatkowania: niepowstanie lub obniżenie zobowiązania, nadpłata, zwrot albo strata do odliczenia. *Też: Oszczędność podatkowa.*
- **[[Koszt alternatywny]]** – Koszt alternatywny (koszt utraconych korzyści) to wartość najlepszej możliwości, z której rezygnujemy, dokonując wyboru. *Też: Koszt utraconych korzyści, Opportunity cost.*
- **[[Koszt księgowy a koszt ekonomiczny]]** – Koszt księgowy obejmuje tylko faktycznie poniesione wydatki (jawne), a koszt ekonomiczny – wartość wszystkich zasobów użytych w produkcji: koszty jawne plus niejawne (alternatywne). *Też: Koszt księgowy, Koszt ekonomiczny, Koszty explicite, Koszty implicite, Koszt rachunkowy.*
- **[[Koszt marginalny]]** – Koszt marginalny (MC) to przyrost kosztu całkowitego wywołany wytworzeniem dodatkowej jednostki produktu: MC = ΔTC/ΔQ = TC′. *Też: MC, Koszt krańcowy.*
- **[[Koszt przeciętny]]** – Koszt przeciętny to koszt przypadający na jednostkę produkcji: stały AFC = FC/Q, zmienny AVC = VC/Q i całkowity ATC = TC/Q = AFC + AVC. *Też: ATC, AVC, AFC, Koszt jednostkowy.*
- **[[Koszt relewantny]]** – Koszt relewantny (istotny) to przyszły koszt różnicowy – taki, który zmienia się zależnie od wybranego wariantu decyzji; kosztów utopionych i niezmiennych między wariantami nie uwzględniamy. *Też: Koszt istotny, Koszt utopiony, Koszt uniknięty, Koszt różnicowy.*
- **[[Koszt stały i zmienny]]** – Koszt stały (FC) nie zależy od wielkości produkcji w krótkim okresie, koszt zmienny (VC) rośnie wraz z produkcją; razem tworzą koszt całkowity TC = FC + VC. *Też: FC, VC, TC, Koszt stały, Koszt zmienny, Koszt całkowity.*
- **[[Koszty a produktywność]]** – Koszty są lustrzanym odbiciem produktywności: przy stałej płacy w przeciętny koszt zmienny AVC = w/AP_L, a koszt marginalny MC = w/MP_L. *Też: Dualność produkcji i kosztów, AVC = w/AP.*
- **[[Krańcowa stopa substytucji]]** – Krańcowa stopa substytucji (MRS) to ilość dobra Y, z której konsument zrezygnuje w zamian za dodatkową jednostkę dobra X, pozostając na tej samej krzywej obojętności. *Też: MRS, Marginalna stopa substytucji.*
- **[[Krańcowa stopa technicznej substytucji]]** – Krańcowa stopa technicznej substytucji (MRTS) to ilość kapitału, którą można zastąpić jednostką pracy tak, by produkcja się nie zmieniła. *Też: MRTS, Marginalna stopa technicznej substytucji.*
- **[[Krańcowy przychód z pracy]]** – Krańcowy przychód z pracy (MRP_L) to przyrost przychodu dzięki zatrudnieniu dodatkowej jednostki pracy: MRP_L = MR·MP_L; firma zatrudnia, dopóki MRP_L ≥ koszt krańcowy pracy. *Też: MRP, MRPL, Optymalne zatrudnienie, Krańcowy koszt pracy.*
- **[[Krzywa cena–konsumpcja]]** – Krzywa cena–konsumpcja (PCC) to zbiór punktów równowagi konsumenta przy zmieniającej się cenie jednego dobra (dochód, cena drugiego dobra i preferencje stałe); z niej wyprowadzamy krzywą popytu. *Też: PCC, Popyt indywidualny.*
- **[[Krzywa dochód–konsumpcja]]** – Krzywa dochód–konsumpcja (ICC) to zbiór punktów równowagi konsumenta dla wszystkich poziomów dochodu przy stałych cenach i preferencjach. *Też: ICC, Ścieżka ekspansji dochodowej.*
- **[[Krzywa Engla]]** – Krzywa Engla pokazuje, jak optymalna ilość kupowanego dobra zmienia się wraz z dochodem konsumenta przy stałych cenach. *Też: Prawo Engla, Krzywe Engla.*
- **[[Krzywa obojętności]]** – Krzywa obojętności to zbiór wszystkich kombinacji dwóch dóbr dających konsumentowi taki sam poziom zadowolenia (tę samą użyteczność). *Też: Mapa obojętności, Izokwanta użyteczności.*
- **[[Krzywa podaży przedsiębiorstwa]]** – W konkurencji doskonałej krzywa podaży przedsiębiorstwa w krótkim okresie to odcinek krzywej kosztu marginalnego leżący powyżej minimum AVC. *Też: Podaż firmy, Podaż gałęzi.*
- **[[Krzywa uczenia się]]** – Krzywa uczenia się opisuje spadek średniego czasu (kosztu) pracy na sztukę wraz ze wzrostem skumulowanej produkcji; w modelu Wrighta przy każdym podwojeniu produkcji średni czas spada do r% poprzedniego poziomu. *Też: Efekt uczenia się, Model Wrighta.*

## L
- **[[Limit kosztów finansowania dłużnego]]** – Zgodnie z art. 15c UPDOP do KUP nie zalicza się nadwyżki kosztów finansowania dłużnego w części przekraczającej wyższą z kwot: 3 mln zł albo 30% podatkowej EBITDA. *Też: Earnings stripping, Art. 15c UPDOP, ATAD, Nadwyżka kosztów finansowania dłużnego.*
- **[[Linia budżetowa]]** – Linia budżetowa to zbiór koszyków dwóch dóbr, na które konsument wydaje cały dochód przy danych cenach. *Też: Ograniczenie budżetowe, Budżet konsumenta.*

## M
- **[[Maksymalizacja przychodu]]** – Maksymalizacja przychodu (utargu) to wybór ceny i ilości, przy których TR jest największy: MR = 0, czyli Ep = −1. *Też: Maksymalizacja utargu, TRmax.*
- **[[Maksymalizacja zysku]]** – Firma maksymalizuje zysk przy takiej wielkości produkcji, dla której przychód marginalny równa się kosztowi marginalnemu (MR = MC), a funkcja zysku ma maksimum (MR′ < MC′). *Też: MR = MC, Warunek maksymalizacji zysku.*
- **[[Mały podatnik]]** – Mały podatnik to podatnik, którego przychód ze sprzedaży brutto (z VAT) w poprzednim roku nie przekroczył równowartości 2 mln euro. *Też: Status małego podatnika.*
- **[[Marża wkładu]]** – Marża wkładu (marża pokrycia) to cena minus koszty zmienne – kwota, którą każda sprzedana jednostka wnosi do pokrycia kosztów stałych i zysku. *Też: Marża brutto, Marża pokrycia, Contribution margin, Wielostopniowy rachunek marż.*
- **[[Metoda mnożników Lagrange'a]]** – Metoda mnożników Lagrange'a pozwala znaleźć maksimum (minimum) funkcji celu, gdy zmienne muszą spełniać ograniczenie g(x₁, x₂, …) = 0. *Też: Lagrange, Optymalizacja z ograniczeniem, Mnożnik Lagrange'a.*
- **[[Mikroekonomia]]** – Mikroekonomia to dział ekonomii badający decyzje pojedynczych podmiotów – konsumentów i przedsiębiorstw – oraz funkcjonowanie poszczególnych rynków. *Też: Ekonomia, Makroekonomia.*
- **[[Model Cournota]]** – W modelu Cournota oligopoliści o podobnej sile jednocześnie wybierają wielkość produkcji, przyjmując produkcję rywali za daną; cena zależy od łącznej produkcji. *Też: Cournot, Funkcja reakcji.*
- **[[Model firmy dominującej]]** – W modelu firmy dominującej jedna duża firma ustala cenę jak monopolista (MR = MC na swojej krzywej popytu), a mniejsze firmy przyjmują tę cenę za daną i zaspokajają resztę popytu rynkowego. *Też: Przywództwo cenowe, Firma dominująca.*
- **[[Model Stackelberga]]** – W modelu Stackelberga przywódca wybiera produkcję pierwszy, uwzględniając funkcję reakcji naśladowcy, i dzięki temu narzuca mu warunki gry. *Też: Stackelberg, Przywódca i naśladowca.*
- **[[Monopol pełny]]** – Monopol pełny to rynek z jednym sprzedawcą produktu bez bliskich substytutów i z zablokowanym wejściem; jego krzywa popytu jest krzywą popytu rynkowego, więc P = AR > MR. *Też: Monopol, Monopol naturalny, Cenodawca.*
- **[[Moralność podatkowa]]** – Moralność podatkowa to wewnętrzna akceptacja (lub jej brak) obowiązku podatkowego i zwierzchności państwa; mentalność podatkowa to ogólne nastawienie do podatków. *Też: Mentalność podatkowa, Postawy wobec podatków, Szara strefa.*

## N
- **[[Nadwyżka konsumenta i producenta]]** – Nadwyżka konsumenta to różnica między ceną, jaką kupujący byli skłonni zapłacić, a ceną zapłaconą; nadwyżka producenta – różnica między ceną otrzymaną a minimalną ceną, za którą sprzedawcy by sprzedali. *Też: Nadwyżka konsumenta, Nadwyżka producenta, CS, PS, Efektywność wymiany.*
- **[[Narzut ceny na koszt krańcowy]]** – Cena maksymalizująca zysk to koszt krańcowy pomnożony przez współczynnik narzutu zależny od elastyczności: P = MC·Ep/(Ep + 1). *Też: Mark-up, Współczynnik narzutu, Cena optymalna.*
- **[[Niedostateczna kapitalizacja]]** – Niedostateczna (cienka) kapitalizacja to finansowanie spółki w nadmiernym stopniu długiem, zwłaszcza pożyczkami od podmiotów powiązanych, w celu wykorzystania tarczy odsetkowej. *Też: Cienka kapitalizacja, Thin capitalization.*
- **[[Nierównowaga rynkowa]]** – Nierównowaga rynkowa występuje, gdy cena różni się od ceny równowagi: przy cenie niższej powstaje niedobór (Qd > Qs), przy wyższej – nadmiar (Qs > Qd). *Też: Niedobór, Nadmiar, Nadwyżka podaży, Cena maksymalna, Cena minimalna.*

## O
- **[[Odliczenie podatkowe]]** – Odliczenie podatkowe może być stosowane na I etapie – od dochodu lub podstawy opodatkowania – albo na II etapie – bezpośrednio od kwoty podatku; etap decyduje o wartości bodźca. *Też: Odliczenie od dochodu, Odliczenie od podatku, Ulga B+R, Ulga prorodzinna.*
- **[[Oligopol]]** – Oligopol to rynek zdominowany przez niewielką liczbę dużych firm, których decyzje są współzależne – każda bierze pod uwagę reakcje rywali. *Też: Duopol, Rynek oligopolistyczny.*
- **[[Optimum konsumenta]]** – Optimum (równowaga) konsumenta to koszyk na najwyższej osiągalnej krzywej obojętności – punkt styczności krzywej obojętności z linią budżetową. *Też: Równowaga konsumenta, Koszyk optymalny.*
- **[[Optimum producenta]]** – Optimum producenta to kombinacja czynników, która przy danym koszcie daje maksymalną produkcję albo daną produkcję wytwarza najtaniej – punkt styczności izokwanty z izokosztą. *Też: Zasada najmniejszego kosztu, Równowaga producenta.*
- **[[Optymalizacja funkcji dwóch zmiennych]]** – Optymalizacja funkcji dwóch zmiennych to szukanie maksimum (minimum) funkcji celu f(x, y) przez przyrównanie obu pochodnych cząstkowych do zera i sprawdzenie warunków drugiego rzędu. *Też: Funkcja celu dwóch zmiennych, Hesjan, Pochodna cząstkowa.*

## P
- **[[Planowanie podatkowe]]** – Planowanie podatkowe to uwzględnianie konsekwencji podatkowych w planowaniu finansowym (szerzej) albo prowadzenie interesów tak, by legalnie zminimalizować obciążenie (węziej: tax planning, tax structuring). *Też: Strategia podatkowa, Tax planning, Optymalizacja podatkowa.*
- **[[Podatek]]** – Podatek to przymusowe, jednostronnie ustalane, bezzwrotne i nieodpłatne świadczenie pieniężne o charakterze ogólnym na rzecz władzy publicznej. *Też: Cechy podatku, Istota podatku.*
- **[[Podaż]]** – Podaż to zależność między ceną dobra a ilością, jaką producenci chcą i mogą zaoferować w danym okresie (ceteris paribus). *Też: Prawo podaży, Krzywa podaży, Funkcja podaży, S.*
- **[[Popyt]]** – Popyt to zależność między ceną dobra a ilością, jaką nabywcy chcą i mogą kupić w danym okresie (ceteris paribus). *Też: Prawo popytu, Krzywa popytu, Funkcja popytu, Wielkość popytu, Popyt rynkowy, D.*
- **[[Pozacenowa determinanta podaży]]** – Pozacenowa determinanta podaży to czynnik inny niż cena dobra, którego zmiana przesuwa całą krzywą podaży. *Też: Determinanty podaży, Przesunięcie krzywej podaży.*
- **[[Pozacenowa determinanta popytu]]** – Pozacenowa determinanta popytu to każdy czynnik inny niż cena danego dobra, którego zmiana przesuwa całą krzywą popytu. *Też: Determinanty popytu, Przesunięcie krzywej popytu, Czynniki pozacenowe popytu.*
- **[[Prawo malejących przychodów]]** – Prawo malejących przychodów mówi, że gdy zwiększamy nakład jednego czynnika przy stałych pozostałych, to od pewnego momentu przyrosty produkcji (MP) maleją. *Też: Prawo malejącego produktu marginalnego, Prawo malejących przychodów krańcowych.*
- **[[Preferencja podatkowa]]** – Preferencje podatkowe to ulgi, zwolnienia i wyłączenia, które w określonych sytuacjach zmniejszają obciążenie podatkowe lub wyłączają opodatkowanie. *Też: Ulga podatkowa, Zwolnienie podatkowe, Wyłączenie z opodatkowania, Tax expenditures.*
- **[[Preferencje konsumenta]]** – System preferencji to uporządkowanie wszystkich koszyków dóbr według zadowolenia, jakie dają konsumentowi, spełniające założenia kompletności, przechodniości i nienasycenia. *Też: System preferencji, Racjonalność konsumenta.*
- **[[Preferencyjna stawka CIT]]** – Stawka 9% CIT przysługuje małym podatnikom od dochodów innych niż zyski kapitałowe, jeśli przychody w roku podatkowym nie przekroczyły równowartości 2 mln euro (art. 19 UPDOP). *Też: CIT 9%, Obniżona stawka CIT.*
- **[[Produkt przeciętny i marginalny]]** – Produkt przeciętny pracy (AP) to produkcja na jednego pracownika, a produkt marginalny (MP) – przyrost produkcji z dodatkowej jednostki pracy. *Też: AP, MP, TP, Produkt całkowity, Produkt krańcowy.*
- **[[Przychód]]** – Przychód firmy to wpływy ze sprzedaży: całkowity TR = P·Q, przeciętny AR = TR/Q = P oraz marginalny MR = TR′ – przyrost TR z dodatkowej sprzedanej jednostki. *Też: TR, AR, MR, Przychód marginalny, Przychód całkowity.*
- **[[Próg rentowności]]** – Próg rentowności (punkt niwelacji, BEP) to poziom ceny lub sprzedaży, przy którym przychody równają się kosztom, a zysk ekonomiczny wynosi zero. *Też: Punkt niwelacji, Cena niwelacji, BEP.*
- **[[Punkt zamknięcia]]** – Punkt zamknięcia to cena równa minimum przeciętnego kosztu zmiennego (P = AVCmin), przy której strata firmy równa się kosztom stałym; poniżej niej firma powinna wstrzymać produkcję. *Też: Cena zamknięcia, Decyzja o zamknięciu.*

## R
- **[[Rachunek kosztów działań]]** – Rachunek kosztów działań (ABC) przypisuje koszty zasobów do działań, a koszty działań – do obiektów kosztów według zużycia nośników kosztów. *Też: ABC, Activity-based costing, Nośnik kosztów.*
- **[[Rachunek kosztów działań sterowany czasem]]** – TDABC (Kaplan, Anderson 2004) zastępuje ankiety o podziale czasu dwoma parametrami: stawką kosztu zdolności i równaniami czasu działań; koszt niewykorzystanych mocy widać wprost. *Też: TDABC, Równanie czasu, Praktyczna zdolność.*
- **[[Rachunek kosztów zmiennych i pełnych]]** – Rachunek kosztów pełnych (RKP) wlicza stałe koszty pośrednie produkcji do kosztu wytworzenia i zapasów, a rachunek kosztów zmiennych (RKZ) traktuje je w całości jako koszt okresu. *Też: RKZ, RKP, Rachunek kosztów zmiennych, Rachunek kosztów pełnych, Koszt niewykorzystanych mocy.*
- **[[Rachunkowość zarządcza]]** – Rachunkowość zarządcza to pozyskiwanie, analiza, komunikowanie i wykorzystanie istotnych dla decyzji informacji finansowych i niefinansowych w celu tworzenia i ochrony wartości organizacji (CIMA/AICPA, 2014). *Też: RZ, Management accounting.*
- **[[Rachunkowość zarządcza a finansowa]]** – Rachunkowość zarządcza dostarcza informacji dla menedżerów wewnątrz firmy, bez obowiązków regulacyjnych i z orientacją na przyszłość; rachunkowość finansowa – dla odbiorców zewnętrznych, zgodnie z przepisami i z orientacją na przeszłość. *Też: Rachunkowość finansowa.*
- **[[Reakcja podatnika na opodatkowanie]]** – Reakcje podatników na opodatkowanie to sposoby dostosowania się do podatku: od powstrzymania się od działalności, przez dostosowanie i przerzucenie, po unikanie i uchylanie się. *Też: Opór podatkowy, Przerzucenie podatku.*
- **[[Rentowność klientów]]** – Rentowność klientów to wynik na poszczególnych klientach po uwzględnieniu kosztów ich obsługi; uszeregowana tworzy krzywą wieloryba – niewielka grupa klientów generuje ponad 100% zysku. *Też: Krzywa wieloryba, Whale curve.*
- **[[Rola kontrolera]]** – Kontroler łączy trzy role informacji księgowej – rejestrowanie, kierowanie uwagi i rozwiązywanie problemów (Simon i in. 1954) – a współcześnie działa jako partner biznesowy kierownictwa. *Też: Kontroler, Kontroling, Partner biznesowy.*
- **[[Rozliczanie straty podatkowej w czasie]]** – Stratę ze źródła przychodów można odliczać od dochodu z tego źródła w kolejnych pięciu latach – maksymalnie 50% straty rocznie albo jednorazowo do 5 mln zł (art. 7 ust. 5 UPDOP, art. 9 ust. 3 UPDOF). *Też: Odliczenie straty, Carry forward, Carry back.*
- **[[Rynek]]** – Rynek to miejsce i proces koordynowania decyzji kupujących i sprzedających za pomocą cen – mechanizm, który decyduje o alokacji zasobów. *Też: Gospodarka rynkowa, Mechanizm rynkowy.*
- **[[Rzadkość zasobów]]** – Rzadkość to sytuacja, w której potrzeby ludzi są nieograniczone, a zasoby potrzebne do ich zaspokojenia – ograniczone, więc ilość dóbr pożądanych przewyższa zdolność ich wytworzenia. *Też: Problem rzadkości, Ograniczoność zasobów.*
- **[[Równowaga monopolu]]** – Monopol maksymalizuje zysk przy wielkości produkcji, dla której MR = MC, a cenę monopolową odczytuje z krzywej popytu nad tą wielkością. *Też: Cena monopolowa, Optimum monopolu.*
- **[[Równowaga rynkowa]]** – Równowaga rynkowa to stan, w którym przy danej cenie wielkość popytu równa się wielkości podaży (Qd = Qs) – cena „czyści rynek”. *Też: Cena równowagi, Punkt równowagi, Pe, Qe.*

## S
- **[[Strata podatkowa]]** – Strata podatkowa to nadwyżka kosztów uzyskania przychodów nad przychodami ze źródła; w CIT i PIT można ją rozliczać tylko w obrębie tego samego źródła przychodów. *Też: Strata ze źródła przychodów.*
- **[[Strata społeczna monopolu]]** – Strata społeczna (deadweight loss, DWL) to utracona nadwyżka całkowita z transakcji, do których nie dochodzi, bo monopol produkuje mniej niż rynek konkurencyjny. *Też: DWL, Deadweight loss, Nieefektywność monopolu.*
- **[[Struktura rynkowa]]** – Struktura rynkowa to forma organizacji rynku, wyróżniana według stopnia wpływu firmy na cenę: konkurencja doskonała, konkurencja monopolistyczna, oligopol, monopol. *Też: Formy rynku.*
- **[[Substytucyjność i komplementarność dóbr]]** – Substytuty to dobra zaspokajające tę samą potrzebę i zastępujące się nawzajem; dobra komplementarne to dobra używane razem, uzupełniające się. *Też: Substytut, Dobro komplementarne, Dobra niezależne.*
- **[[System podatkowy w Polsce]]** – System podatkowy to ogół podatków pobieranych w państwie; w Polsce najważniejsze fiskalnie są VAT, PIT, CIT i akcyza. *Też: Tax mix, Podatki w Polsce.*
- **[[Szacowanie funkcji kosztów]]** – Szacowanie funkcji kosztów to wyznaczanie zależności y = a + bx (a – koszty stałe, b – koszt zmienny na jednostkę nośnika) metodami technicznymi, analizy kont, wielkości skrajnych lub regresji. *Też: Metoda wielkości skrajnych, Regresja kosztów, Funkcja kosztów y = a + bx.*

## T
- **[[Tarcza podatkowa]]** – Tarcza (osłona) podatkowa to wartość oszczędności podatkowej – o ile niższy jest podatek – powstałej dzięki odliczeniu od dochodu lub podstawy opodatkowania. *Też: Osłona podatkowa, Tax shield, Tarcza odsetkowa.*

## U
- **[[Unikanie i uchylanie się od opodatkowania]]** – Unikanie opodatkowania to legalne obniżanie obciążeń przez korzystanie z możliwości oferowanych przez ustawodawcę; uchylanie się – zmniejszanie lub eliminowanie podatku z naruszeniem prawa. *Też: Unikanie opodatkowania, Uchylanie się od opodatkowania, Oszustwo podatkowe, GAAR.*
- **[[Użyteczność]]** – Użyteczność to zadowolenie, jakie konsument osiąga z konsumpcji lub posiadania dobra; użyteczność marginalna (MU) to zadowolenie z ostatniej, dodatkowej jednostki. *Też: TU, MU, Użyteczność marginalna, Prawo malejącej użyteczności marginalnej.*

## Z
- **[[Zachowanie kosztów]]** – Zachowanie kosztów to sposób, w jaki koszty reagują na zmiany aktywności; podział na stałe i zmienne obowiązuje tylko w określonym przedziale i horyzoncie, a w praktyce koszty bywają mieszane, schodkowe i sztywne. *Też: Koszty sztywne, Sticky costs, Relevant range, Koszty mieszane, Koszty schodkowe.*
- **[[Zysk ekonomiczny]]** – Zysk ekonomiczny to różnica między przychodem całkowitym a kosztami ekonomicznymi (jawnymi i niejawnymi): π = TR − TC. *Też: Zysk, Zysk normalny, Zysk księgowy, π, Zysk nadzwyczajny.*
- **[[Zysk marginalny]]** – Zysk marginalny (MΠ) to przyrost zysku całkowitego wywołany niewielkim zwiększeniem zmiennej decyzyjnej – pochodna funkcji zysku: $M\Pi = \Pi' = MR - MC$. *Też: MΠ, Funkcja zysku, Warunek konieczny i wystarczający, Funkcja celu.*

## Ź
- **[[Źródło prawa podatkowego]]** – Źródła prawa podatkowego to akty, z których wynikają normy podatkowe: Konstytucja, ustawy, ratyfikowane umowy międzynarodowe, rozporządzenia, akty prawa miejscowego, prawo UE oraz – praktycznie – orzecznictwo sądowe. *Też: Prawo podatkowe, Ordynacja podatkowa.*
- **[[Źródło przychodów w CIT]]** – W CIT przedmiotem opodatkowania jest suma dochodów z dwóch źródeł: zysków kapitałowych i innych źródeł przychodów (głównie działalności operacyjnej), liczonych osobno. *Też: Zyski kapitałowe, Inne źródła przychodów, Podatek dochodowy od osób prawnych, CIT.*
