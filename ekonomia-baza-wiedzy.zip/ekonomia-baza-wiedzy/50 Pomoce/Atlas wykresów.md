---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Wykresy"]
---
Wszystkie wykresy bazy w jednym miejscu. Pod każdym – notatka, która go wyjaśnia.

## Podstawy gospodarowania i optymalizacja
![[01_PPF_i_analiza_marginalna.png|600]]
Wyjaśnienie: [[Granica możliwości produkcyjnych]] i [[Analiza marginalna]].

![[e01_funkcja_zysku.png|600]]
Wyjaśnienie: [[Zysk marginalny]].

![[e02_analiza_wrazliwosci.png|600]]
Wyjaśnienie: [[Analiza wrażliwości]].

![[e06_poziomice_zysku_cena_reklama.png|600]]
Wyjaśnienie: [[Optymalizacja funkcji dwóch zmiennych]].

![[e07_lagrange_dwa_segmenty.png|600]]
Wyjaśnienie: [[Metoda mnożników Lagrange'a]].

## Rynek, popyt i elastyczność
![[02_rownowaga_niedobor_nadwyzka.png|600]]
Wyjaśnienie: [[Równowaga rynkowa]].

![[03_przesuniecia_D_S.png|600]]
Wyjaśnienie: [[Pozacenowa determinanta popytu]].

![[04_rownowaga_liczbowo.png|600]]
Wyjaśnienie: [[Równowaga rynkowa]].

![[05_podatek_dotacja.png|600]]
Wyjaśnienie: [[Interwencja państwa na rynku]].

![[06_elastycznosc_na_krzywej_liniowej.png|600]]
Wyjaśnienie: [[Elastyczność punktowa]].

![[07_elastycznosc_przypadki_skrajne.png|600]]
Wyjaśnienie: [[Elastyczność cenowa popytu]].

![[08_przychody_TR_AR_MR.png|600]]
Wyjaśnienie: [[Przychód]].

![[09_elastycznosc_a_przychody.png|600]]
Wyjaśnienie: [[Elastyczność a przychód]].

![[e03_max_przychodu_vs_zysku.png|600]]
Wyjaśnienie: [[Maksymalizacja przychodu]].

![[e04_narzut_vs_elastycznosc.png|600]]
Wyjaśnienie: [[Narzut ceny na koszt krańcowy]].

![[e05_popyt_stala_elastycznosc.png|600]]
Wyjaśnienie: [[Funkcja popytu o stałej elastyczności]].

![[m01_elastycznosc_punktowa_geometria.png|600]]
Wyjaśnienie: [[Elastyczność punktowa]].

![[m02_elastycznosc_lukowa.png|600]]
Wyjaśnienie: [[Elastyczność łukowa]].

![[m03_popyt_rynkowy_suma.png|600]]
Wyjaśnienie: [[Popyt]].

![[m04_podaz_galezi_suma_MC.png|600]]
Wyjaśnienie: [[Podaż]] i [[Krzywa podaży przedsiębiorstwa]].

![[m18_podatek_procentowy.png|600]]
Wyjaśnienie: [[Interwencja państwa na rynku]].

## Wybór konsumenta
![[10_uzytecznosc_TU_MU.png|600]]
Wyjaśnienie: [[Użyteczność]].

![[11_optimum_konsumenta.png|600]]
Wyjaśnienie: [[Optimum konsumenta]].

![[12_linia_budzetowa_zmiany.png|600]]
Wyjaśnienie: [[Linia budżetowa]].

![[13_ICC_i_krzywe_Engla.png|600]]
Wyjaśnienie: [[Krzywa Engla]].

![[14_PCC_i_krzywa_popytu.png|600]]
Wyjaśnienie: [[Krzywa cena–konsumpcja]].

![[15_efekt_substytucji_i_dochodowy.png|600]]
Wyjaśnienie: [[Efekt substytucji i efekt dochodowy]].

![[m05_MRS_schodki.png|600]]
Wyjaśnienie: [[Krańcowa stopa substytucji]].

![[m06_krzywe_obojetnosci_nie_przecinaja_sie.png|600]]
Wyjaśnienie: [[Krzywa obojętności]].

![[m07_ICC_trzy_warianty.png|600]]
Wyjaśnienie: [[Krzywa dochód–konsumpcja]].

![[m08_giffen_wodospad.png|600]]
Wyjaśnienie: [[Efekt substytucji i efekt dochodowy]].

## Produkcja i koszty
![[16_funkcja_produkcji_TP_AP_MP.png|600]]
Wyjaśnienie: [[Produkt przeciętny i marginalny]].

![[17_izokwanty_izokoszt_optimum.png|600]]
Wyjaśnienie: [[Optimum producenta]].

![[18_efekty_skali.png|600]]
Wyjaśnienie: [[Efekty skali]].

![[19_koszty_FC_VC_TC.png|600]]
Wyjaśnienie: [[Koszt stały i zmienny]].

![[20_koszty_przecietne_i_MC.png|600]]
Wyjaśnienie: [[Koszt przeciętny]] i [[Koszt marginalny]].

![[e08_MRP_zatrudnienie.png|600]]
Wyjaśnienie: [[Krańcowy przychód z pracy]].

![[e09_zysk_ksiegowy_ekonomiczny.png|600]]
Wyjaśnienie: [[Koszt księgowy a koszt ekonomiczny]].

![[m09_prawo_malejacych_przychodow_slupki.png|600]]
Wyjaśnienie: [[Prawo malejących przychodów]].

![[m10_MRTS_schodki.png|600]]
Wyjaśnienie: [[Izokwanta]].

![[m11_izokoszta_zmiany.png|600]]
Wyjaśnienie: [[Izokoszta]].

![[m12_optimum_producenta_min_koszt.png|600]]
Wyjaśnienie: [[Optimum producenta]].

![[m13_lustro_produkcja_koszty.png|600]]
Wyjaśnienie: [[Koszty a produktywność]].

![[m14_koszty_z_funkcji_produkcji.png|600]]
Wyjaśnienie: [[Koszty a produktywność]].

## Struktury rynkowe i decyzje firmy
![[21_KD_rynek_a_firma.png|600]]
Wyjaśnienie: [[Konkurencja doskonała]].

![[22_KD_trzy_sytuacje_firmy.png|600]]
Wyjaśnienie: [[Punkt zamknięcia]].

![[23_KD_punkty_graniczne_podaz.png|600]]
Wyjaśnienie: [[Próg rentowności]] i [[Krzywa podaży przedsiębiorstwa]].

![[24_monopol_zysk.png|600]]
Wyjaśnienie: [[Równowaga monopolu]].

![[25_monopol_strata.png|600]]
Wyjaśnienie: [[Równowaga monopolu]].

![[26_nadwyzki_konsumenta_producenta.png|600]]
Wyjaśnienie: [[Nadwyżka konsumenta i producenta]].

![[27_monopol_vs_KD_DWL.png|600]]
Wyjaśnienie: [[Strata społeczna monopolu]].

![[28_dyskryminacja_cenowa.png|600]]
Wyjaśnienie: [[Dyskryminacja cenowa]].

![[e10_prog_rentownosci_liniowy.png|600]]
Wyjaśnienie: [[Próg rentowności]].

![[e11_KD_dlugi_okres.png|600]]
Wyjaśnienie: [[Konkurencja doskonała]].

![[e12_CR4_HHI.png|600]]
Wyjaśnienie: [[Koncentracja rynku]].

![[e13_cournot_stackelberg.png|600]]
Wyjaśnienie: [[Model Cournota]].

![[e14_firma_dominujaca.png|600]]
Wyjaśnienie: [[Model firmy dominującej]].

![[e15_konkurencja_monopolistyczna.png|600]]
Wyjaśnienie: [[Konkurencja monopolistyczna]].

![[m15_struktury_spektrum.png|600]]
Wyjaśnienie: [[Struktura rynkowa]].

![[m16_KD_zysk.png|600]]
Wyjaśnienie: [[Konkurencja doskonała]].

![[m17_nadwyzki.png|600]]
Wyjaśnienie: [[Nadwyżka konsumenta i producenta]].

## Rachunkowość zarządcza
![[r01_ewolucja_RZ.png|600]]
Wyjaśnienie: [[Ewolucja rachunkowości zarządczej]].

## Rachunek kosztów
![[r02_hierarchia_kosztow.png|600]]
Wyjaśnienie: [[Hierarchia kosztów]].

![[r03_koszty_sztywne.png|600]]
Wyjaśnienie: [[Zachowanie kosztów]].

![[r04_regresja_vs_skrajne.png|600]]
Wyjaśnienie: [[Szacowanie funkcji kosztów]].

![[r05_krzywa_uczenia.png|600]]
Wyjaśnienie: [[Krzywa uczenia się]].

![[r06_RKP_RKZ_kwartaly.png|600]]
Wyjaśnienie: [[Rachunek kosztów zmiennych i pełnych]].

![[r07_rachunek_marz_kaskada.png|600]]
Wyjaśnienie: [[Marża wkładu]].

![[r08_ABC_trzy_metody.png|600]]
Wyjaśnienie: [[Klasyfikacja kosztów]].

![[r09_TDABC_wykorzystanie.png|600]]
Wyjaśnienie: [[Rachunek kosztów działań sterowany czasem]].

![[r10_krzywa_wieloryba.png|600]]
Wyjaśnienie: [[Rentowność klientów]].

## System podatkowy i zachowania podatników
![[p01_tax_mix.png|600]]
Wyjaśnienie: [[System podatkowy w Polsce]].

![[p02_incydencja_podatku.png|600]]
Wyjaśnienie: [[Incydencja podatkowa]].

## Podatek dochodowy przedsiębiorstw
![[p03_tarcza_podatkowa.png|600]]
Wyjaśnienie: [[Odliczenie podatkowe]].

![[p04_dlug_vs_kapital.png|600]]
Wyjaśnienie: [[Tarcza podatkowa]].

![[p05_limit_odsetek_kaskada.png|600]]
Wyjaśnienie: [[Limit kosztów finansowania dłużnego]].

![[p06_NID_limit.png|600]]
Wyjaśnienie: [[Hipotetyczne odsetki od kapitału własnego]].

![[p07_strata_metody.png|600]]
Wyjaśnienie: [[Rozliczanie straty podatkowej w czasie]].

