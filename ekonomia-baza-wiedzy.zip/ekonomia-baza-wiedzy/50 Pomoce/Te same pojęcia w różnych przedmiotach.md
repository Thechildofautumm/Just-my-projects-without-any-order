---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Mosty między przedmiotami"]
---
Cztery przedmioty opisują te same zjawiska z różnych stron: mikroekonomia – jak działa rynek i firma, ekonomia menedżerska – jak policzyć optymalną decyzję, rachunkowość zarządcza – jak zmierzyć koszty w konkretnej firmie, podatki – jak państwo zmienia opłacalność decyzji. Poniżej najważniejsze mosty, a dalej pełna lista notatek wspólnych dla co najmniej dwóch przedmiotów.

## Najważniejsze mosty

| Mikroekonomia / EM | Rachunkowość zarządcza / Podatki | Na czym polega most |
|---|---|---|
| [[Koszt alternatywny]] | [[Koszt relewantny]], [[Hipotetyczne odsetki od kapitału własnego]] | utracona korzyść jest kosztem decyzji; NID to „koszt alternatywny kapitału” uznany przez fiskusa |
| [[Próg rentowności]] | [[Marża wkładu]] | $Q_{BEP} = FC/(P - AVC)$ – mianownik to jednostkowa marża wkładu |
| [[Koszt stały i zmienny]] | [[Zachowanie kosztów]], [[Rachunek kosztów zmiennych i pełnych]] | ten sam podział kosztów; RZ dodaje koszty mieszane, schodkowe i sztywne |
| [[Koszt księgowy a koszt ekonomiczny]], [[Zysk ekonomiczny]] | [[Dochód podatkowy]] | trzy różne „zyski”: ekonomiczny (z kosztami niejawnymi), księgowy, podatkowy (przychody − KUP) |
| [[Analiza marginalna]], [[Zysk marginalny]] | [[Koszt relewantny]] | decyzję podejmujemy na podstawie przyrostów, nie średnich |
| [[Interwencja państwa na rynku]], [[Elastyczność cenowa popytu]] | [[Incydencja podatkowa]] | podatek przesuwa krzywą; jego ciężar ponosi strona mniej elastyczna |
| [[Efekty skali]] | [[Krzywa uczenia się]] | koszt jednostkowy spada z rozmiarem produkcji (skala) i z doświadczeniem (uczenie się) |
| [[Maksymalizacja zysku]] | [[Tarcza podatkowa]] | podatek dochodowy nie zmienia optymalnej produkcji, ale tarcza zmienia opłacalność finansowania i inwestycji |
| [[Dyskryminacja cenowa]] | [[Rentowność klientów]] | różni klienci – różna cena i różny koszt obsługi |

## Wszystkie pojęcia wspólne dla kilku przedmiotów
| Pojęcie | Przedmioty | W skrócie |
|---|---|---|
| [[Koszt alternatywny]] | Mikroekonomia, Ekonomia menedżerska, Rachunkowość zarządcza | wartość najlepszej możliwości utraconej przy wyborze |
| [[Analiza marginalna]] | Mikroekonomia, Ekonomia menedżerska | porównywanie korzyści i kosztów ostatniej jednostki; optimum MB = MC |
| [[Popyt]] | Mikroekonomia, Ekonomia menedżerska | zależność między ceną a ilością, jaką nabywcy chcą kupić; prawo popytu |
| [[Pozacenowa determinanta popytu]] | Mikroekonomia, Ekonomia menedżerska | czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…) |
| [[Interwencja państwa na rynku]] | Mikroekonomia, Podatki i strategie podatkowe | podatki, dotacje i ceny administracyjne w modelu popytu i podaży |
| [[Elastyczność popytu]] | Mikroekonomia, Ekonomia menedżerska | ogólna miara: % zmiany popytu / % zmiany czynnika; trzy rodzaje |
| [[Elastyczność cenowa popytu]] | Mikroekonomia, Ekonomia menedżerska | reakcja popytu na cenę własną; klasyfikacja i determinanty |
| [[Elastyczność punktowa]] | Mikroekonomia, Ekonomia menedżerska | elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax) |
| [[Elastyczność łukowa]] | Mikroekonomia, Ekonomia menedżerska | elastyczność na odcinku krzywej – wzór ze średnich |
| [[Elastyczność mieszana popytu]] | Mikroekonomia, Ekonomia menedżerska | reakcja popytu na X na cenę Y; rozpoznaje substytuty i komplementy |
| [[Elastyczność dochodowa popytu]] | Mikroekonomia, Ekonomia menedżerska | reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe |
| [[Przychód]] | Mikroekonomia, Ekonomia menedżerska | przychód całkowity, przeciętny i marginalny (TR, AR, MR) |
| [[Elastyczność a przychód]] | Mikroekonomia, Ekonomia menedżerska | MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe |
| [[Funkcja produkcji]] | Mikroekonomia, Ekonomia menedżerska | zależność produkcji od nakładów; krótki i długi okres |
| [[Produkt przeciętny i marginalny]] | Mikroekonomia, Ekonomia menedżerska | TP, AP = Q/L, MP = Q′ i relacje między nimi |
| [[Prawo malejących przychodów]] | Mikroekonomia, Ekonomia menedżerska | od pewnego poziomu nakładu MP maleje |
| [[Etapy produkcji]] | Mikroekonomia, Ekonomia menedżerska | I, II, III etap wg AP i MP; racjonalny tylko II |
| [[Izokwanta]] | Mikroekonomia, Ekonomia menedżerska | kombinacje L i K dające tę samą produkcję |
| [[Izokoszta]] | Mikroekonomia, Ekonomia menedżerska | kombinacje L i K o tym samym koszcie: TC = wL + rK |
| [[Optimum producenta]] | Mikroekonomia, Ekonomia menedżerska | styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu |
| [[Koszt księgowy a koszt ekonomiczny]] | Mikroekonomia, Ekonomia menedżerska, Rachunkowość zarządcza | koszty jawne vs jawne + ukryte (alternatywne) |
| [[Zysk ekonomiczny]] | Mikroekonomia, Ekonomia menedżerska | π = TR − TC; zysk ekonomiczny, księgowy i normalny |
| [[Koszt stały i zmienny]] | Mikroekonomia, Ekonomia menedżerska, Rachunkowość zarządcza | FC, VC i TC = FC + VC w krótkim okresie |
| [[Koszt przeciętny]] | Mikroekonomia, Ekonomia menedżerska | AFC, AVC, ATC – przebieg w kształcie U |
| [[Koszt marginalny]] | Mikroekonomia, Ekonomia menedżerska | przyrost TC z dodatkowej jednostki: MC = TC′ |
| [[Koszty a produktywność]] | Mikroekonomia, Ekonomia menedżerska | AVC = w/AP i MC = w/MP – lustrzane odbicie produkcji |
| [[Struktura rynkowa]] | Mikroekonomia, Ekonomia menedżerska | typologia rynków wg wpływu firmy na cenę |
| [[Koncentracja rynku]] | Mikroekonomia, Ekonomia menedżerska | CR4 i wskaźnik Herfindahla-Hirschmana (HHI); progi struktur rynku |
| [[Konkurencja doskonała]] | Mikroekonomia, Ekonomia menedżerska | założenia modelu, popyt firmy (P = MR), równowaga krótko- i długookresowa, cena wyjścia |
| [[Maksymalizacja zysku]] | Mikroekonomia, Ekonomia menedżerska | warunek MR = MC i warunek drugiego rzędu |
| [[Próg rentowności]] | Mikroekonomia, Ekonomia menedżerska, Rachunkowość zarządcza | BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC) |
| [[Punkt zamknięcia]] | Mikroekonomia, Ekonomia menedżerska | P = AVCmin, strata = FC; reguła produkować czy zamknąć |
| [[Monopol pełny]] | Mikroekonomia, Ekonomia menedżerska | założenia, źródła monopolu, popyt monopolu (P > MR) |
| [[Równowaga monopolu]] | Mikroekonomia, Ekonomia menedżerska | MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży |
| [[Koszt relewantny]] | Rachunkowość zarządcza, Ekonomia menedżerska | przyszły koszt różnicowy; koszty utopione i stałe pomijamy w decyzji |
