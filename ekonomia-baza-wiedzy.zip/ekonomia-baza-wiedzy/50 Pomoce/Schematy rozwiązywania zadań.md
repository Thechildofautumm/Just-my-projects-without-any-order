---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Algorytmy zadań", "Jak rozwiązać zadanie"]
---
Procedury krok po kroku dla typowych zadań obliczeniowych. Każdy schemat wskazuje pojęcie, z którego wynika, i zadanie, na którym można go przećwiczyć. Wzory zebrane są w [[Tabela wzorów|tabeli wzorów]].

## Rynek i elastyczność

### Równowaga i cena narzucona
1. Zapisz obie funkcje jako $P = f(Q)$ (odwróć, jeśli trzeba).
2. Przyrównaj $f_D(Q) = f_S(Q)$ → $Q_e$, podstaw → $P_e$.
3. Policz $P_{max}$ ($Q = 0$) i $Q_{max}$ ($P = 0$) – potrzebne do wykresu.
4. Przy cenie narzuconej policz $Q_D$ i $Q_S$ → niedobór albo nadwyżka.

Teoria: [[Równowaga rynkowa]] · ćwiczenie: [[Rynek rowerów – równowaga i cena poniżej równowagi]].

### Podatek, dotacja, czynnik pozacenowy
1. Ustal, **czyj** to czynnik: konsumentów (D) czy producentów (S), i kierunek zmiany.
2. Kwota na jednostkę → zmień wyraz wolny (przesunięcie równoległe); procent od ceny → zmień współczynnik przy $P$ (obrót krzywej).
3. Gdy znana jest docelowa cena: policz $Q_e'$ z **niezmienionej** krzywej, podstaw punkt do zmienionej i wylicz parametr.
4. Jakościowo: co jest pewne (↑/↓), a co zależy od siły czynników.

Teoria: [[Interwencja państwa na rynku]] · ćwiczenie: [[Kolonie letnie – subwencja dla organizatorów]].

### Łączny wpływ kilku determinant
- **Funkcja liniowa:** $dQ = \sum Q'_{z}\cdot dz$ (różniczka zupełna) – zmiany w jednostkach.
- **Elastyczności:** $\%\Delta Q = \sum E_z\cdot\%\Delta z$ – zmiany w procentach.
- Pilnuj znaków zmian (spadek ceny = −).

Teoria: [[Funkcja popytu wielu zmiennych]] · ćwiczenia: [[Krem z filtrem – łączny wpływ determinant popytu]], [[Miesięcznik podróżniczy – elastyczności mieszane]].

### Elastyczność punktowa (liniowy popyt)
1. Wyznacz $P_{max}$ i $Q_{max}$ (lub z $TR_{max}$: $Q = \frac12Q_{max}$, $P = \frac12P_{max}$).
2. $E_p = \frac{P}{P - P_{max}}$ albo $E_p = \frac{Q - Q_{max}}{Q}$.
3. Zinterpretuj: powyżej połowy krzywej elastyczny, poniżej nieelastyczny.

Teoria: [[Elastyczność punktowa]] · ćwiczenie: [[Przychód przy cenie 4000]].

### Cena maksymalizująca przychód lub zysk
- **Przychód (brak kosztów zmiennych):** $MR = 0$ lub $E_p = -1$.
- **Zysk przy znanej elastyczności:** $P = MC\cdot\frac{E_p}{E_p + 1}$ (tylko dla $|E_p| > 1$).
- **Zysk przy znanych funkcjach:** $\Pi(Q) = TR - TC$, $\Pi' = 0$, sprawdź $\Pi'' < 0$, cena z popytu.

Teoria: [[Maksymalizacja przychodu]], [[Narzut ceny na koszt krańcowy]] · ćwiczenia: [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]], [[Puzzle – wysoki narzut przy słabo elastycznym popycie]].

## Optymalizacja

### Funkcja zysku z jedną zmienną i analiza wrażliwości
1. $TR = P(Q)\cdot Q$, $TC = FC + VC$, $\Pi = TR - TC$.
2. $M\Pi = 0$ → $Q^*$; $\Pi'' < 0$.
3. Cena z funkcji popytu, zysk z funkcji zysku.
4. Wrażliwość: zmiana $FC$ zmienia tylko zysk; zmiana $MC$ lub popytu zmienia $Q^*$, $P^*$ i zysk.

Teoria: [[Zysk marginalny]], [[Analiza wrażliwości]] · ćwiczenie: [[Producent dronów – analiza wrażliwości]].

### Dwie zmienne
1. Pochodne cząstkowe = 0 → układ równań.
2. Hesjan: $\Pi_{xx} < 0$, $\Pi_{yy} < 0$, $\det > 0$.
3. Podstaw do funkcji celu.

Teoria: [[Optymalizacja funkcji dwóch zmiennych]] · ćwiczenie: [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]].

### Ograniczenie (Lagrange)
1. Sprawdź, czy ograniczenie wiąże (rozwiązanie bez ograniczenia je łamie?).
2. $Z = f + \lambda(\text{ograniczenie})$, pochodne po wszystkich zmiennych i $\lambda$ = 0.
3. Rozwiąż; zinterpretuj $\lambda$ jako cenę cienia zasobu.

Teoria: [[Metoda mnożników Lagrange'a]] · ćwiczenie: [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]].

## Konsument

### Optimum konsumenta i kompensacja
1. $MU_x$, $MU_y$ (pochodne cząstkowe).
2. Układ: $\frac{MU_x}{MU_y} = \frac{P_x}{P_y}$ i linia budżetowa.
3. Wyznacz $Q_y(Q_x)$, podstaw do budżetu → koszyk, $TU$.
4. Kompensacja: $TU = TU_0$ i $MRS = P_x'/P_y$ → nowy koszyk → potrzebny dochód.

Teoria: [[Optimum konsumenta]] · ćwiczenie: [[Kompensacja wzrostu ceny – utrzymanie użyteczności]].

## Produkcja i koszty

### Etapy produkcji
1. $AP = Q/L$, $MP = Q'$.
2. $AP' = 0$ → granica I/II; $MP = 0$ → granica II/III.
3. $MP' = 0$ → początek działania prawa malejących przychodów.

Teoria: [[Etapy produkcji]] · ćwiczenie: [[Granice II etapu produkcji]].

### Optymalne zatrudnienie (krótki okres)
1. $MP_L = Q'(L)$; $MRP_L = P\cdot MP_L$.
2. $MRP_L = w$ → $L^*$ (wybierz pierwiastek w II etapie).
3. $Q^* = Q(L^*)$; zysk $= P\cdot Q^* - wL^* - rK$.

Teoria: [[Krańcowy przychód z pracy]] · ćwiczenie: [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]].

### Najtańsza kombinacja czynników (długi okres)
1. $\frac{MP_L}{w} = \frac{MP_K}{r}$ → relacja $K(L)$.
2. **Min koszt przy danym Q:** podstaw relację do funkcji produkcji. **Max Q przy danym TC:** podstaw do izokoszty.
3. Policz $TC = wL + rK$ albo $Q$.

Teoria: [[Optimum producenta]] · ćwiczenie: [[Najtańsza technika dla funkcji Cobba-Douglasa]].

### Funkcje kosztów
1. $FC$ = wyraz wolny $TC$; $VC$ = reszta.
2. $ATC$, $AVC$, $AFC$, $MC = TC'$.
3. Minima: $AVC' = 0$, $ATC' = 0$, $MC' = 0$.

Teoria: [[Koszt przeciętny]], [[Koszt marginalny]] · ćwiczenie: [[Funkcje kosztów przeciętnych i krańcowego]].

### Zysk księgowy a ekonomiczny
1. Koszty jawne → zysk księgowy = utarg − koszty jawne.
2. Koszty niejawne: utracony czynsz, odsetki od własnego kapitału, utracona pensja.
3. Zysk ekonomiczny = zysk księgowy − koszty niejawne; > 0 → decyzja słuszna.

Teoria: [[Zysk ekonomiczny]] · ćwiczenie: [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]].

## Decyzje firmy na rynku

### Konkurencja doskonała – produkować czy zamknąć
1. $P = MC$ → $Q$ (rosnąca gałąź $MC$).
2. $ATC(Q)$, $AVC(Q)$; $\pi = (P - ATC)\cdot Q$.
3. $P \ge ATC$ → zysk; $AVC \le P < ATC$ → produkuj ze stratą; $P < AVC_{min}$ → zamknij.
4. Ceny graniczne: niwelacji $ATC_{min}$, zamknięcia $AVC_{min}$; długi okres – wyjście poniżej $AC_{min}$.

Teoria: [[Punkt zamknięcia]] · ćwiczenie: [[Konkurencja doskonała – strata mniejsza od kosztów stałych]] · wizualnie: [[Decyzja firmy – produkować czy zamknąć.canvas|kanwa decyzji firmy]].

### Monopol
1. $TR = P(Q)\cdot Q$ → $MR$; $MC = TC'$.
2. $MR = MC$ → $Q_m$; cena z **popytu**.
3. Zysk $= TR - TC$; jeśli $P < AVC$ → zamknąć.

Teoria: [[Równowaga monopolu]] · ćwiczenie: [[Monopol – optymalna cena i zysk]].

### Oligopol: Cournot, Stackelberg, firma dominująca
- **Cournot:** $MR_1 = MC_1$ i $MR_2 = MC_2$ (pochodne po własnej ilości) → układ dwóch równań.
- **Stackelberg:** funkcja reakcji naśladowcy → podstaw do popytu przywódcy → $MR_1 = MC_1$ → $q_1$, potem $q_2$.
- **Firma dominująca:** $MR = MC$ na jej popycie → $q$, cena; popyt rynkowy przy tej cenie → reszta dla małych firm.

Teoria: [[Model Cournota]], [[Model Stackelberga]], [[Model firmy dominującej]] · ćwiczenie: [[Producenci autobusów – Cournot i Stackelberg]].

### Próg rentowności w trzech ujęciach
1. $Q_{BEP} = FC/(P - AVC)$.
2. $TR_{BEP} = P\cdot Q_{BEP}$.
3. $Q_{BEP}/\text{zdolności}\cdot 100\%$.

Teoria: [[Próg rentowności]] · ćwiczenie: [[Próg rentowności ilościowy, wartościowy i procentowy]].

## Rachunek kosztów

### RKP a RKZ
1. Marża wkładu na sztukę = cena − wszystkie koszty zmienne → RKZ: marża × sprzedaż − wszystkie koszty stałe.
2. RKP: (cena − koszt wytworzenia) × sprzedaż − koszty sprzedaży i zarządu − koszt niewykorzystanych mocy.
3. Kontrola: różnica = zmiana zapasu × stawka kosztów stałych.

Teoria: [[Rachunek kosztów zmiennych i pełnych]] · ćwiczenie: [[Velomia – RKP i RKZ w dwóch kwartałach]].

### ABC i TDABC
1. ABC: stawka działania = koszt / nośnik → koszt obiektu = Σ stawka × zużycie → podziel przez liczbę sztuk.
2. TDABC: stawka = koszt zdolności / praktyczna zdolność; czas z równania; niewykorzystane moce osobno.

Teoria: [[Rachunek kosztów działań]], [[Rachunek kosztów działań sterowany czasem]] · ćwiczenia: [[Velomia – ABC w zakładzie w Lesznie]], [[Velomia – TDABC działu wsparcia technicznego]].

## Podatki

### Limit kosztów finansowania dłużnego
1. Nadwyżka = koszty finansowania − przychody odsetkowe (≤ 0 → brak limitu).
2. Limit = max(3 mln zł; 30% EBITDA podatkowej).
3. NKUP = nadwyżka − limit (do rozliczenia przez 5 lat).

Teoria: [[Limit kosztów finansowania dłużnego]] · ćwiczenie: [[Podatki – limit kosztów finansowania dłużnego]].

### Rozliczenie straty
1. Czy strata i dochód są z tego samego źródła? Jeśli nie – nie łączymy.
2. Tradycyjnie: ≤ 50% straty rocznie; jednorazowo: ≤ 5 mln zł.
3. Odliczenie nie może przekroczyć dochodu roku.

Teoria: [[Rozliczanie straty podatkowej w czasie]] · ćwiczenie: [[Podatki – rozliczenie straty 3 i 18 mln zł]].
