---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Lista zadań", "Zadania"]
---
Wszystkie zadania z rozwiązaniami, według obszarów wiedzy i tematów. Przy każdym – pojęcie, do którego zadanie jest przypięte.

## Podstawy gospodarowania i optymalizacja
- [[Kategorie marginalne i warunki maksimum zysku]] `EM` – do pojęcia [[Zysk marginalny]]
- [[Producent dronów – funkcja zysku]] `EM` – do pojęcia [[Zysk marginalny]]
- [[Producent dronów – analiza wrażliwości]] `EM` – do pojęcia [[Analiza wrażliwości]]
- [[Optymalna produkcja – dwa warianty funkcji]] `EM` – do pojęcia [[Zysk marginalny]]
- [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]] `EM` – do pojęcia [[Optymalizacja funkcji dwóch zmiennych]]
- [[Cena i budżet reklamowy – zysk z dwiema zmiennymi]] `EM` – do pojęcia [[Optymalizacja funkcji dwóch zmiennych]]
- [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]] `EM` – do pojęcia [[Metoda mnożników Lagrange'a]]
- [[Praca i kapitał przy liniowej funkcji produkcji]] `EM` – do pojęcia [[Metoda mnożników Lagrange'a]]

## Rynek, popyt i elastyczność
### Rynek
- [[Rynek rowerów – równowaga i cena poniżej równowagi]] `MI` – do pojęcia [[Równowaga rynkowa]]
- [[Rynek lodówek – cena administracyjna]] `MI` – do pojęcia [[Równowaga rynkowa]]
- [[Napoje energetyczne – cena maksymalna i kampania społeczna]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Sok jabłkowy – dopłata dla konsumentów]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Rynek najmu – dopłata dla wynajmujących]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Kolonie letnie – subwencja dla organizatorów]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Elektronika – podatek procentowy od ceny]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Dopłata procentowa dla konsumentów]] `MI` – do pojęcia [[Interwencja państwa na rynku]]
- [[Smartwatche – ta sama cena, mniejsza ilość]] `MI` – do pojęcia [[Pozacenowa determinanta popytu]]
- [[Rynek pelletu – nowe tartaki i droższe kotły]] `MI` – do pojęcia [[Pozacenowa determinanta podaży]]
- [[Samochody używane – droższy kredyt i niższe cło]] `MI` – do pojęcia [[Pozacenowa determinanta popytu]]
- [[Rynek kawy – przymrozki i drogi fracht]] `MI` – do pojęcia [[Pozacenowa determinanta podaży]]
- [[Truskawki – różniczka zupełna popytu]] `EM` – do pojęcia [[Funkcja popytu wielu zmiennych]]
- [[Krem z filtrem – łączny wpływ determinant popytu]] `EM` – do pojęcia [[Funkcja popytu wielu zmiennych]]
- [[Sprzedaż na dwóch rynkach z łączną funkcją kosztów]] `EM` – do pojęcia [[Optymalizacja funkcji dwóch zmiennych]]

### Elastyczność
- [[Interpretacja współczynników elastyczności]] `MI` – do pojęcia [[Elastyczność cenowa popytu]]
- [[Masło, łosoś i ser – rodzaj dobra i polityka cenowa]] `MI` – do pojęcia [[Elastyczność dochodowa popytu]]
- [[Ilość, przy której elastyczność wynosi −2]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Zeszyty – elastyczność łukowa i przychód marginalny]] `MI` – do pojęcia [[Elastyczność łukowa]]
- [[Ekspresy do kawy – elastyczność przy maksymalnym przychodzie]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Elastyczność i przychód przy cenie 20]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Elastyczność wyznaczona z przychodu marginalnego]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Przychód przy cenie 4000]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Ilość przy zerowym przychodzie marginalnym]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Równania AR, MR i TR z dwóch informacji]] `MI` – do pojęcia [[Elastyczność punktowa]]
- [[Masło i margaryna – elastyczność mieszana]] `MI` – do pojęcia [[Elastyczność mieszana popytu]]
- [[Olej napędowy – łączny wpływ ceny i dochodu]] `EM` – do pojęcia [[Elastyczność cenowa popytu]]
- [[Miesięcznik podróżniczy – elastyczności mieszane]] `EM` – do pojęcia [[Elastyczność mieszana popytu]]
- [[Kawa mrożona – potęgowa funkcja popytu]] `EM` – do pojęcia [[Funkcja popytu o stałej elastyczności]]
- [[Słuchawki bezprzewodowe – stała elastyczność i narzut]] `EM` – do pojęcia [[Funkcja popytu o stałej elastyczności]]

### Przychody i cena
- [[Maksymalny przychód przy popycie liniowym]] `MI` – do pojęcia [[Przychód]]
- [[Batony – przychód marginalny w punkcie i na odcinku]] `MI` – do pojęcia [[Przychód]]
- [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]] `EM` – do pojęcia [[Maksymalizacja przychodu]]
- [[Cena maksymalizująca utarg – dwa rynki]] `EM` – do pojęcia [[Maksymalizacja przychodu]]
- [[Linia promowa – podnieść czy obniżyć cenę]] `EM` – do pojęcia [[Maksymalizacja przychodu]]
- [[Kubki z nadrukiem – cena z narzutem na koszt krańcowy]] `EM` – do pojęcia [[Narzut ceny na koszt krańcowy]]
- [[Puzzle – wysoki narzut przy słabo elastycznym popycie]] `EM` – do pojęcia [[Narzut ceny na koszt krańcowy]]

## Wybór konsumenta
- [[Bilety do kina – użyteczność marginalna]] `MI` – do pojęcia [[Użyteczność]]
- [[Herbata i ciastka – krańcowa stopa substytucji]] `MI` – do pojęcia [[Krańcowa stopa substytucji]]
- [[Książki i płyty – optymalny koszyk]] `MI` – do pojęcia [[Optimum konsumenta]]
- [[Kompensacja wzrostu ceny – utrzymanie użyteczności]] `MI` – do pojęcia [[Optimum konsumenta]]
- [[Funkcja popytu z dwóch optimów konsumenta]] `MI` – do pojęcia [[Krzywa cena–konsumpcja]]
- [[Krzywa Engla dla funkcji Cobba-Douglasa]] `MI` – do pojęcia [[Krzywa Engla]]

## Produkcja i koszty
### Produkcja
- [[Produkt przeciętny i krańcowy z funkcji produkcji]] `MI` – do pojęcia [[Produkt przeciętny i marginalny]]
- [[Firma Kowal – maksimum produktu przeciętnego]] `MI` – do pojęcia [[Produkt przeciętny i marginalny]]
- [[Maksymalna produkcja przy jednym czynniku zmiennym]] `MI` – do pojęcia [[Produkt przeciętny i marginalny]]
- [[Od którego pracownika działa prawo malejących przychodów]] `MI` – do pojęcia [[Prawo malejących przychodów]]
- [[Granice I i III etapu produkcji]] `MI` – do pojęcia [[Etapy produkcji]]
- [[Gdzie działa racjonalny producent]] `MI` – do pojęcia [[Etapy produkcji]]
- [[Granice II etapu produkcji]] `MI` – do pojęcia [[Etapy produkcji]]
- [[Wytwórnia przetworów – II etap i powtórna wartość MP]] `MI` – do pojęcia [[Etapy produkcji]]
- [[Efekty skali dwóch funkcji produkcji]] `MI` – do pojęcia [[Efekty skali]]
- [[Krańcowa stopa substytucji technicznej na izokwancie]] `MI` – do pojęcia [[Krańcowa stopa technicznej substytucji]]
- [[Pracownia ceramiki – maksymalna produkcja przy danym budżecie]] `MI` – do pojęcia [[Optimum producenta]]
- [[Piekarnia – minimalny koszt produkcji]] `MI` – do pojęcia [[Optimum producenta]]
- [[Prawo malejących przychodów dla Q = 2√(KL)]] `EM` – do pojęcia [[Prawo malejących przychodów]]
- [[Kawiarnia – optymalne zatrudnienie]] `EM` – do pojęcia [[Krańcowy przychód z pracy]]
- [[Optymalna liczba roboczogodzin z MRP]] `EM` – do pojęcia [[Krańcowy przychód z pracy]]
- [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]] `EM` – do pojęcia [[Krańcowy przychód z pracy]]
- [[Najtańsza technika dla funkcji Cobba-Douglasa]] `EM` – do pojęcia [[Optimum producenta]]
- [[Najtańsza kombinacja nakładów dla Q = 50√(LK)]] `EM` – do pojęcia [[Optimum producenta]]

### Koszty i zysk
- [[Funkcje kosztów przeciętnych i krańcowego]] `MI` – do pojęcia [[Koszt przeciętny]]
- [[Koszty stałe z położenia minimum ATC]] `MI` – do pojęcia [[Koszt przeciętny]]
- [[Pani Grażyna – czy zmniejszyć produkcję]] `MI` – do pojęcia [[Koszt przeciętny]]
- [[Najniższy koszt krańcowy z funkcji produkcji]] `MI` – do pojęcia [[Koszty a produktywność]]
- [[Od funkcji produkcji do funkcji kosztów]] `MI` – do pojęcia [[Koszty a produktywność]]
- [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]] `EM` – do pojęcia [[Koszt księgowy a koszt ekonomiczny]]
- [[Food truck – przy jakiej stopie procentowej się opłaca]] `EM` – do pojęcia [[Zysk ekonomiczny]]
- [[Wzrost kosztów stałych a decyzja o produkcji]] `EM` – do pojęcia [[Koszt stały i zmienny]]

## Struktury rynkowe i decyzje firmy
### Formy rynku
- [[Monopol – optymalna cena i zysk]] `MI` – do pojęcia [[Równowaga monopolu]]
- [[Monopol – strata większa od kosztów stałych]] `MI` – do pojęcia [[Równowaga monopolu]]
- [[Monopol – za duża produkcja]] `MI` – do pojęcia [[Równowaga monopolu]]
- [[Monopol – kiedy zamknąć mimo MR = MC]] `MI` – do pojęcia [[Równowaga monopolu]]
- [[Koncentracja rynku – CR4 i HHI]] `MI` – do pojęcia [[Koncentracja rynku]]
- [[Rynek pralek – CR4 i HHI]] `EM` – do pojęcia [[Koncentracja rynku]]
- [[HHI dla modelowych struktur rynku]] `EM` – do pojęcia [[Koncentracja rynku]]
- [[Cena, przy której ustaje wejście do gałęzi]] `EM` – do pojęcia [[Konkurencja doskonała]]
- [[Cena wyjścia z gałęzi w długim okresie]] `EM` – do pojęcia [[Konkurencja doskonała]]
- [[Model firmy dominującej – cena i podział rynku]] `EM` – do pojęcia [[Model firmy dominującej]]
- [[Rynek gazu płynnego – firma dominująca]] `EM` – do pojęcia [[Model firmy dominującej]]
- [[Dwa kamieniołomy – duopol Cournota z kosztami stałymi]] `EM` – do pojęcia [[Model Cournota]]
- [[Duopol Cournota – porównanie z konkurencją i monopolem]] `EM` – do pojęcia [[Model Cournota]]
- [[Model Stackelberga – przewaga pierwszego ruchu]] `EM` – do pojęcia [[Model Stackelberga]]
- [[Producenci autobusów – Cournot i Stackelberg]] `EM` – do pojęcia [[Model Cournota]]

### Decyzje firmy i efektywność
- [[Konkurencja doskonała – produkcja przy cenie 34]] `MI` – do pojęcia [[Maksymalizacja zysku]]
- [[Konkurencja doskonała – zysk zerowy]] `MI` – do pojęcia [[Próg rentowności]]
- [[Konkurencja doskonała – strata mniejsza od kosztów stałych]] `MI` – do pojęcia [[Punkt zamknięcia]]
- [[Konkurencja doskonała – decyzja przy MR = 24]] `MI` – do pojęcia [[Punkt zamknięcia]]
- [[Cena progu rentowności z funkcji kosztów]] `MI` – do pojęcia [[Próg rentowności]]
- [[Cena zamknięcia z funkcji kosztów]] `MI` – do pojęcia [[Punkt zamknięcia]]
- [[Odtwarzanie tabeli kosztów trzech firm]] `MI` – do pojęcia [[Maksymalizacja zysku]]
- [[Strata społeczna monopolu – porównanie z konkurencją]] `MI` – do pojęcia [[Strata społeczna monopolu]]
- [[Próg rentowności przy liniowych kosztach]] `EM` – do pojęcia [[Próg rentowności]]
- [[Próg rentowności ilościowy, wartościowy i procentowy]] `EM` – do pojęcia [[Próg rentowności]]

## Rachunkowość zarządcza
## Rachunek kosztów
- [[Velomia – trzy marże roweru Urban 5]] `RZ` – do pojęcia [[Marża wkładu]]
- [[Velomia – regresja a metoda wielkości skrajnych]] `RZ` – do pojęcia [[Szacowanie funkcji kosztów]]
- [[Velomia – krzywa uczenia się roweru Urban 9]] `RZ` – do pojęcia [[Krzywa uczenia się]]
- [[Velomia – RKP i RKZ w dwóch kwartałach]] `RZ` – do pojęcia [[Rachunek kosztów zmiennych i pełnych]]
- [[Velomia – wielostopniowy rachunek marż]] `RZ` – do pojęcia [[Marża wkładu]]
- [[Velomia – ABC w zakładzie w Lesznie]] `RZ` – do pojęcia [[Rachunek kosztów działań]]
- [[Velomia – TDABC działu wsparcia technicznego]] `RZ` – do pojęcia [[Rachunek kosztów działań sterowany czasem]]
- [[Velomia – zamówienie specjalne na Urban 5]] `RZ` – do pojęcia [[Koszt relewantny]]
- [[Velomia – koszty sztywne po spadku sprzedaży]] `RZ` – do pojęcia [[Zachowanie kosztów]]

## System podatkowy i zachowania podatników
### System podatkowy
- [[Podatki – klasyfikacja wybranych podatków]] `PD` – do pojęcia [[Klasyfikacja podatków]]

### Zachowania podatników
- [[Podatki – arbitraż przy stawkach 12% i 32%]] `PD` – do pojęcia [[Arbitraż podatkowy]]

## Podatek dochodowy przedsiębiorstw
### Podstawa i stawka
- [[Podatki – czy spółka zapłaci 9% CIT]] `PD` – do pojęcia [[Mały podatnik]]

### Odliczenia i straty
- [[Podatki – tarcza przy stawce 9% i 19%]] `PD` – do pojęcia [[Tarcza podatkowa]]
- [[Podatki – ulga prorodzinna jako odliczenie od podatku]] `PD` – do pojęcia [[Odliczenie podatkowe]]
- [[Podatki – strata operacyjna a zysk kapitałowy]] `PD` – do pojęcia [[Strata podatkowa]]
- [[Podatki – strata spółki a dochód z JDG]] `PD` – do pojęcia [[Strata podatkowa]]
- [[Podatki – rozliczenie straty 3 i 18 mln zł]] `PD` – do pojęcia [[Rozliczanie straty podatkowej w czasie]]

### Finansowanie a podatek
- [[Podatki – dług czy kapitał własny]] `PD` – do pojęcia [[Asymetria podatkowa finansowania]]
- [[Podatki – limit kosztów finansowania dłużnego]] `PD` – do pojęcia [[Limit kosztów finansowania dłużnego]]
- [[Podatki – hipotetyczne odsetki od kapitału zapasowego]] `PD` – do pojęcia [[Hipotetyczne odsetki od kapitału własnego]]

