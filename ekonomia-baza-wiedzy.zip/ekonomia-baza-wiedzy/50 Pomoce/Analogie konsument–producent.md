---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
---
Teoria konsumenta i teoria producenta mają tę samą konstrukcję: obie optymalizują przy ograniczeniu, a ich warunki optimum wyglądają identycznie. Jeśli rozumiesz jedną stronę, drugą znasz „za darmo”.

| Konsument | Producent | Co je łączy |
|---|---|---|
| [[Użyteczność]] $TU(x, y)$ | [[Funkcja produkcji]] $Q(L, K)$ | funkcja celu zależna od dwóch „nakładów” |
| użyteczność marginalna $MU$ | [[Produkt przeciętny i marginalny\|produkt marginalny]] $MP$ | pochodna cząstkowa funkcji celu |
| prawo malejącej użyteczności krańcowej | [[Prawo malejących przychodów]] | kolejne jednostki dają coraz mniejszy przyrost |
| [[Krzywa obojętności]] | [[Izokwanta]] | kombinacje dające ten sam wynik (TU lub Q) |
| [[Krańcowa stopa substytucji]] $MRS = \frac{MU_x}{MU_y}$ | [[Krańcowa stopa technicznej substytucji]] $MRTS = \frac{MP_L}{MP_K}$ | nachylenie krzywej „jednakowego wyniku” |
| [[Linia budżetowa]] $I = P_xx + P_yy$ | [[Izokoszta]] $TC = wL + rK$ | ograniczenie; nachylenie = relacja cen |
| [[Optimum konsumenta]] $\frac{MU_x}{P_x} = \frac{MU_y}{P_y}$ | [[Optimum producenta]] $\frac{MP_L}{w} = \frac{MP_K}{r}$ | styczność krzywej wyniku z ograniczeniem |
| [[Krzywa dochód–konsumpcja]] (rośnie dochód) | ścieżka ekspansji (rośnie budżet firmy) | przesuwanie ograniczenia równolegle |
| [[Krzywa cena–konsumpcja]] → krzywa popytu | zmiana ceny czynnika → popyt na czynnik | obrót ograniczenia przy zmianie jednej ceny |
| max użyteczności przy danym dochodzie | min kosztu przy danej produkcji / max produkcji przy danym koszcie | zadanie pierwotne i dualne |

> [!tip] Jak to wykorzystać na egzaminie
> Pytanie „wyprowadź warunek optimum producenta” rozwiązujesz tym samym rysunkiem co optimum konsumenta – zamieniasz tylko nazwy osi i krzywych.

Obie strony są przykładem tej samej techniki – [[Metoda mnożników Lagrange'a|optymalizacji z ograniczeniem]].
