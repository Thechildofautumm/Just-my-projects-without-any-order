---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Popyt, podaż, równowaga, elastyczności, przychody i ustalanie ceny.

## Rynek
- [[Rynek]] – miejsce i mechanizm koordynacji decyzji kupujących i sprzedających `MI`
- [[Popyt]] – zależność między ceną a ilością, jaką nabywcy chcą kupić; prawo popytu `MI/EM`
- [[Podaż]] – zależność między ceną a ilością oferowaną przez producentów; prawo podaży `MI`
- [[Równowaga rynkowa]] – cena i ilość, przy których Qd = Qs `MI`
- [[Nierównowaga rynkowa]] – niedobór lub nadmiar przy cenie innej niż równowagi; ceny administracyjne `MI`
- [[Pozacenowa determinanta popytu]] – czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…) `MI/EM`
- [[Pozacenowa determinanta podaży]] – czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…) `MI`
- [[Funkcja popytu wielu zmiennych]] – Q = f(P, I, Py, N, A…); łączna zmiana popytu z różniczki zupełnej `EM`
- [[Interwencja państwa na rynku]] – podatki, dotacje i ceny administracyjne w modelu popytu i podaży `MI/PD`
- [[Substytucyjność i komplementarność dóbr]] – dobra zastępujące się i uzupełniające się `MI`

## Elastyczność
- [[Elastyczność popytu]] – ogólna miara: % zmiany popytu / % zmiany czynnika; trzy rodzaje `MI/EM`
- [[Elastyczność cenowa popytu]] – reakcja popytu na cenę własną; klasyfikacja i determinanty `MI/EM`
- [[Elastyczność punktowa]] – elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax) `MI/EM`
- [[Elastyczność łukowa]] – elastyczność na odcinku krzywej – wzór ze średnich `MI/EM`
- [[Elastyczność mieszana popytu]] – reakcja popytu na X na cenę Y; rozpoznaje substytuty i komplementy `MI/EM`
- [[Elastyczność dochodowa popytu]] – reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe `MI/EM`
- [[Funkcja popytu o stałej elastyczności]] – Q = k·P^α: elastyczności równe wykładnikom potęg `EM`

## Przychody i cena
- [[Przychód]] – przychód całkowity, przeciętny i marginalny (TR, AR, MR) `MI/EM`
- [[Elastyczność a przychód]] – MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe `MI/EM`
- [[Maksymalizacja przychodu]] – TR max przy MR = 0 (Ep = −1); kiedy pokrywa się z maksymalizacją zysku `EM`
- [[Narzut ceny na koszt krańcowy]] – P = MC · Ep/(Ep + 1): cena maksymalizująca zysk `EM`

## Zadania
W tym obszarze jest **37 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Wybór konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Wyb%C3%B3r%20konsumenta) – popyt rynkowy jest sumą popytów konsumentów.
- [MOC Struktury rynkowe i decyzje firmy](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Struktury%20rynkowe%20i%20decyzje%20firmy) – MR i elastyczność decydują o cenie firmy i monopolu.
- [MOC System podatkowy i zachowania podatników](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20System%20podatkowy%20i%20zachowania%20podatnik%C3%B3w) – podatek zmienia równowagę, a jego ciężar zależy od elastyczności.
