---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Od użyteczności i krzywych obojętności do krzywej popytu, krzywych Engla i efektów cenowych.

## Pojęcia
- [[Użyteczność]] – zadowolenie z konsumpcji; TU, MU i prawo malejącej użyteczności marginalnej `MI`
- [[Preferencje konsumenta]] – założenia: kompletność, przechodniość, nienasycenie `MI`
- [[Krzywa obojętności]] – koszyki dające tę samą użyteczność; cechy krzywych `MI`
- [[Krańcowa stopa substytucji]] – ile Y oddajemy za jednostkę X przy stałej użyteczności `MI`
- [[Linia budżetowa]] – koszyki, na które stać konsumenta; przesunięcia i obroty `MI`
- [[Optimum konsumenta]] – styczność krzywej obojętności z linią budżetową: MRS = Px/Py `MI`
- [[Krzywa dochód–konsumpcja]] – ścieżka optimów przy rosnącym dochodzie (ICC) `MI`
- [[Krzywa Engla]] – ilość dobra jako funkcja dochodu; prawidłowości Engla `MI`
- [[Krzywa cena–konsumpcja]] – ścieżka optimów przy zmianie ceny X (PCC); wyprowadzenie krzywej popytu `MI`
- [[Efekt substytucji i efekt dochodowy]] – dekompozycja reakcji na zmianę ceny `MI`
- [[Dobro Giffena]] – silnie podrzędne dobro, którego popyt rośnie wraz z ceną `MI`

## Zadania
W tym obszarze jest **6 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Rynek, popyt i elastyczność](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rynek%2C%20popyt%20i%20elastyczno%C5%9B%C4%87) – z optimum konsumenta wyprowadzamy krzywą popytu i krzywe Engla.
- [MOC Produkcja i koszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Produkcja%20i%20koszty) – analogia: krzywa obojętności ↔ izokwanta.
- [MOC Podstawy gospodarowania i optymalizacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podstawy%20gospodarowania%20i%20optymalizacja) – optimum konsumenta to optymalizacja z ograniczeniem.
