---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Rzadkość, koszt alternatywny, analiza marginalna i matematyczne metody optymalizacji decyzji.

## Pojęcia
- [[Mikroekonomia]] – czym zajmuje się ekonomia i czym mikro różni się od makro `MI`
- [[Rzadkość zasobów]] – potrzeby są nieograniczone, zasoby ograniczone – źródło konieczności wyboru `MI`
- [[Czynnik produkcji]] – praca, ziemia i kapitał jako nakłady w produkcji `MI`
- [[Koszt alternatywny]] – wartość najlepszej możliwości utraconej przy wyborze `MI/EM/RZ`
- [[Granica możliwości produkcyjnych]] – zbiór efektywnych kombinacji dwóch dóbr przy danych zasobach `MI`
- [[Analiza marginalna]] – porównywanie korzyści i kosztów ostatniej jednostki; optimum MB = MC `MI/EM`
- [[Zysk marginalny]] – MΠ = MR − MC; warunek konieczny MΠ = 0 i wystarczający Π″ < 0 `EM`
- [[Optymalizacja funkcji dwóch zmiennych]] – pochodne cząstkowe = 0, drugie pochodne < 0, wyznacznik hesjanu > 0 `EM`
- [[Metoda mnożników Lagrange'a]] – maksymalizacja funkcji celu przy ograniczeniu: Z = f + λg `EM`
- [[Analiza wrażliwości]] – jak zmienia się optimum i zysk przy zmianie kosztów stałych, zmiennych lub popytu `EM`

## Zadania
W tym obszarze jest **8 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Rynek, popyt i elastyczność](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rynek%2C%20popyt%20i%20elastyczno%C5%9B%C4%87) – na popycie i przychodzie ćwiczymy optymalizację jednej zmiennej.
- [MOC Produkcja i koszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Produkcja%20i%20koszty) – czynniki produkcji są rzadkimi zasobami.
- [MOC Rachunek kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunek%20koszt%C3%B3w) – koszt alternatywny i koszt relewantny to podstawa rachunków decyzyjnych.
