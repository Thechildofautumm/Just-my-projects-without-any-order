---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Konkurencja doskonała, monopolistyczna, oligopol, monopol; decyzje produkcyjne i efektywność.

## Formy rynku
- [[Struktura rynkowa]] – typologia rynków wg wpływu firmy na cenę `MI/EM`
- [[Koncentracja rynku]] – CR4 i wskaźnik Herfindahla-Hirschmana (HHI); progi struktur rynku `MI/EM`
- [[Konkurencja doskonała]] – założenia modelu, popyt firmy (P = MR), równowaga krótko- i długookresowa, cena wyjścia `MI/EM`
- [[Konkurencja monopolistyczna]] – wiele firm, produkt zróżnicowany, lekko opadający popyt; zysk znika w długim okresie `EM`
- [[Oligopol]] – kilka dużych firm, decyzje współzależne, wysokie bariery wejścia `EM`
- [[Model firmy dominującej]] – lider zachowuje się jak monopolista, mniejsze firmy jak cenobiorcy `EM`
- [[Model Cournota]] – jednoczesny wybór ilości; funkcje reakcji, równowaga z układu MR_i = MC_i `EM`
- [[Model Stackelberga]] – przywódca wybiera ilość pierwszy, znając funkcję reakcji naśladowcy `EM`
- [[Monopol pełny]] – założenia, źródła monopolu, popyt monopolu (P > MR) `MI/EM`
- [[Równowaga monopolu]] – MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży `MI/EM`
- [[Dyskryminacja cenowa]] – różne ceny tego samego produktu dla różnych nabywców `MI`

## Decyzje firmy i efektywność
- [[Maksymalizacja zysku]] – warunek MR = MC i warunek drugiego rzędu `MI/EM`
- [[Próg rentowności]] – BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC) `MI/EM/RZ`
- [[Punkt zamknięcia]] – P = AVCmin, strata = FC; reguła produkować czy zamknąć `MI/EM`
- [[Krzywa podaży przedsiębiorstwa]] – w KD to odcinek MC powyżej AVCmin; suma daje podaż gałęzi `MI`
- [[Nadwyżka konsumenta i producenta]] – korzyści netto kupujących i sprzedających; efektywność wymiany `MI`
- [[Strata społeczna monopolu]] – DWL i porównanie monopolu z konkurencją doskonałą `MI`

## Zadania
W tym obszarze jest **25 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Produkcja i koszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Produkcja%20i%20koszty) – porównanie ceny z ATC i AVC.
- [MOC Rynek, popyt i elastyczność](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rynek%2C%20popyt%20i%20elastyczno%C5%9B%C4%87) – MR = P w KD, MR < P w monopolu.
- [MOC Rachunek kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunek%20koszt%C3%B3w) – próg rentowności liczony przez marżę wkładu.
