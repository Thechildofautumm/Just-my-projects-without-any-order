---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Istota i konstrukcja podatku, system podatkowy, reakcje podatników i planowanie podatkowe.

## System podatkowy
- [[Podatek]] – przymusowe, bezzwrotne, nieodpłatne, ogólne świadczenie pieniężne na rzecz władzy publicznej `PD`
- [[Źródło prawa podatkowego]] – Konstytucja (art. 217), ustawy, umowy międzynarodowe, rozporządzenia, prawo miejscowe, prawo UE, orzecznictwo `PD`
- [[Danina publiczna]] – podatki, opłaty, cła, parapodatki – nazwa nie przesądza o charakterze `PD`
- [[Funkcja podatku]] – fiskalna, redystrybucyjna, alokacyjna, stabilizująca, informacyjna `PD`
- [[System podatkowy w Polsce]] – katalog podatków, tax mix, podział PIT i CIT z samorządami `PD`
- [[Klasyfikacja podatków]] – według przedmiotu, ponoszenia ciężaru (bezpośrednie/pośrednie) i adresata wpływów `PD`
- [[Element konstrukcji podatku]] – podmiot (czynny, bierny), przedmiot, podstawa, stawka i skala, preferencje, warunki zapłaty `PD`
- [[Preferencja podatkowa]] – ulga, zwolnienie, wyłączenie; tax expenditures `PD`
- [[Incydencja podatkowa]] – kto faktycznie ponosi ciężar podatku; podatnik formalny vs materialny; przerzucalność `PD`

## Zachowania podatników
- [[Reakcja podatnika na opodatkowanie]] – powstrzymanie, wycofanie, dostosowanie, nadrobienie, przerzucenie, unikanie, uchylanie `PD`
- [[Unikanie i uchylanie się od opodatkowania]] – legalne obniżanie obciążeń vs działania z naruszeniem prawa `PD`
- [[Korzyść podatkowa]] – brak lub obniżenie zobowiązania, nadpłata, zwrot, strata do odliczenia `PD`
- [[Moralność podatkowa]] – mentalność i moralność podatkowa, postawy Polaków, przyczyny lekceważenia obowiązków `PD`
- [[Arbitraż podatkowy]] – wykorzystanie różnic w opodatkowaniu podatników lub strumieni dochodu `PD`
- [[Planowanie podatkowe]] – uwzględnianie podatków w planowaniu finansowym; strategia podatkowa jako część strategii firmy `PD`

## Zadania
W tym obszarze jest **2 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Podatek dochodowy przedsiębiorstw](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podatek%20dochodowy%20przedsi%C4%99biorstw) – konstrukcja podatku w praktyce CIT.
- [MOC Rynek, popyt i elastyczność](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rynek%2C%20popyt%20i%20elastyczno%C5%9B%C4%87) – podatek jako interwencja na rynku i jego przerzucalność.
- [MOC Rachunkowość zarządcza](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza) – planowanie podatkowe jako część strategii przedsiębiorstwa.
