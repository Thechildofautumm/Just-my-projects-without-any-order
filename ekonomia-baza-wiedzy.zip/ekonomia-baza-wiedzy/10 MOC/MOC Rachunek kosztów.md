---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Klasyfikacja i zachowanie kosztów, szacowanie funkcji kosztów, RKZ/RKP, marże, ABC i TDABC.

## Pojęcia
- [[Klasyfikacja kosztów]] – „różne koszty do różnych celów” (Clark): rodzaj, funkcja, przypisanie, zachowanie, znaczenie dla decyzji, kontrolowalność `RZ`
- [[Koszt relewantny]] – przyszły koszt różnicowy; koszty utopione i stałe pomijamy w decyzji `RZ/EM`
- [[Hierarchia kosztów]] – poziom jednostki, partii, produktu, klienta i organizacji (Cooper) `RZ`
- [[Zachowanie kosztów]] – przedział istotności, koszty zaangażowane i uznaniowe, schodkowe, koszty sztywne (sticky costs) `RZ`
- [[Szacowanie funkcji kosztów]] – y = a + bx: analiza techniczna, kont, wielkości skrajnych, regresja (MNK) i jej ocena `RZ`
- [[Krzywa uczenia się]] – model Wrighta y = a·x^b, b = log r / log 2 `RZ`
- [[Rachunek kosztów zmiennych i pełnych]] – RKZ vs RKP: gdzie trafiają stałe koszty pośrednie; uzgodnienie wyników `RZ`
- [[Marża wkładu]] – cena − koszty zmienne; wielostopniowy rachunek marż `RZ`
- [[Rachunek kosztów działań]] – ABC: zasoby → działania → obiekty; nośniki kosztów, 5 kroków `RZ`
- [[Rachunek kosztów działań sterowany czasem]] – TDABC: stawka kosztu zdolności, równania czasu, koszt niewykorzystanych mocy `RZ`
- [[Rentowność klientów]] – krzywa wieloryba; działania wobec nierentownych klientów `RZ`

## Zadania
W tym obszarze jest **9 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Produkcja i koszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Produkcja%20i%20koszty) – koszty stałe/zmienne i koszt ekonomiczny w ujęciu mikro.
- [MOC Struktury rynkowe i decyzje firmy](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Struktury%20rynkowe%20i%20decyzje%20firmy) – marża wkładu i próg rentowności.
- [MOC Rachunkowość zarządcza](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza) – dlaczego różne koszty służą różnym celom.
