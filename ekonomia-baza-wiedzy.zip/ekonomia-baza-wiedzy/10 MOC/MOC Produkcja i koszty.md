---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Funkcja produkcji, optymalne zatrudnienie i kombinacja czynników, rodzaje kosztów, zysk ekonomiczny.

## Produkcja
- [[Funkcja produkcji]] – zależność produkcji od nakładów; krótki i długi okres `MI/EM`
- [[Produkt przeciętny i marginalny]] – TP, AP = Q/L, MP = Q′ i relacje między nimi `MI/EM`
- [[Prawo malejących przychodów]] – od pewnego poziomu nakładu MP maleje `MI/EM`
- [[Etapy produkcji]] – I, II, III etap wg AP i MP; racjonalny tylko II `MI/EM`
- [[Krańcowy przychód z pracy]] – MRP_L = MR · MP_L; optymalne zatrudnienie MRP_L = MC_L (w KD: P·MP_L = w) `EM`
- [[Efekty skali]] – reakcja produkcji na proporcjonalny wzrost wszystkich nakładów `MI`
- [[Izokwanta]] – kombinacje L i K dające tę samą produkcję `MI/EM`
- [[Krańcowa stopa technicznej substytucji]] – ile K można zastąpić jednostką L przy stałej produkcji `MI`
- [[Izokoszta]] – kombinacje L i K o tym samym koszcie: TC = wL + rK `MI/EM`
- [[Optimum producenta]] – styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu `MI/EM`

## Koszty i zysk
- [[Koszt księgowy a koszt ekonomiczny]] – koszty jawne vs jawne + ukryte (alternatywne) `MI/EM/RZ`
- [[Zysk ekonomiczny]] – π = TR − TC; zysk ekonomiczny, księgowy i normalny `MI/EM`
- [[Koszt stały i zmienny]] – FC, VC i TC = FC + VC w krótkim okresie `MI/EM/RZ`
- [[Koszt przeciętny]] – AFC, AVC, ATC – przebieg w kształcie U `MI/EM`
- [[Koszt marginalny]] – przyrost TC z dodatkowej jednostki: MC = TC′ `MI/EM`
- [[Koszty a produktywność]] – AVC = w/AP i MC = w/MP – lustrzane odbicie produkcji `MI/EM`

## Zadania
W tym obszarze jest **26 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Struktury rynkowe i decyzje firmy](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Struktury%20rynkowe%20i%20decyzje%20firmy) – krzywe kosztów wyznaczają decyzje firmy w każdej strukturze rynku.
- [MOC Rachunek kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunek%20koszt%C3%B3w) – ekonomiczne krzywe kosztów vs zarządcze funkcje kosztów.
- [MOC Podstawy gospodarowania i optymalizacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podstawy%20gospodarowania%20i%20optymalizacja) – koszt ekonomiczny zawiera koszty alternatywne.
