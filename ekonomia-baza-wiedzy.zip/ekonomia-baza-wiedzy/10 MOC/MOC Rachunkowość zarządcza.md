---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Istota, funkcje i organizacja rachunkowości zarządczej, rola i etyka kontrolera.

## Pojęcia
- [[Rachunkowość zarządcza]] – pozyskiwanie i wykorzystanie informacji finansowych i niefinansowych do decyzji i tworzenia wartości `RZ`
- [[Rachunkowość zarządcza a finansowa]] – adresat, regulacje, orientacja w czasie, miary, częstotliwość `RZ`
- [[Ewolucja rachunkowości zarządczej]] – cztery etapy IFAC i krytyka „Relevance Lost” (Johnson, Kaplan 1987) `RZ`
- [[Funkcja rachunkowości zarządczej]] – planowanie, decyzje, kontrola, motywowanie; cztery zasady CGMA `RZ`
- [[Rola kontrolera]] – rejestrowanie, kierowanie uwagi, rozwiązywanie problemów (Simon); partner biznesowy; kompetencje `RZ`
- [[Etyka kontrolera]] – kodeks IMA: uczciwość, rzetelność, obiektywizm, odpowiedzialność; typowe dylematy `RZ`
- [[Cyfryzacja i ESG w rachunkowości zarządczej]] – ERP, BI, planowanie oparte na czynnikach, AI; koszty środowiskowe, cena CO₂ `RZ`

## Zadania
W tym obszarze jest **0 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC Rachunek kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunek%20koszt%C3%B3w) – rachunek kosztów to główne narzędzie rachunkowości zarządczej.
- [MOC Podstawy gospodarowania i optymalizacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podstawy%20gospodarowania%20i%20optymalizacja) – rachunki decyzyjne opierają się na analizie marginalnej i kosztach alternatywnych.
- [MOC Podatek dochodowy przedsiębiorstw](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podatek%20dochodowy%20przedsi%C4%99biorstw) – funkcja finansowa łączy kontroling z księgowością i podatkami.
