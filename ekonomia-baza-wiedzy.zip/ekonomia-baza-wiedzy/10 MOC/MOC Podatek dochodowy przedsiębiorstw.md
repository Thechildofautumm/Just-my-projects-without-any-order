---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> CIT: źródła przychodów, mały podatnik, odliczenia i tarcza, straty, finansowanie a podatek.

## Podstawa i stawka
- [[Dochód podatkowy]] – przychody − koszty uzyskania przychodów (KUP) ze źródła; ujemny wynik = strata `PD`
- [[Źródło przychodów w CIT]] – zyski kapitałowe vs inne źródła; rodzaje spółek; stawki 19% i 9% `PD`
- [[Mały podatnik]] – przychody ze sprzedaży brutto ≤ 2 mln euro; kwartalne zaliczki, jednorazowa amortyzacja, 9% CIT `PD`
- [[Preferencyjna stawka CIT]] – 9% dla małych podatników poza zyskami kapitałowymi; wyłączenia, limity, strategie `PD`

## Odliczenia i straty
- [[Odliczenie podatkowe]] – na I etapie (od dochodu/podstawy) vs na II etapie (od podatku) `PD`
- [[Tarcza podatkowa]] – oszczędność podatkowa z odliczenia = odliczenie × stawka; od czego zależy `PD`
- [[Strata podatkowa]] – rozliczanie straty tylko w obrębie źródła (CIT i PIT); spółki transparentne `PD`
- [[Rozliczanie straty podatkowej w czasie]] – wprzód: 5 lat, max 50% rocznie albo jednorazowo do 5 mln zł; wstecz – wyjątki `PD`

## Finansowanie a podatek
- [[Asymetria podatkowa finansowania]] – odsetki są KUP, dywidendy nie → preferencja długu (debt-equity bias); CBIT `PD`
- [[Niedostateczna kapitalizacja]] – nadmierne finansowanie długiem wewnętrznym; tradycyjne przepisy (3× kapitał) `PD`
- [[Limit kosztów finansowania dłużnego]] – art. 15c: nadwyżka kosztów długu ponad max(3 mln zł; 30% EBITDA) jest NKUP; przeniesienie na 5 lat `PD`
- [[Hipotetyczne odsetki od kapitału własnego]] – NID (art. 15cb): stopa ref. NBP + 1 p.p., limit 250 000 zł, podejście przyrostowe `PD`

## Zadania
W tym obszarze jest **9 zadań** z rozwiązaniami. Każde zadanie jest przypięte do pojęcia, które ćwiczy – znajdziesz je w sekcji „Zadania” notatek powyżej, a pełną listę w [[Indeks zadań|indeksie zadań]].

## Powiązane obszary
- [MOC System podatkowy i zachowania podatników](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20System%20podatkowy%20i%20zachowania%20podatnik%C3%B3w) – elementy konstrukcji: podmiot, podstawa, stawka, ulgi.
- [MOC Produkcja i koszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Produkcja%20i%20koszty) – dochód podatkowy ≠ zysk ekonomiczny.
- [MOC Struktury rynkowe i decyzje firmy](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Struktury%20rynkowe%20i%20decyzje%20firmy) – stawka i tarcza zmieniają opłacalność decyzji firmy.
