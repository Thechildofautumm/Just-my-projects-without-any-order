---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
aliases: ["Pomoce do nauki"]
---
> [!abstract] Obszar
> Narzędzia do powtórki i nauki pod zaliczenie: wzory, słownik, schematy, fiszki, pytania egzaminacyjne, wykresy i kanwy oraz przewodniki po przedmiotach.

## Przewodniki po przedmiotach
- [[Przedmiot – Mikroekonomia]] – wykłady, pojęcia i zadania w kolejności kursu.
- [[Przedmiot – Ekonomia menedżerska]] – wykłady, pojęcia i zadania w kolejności kursu.
- [[Przedmiot – Rachunkowość zarządcza]] – wykłady, pojęcia i zadania w kolejności kursu.
- [[Przedmiot – Podatki i strategie podatkowe]] – wykłady, pojęcia i zadania w kolejności kursu.

## Pomoce
- [[Tabela wzorów]] – wszystkie wzory z czterech przedmiotów z odnośnikiem do pojęcia.
- [[Słownik pojęć]] – alfabetyczna lista pojęć z krótką definicją i synonimami.
- [[Schematy rozwiązywania zadań]] – procedury krok po kroku dla typowych zadań obliczeniowych.
- [[Indeks zadań]] – wszystkie zadania według obszarów i tematów, z pojęciem, do którego są przypięte.
- [[Fiszki]] – pytania i odpowiedzi do szybkiej powtórki, po sekcji na przedmiot.
- [[Bank pytań egzaminacyjnych]] – pytania testowe, otwarte i pułapki zebrane ze wszystkich notatek.
- [[Atlas wykresów]] – wszystkie wykresy w jednym miejscu, z odnośnikiem do notatki.
- [[Analogie konsument–producent]] – równoległa budowa teorii konsumenta i producenta.
- [[Te same pojęcia w różnych przedmiotach]] – mosty między mikroekonomią, ekonomią menedżerską, rachunkowością zarządczą i podatkami.

## Kanwy
- [[Mapa wiedzy.canvas|Mapa wiedzy]] – dziewięć obszarów wiedzy i powiązania między nimi.
- [[Decyzja firmy – produkować czy zamknąć.canvas|Decyzja firmy – produkować czy zamknąć]] – drzewo decyzji firmy w krótkim i długim okresie.
- [[Od przychodu do podatku CIT.canvas|Od przychodu do podatku CIT]] – kolejne kroki obliczania podatku dochodowego spółki i miejsca, w których działają strategie podatkowe.

## Powiązane obszary
- [MOC Struktury rynkowe i decyzje firmy](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Struktury%20rynkowe%20i%20decyzje%20firmy) – kanwa decyzji firmy i schematy zadań z decyzji produkcyjnych.
- [MOC Rachunek kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Rachunek%20koszt%C3%B3w) – schematy RKP/RKZ, ABC i TDABC oraz wzory rachunku kosztów.
- [MOC Podatek dochodowy przedsiębiorstw](obsidian://open?vault=ekonomia-baza-wiedzy&file=MOC%20Podatek%20dochodowy%20przedsi%C4%99biorstw) – kanwa obliczania CIT i schematy zadań podatkowych.
