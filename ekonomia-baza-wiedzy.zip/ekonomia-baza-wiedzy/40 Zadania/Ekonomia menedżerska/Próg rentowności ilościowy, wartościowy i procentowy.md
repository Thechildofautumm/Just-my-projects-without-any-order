---
typ: zadanie
up: "[[Próg rentowności]]"
przykład-z: ["Marża wkładu"]
powiązane: ["Próg rentowności przy liniowych kosztach"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Koszty stałe 12 000 zł, koszt zmienny jednostki 9 zł, cena 12 zł, zdolność produkcyjna 20 000 szt. Wyznacz próg rentowności w trzech ujęciach.

> [!success]- Rozwiązanie
> - ilościowy: $Q_{BEP} = \frac{12\,000}{12 - 9} = \mathbf{4000}$ szt.,
> - wartościowy: $12\cdot 4000 = \mathbf{48\,000}$ zł,
> - procentowy: $\frac{4000}{20\,000} = \mathbf{20\%}$ zdolności.
>
> $P - AVC = 3$ zł to jednostkowa marża wkładu (to samo narzędzie co w rachunkowości zarządczej).

## Jak to się łączy
To zadanie ćwiczy [[Próg rentowności]] (BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC)) oraz [Marża wkładu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mar%C5%BCa%20wk%C5%82adu) (cena − koszty zmienne; wielostopniowy rachunek marż). Podobny schemat rozwiązania ma zadanie [Próg rentowności przy liniowych kosztach](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci%20przy%20liniowych%20kosztach).
