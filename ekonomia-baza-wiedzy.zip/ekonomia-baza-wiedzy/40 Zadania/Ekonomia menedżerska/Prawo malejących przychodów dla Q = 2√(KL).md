---
typ: zadanie
up: "[[Prawo malejących przychodów]]"
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Funkcja produkcji: $Q = 2\sqrt{KL}$, w krótkim okresie $K = 9$. Czy obowiązuje prawo malejących przychodów pracy?

> [!success]- Rozwiązanie
> $MP_L = \frac{\partial Q}{\partial L} = \frac{\sqrt K}{\sqrt L} = \frac{3}{\sqrt L}$.
>
> | $L$ | 1 | 4 | 9 |
> |---|---|---|---|
> | $MP_L$ | 3 | 1,5 | 1 |
>
> $MP_L$ maleje od pierwszej jednostki pracy ($\frac{\partial^2 Q}{\partial L^2} < 0$) → **prawo obowiązuje**.

## Jak to się łączy
To zadanie ćwiczy [[Prawo malejących przychodów]] (od pewnego poziomu nakładu MP maleje).
