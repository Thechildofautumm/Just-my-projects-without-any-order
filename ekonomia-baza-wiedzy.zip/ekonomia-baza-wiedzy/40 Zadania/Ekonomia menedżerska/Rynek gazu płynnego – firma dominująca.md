---
typ: zadanie
up: "[[Model firmy dominującej]]"
powiązane: ["Model firmy dominującej – cena i podział rynku"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt rynkowy na gaz płynny: $P = -0{,}01Q + 15$. Lider: $TC = 0{,}01q^2 + 3q + 20$, popyt rezydualny $P = -0{,}02q + 12$. Wyznacz cenę, sprzedaż lidera i pozostałych firm oraz udział lidera.

> [!success]- Rozwiązanie
> $MR = 12 - 0{,}04q$, $MC = 0{,}02q + 3$ → $9 = 0{,}06q \Rightarrow q = \mathbf{150}$; $P = 12 - 3 = \mathbf{9}$.
> Rynek: $9 = -0{,}01Q + 15 \Rightarrow Q = \mathbf{600}$; pozostali: $\mathbf{450}$; udział lidera $\mathbf{25\%}$.

## Jak to się łączy
To zadanie ćwiczy [[Model firmy dominującej]] (lider zachowuje się jak monopolista, mniejsze firmy jak cenobiorcy). Podobny schemat rozwiązania ma zadanie [Model firmy dominującej – cena i podział rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20firmy%20dominuj%C4%85cej%20%E2%80%93%20cena%20i%20podzia%C5%82%20rynku).
