---
typ: zadanie
up: "[[Optimum producenta]]"
powiązane: ["Najtańsza kombinacja nakładów dla Q = 50√(LK)"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = 60L^{0{,}25}K^{0{,}75}$, płaca 150, cena kapitału 50. Jaka kombinacja nakładów pozwoli wytworzyć ok. 3118 sztuk najtaniej?

> [!success]- Rozwiązanie
> $\frac{MP_L}{MP_K} = \frac{0{,}25K}{0{,}75L} = \frac{w}{r} = 3 \Rightarrow K = 9L$.
> $Q = 60L^{0{,}25}(9L)^{0{,}75} = 60\cdot 9^{0{,}75}L \approx 311{,}8L = 3118 \Rightarrow L \approx \mathbf{10}$, $K \approx \mathbf{90}$.
> $TC = 150\cdot 10 + 50\cdot 90 = \mathbf{6000}$ (na kapitał idzie ¾ kosztów – zgodnie z wykładnikiem).

## Jak to się łączy
To zadanie ćwiczy [[Optimum producenta]] (styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu). Podobny schemat rozwiązania ma zadanie [Najtańsza kombinacja nakładów dla Q = 50√(LK)](obsidian://open?vault=ekonomia-baza-wiedzy&file=Najta%C5%84sza%20kombinacja%20nak%C5%82ad%C3%B3w%20dla%20Q%20%3D%2050%E2%88%9A%28LK%29).
