---
typ: zadanie
up: "[[Krańcowy przychód z pracy]]"
powiązane: ["Kawiarnia – optymalne zatrudnienie"]
źródło: ["[[EM – Produkcja i koszty]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = 80L - L^2$ ($L$ – roboczogodziny), cena produktu 3 zł, koszt roboczogodziny 30 zł. Ile roboczogodzin zaangażować? Jaka będzie produkcja i nadwyżka przychodu nad kosztem pracy?

> [!success]- Rozwiązanie
> $MRP_L = 3(80 - 2L) = 240 - 6L = 30 \Rightarrow L = \mathbf{35}$.
> $Q = 2800 - 1225 = \mathbf{1575}$; $\pi = 3\cdot 1575 - 30\cdot 35 = 4725 - 1050 = \mathbf{3675}$ zł.

## Jak to się łączy
To zadanie ćwiczy [[Krańcowy przychód z pracy]] (MRP_L = MR · MP_L; optymalne zatrudnienie MRP_L = MC_L (w KD: P·MP_L = w)). Podobny schemat rozwiązania ma zadanie [Kawiarnia – optymalne zatrudnienie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kawiarnia%20%E2%80%93%20optymalne%20zatrudnienie).
