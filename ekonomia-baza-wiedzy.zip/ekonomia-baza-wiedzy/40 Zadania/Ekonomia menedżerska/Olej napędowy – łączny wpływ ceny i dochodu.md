---
typ: zadanie
up: "[[Elastyczność cenowa popytu]]"
przykład-z: ["Elastyczność dochodowa popytu", "Elastyczność popytu"]
powiązane: ["Miesięcznik podróżniczy – elastyczności mieszane"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Elastyczność cenowa popytu na olej napędowy wynosi −0,25, a dochodowa 0,3. Cena spadnie o 8%, a dochody wzrosną o 5%. Jak zmieni się sprzedaż?

> [!success]- Rozwiązanie
> Cena: $-0{,}25\cdot(-8\%) = +2\%$; dochód: $0{,}3\cdot 5\% = +1{,}5\%$.
> Łącznie $\%\Delta Q \approx \mathbf{+3{,}5\%}$ – popyt nieelastyczny, więc sprzedaż zmienia się słabiej niż jej determinanty.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność cenowa popytu]] (reakcja popytu na cenę własną; klasyfikacja i determinanty), [Elastyczność dochodowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu) (reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe) oraz [Elastyczność popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu) (ogólna miara: % zmiany popytu / % zmiany czynnika; trzy rodzaje). Podobny schemat rozwiązania ma zadanie [Miesięcznik podróżniczy – elastyczności mieszane](obsidian://open?vault=ekonomia-baza-wiedzy&file=Miesi%C4%99cznik%20podr%C3%B3%C5%BCniczy%20%E2%80%93%20elastyczno%C5%9Bci%20mieszane).
