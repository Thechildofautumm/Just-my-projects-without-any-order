---
typ: zadanie
up: "[[Elastyczność mieszana popytu]]"
przykład-z: ["Elastyczność cenowa popytu"]
powiązane: ["Olej napędowy – łączny wpływ ceny i dochodu"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Elastyczności popytu na miesięcznik: cenowa −0,6; mieszana względem ceny konkurencyjnego miesięcznika 1,5; mieszana względem ceny przewodników turystycznych −0,4. Wydawca obniża cenę o 10%, konkurent obniża cenę o 12%, a przewodniki tanieją o 15%. Jak zmieni się popyt?

> [!success]- Rozwiązanie
> - cena własna: $-0{,}6\cdot(-10\%) = +6\%$,
> - konkurent (substytut): $1{,}5\cdot(-12\%) = -18\%$,
> - przewodniki (komplement): $-0{,}4\cdot(-15\%) = +6\%$.
>
> $\%\Delta Q = 6\% - 18\% + 6\% = \mathbf{-6\%}$ – tańszy substytut „zjada” efekt własnej obniżki.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność mieszana popytu]] (reakcja popytu na X na cenę Y; rozpoznaje substytuty i komplementy) oraz [Elastyczność cenowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu) (reakcja popytu na cenę własną; klasyfikacja i determinanty). Podobny schemat rozwiązania ma zadanie [Olej napędowy – łączny wpływ ceny i dochodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Olej%20nap%C4%99dowy%20%E2%80%93%20%C5%82%C4%85czny%20wp%C5%82yw%20ceny%20i%20dochodu).
