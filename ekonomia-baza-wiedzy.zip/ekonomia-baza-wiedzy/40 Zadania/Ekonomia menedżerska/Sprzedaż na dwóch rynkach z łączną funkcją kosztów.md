---
typ: zadanie
up: "[[Optymalizacja funkcji dwóch zmiennych]]"
przykład-z: ["Dyskryminacja cenowa"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na dwóch rynkach: $P_x = 100 - Q_x$, $P_y = 60 - 2Q_y$. Koszt: $TC = 50 + 14Q_x + 16Q_y + 9Q_x^2 + 4Q_y^2 + 2Q_xQ_y$. Wyznacz ilości, ceny i zysk.

> [!success]- Rozwiązanie
> $\Pi = 86Q_x - 10Q_x^2 + 44Q_y - 6Q_y^2 - 2Q_xQ_y - 50$.
> $\Pi_x = 86 - 20Q_x - 2Q_y = 0$; $\Pi_y = 44 - 12Q_y - 2Q_x = 0 \Rightarrow Q_x = 22 - 6Q_y$.
> $86 - 440 + 120Q_y - 2Q_y = 0 \Rightarrow Q_y = \mathbf{3}$, $Q_x = \mathbf{4}$.
> Hesjan: $-20$, $-12$, $-2$; $\det = 240 - 4 = 236 > 0$ → maksimum.
> Ceny: $P_x = 96$, $P_y = 54$; $\Pi = 344 - 160 + 132 - 54 - 24 - 50 = \mathbf{188}$. Różne ceny na rynkach – segmentacja (dyskryminacja III stopnia).

## Jak to się łączy
To zadanie ćwiczy [[Optymalizacja funkcji dwóch zmiennych]] (pochodne cząstkowe = 0, drugie pochodne < 0, wyznacznik hesjanu > 0) oraz [Dyskryminacja cenowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dyskryminacja%20cenowa) (różne ceny tego samego produktu dla różnych nabywców).
