---
typ: zadanie
up: "[[Zysk marginalny]]"
przykład-z: ["Maksymalizacja zysku"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Wyznacz produkcję maksymalizującą zysk i największy zysk (sprawdź warunek wystarczający):
a) $P = -Q + 20$, $TC = 0{,}5Q^2 + 2Q$;
b) $P = -200Q + 8000$, $TC = 300Q^2 + 1000Q + 20\,000$.

> [!success]- Rozwiązanie
> **a)** $\Pi = 20Q - Q^2 - 0{,}5Q^2 - 2Q = -1{,}5Q^2 + 18Q$; $M\Pi = -3Q + 18 = 0 \Rightarrow Q^* = \mathbf{6}$; $\Pi'' = -3 < 0$.
> $P = 14$, $\Pi_{max} = -54 + 108 = \mathbf{54}$.
> **b)** $\Pi = -500Q^2 + 7000Q - 20\,000$; $M\Pi = -1000Q + 7000 = 0 \Rightarrow Q^* = \mathbf{7}$; $\Pi'' = -1000 < 0$.
> $P = 6600$, $\Pi_{max} = -24\,500 + 49\,000 - 20\,000 = \mathbf{4500}$.
> Kontrola b): $MR = 8000 - 400\cdot 7 = 5200$, $MC = 600\cdot 7 + 1000 = 5200$ ✔

## Jak to się łączy
To zadanie ćwiczy [[Zysk marginalny]] (MΠ = MR − MC; warunek konieczny MΠ = 0 i wystarczający Π″ < 0) oraz [Maksymalizacja zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) (warunek MR = MC i warunek drugiego rzędu).
