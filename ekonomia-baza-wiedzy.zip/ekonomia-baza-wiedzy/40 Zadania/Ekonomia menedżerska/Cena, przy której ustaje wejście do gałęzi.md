---
typ: zadanie
up: "[[Konkurencja doskonała]]"
powiązane: ["Cena wyjścia z gałęzi w długim okresie"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Długookresowy koszt każdej z identycznych firm w konkurencji doskonałej: $TC = 0{,}2Q^3 - 4Q^2 + 50Q$. Przy jakiej cenie przestaną wchodzić nowe firmy?

> [!success]- Rozwiązanie
> W długim okresie $P = AC_{min}$. $AC = 0{,}2Q^2 - 4Q + 50$; $AC' = 0{,}4Q - 4 = 0 \Rightarrow Q = 10$.
> $AC(10) = 20 - 40 + 50 = \mathbf{30}$ → przy $P \le 30$ wejście ustaje.

## Jak to się łączy
To zadanie ćwiczy [[Konkurencja doskonała]] (założenia modelu, popyt firmy (P = MR), równowaga krótko- i długookresowa, cena wyjścia). Podobny schemat rozwiązania ma zadanie [Cena wyjścia z gałęzi w długim okresie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%20wyj%C5%9Bcia%20z%20ga%C5%82%C4%99zi%20w%20d%C5%82ugim%20okresie).
