---
typ: zadanie
up: "[[Maksymalizacja przychodu]]"
przykład-z: ["Elastyczność a przychód"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Armator obsługujący linię promową ponosi praktycznie tylko koszty stałe (rejs odbywa się niezależnie od liczby pasażerów).
a) Czy maksymalizacja zysku oznacza tu maksymalizację przychodu?
b) Przy obecnej cenie biletu elastyczność cenowa popytu wynosi −0,6. Co zrobić z ceną?

> [!success]- Rozwiązanie
> **a)** Tak – przy $MC = 0$ warunek $MR = MC$ to $MR = 0$, czyli maksimum przychodu.
> **b)** $|E_p| = 0{,}6 < 1$ – popyt **nieelastyczny**: po podwyżce liczba pasażerów spadnie procentowo mniej, niż wzrośnie cena, więc przychód wzrośnie. Należy **podnieść cenę** – aż do poziomu, przy którym $E_p = -1$.

## Jak to się łączy
To zadanie ćwiczy [[Maksymalizacja przychodu]] (TR max przy MR = 0 (Ep = −1); kiedy pokrywa się z maksymalizacją zysku) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe).
