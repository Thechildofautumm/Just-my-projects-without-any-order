---
typ: zadanie
up: "[[Optymalizacja funkcji dwóch zmiennych]]"
powiązane: ["Cena i budżet reklamowy – zysk z dwiema zmiennymi"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Firma wytwarza dwa produkty w ilościach $x$ i $y$. Wyznacz ilości maksymalizujące zysk i zysk:
a) $\Pi = -x^3 - 2y^3 + 12x + 24y$;
b) $\Pi = 80x - 2x^2 + 2xy - 3y^2 + 40y - 20$.

> [!success]- Rozwiązanie
> Warunki: $\Pi_x = \Pi_y = 0$; $\Pi_{xx} < 0$, $\Pi_{yy} < 0$; wyznacznik hesjanu $\Pi_{xx}\Pi_{yy} - \Pi_{xy}^2 > 0$.
> **a)** $\Pi_x = -3x^2 + 12 = 0 \Rightarrow x = 2$; $\Pi_y = -6y^2 + 24 = 0 \Rightarrow y = 2$.
> $\Pi_{xx} = -12$, $\Pi_{yy} = -24$, $\Pi_{xy} = 0$, $\det = 288 > 0$ ✔. $\Pi = -8 - 16 + 24 + 48 = \mathbf{48}$.
> **b)** $\Pi_x = 80 - 4x + 2y = 0$, $\Pi_y = 2x - 6y + 40 = 0 \Rightarrow x = 3y - 20$.
> $80 - 12y + 80 + 2y = 0 \Rightarrow y = \mathbf{16}$, $x = \mathbf{28}$.
> $\Pi_{xx} = -4$, $\Pi_{yy} = -6$, $\Pi_{xy} = 2$, $\det = 24 - 4 = 20 > 0$ ✔.
> $\Pi = 2240 - 1568 + 896 - 768 + 640 - 20 = \mathbf{1420}$.

## Jak to się łączy
To zadanie ćwiczy [[Optymalizacja funkcji dwóch zmiennych]] (pochodne cząstkowe = 0, drugie pochodne < 0, wyznacznik hesjanu > 0). Podobny schemat rozwiązania ma zadanie [Cena i budżet reklamowy – zysk z dwiema zmiennymi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%20i%20bud%C5%BCet%20reklamowy%20%E2%80%93%20zysk%20z%20dwiema%20zmiennymi).
