---
typ: zadanie
up: "[[Zysk marginalny]]"
przykład-z: ["Analiza marginalna"]
źródło: ["[[EM – Wprowadzenie, analiza marginalna]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
a) Do czego służy analiza marginalna i jaką regułą kieruje się w niej decydent?
b) Wyznacz funkcje marginalne dla: $TC(Q) = 4Q^2 + 200Q + 1800$, $TR(Q) = -5Q^2 + 1000Q$, $Q(L) = -3L^3 + 45L^2 + 6000L$, $\Pi(Q) = -0{,}8Q^2 + 320Q - 2000$.
c) Zapisz warunek konieczny i wystarczający maksimum zysku z jedną zmienną i zastosuj je do funkcji $\Pi(Q)$ z punktu b).

> [!success]- Rozwiązanie
> **a)** Analiza marginalna służy do wyboru optymalnej skali działania. Porównuje się skutki **ostatniej** (dodatkowej) jednostki: przychód krańcowy $MR$, koszt krańcowy $MC$ i zysk krańcowy $M\Pi$. Reguła: zwiększaj działalność, dopóki dodatkowa jednostka podnosi wynik; zatrzymaj się, gdy przestaje.
> **b)**
>
> | Funkcja całkowita | Funkcja marginalna |
> |---|---|
> | $TC = 4Q^2 + 200Q + 1800$ | $MC = 8Q + 200$ |
> | $TR = -5Q^2 + 1000Q$ | $MR = -10Q + 1000$ |
> | $Q = -3L^3 + 45L^2 + 6000L$ | $MP_L = -9L^2 + 90L + 6000$ |
> | $\Pi = -0{,}8Q^2 + 320Q - 2000$ | $M\Pi = -1{,}6Q + 320$ |
>
> **c)** Warunek konieczny: $M\Pi = 0 \iff MR = MC$. Warunek wystarczający: $\Pi'' < 0$ (zysk jest funkcją wklęsłą, czyli $MR' < MC'$).
> $-1{,}6Q + 320 = 0 \Rightarrow Q^* = 200$; $\Pi'' = -1{,}6 < 0$ → maksimum; $\Pi_{max} = -32\,000 + 64\,000 - 2000 = \mathbf{30\,000}$.

## Jak to się łączy
To zadanie ćwiczy [[Zysk marginalny]] (MΠ = MR − MC; warunek konieczny MΠ = 0 i wystarczający Π″ < 0) oraz [Analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) (porównywanie korzyści i kosztów ostatniej jednostki; optimum MB = MC).
