---
typ: zadanie
up: "[[Optimum producenta]]"
powiązane: ["Najtańsza technika dla funkcji Cobba-Douglasa"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = 50\sqrt{LK}$. Wyznacz najtańszy sposób wytworzenia 2000 sztuk przy płacy 30 i cenie kapitału 120.

> [!success]- Rozwiązanie
> $\frac{K}{L} = \frac{w}{r} = \frac{30}{120} \Rightarrow L = 4K$; $50\sqrt{4K^2} = 100K = 2000 \Rightarrow K = \mathbf{20}$, $L = \mathbf{80}$.
> $TC = 30\cdot 80 + 120\cdot 20 = \mathbf{4800}$ (wydatki na oba czynniki równe).

## Jak to się łączy
To zadanie ćwiczy [[Optimum producenta]] (styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu). Podobny schemat rozwiązania ma zadanie [Najtańsza technika dla funkcji Cobba-Douglasa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Najta%C5%84sza%20technika%20dla%20funkcji%20Cobba-Douglasa).
