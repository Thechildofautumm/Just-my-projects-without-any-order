---
typ: zadanie
up: "[[Krańcowy przychód z pracy]]"
przykład-z: ["Prawo malejących przychodów"]
powiązane: ["Optymalna liczba roboczogodzin z MRP"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Produkcja kawiarni: $Q = 40L - L^2$ (napoje dziennie, $L$ – baristów). Napój kosztuje 5 zł (przychód netto), dniówka baristy 50 zł.
a) Czy działa prawo malejących przychodów? b) Ilu baristów zatrudnić?

> [!success]- Rozwiązanie
> **a)** $MP_L = 40 - 2L$ maleje → **tak**.
> **b)** $MRP_L = 5(40 - 2L) = 50 \Rightarrow L = \mathbf{15}$; $Q = 600 - 225 = 375$ napojów.

## Jak to się łączy
To zadanie ćwiczy [[Krańcowy przychód z pracy]] (MRP_L = MR · MP_L; optymalne zatrudnienie MRP_L = MC_L (w KD: P·MP_L = w)) oraz [Prawo malejących przychodów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Prawo%20malej%C4%85cych%20przychod%C3%B3w) (od pewnego poziomu nakładu MP maleje). Podobny schemat rozwiązania ma zadanie [Optymalna liczba roboczogodzin z MRP](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optymalna%20liczba%20roboczogodzin%20z%20MRP).
