---
typ: zadanie
up: "[[Optymalizacja funkcji dwóch zmiennych]]"
powiązane: ["Zysk z dwóch produktów – optymalizacja dwóch zmiennych"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Zysk sklepu internetowego zależy od ceny $P$ i wydatków na reklamę $A$: $\Pi = 30 + 4P - 2P^2 + 6A - A^2 + 2PA$. Wyznacz cenę i wydatki na reklamę maksymalizujące zysk.

> [!success]- Rozwiązanie
> $\Pi_P = 4 - 4P + 2A = 0$, $\Pi_A = 6 - 2A + 2P = 0 \Rightarrow A = 3 + P$.
> $4 - 4P + 6 + 2P = 0 \Rightarrow P^* = \mathbf{5}$, $A^* = \mathbf{8}$.
> Hesjan: $-4$, $-2$, $\Pi_{PA} = 2$; $\det = 8 - 4 = 4 > 0$ → maksimum.
> $\Pi_{max} = 30 + 20 - 50 + 48 - 64 + 80 = \mathbf{64}$.
> Składnik $2PA$ oznacza, że reklama podnosi opłacalną cenę – obie decyzje trzeba podejmować razem.

## Jak to się łączy
To zadanie ćwiczy [[Optymalizacja funkcji dwóch zmiennych]] (pochodne cząstkowe = 0, drugie pochodne < 0, wyznacznik hesjanu > 0). Podobny schemat rozwiązania ma zadanie [Zysk z dwóch produktów – optymalizacja dwóch zmiennych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20z%20dw%C3%B3ch%20produkt%C3%B3w%20%E2%80%93%20optymalizacja%20dw%C3%B3ch%20zmiennych).
