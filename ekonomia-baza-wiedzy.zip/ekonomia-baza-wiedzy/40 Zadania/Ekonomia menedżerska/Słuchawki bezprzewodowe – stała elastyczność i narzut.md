---
typ: zadanie
up: "[[Funkcja popytu o stałej elastyczności]]"
przykład-z: ["Narzut ceny na koszt krańcowy"]
powiązane: ["Kawa mrożona – potęgowa funkcja popytu"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na słuchawki: $Q = 20P^{-3}$.
a) Czy popyt jest elastyczny? b) Jak 10-procentowa podwyżka wpłynie na sprzedaż?
c) Jaki narzut na koszt krańcowy jest optymalny? d) Wyznacz cenę przy $TC = 200Q + 800$.

> [!success]- Rozwiązanie
> **a)** $E_p = -3$ w każdym punkcie – popyt **elastyczny**.
> **b)** $\%\Delta Q \approx -3\cdot 10\% = \mathbf{-30\%}$.
> **c)** $\frac{E_p}{E_p + 1} = \frac{-3}{-2} = \mathbf{1{,}5}$ – cena o 50% wyższa od $MC$.
> **d)** $MC = 200 \Rightarrow P = \mathbf{300}$.

## Jak to się łączy
To zadanie ćwiczy [[Funkcja popytu o stałej elastyczności]] (Q = k·P^α: elastyczności równe wykładnikom potęg) oraz [Narzut ceny na koszt krańcowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Narzut%20ceny%20na%20koszt%20kra%C5%84cowy) (P = MC · Ep/(Ep + 1): cena maksymalizująca zysk). Podobny schemat rozwiązania ma zadanie [Kawa mrożona – potęgowa funkcja popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kawa%20mro%C5%BCona%20%E2%80%93%20pot%C4%99gowa%20funkcja%20popytu).
