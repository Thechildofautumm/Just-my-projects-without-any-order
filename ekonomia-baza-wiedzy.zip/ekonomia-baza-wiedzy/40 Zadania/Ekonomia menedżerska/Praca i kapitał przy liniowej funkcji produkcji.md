---
typ: zadanie
up: "[[Metoda mnożników Lagrange'a]]"
przykład-z: ["Optimum producenta"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Produkcja: $Q = 3L + 2K$; płaca 4, koszt jednostki kapitału 1, cena produktu 6.
a) Zapisz zysk jako funkcję $L$ i $K$.
b) Czy istnieje maksimum zysku bez ograniczeń?
c) Koszt nie może przekroczyć 120. Jak rozdzielić budżet i jaki będzie zysk?

> [!success]- Rozwiązanie
> **a)** $\Pi = 6(3L + 2K) - 4L - K = \mathbf{14L + 11K}$.
> **b)** $\Pi_L = 14 > 0$, $\Pi_K = 11 > 0$ – zysk rośnie bez końca, **maksimum nie istnieje** (funkcja liniowa).
> **c)** Ograniczenie $4L + K \le 120$. Zysk na 1 zł kosztu: praca $14/4 = 3{,}5$, kapitał $11/1 = 11$ → cały budżet na kapitał: $K = \mathbf{120}$, $L = \mathbf{0}$, $Q = 240$, $\Pi = \mathbf{1320}$ (rozwiązanie narożne).

## Jak to się łączy
To zadanie ćwiczy [[Metoda mnożników Lagrange'a]] (maksymalizacja funkcji celu przy ograniczeniu: Z = f + λg) oraz [Optimum producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20producenta) (styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu).
