---
typ: zadanie
up: "[[Funkcja popytu wielu zmiennych]]"
przykład-z: ["Substytucyjność i komplementarność dóbr"]
powiązane: ["Truskawki – różniczka zupełna popytu"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na krem z filtrem: $Q = -30P + 2I + 25P_s - 10P_k + 0{,}1A + 500$ ($P_s$ – cena kremu konkurencji, $P_k$ – cena okularów przeciwsłonecznych, $A$ – reklama). Oblicz łączny wpływ: cena +4 zł, dochód +300 zł, cena konkurencji −2 zł, cena okularów −6 zł, reklama +8000 zł.

> [!success]- Rozwiązanie
>
> | Determinanta | Pochodna | Zmiana | Wpływ |
> |---|---|---|---|
> | cena własna | −30 | +4 | −120 |
> | dochód | 2 | +300 | +600 |
> | cena substytutu | 25 | −2 | −50 |
> | cena komplementu | −10 | −6 | +60 |
> | reklama | 0,1 | +8000 | +800 |
> | **razem** | | | **+1290** |
>
> Popyt **wzrośnie o 1290 sztuk**.

## Jak to się łączy
To zadanie ćwiczy [[Funkcja popytu wielu zmiennych]] (Q = f(P, I, Py, N, A…); łączna zmiana popytu z różniczki zupełnej) oraz [Substytucyjność i komplementarność dóbr](obsidian://open?vault=ekonomia-baza-wiedzy&file=Substytucyjno%C5%9B%C4%87%20i%20komplementarno%C5%9B%C4%87%20d%C3%B3br) (dobra zastępujące się i uzupełniające się). Podobny schemat rozwiązania ma zadanie [Truskawki – różniczka zupełna popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Truskawki%20%E2%80%93%20r%C3%B3%C5%BCniczka%20zupe%C5%82na%20popytu).
