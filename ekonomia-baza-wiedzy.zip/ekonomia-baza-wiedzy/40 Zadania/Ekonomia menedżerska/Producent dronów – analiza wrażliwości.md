---
typ: zadanie
up: "[[Analiza wrażliwości]]"
powiązane: ["Producent dronów – funkcja zysku"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Jak zmieni się optymalna decyzja producenta dronów (popyt $P = 210 - 25Q$, koszt partii 60, koszty stałe 150), jeśli:
a) koszty stałe wzrosną do 170,
b) koszt partii wzrośnie do 70,
c) popyt wzrośnie do $P = 240 - 25Q$?

> [!success]- Rozwiązanie
>
> | Wariant | Funkcja zysku | $Q^*$ | $P^*$ | $\Pi_{max}$ |
> |---|---|---|---|---|
> | bazowy | $-25Q^2 + 150Q - 150$ | 3 | 135 | 75 |
> | a) FC = 170 | $-25Q^2 + 150Q - 170$ | **3** | 135 | **55** |
> | b) MC = 70 | $-25Q^2 + 140Q - 150$ | **2,8** | **140** | **46** |
> | c) wyższy popyt | $-25Q^2 + 180Q - 150$ | **3,6** | **150** | **174** |
>
> - koszty **stałe** nie zmieniają $M\Pi$, więc nie zmieniają $Q^*$ ani ceny – tylko obniżają zysk,
> - wyższy koszt **krańcowy** zmniejsza produkcję i podnosi cenę,
> - wyższy **popyt** zwiększa produkcję, cenę i zysk.

## Jak to się łączy
To zadanie ćwiczy [[Analiza wrażliwości]] (jak zmienia się optimum i zysk przy zmianie kosztów stałych, zmiennych lub popytu). Podobny schemat rozwiązania ma zadanie [Producent dronów – funkcja zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producent%20dron%C3%B3w%20%E2%80%93%20funkcja%20zysku).
