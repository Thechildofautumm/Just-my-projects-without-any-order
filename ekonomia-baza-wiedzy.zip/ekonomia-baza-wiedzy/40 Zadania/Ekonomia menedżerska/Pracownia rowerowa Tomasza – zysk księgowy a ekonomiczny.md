---
typ: zadanie
up: "[[Koszt księgowy a koszt ekonomiczny]]"
przykład-z: ["Zysk ekonomiczny"]
powiązane: ["Food truck – przy jakiej stopie procentowej się opłaca"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Tomasz prowadzi pracownię rowerową. Przychody roczne: 160 000 zł, wydatki: 90 000 zł. Pracownia mieści się w jego garażu, który mógłby wynająć za 24 000 zł rocznie. Zainwestował 80 000 zł oszczędności (lokata dałaby 8%). Na etacie zarabiałby 45 000 zł.
a) Oblicz zysk księgowy, koszty niejawne i zysk ekonomiczny.
b) Czy prowadzenie pracowni się opłaca?

> [!success]- Rozwiązanie
>
> | Pozycja | Kwota |
> |---|---|
> | przychody | 160 000 |
> | koszty jawne | 90 000 |
> | **zysk księgowy** | **70 000** |
> | utracony czynsz | 24 000 |
> | utracone odsetki (8% × 80 000) | 6 400 |
> | utracona pensja | 45 000 |
> | **koszty niejawne** | **75 400** |
> | **zysk ekonomiczny** | **−5 400** |
>
> **b)** Mimo zysku księgowego firma przynosi **stratę ekonomiczną** – najlepsza alternatywa (wynajem, lokata, etat) dałaby o 5400 zł więcej.

## Jak to się łączy
To zadanie ćwiczy [[Koszt księgowy a koszt ekonomiczny]] (koszty jawne vs jawne + ukryte (alternatywne)) oraz [Zysk ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny) (π = TR − TC; zysk ekonomiczny, księgowy i normalny). Podobny schemat rozwiązania ma zadanie [Food truck – przy jakiej stopie procentowej się opłaca](obsidian://open?vault=ekonomia-baza-wiedzy&file=Food%20truck%20%E2%80%93%20przy%20jakiej%20stopie%20procentowej%20si%C4%99%20op%C5%82aca).
