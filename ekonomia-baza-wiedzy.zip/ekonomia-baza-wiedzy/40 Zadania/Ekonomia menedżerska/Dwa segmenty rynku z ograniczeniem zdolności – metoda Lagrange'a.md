---
typ: zadanie
up: "[[Metoda mnożników Lagrange'a]]"
źródło: ["[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Firma sprzedaje produkt w dwóch segmentach ($Q_1$, $Q_2$ w tys. szt.) i może wyprodukować najwyżej 40 tys. sztuk. Zysk: $\Pi = (30Q_1 - 0{,}5Q_1^2) + (50Q_2 - Q_2^2)$. Wyznacz rozwiązanie optymalne i zinterpretuj mnożnik.

> [!success]- Rozwiązanie
> Bez ograniczenia: $Q_1 = 30$, $Q_2 = 25$ → razem 55 > 40, więc ograniczenie **wiąże**.
> $Z = 30Q_1 - 0{,}5Q_1^2 + 50Q_2 - Q_2^2 + \lambda(40 - Q_1 - Q_2)$.
> $Z_{Q_1} = 30 - Q_1 - \lambda = 0$; $Z_{Q_2} = 50 - 2Q_2 - \lambda = 0$; $Q_1 + Q_2 = 40$.
> Zysk krańcowy w obu segmentach musi być równy: $30 - Q_1 = 50 - 2Q_2$; z $Q_1 = 40 - Q_2$: $3Q_2 = 60 \Rightarrow Q_2 = \mathbf{20}$, $Q_1 = \mathbf{20}$, $\lambda = \mathbf{10}$.
> $\Pi = 400 + 600 = \mathbf{1000}$. Zwiększenie zdolności o 1 tys. szt. podniosłoby zysk o ok. 10.

## Jak to się łączy
To zadanie ćwiczy [[Metoda mnożników Lagrange'a]] (maksymalizacja funkcji celu przy ograniczeniu: Z = f + λg).
