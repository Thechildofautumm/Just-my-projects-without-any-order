---
typ: zadanie
up: "[[Koszt stały i zmienny]]"
przykład-z: ["Punkt zamknięcia"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TC = 0{,}5Q^2 + 8Q + 200$, popyt $P = -0{,}5Q + 48$.
a) Wyznacz produkcję i cenę maksymalizujące zysk. b) Ile wynosi zysk?
c) Koszty stałe rosną o 250 zł. Czy zmieni się optymalna produkcja? d) Czy kontynuować działalność?

> [!success]- Rozwiązanie
> **a)** $MR = 48 - Q$, $MC = Q + 8$ → $Q = \mathbf{20}$, $P = \mathbf{38}$.
> **b)** $TR = 760$, $TC = 200 + 160 + 200 = 560$ → **zysk 200**.
> **c)** Koszty stałe nie zmieniają $MC$ → $Q$ i $P$ **bez zmian**.
> **d)** $TC = 810$ → **strata 50**. $AVC(20) = 18 < P = 38 < ATC = 40{,}5$; strata (50) < koszty stałe (450) → **kontynuować** w krótkim okresie.

## Jak to się łączy
To zadanie ćwiczy [[Koszt stały i zmienny]] (FC, VC i TC = FC + VC w krótkim okresie) oraz [Punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia) (P = AVCmin, strata = FC; reguła produkować czy zamknąć).
