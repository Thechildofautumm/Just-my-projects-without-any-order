---
typ: zadanie
up: "[[Model firmy dominującej]]"
powiązane: ["Rynek gazu płynnego – firma dominująca"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Popyt rezydualny firmy dominującej: $P = -0{,}5q + 30$, jej koszt krańcowy $MC = q + 6$. Popyt rynkowy: $P = -Q + 60$. Wyznacz cenę, sprzedaż firmy dominującej i pozostałych firm.

> [!success]- Rozwiązanie
> $MR = 30 - q = q + 6 \Rightarrow q = \mathbf{12}$; $P = -6 + 30 = \mathbf{24}$.
> Rynek przy $P = 24$: $Q = 36$; pozostałe firmy: $36 - 12 = \mathbf{24}$ (udział lidera 33%).

## Jak to się łączy
To zadanie ćwiczy [[Model firmy dominującej]] (lider zachowuje się jak monopolista, mniejsze firmy jak cenobiorcy). Podobny schemat rozwiązania ma zadanie [Rynek gazu płynnego – firma dominująca](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20gazu%20p%C5%82ynnego%20%E2%80%93%20firma%20dominuj%C4%85ca).
