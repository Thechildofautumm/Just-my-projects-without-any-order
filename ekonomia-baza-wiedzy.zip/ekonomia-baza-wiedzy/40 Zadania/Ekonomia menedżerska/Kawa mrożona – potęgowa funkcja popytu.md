---
typ: zadanie
up: "[[Funkcja popytu o stałej elastyczności]]"
powiązane: ["Słuchawki bezprzewodowe – stała elastyczność i narzut"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na kawę mrożoną: $Q = 2\,I^{0{,}4}P^{-1{,}3}P_y^{0{,}6}T^{1{,}1}$ ($P_y$ – cena napojów gazowanych, $T$ – średnia temperatura). Zinterpretuj wpływ poszczególnych determinant.

> [!success]- Rozwiązanie
> W funkcji potęgowej elastyczności są stałe i równe wykładnikom:
>
> | Determinanta | Elastyczność | Interpretacja |
> |---|---|---|
> | dochód $I$ | 0,4 | dobro normalne, pierwszej potrzeby |
> | cena $P$ | −1,3 | popyt elastyczny – obniżka ceny podnosi przychód |
> | cena napojów $P_y$ | 0,6 | substytuty |
> | temperatura $T$ | 1,1 | +1% temperatury → +1,1% popytu |

## Jak to się łączy
To zadanie ćwiczy [[Funkcja popytu o stałej elastyczności]] (Q = k·P^α: elastyczności równe wykładnikom potęg). Podobny schemat rozwiązania ma zadanie [Słuchawki bezprzewodowe – stała elastyczność i narzut](obsidian://open?vault=ekonomia-baza-wiedzy&file=S%C5%82uchawki%20bezprzewodowe%20%E2%80%93%20sta%C5%82a%20elastyczno%C5%9B%C4%87%20i%20narzut).
