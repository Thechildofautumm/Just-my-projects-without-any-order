---
typ: zadanie
up: "[[Narzut ceny na koszt krańcowy]]"
powiązane: ["Kubki z nadrukiem – cena z narzutem na koszt krańcowy"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Elastyczność cenowa popytu na nową serię puzzli wynosi −1,25, a koszt krańcowy 15 zł. Jaka cena maksymalizuje zysk?

> [!success]- Rozwiązanie
> $P = 15\cdot\frac{-1{,}25}{-0{,}25} = 15\cdot 5 = \mathbf{75}$ zł.
> Im bliżej −1 jest elastyczność, tym wyższy narzut; przy $|E_p| \le 1$ wzór nie ma zastosowania (firma nie działa na nieelastycznym odcinku popytu).

## Jak to się łączy
To zadanie ćwiczy [[Narzut ceny na koszt krańcowy]] (P = MC · Ep/(Ep + 1): cena maksymalizująca zysk). Podobny schemat rozwiązania ma zadanie [Kubki z nadrukiem – cena z narzutem na koszt krańcowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kubki%20z%20nadrukiem%20%E2%80%93%20cena%20z%20narzutem%20na%20koszt%20kra%C5%84cowy).
