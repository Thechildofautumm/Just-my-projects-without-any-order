---
typ: zadanie
up: "[[Zysk marginalny]]"
przykład-z: ["Maksymalizacja przychodu"]
powiązane: ["Producent dronów – analiza wrażliwości"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na drony rolnicze: $P = 210 - 25Q$ ($Q$ – partie tygodniowo, kwoty w tys. zł). Wyprodukowanie partii kosztuje 60 tys., a koszty utrzymania hali (ponoszone także przy przestoju) – 150 tys. tygodniowo. Zapisz funkcję zysku i wyznacz optymalną produkcję, cenę i zysk. Porównaj z wariantem maksymalizacji przychodu.

> [!success]- Rozwiązanie
> 1. $TR = 210Q - 25Q^2$; $TC = 150 + 60Q$.
> 2. $\Pi = -25Q^2 + 150Q - 150$.
> 3. $M\Pi = -50Q + 150 = 0 \Rightarrow Q^* = \mathbf{3}$ (to samo daje $MR = 210 - 50Q = 60 = MC$); $\Pi'' = -50 < 0$.
> 4. $P = 210 - 75 = \mathbf{135}$; $\Pi = -225 + 450 - 150 = \mathbf{75}$ tys. zł.
>
> Maksimum przychodu: $MR = 0 \Rightarrow Q = 4{,}2$, $P = 105$ – firma nastawiona na zysk produkuje **mniej** i sprzedaje **drożej**.

## Jak to się łączy
To zadanie ćwiczy [[Zysk marginalny]] (MΠ = MR − MC; warunek konieczny MΠ = 0 i wystarczający Π″ < 0) oraz [Maksymalizacja przychodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20przychodu) (TR max przy MR = 0 (Ep = −1); kiedy pokrywa się z maksymalizacją zysku). Podobny schemat rozwiązania ma zadanie [Producent dronów – analiza wrażliwości](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producent%20dron%C3%B3w%20%E2%80%93%20analiza%20wra%C5%BCliwo%C5%9Bci).
