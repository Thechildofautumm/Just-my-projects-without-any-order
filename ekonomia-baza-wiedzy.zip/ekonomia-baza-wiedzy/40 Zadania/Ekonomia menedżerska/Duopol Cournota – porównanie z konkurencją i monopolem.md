---
typ: zadanie
up: "[[Model Cournota]]"
powiązane: ["Dwa kamieniołomy – duopol Cournota z kosztami stałymi"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dwie firmy mają $MC = 20$, popyt rynkowy $P = 200 - q_1 - q_2$. Wyznacz równowagę Cournota i porównaj ją z konkurencją doskonałą i monopolem.

> [!success]- Rozwiązanie
> $200 - 2q_1 - q_2 = 20$; symetria → $3q = 180 \Rightarrow q = \mathbf{60}$; $P = \mathbf{80}$.
> Konkurencja: $P = 20$, $Q = 180$; monopol: $MR = 200 - 2Q = 20 \Rightarrow Q = 90$, $P = 110$. Cournot (Q = 120, P = 80) leży pomiędzy.

## Jak to się łączy
To zadanie ćwiczy [[Model Cournota]] (jednoczesny wybór ilości; funkcje reakcji, równowaga z układu MR_i = MC_i). Podobny schemat rozwiązania ma zadanie [Dwa kamieniołomy – duopol Cournota z kosztami stałymi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dwa%20kamienio%C5%82omy%20%E2%80%93%20duopol%20Cournota%20z%20kosztami%20sta%C5%82ymi).
