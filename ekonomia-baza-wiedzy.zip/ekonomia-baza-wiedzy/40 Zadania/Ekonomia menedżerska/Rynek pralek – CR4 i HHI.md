---
typ: zadanie
up: "[[Koncentracja rynku]]"
powiązane: ["HHI dla modelowych struktur rynku"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Na rynku pralek działa 10 sprzedawców o udziałach: 24%, 18%, 14%, 11%, 9%, 7%, 6%, 5%, 3%, 3%. Oblicz $CR_4$ i $HHI$ i oceń koncentrację.

> [!success]- Rozwiązanie
> $CR_4 = 24 + 18 + 14 + 11 = \mathbf{67\%}$ → ścisły oligopol.
> $HHI = 576 + 324 + 196 + 121 + 81 + 49 + 36 + 25 + 9 + 9 = \mathbf{1426}$ → rynek **umiarkowanie skoncentrowany** (1000–1800).
> HHI liczymy z udziałów w procentach i po **wszystkich** firmach.

## Jak to się łączy
To zadanie ćwiczy [[Koncentracja rynku]] (CR4 i wskaźnik Herfindahla-Hirschmana (HHI); progi struktur rynku). Podobny schemat rozwiązania ma zadanie [HHI dla modelowych struktur rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=HHI%20dla%20modelowych%20struktur%20rynku).
