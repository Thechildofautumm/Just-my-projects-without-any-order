---
typ: zadanie
up: "[[Model Cournota]]"
powiązane: ["Duopol Cournota – porównanie z konkurencją i monopolem"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dwa kamieniołomy: popyt $P = 20 - q_1 - q_2$, koszty $TC_1 = 5q_1 + 10$, $TC_2 = 5q_2 + 6$. Wyznacz wydobycie, cenę i zyski w modelu Cournota.

> [!success]- Rozwiązanie
> $MR_1 = 20 - 2q_1 - q_2 = 5 \Rightarrow q_1 = 7{,}5 - 0{,}5q_2$; symetrycznie $q_2 = 7{,}5 - 0{,}5q_1$.
> $q_1 = q_2 = \mathbf{5}$; $P = \mathbf{10}$.
> $\Pi_1 = 50 - 35 = \mathbf{15}$; $\Pi_2 = 50 - 31 = \mathbf{19}$ (różnią się tylko kosztami stałymi).

## Jak to się łączy
To zadanie ćwiczy [[Model Cournota]] (jednoczesny wybór ilości; funkcje reakcji, równowaga z układu MR_i = MC_i). Podobny schemat rozwiązania ma zadanie [Duopol Cournota – porównanie z konkurencją i monopolem](obsidian://open?vault=ekonomia-baza-wiedzy&file=Duopol%20Cournota%20%E2%80%93%20por%C3%B3wnanie%20z%20konkurencj%C4%85%20i%20monopolem).
