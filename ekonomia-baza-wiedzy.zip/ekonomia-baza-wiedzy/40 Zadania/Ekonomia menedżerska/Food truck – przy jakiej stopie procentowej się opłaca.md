---
typ: zadanie
up: "[[Zysk ekonomiczny]]"
przykład-z: ["Koszt alternatywny"]
powiązane: ["Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Absolwentka ma 60 000 zł oszczędności i ofertę pracy za 36 000 zł rocznie. Rozważa food truck: przychody 150 000 zł, opłata za miejsce 12 000 zł, leasing pojazdu 18 000 zł, produkty 54 000 zł, pomocnik 27 000 zł; oszczędności zaangażuje w firmę. Przy jakiej stopie procentowej działalność się opłaca?

> [!success]- Rozwiązanie
> Koszty jawne: $12\,000 + 18\,000 + 54\,000 + 27\,000 = 111\,000$ → zysk księgowy $39\,000$.
> Zysk ekonomiczny: $39\,000 - 36\,000 - 60\,000r = 3000 - 60\,000r$.
> Zysk normalny przy $r = \frac{3000}{60\,000} = 5\%$ → działalność opłaca się przy **$r < 5\%$**.

## Jak to się łączy
To zadanie ćwiczy [[Zysk ekonomiczny]] (π = TR − TC; zysk ekonomiczny, księgowy i normalny) oraz [Koszt alternatywny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny) (wartość najlepszej możliwości utraconej przy wyborze). Podobny schemat rozwiązania ma zadanie [Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pracownia%20rowerowa%20Tomasza%20%E2%80%93%20zysk%20ksi%C4%99gowy%20a%20ekonomiczny).
