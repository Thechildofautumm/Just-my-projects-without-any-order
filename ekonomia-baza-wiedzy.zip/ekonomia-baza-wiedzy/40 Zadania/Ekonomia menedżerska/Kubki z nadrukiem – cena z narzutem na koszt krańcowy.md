---
typ: zadanie
up: "[[Narzut ceny na koszt krańcowy]]"
powiązane: ["Puzzle – wysoki narzut przy słabo elastycznym popycie"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Koszt krańcowy kubka z nadrukiem jest stały i wynosi 4 zł, a elastyczność cenowa popytu $-3$. Jaką cenę powinna ustalić firma maksymalizująca zysk?

> [!success]- Rozwiązanie
> $P = MC\cdot\frac{E_p}{E_p + 1} = 4\cdot\frac{-3}{-2} = \mathbf{6}$ zł – cena o 50% wyższa od kosztu krańcowego.

## Jak to się łączy
To zadanie ćwiczy [[Narzut ceny na koszt krańcowy]] (P = MC · Ep/(Ep + 1): cena maksymalizująca zysk). Podobny schemat rozwiązania ma zadanie [Puzzle – wysoki narzut przy słabo elastycznym popycie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Puzzle%20%E2%80%93%20wysoki%20narzut%20przy%20s%C5%82abo%20elastycznym%20popycie).
