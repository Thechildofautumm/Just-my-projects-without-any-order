---
typ: zadanie
up: "[[Krańcowy przychód z pracy]]"
przykład-z: ["Etapy produkcji"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Namiot kosztuje 250 zł (cena stała), płaca wynosi 300 zł, a $Q = -0{,}001L^3 + 0{,}09L^2 + 6L$.
a) Ilu pracowników zatrudnić? b) Ile namiotów powstanie?
c) Firma leasinguje 10 maszyn po 8000 zł. Jaki jest zysk? d) Wyznacz II etap produkcji.

> [!success]- Rozwiązanie
> **a)** $MP_L = -0{,}003L^2 + 0{,}18L + 6$; $250\cdot MP_L = 300 \Rightarrow -0{,}003L^2 + 0{,}18L + 4{,}8 = 0 \Rightarrow L^2 - 60L - 1600 = 0 \Rightarrow L = \mathbf{80}$.
> **b)** $Q = -512 + 576 + 480 = \mathbf{544}$.
> **c)** $TR = 136\,000$; $TC = 300\cdot 80 + 8000\cdot 10 = 104\,000$; $\pi = \mathbf{32\,000}$.
> **d)** $AP_L = -0{,}001L^2 + 0{,}09L + 6$ → maksimum przy $L = 45$; $MP_L = 0 \Rightarrow L^2 - 60L - 2000 = 0 \Rightarrow L \approx 83{,}9$. **II etap: $L \in (45;\ 83{,}9)$** – optimum $L = 80$ leży w nim ✔.

## Jak to się łączy
To zadanie ćwiczy [[Krańcowy przychód z pracy]] (MRP_L = MR · MP_L; optymalne zatrudnienie MRP_L = MC_L (w KD: P·MP_L = w)) oraz [Etapy produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Etapy%20produkcji) (I, II, III etap wg AP i MP; racjonalny tylko II).
