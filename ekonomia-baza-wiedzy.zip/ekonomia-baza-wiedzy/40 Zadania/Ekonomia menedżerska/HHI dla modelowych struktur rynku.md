---
typ: zadanie
up: "[[Koncentracja rynku]]"
powiązane: ["Rynek pralek – CR4 i HHI"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Oblicz $HHI$, gdy na rynku działa: a) jedna firma; b) dwie firmy z udziałami 60% i 40%; c) trzy firmy o równych udziałach; d) 20 firm o równych udziałach; e) bardzo wiele małych firm.

> [!success]- Rozwiązanie
>
> | Rynek | Obliczenie | $HHI$ | Ocena |
> |---|---|---|---|
> | a) monopol | $100^2$ | **10 000** | maksimum |
> | b) 60/40 | $3600 + 1600$ | **5200** | wysoko skoncentrowany |
> | c) 3 × 33,3% | $3\cdot 1111$ | **≈ 3333** | wysoko skoncentrowany |
> | d) 20 × 5% | $20\cdot 25$ | **500** | nieskoncentrowany |
> | e) wiele małych | $\approx 0$ | **≈ 0** | konkurencja doskonała |
>
> Przy $n$ równych firmach $HHI = \frac{10\,000}{n}$.

## Jak to się łączy
To zadanie ćwiczy [[Koncentracja rynku]] (CR4 i wskaźnik Herfindahla-Hirschmana (HHI); progi struktur rynku). Podobny schemat rozwiązania ma zadanie [Rynek pralek – CR4 i HHI](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20pralek%20%E2%80%93%20CR4%20i%20HHI).
