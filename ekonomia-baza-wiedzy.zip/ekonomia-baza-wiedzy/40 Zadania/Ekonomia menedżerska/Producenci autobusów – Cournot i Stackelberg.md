---
typ: zadanie
up: "[[Model Cournota]]"
przykład-z: ["Model Stackelberga", "Oligopol"]
powiązane: ["Model Stackelberga – przewaga pierwszego ruchu"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dwaj producenci autobusów: popyt $P = 50 - q_1 - q_2$ (q w setkach sztuk, P w tys. zł); $TC_1 = 12q_1 + 40$, $TC_2 = 10q_2 + 30$.
a) Wyznacz produkcję i zyski w modelu Cournota.
b) Wyznacz je w modelu Stackelberga, gdy przywódcą jest firma 1.

> [!success]- Rozwiązanie
> **a)** $50 - 2q_1 - q_2 = 12 \Rightarrow 2q_1 + q_2 = 38$; $50 - q_1 - 2q_2 = 10 \Rightarrow q_1 + 2q_2 = 40$.
> $q_1 = \mathbf{12}$, $q_2 = \mathbf{14}$, $P = \mathbf{24}$; $\Pi_1 = 288 - 184 = \mathbf{104}$; $\Pi_2 = 336 - 170 = \mathbf{166}$.
> **b)** $q_2 = 20 - 0{,}5q_1$; popyt przywódcy $P = 30 - 0{,}5q_1$; $MR_1 = 30 - q_1 = 12 \Rightarrow q_1 = \mathbf{18}$.
> $q_2 = \mathbf{11}$, $P = \mathbf{21}$; $\Pi_1 = 378 - 256 = \mathbf{122}$; $\Pi_2 = 231 - 140 = \mathbf{91}$.
>
> | Model | $q_1$ | $q_2$ | $P$ | $\Pi_1$ | $\Pi_2$ |
> |---|---|---|---|---|---|
> | Cournot | 12 | 14 | 24 | 104 | 166 |
> | Stackelberg | 18 | 11 | 21 | 122 | 91 |

## Jak to się łączy
To zadanie ćwiczy [[Model Cournota]] (jednoczesny wybór ilości; funkcje reakcji, równowaga z układu MR_i = MC_i), [Model Stackelberga](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20Stackelberga) (przywódca wybiera ilość pierwszy, znając funkcję reakcji naśladowcy) oraz [Oligopol](obsidian://open?vault=ekonomia-baza-wiedzy&file=Oligopol) (kilka dużych firm, decyzje współzależne, wysokie bariery wejścia). Podobny schemat rozwiązania ma zadanie [Model Stackelberga – przewaga pierwszego ruchu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20Stackelberga%20%E2%80%93%20przewaga%20pierwszego%20ruchu).
