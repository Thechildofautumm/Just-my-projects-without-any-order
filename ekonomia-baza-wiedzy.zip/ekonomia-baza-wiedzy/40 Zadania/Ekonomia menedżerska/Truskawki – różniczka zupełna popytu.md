---
typ: zadanie
up: "[[Funkcja popytu wielu zmiennych]]"
powiązane: ["Krem z filtrem – łączny wpływ determinant popytu"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na truskawki: $Q = -3P + 0{,}2I + 0{,}4P_y$ ($P_y$ – cena malin). Cena truskawek rośnie o 1 zł, dochód spada o 40 zł, a cena malin rośnie o 10 zł. Jak zmieni się popyt?

> [!success]- Rozwiązanie
> $dQ = Q'_P\,dP + Q'_I\,dI + Q'_{P_y}\,dP_y = -3\cdot 1 + 0{,}2\cdot(-40) + 0{,}4\cdot 10 = -3 - 8 + 4 = \mathbf{-7}$.
> Popyt spadnie o 7 jednostek; droższe maliny (substytut) częściowo łagodzą spadek.

## Jak to się łączy
To zadanie ćwiczy [[Funkcja popytu wielu zmiennych]] (Q = f(P, I, Py, N, A…); łączna zmiana popytu z różniczki zupełnej). Podobny schemat rozwiązania ma zadanie [Krem z filtrem – łączny wpływ determinant popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krem%20z%20filtrem%20%E2%80%93%20%C5%82%C4%85czny%20wp%C5%82yw%20determinant%20popytu).
