---
typ: zadanie
up: "[[Maksymalizacja przychodu]]"
przykład-z: ["Elastyczność a przychód"]
powiązane: ["Festiwal w amfiteatrze – cena maksymalizująca wpływy"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Wyznacz cenę, ilość i utarg maksymalny dla: a) $Q = -50P + 20\,000$; b) $Q = -8P + 4800$.

> [!success]- Rozwiązanie
> Warunek $E_p = -1$, czyli dla $Q = a - bP$: $P = \frac{a}{2b}$.
> **a)** $P = \mathbf{200}$, $Q = 10\,000$, $TR = \mathbf{2\,000\,000}$.
> **b)** $P = \mathbf{300}$, $Q = 2400$, $TR = \mathbf{720\,000}$.

## Jak to się łączy
To zadanie ćwiczy [[Maksymalizacja przychodu]] (TR max przy MR = 0 (Ep = −1); kiedy pokrywa się z maksymalizacją zysku) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe). Podobny schemat rozwiązania ma zadanie [Festiwal w amfiteatrze – cena maksymalizująca wpływy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Festiwal%20w%20amfiteatrze%20%E2%80%93%20cena%20maksymalizuj%C4%85ca%20wp%C5%82ywy).
