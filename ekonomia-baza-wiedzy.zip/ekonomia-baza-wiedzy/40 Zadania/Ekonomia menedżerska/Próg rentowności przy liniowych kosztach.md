---
typ: zadanie
up: "[[Próg rentowności]]"
powiązane: ["Próg rentowności ilościowy, wartościowy i procentowy"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TC = 25Q + 48\,000$, firma jest cenobiorcą, cena 31. Od jakiej produkcji firma osiąga zysk?

> [!success]- Rozwiązanie
> $Q_{BEP} = \frac{FC}{P - AVC} = \frac{48\,000}{31 - 25} = \mathbf{8000}$; powyżej tej ilości każda sztuka daje 6 zł zysku.

## Jak to się łączy
To zadanie ćwiczy [[Próg rentowności]] (BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC)). Podobny schemat rozwiązania ma zadanie [Próg rentowności ilościowy, wartościowy i procentowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci%20ilo%C5%9Bciowy%2C%20warto%C5%9Bciowy%20i%20procentowy).
