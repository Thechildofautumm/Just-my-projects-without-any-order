---
typ: zadanie
up: "[[Konkurencja doskonała]]"
powiązane: ["Cena, przy której ustaje wejście do gałęzi"]
źródło: ["[[EM – Struktury rynkowe I]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Długookresowy koszt firmy: $TC = 0{,}04Q^3 - 1{,}2Q^2 + 15Q$. Przy jakiej cenie ustanie wchodzenie firm i poniżej jakiej zaczną wychodzić?

> [!success]- Rozwiązanie
> $AC = 0{,}04Q^2 - 1{,}2Q + 15$; $AC' = 0{,}08Q - 1{,}2 = 0 \Rightarrow Q = 15$; $AC(15) = 9 - 18 + 15 = \mathbf{6}$.
> Przy $P = 6$ wejście ustaje; poniżej 6 firmy ponoszą straty i w długim okresie wychodzą.

## Jak to się łączy
To zadanie ćwiczy [[Konkurencja doskonała]] (założenia modelu, popyt firmy (P = MR), równowaga krótko- i długookresowa, cena wyjścia). Podobny schemat rozwiązania ma zadanie [Cena, przy której ustaje wejście do gałęzi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%2C%20przy%20kt%C3%B3rej%20ustaje%20wej%C5%9Bcie%20do%20ga%C5%82%C4%99zi).
