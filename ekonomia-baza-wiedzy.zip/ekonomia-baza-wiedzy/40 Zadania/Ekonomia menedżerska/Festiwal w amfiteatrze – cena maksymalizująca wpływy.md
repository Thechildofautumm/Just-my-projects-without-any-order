---
typ: zadanie
up: "[[Maksymalizacja przychodu]]"
powiązane: ["Cena maksymalizująca utarg – dwa rynki"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na bilety: $Q = -20P + 9000$; amfiteatr mieści 7000 osób, a koszty festiwalu nie zależą od liczby widzów. Jaką cenę ustalić? Czy opłaca się zapełnić wszystkie miejsca?

> [!success]- Rozwiązanie
> Koszty stałe → maksimum zysku = maksimum przychodu, czyli $E_p = -1$:
> $\frac{-20P}{-20P + 9000} = -1 \Rightarrow 40P = 9000 \Rightarrow P = \mathbf{225}$ zł; $Q = 4500$; $TR = \mathbf{1\,012\,500}$ zł.
> Pełny amfiteatr: $P = 100$, $TR = 700\,000$ zł – **mniej**. Optymalnie 2500 miejsc zostaje pustych.

## Jak to się łączy
To zadanie ćwiczy [[Maksymalizacja przychodu]] (TR max przy MR = 0 (Ep = −1); kiedy pokrywa się z maksymalizacją zysku). Podobny schemat rozwiązania ma zadanie [Cena maksymalizująca utarg – dwa rynki](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%20maksymalizuj%C4%85ca%20utarg%20%E2%80%93%20dwa%20rynki).
