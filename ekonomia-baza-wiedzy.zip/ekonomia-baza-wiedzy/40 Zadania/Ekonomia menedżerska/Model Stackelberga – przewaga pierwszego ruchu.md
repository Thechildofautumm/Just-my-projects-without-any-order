---
typ: zadanie
up: "[[Model Stackelberga]]"
powiązane: ["Producenci autobusów – Cournot i Stackelberg"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt $P = 20 - q_1 - q_2$, $MC_1 = MC_2 = 5$. Firma 1 decyduje pierwsza. Wyznacz produkcję obu firm i cenę; porównaj z Cournotem.

> [!success]- Rozwiązanie
> Reakcja naśladowcy: $20 - q_1 - 2q_2 = 5 \Rightarrow q_2 = 7{,}5 - 0{,}5q_1$.
> Popyt przywódcy: $P = 12{,}5 - 0{,}5q_1$; $MR_1 = 12{,}5 - q_1 = 5 \Rightarrow q_1 = \mathbf{7{,}5}$.
> $q_2 = \mathbf{3{,}75}$; $P = \mathbf{8{,}75}$. W Cournocie: 5 i 5, $P = 10$ – przywódca produkuje i zarabia więcej.

## Jak to się łączy
To zadanie ćwiczy [[Model Stackelberga]] (przywódca wybiera ilość pierwszy, znając funkcję reakcji naśladowcy). Podobny schemat rozwiązania ma zadanie [Producenci autobusów – Cournot i Stackelberg](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producenci%20autobus%C3%B3w%20%E2%80%93%20Cournot%20i%20Stackelberg).
