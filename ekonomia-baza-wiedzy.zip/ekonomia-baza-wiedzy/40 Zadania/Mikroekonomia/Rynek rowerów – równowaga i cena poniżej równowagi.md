---
typ: zadanie
up: "[[Równowaga rynkowa]]"
przykład-z: ["Nierównowaga rynkowa", "Popyt"]
powiązane: ["Rynek lodówek – cena administracyjna"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na rowery miejskie w pewnym mieście opisuje funkcja $Q = 180 - 3P$, a podaż – funkcja $P = \frac16Q$ (ceny w setkach zł).
a) Wyznacz cenę i ilość równowagi.
b) Co się stanie na rynku, jeśli sprzedawcy umówią się na cenę 14? Oblicz skalę zjawiska.

> [!success]- Rozwiązanie
> Popyt w postaci odwrotnej: $P = 60 - \frac13Q$ ($P_{max} = 60$, $Q_{max} = 180$).
> a) $60 - \frac13Q = \frac16Q \Rightarrow \frac12Q = 60 \Rightarrow Q_e = \mathbf{120}$, $P_e = \mathbf{20}$.
> b) $P = 14 < P_e$: $Q_D = 180 - 42 = 138$, $Q_S = 6\cdot 14 = 84$.
> Na rynku pojawia się **niedobór** równy $138 - 84 = \mathbf{54}$ rowery; sprzedanych zostanie tylko 84 (decyduje krótsza strona rynku).

## Jak to się łączy
To zadanie ćwiczy [[Równowaga rynkowa]] (cena i ilość, przy których Qd = Qs), [Nierównowaga rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nier%C3%B3wnowaga%20rynkowa) (niedobór lub nadmiar przy cenie innej niż równowagi; ceny administracyjne) oraz [Popyt](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) (zależność między ceną a ilością, jaką nabywcy chcą kupić; prawo popytu). Podobny schemat rozwiązania ma zadanie [Rynek lodówek – cena administracyjna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20lod%C3%B3wek%20%E2%80%93%20cena%20administracyjna).
