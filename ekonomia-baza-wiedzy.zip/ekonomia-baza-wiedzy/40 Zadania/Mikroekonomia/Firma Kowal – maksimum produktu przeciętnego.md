---
typ: zadanie
up: "[[Produkt przeciętny i marginalny]]"
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Funkcja produkcji: $Q(L,K) = -2L^2 + 8KL - 2K$, kapitał w krótkim okresie $K = 16$. Wyznacz $Q(L)$, $MP_L$, $AP_L$ i nakład pracy, przy którym produkt przeciętny jest największy.

> [!success]- Rozwiązanie
> $Q(L) = -2L^2 + 128L - 32$; $MP_L = -4L + 128$; $AP_L = -2L + 128 - \frac{32}{L}$.
> $AP' = -2 + \frac{32}{L^2} = 0 \Rightarrow L = \mathbf{4}$; wtedy $AP = MP = \mathbf{112}$ (MP przecina AP w jego maksimum).

## Jak to się łączy
To zadanie ćwiczy [[Produkt przeciętny i marginalny]] (TP, AP = Q/L, MP = Q′ i relacje między nimi).
