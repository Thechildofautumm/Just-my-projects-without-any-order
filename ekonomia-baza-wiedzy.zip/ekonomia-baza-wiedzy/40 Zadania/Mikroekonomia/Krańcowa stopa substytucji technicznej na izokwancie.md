---
typ: zadanie
up: "[[Krańcowa stopa technicznej substytucji]]"
przykład-z: ["Izokwanta"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Izokwanta: $L\cdot K = 600$. Oblicz MRTS dla $L = 30$.

> [!success]- Rozwiązanie
> $K = 20$; $MRTS = \frac{MP_L}{MP_K} = \frac{K}{L} = \frac{20}{30} \approx \mathbf{0{,}67}$ – jedna jednostka pracy zastępuje ⅔ jednostki kapitału.

## Jak to się łączy
To zadanie ćwiczy [[Krańcowa stopa technicznej substytucji]] (ile K można zastąpić jednostką L przy stałej produkcji) oraz [Izokwanta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokwanta) (kombinacje L i K dające tę samą produkcję).
