---
typ: zadanie
up: "[[Równowaga monopolu]]"
przykład-z: ["Punkt zamknięcia"]
powiązane: ["Monopol – optymalna cena i zysk"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Monopolista: $TC = \frac13Q^3 - 6Q^2 + 60Q + 250$, popyt $P = 32 - \frac12Q$. Wyznacz optymalną decyzję.

> [!success]- Rozwiązanie
> $MR = 32 - Q$, $MC = Q^2 - 12Q + 60$ → $Q^2 - 11Q + 28 = 0 \Rightarrow Q \in \{4; 7\}$.
> $Q = 4$ odrzucamy (tam MC przecina MR „od góry” – minimum zysku). **Q = 7, P = 28,5.**
> $TR = 199{,}5$; $VC = 114{,}3 - 294 + 420 = 240{,}3$; $TC = 490{,}3$ → $\pi \approx -290{,}8$.
> $AVC \approx 34{,}3 > P = 28{,}5$, strata > FC (250) → **zamknąć (Q = 0)** – wtedy strata wyniesie tylko 250.

## Jak to się łączy
To zadanie ćwiczy [[Równowaga monopolu]] (MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży) oraz [Punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia) (P = AVCmin, strata = FC; reguła produkować czy zamknąć). Podobny schemat rozwiązania ma zadanie [Monopol – optymalna cena i zysk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20optymalna%20cena%20i%20zysk).
