---
typ: zadanie
up: "[[Optimum producenta]]"
powiązane: ["Pracownia ceramiki – maksymalna produkcja przy danym budżecie"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Piekarnia chce wypiec $Q = L^{1/2}M^{1/2} = 300$ jednostek ($L$ – godziny pracy, $M$ – kg mąki). Godzina pracy kosztuje 45 zł, kilogram mąki 5 zł. Wyznacz najtańszą kombinację i koszt.

> [!success]- Rozwiązanie
> $\frac{MP_L}{MP_M} = \frac{M}{L} = \frac{45}{5} \Rightarrow M = 9L$; $\sqrt{9L^2} = 3L = 300 \Rightarrow L = 100$, $M = 900$.
> $TC = 45\cdot 100 + 5\cdot 900 = \mathbf{9000}$ zł.

## Jak to się łączy
To zadanie ćwiczy [[Optimum producenta]] (styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu). Podobny schemat rozwiązania ma zadanie [Pracownia ceramiki – maksymalna produkcja przy danym budżecie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pracownia%20ceramiki%20%E2%80%93%20maksymalna%20produkcja%20przy%20danym%20bud%C5%BCecie).
