---
typ: zadanie
up: "[[Koszty a produktywność]]"
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q(L) = -2L^3 + 60L^2 + 1800L$, płaca $w = 4000$. Ile wynosi najniższy koszt krańcowy?

> [!success]- Rozwiązanie
> $MC = \frac{w}{MP_L}$, więc $MC$ jest najmniejszy, gdy $MP$ jest największy.
> $MP = -6L^2 + 120L + 1800$, $MP' = 0 \Rightarrow L = 10$, $MP_{max} = 2400$.
> $MC_{min} = \frac{4000}{2400} \approx \mathbf{1{,}67}$.

## Jak to się łączy
To zadanie ćwiczy [[Koszty a produktywność]] (AVC = w/AP i MC = w/MP – lustrzane odbicie produkcji).
