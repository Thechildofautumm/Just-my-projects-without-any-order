---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Pozacenowa determinanta popytu"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na sok jabłkowy tłoczony: $P = 12 - 2Q$, podaż: $P = 2Q + 4$ (Q w tys. litrów, P w zł).
a) Wyznacz równowagę.
b) Samorząd dopłaca konsumentom 2 zł do każdego litra. Wyznacz nową równowagę i cenę faktycznie płaconą przez konsumenta.

> [!success]- Rozwiązanie
> a) $12 - 2Q = 2Q + 4 \Rightarrow Q_e = 2$, $P_e = 8$.
> b) Dopłata dla kupujących przesuwa popyt w górę o 2: $P = 14 - 2Q$.
> $14 - 2Q = 2Q + 4 \Rightarrow Q' = \mathbf{2{,}5}$, $P' = \mathbf{9}$. Konsument płaci faktycznie $9 - 2 = \mathbf{7}$ zł – korzyść z dopłaty dzielą kupujący (−1 zł) i sprzedający (+1 zł).

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Pozacenowa determinanta popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu) (czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…)).
