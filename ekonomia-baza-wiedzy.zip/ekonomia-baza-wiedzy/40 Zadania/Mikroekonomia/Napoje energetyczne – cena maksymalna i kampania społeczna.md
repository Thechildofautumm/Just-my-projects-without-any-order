---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Pozacenowa determinanta popytu"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na napoje energetyczne: $Q = 80 - P$, podaż: $P = 3Q$.
a) Państwo wprowadza cenę maksymalną 30 zł (za zgrzewkę). O ile zmieni się sprzedana ilość?
b) Zamiast ceny maksymalnej prowadzona jest kampania o szkodliwości napojów. Po niej konsumenci są gotowi kupić każdą ilość tylko po cenie o 8 zł niższej niż wcześniej. Ile wyniosą łączne wydatki konsumentów w nowej równowadze?

> [!success]- Rozwiązanie
> Równowaga: $80 - Q = 3Q \Rightarrow Q_e = 20$, $P_e = 60$.
> a) Przy $P = 30$ sprzedaż wyznacza podaż: $30 = 3Q_S \Rightarrow Q_S = 10$. Sprzedana ilość spada o **10 zgrzewek** (z 20 do 10), a niezaspokojony popyt wynosi $Q_D - Q_S = 50 - 10 = 40$.
> b) Kampania to czynnik pozacenowy – popyt przesuwa się w dół o 8: $P = 72 - Q$.
> $72 - Q = 3Q \Rightarrow Q' = 18$, $P' = 54$. Wydatki: $18\cdot 54 = \mathbf{972}$ zł.

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Pozacenowa determinanta popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu) (czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…)).
