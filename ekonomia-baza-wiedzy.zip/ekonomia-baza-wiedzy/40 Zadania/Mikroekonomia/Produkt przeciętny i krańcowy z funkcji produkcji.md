---
typ: zadanie
up: "[[Produkt przeciętny i marginalny]]"
przykład-z: ["Funkcja produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Wyznacz funkcje produktu przeciętnego i marginalnego pracy:
a) $Q = -2L^3 + 90L^2 + 1200L$; b) $Q = -L^3 + 9L^2 + 30L$.

> [!success]- Rozwiązanie
> a) $AP = \frac{Q}{L} = -2L^2 + 90L + 1200$; $MP = Q' = -6L^2 + 180L + 1200$.
> b) $AP = -L^2 + 9L + 30$; $MP = -3L^2 + 18L + 30$.

## Jak to się łączy
To zadanie ćwiczy [[Produkt przeciętny i marginalny]] (TP, AP = Q/L, MP = Q′ i relacje między nimi) oraz [Funkcja produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji) (zależność produkcji od nakładów; krótki i długi okres).
