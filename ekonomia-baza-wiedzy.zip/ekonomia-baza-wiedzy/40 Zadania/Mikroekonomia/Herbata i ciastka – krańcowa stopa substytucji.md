---
typ: zadanie
up: "[[Krańcowa stopa substytucji]]"
przykład-z: ["Krzywa obojętności"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Krzywą obojętności konsumenta opisuje $Q_c = \frac{900}{Q_h}$ ($Q_c$ – ciastka, $Q_h$ – herbaty). Spożycie herbat rośnie z 15 do 45. Oblicz krańcową stopę substytucji na tym odcinku.

> [!success]- Rozwiązanie
> $Q_{c1} = 60$, $Q_{c2} = 20$ → $\Delta Q_c = -40$, $\Delta Q_h = 30$.
> $MRS = -\frac{\Delta Q_c}{\Delta Q_h} = \frac{40}{30} \approx \mathbf{1{,}33}$ – za każdą dodatkową herbatę konsument oddaje średnio 1⅓ ciastka. Wzdłuż krzywej MRS maleje.

## Jak to się łączy
To zadanie ćwiczy [[Krańcowa stopa substytucji]] (ile Y oddajemy za jednostkę X przy stałej użyteczności) oraz [Krzywa obojętności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20oboj%C4%99tno%C5%9Bci) (koszyki dające tę samą użyteczność; cechy krzywych).
