---
typ: zadanie
up: "[[Etapy produkcji]]"
przykład-z: ["Produkt przeciętny i marginalny"]
powiązane: ["Granice II etapu produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = -L^3 + 60L^2 + 675L$.
a) Wyznacz granice II etapu produkcji.
b) Dla jakiego innego L produkt marginalny ma taką samą wartość jak na lewej granicy II etapu? Ile wynosi wtedy produkt przeciętny?

> [!success]- Rozwiązanie
> a) $AP = -L^2 + 60L + 675$ → $AP' = 0 \Rightarrow L = 30$, $AP_{max} = 1575$.
> $MP = -3L^2 + 120L + 675 = 0 \Rightarrow L^2 - 40L - 225 = 0 \Rightarrow (L - 45)(L + 5) = 0 \Rightarrow L = 45$. **II etap: 30–45.**
> b) $MP(30) = 1575$. Drugi raz: $-3L^2 + 120L + 675 = 1575 \Rightarrow L^2 - 40L + 300 = 0 \Rightarrow L = \mathbf{10}$ (lub 30).
> $AP(10) = -100 + 600 + 675 = \mathbf{1175}$ – przy $L = 10$ MP jeszcze rośnie i leży nad AP.

## Jak to się łączy
To zadanie ćwiczy [[Etapy produkcji]] (I, II, III etap wg AP i MP; racjonalny tylko II) oraz [Produkt przeciętny i marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny) (TP, AP = Q/L, MP = Q′ i relacje między nimi). Podobny schemat rozwiązania ma zadanie [Granice II etapu produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Granice%20II%20etapu%20produkcji).
