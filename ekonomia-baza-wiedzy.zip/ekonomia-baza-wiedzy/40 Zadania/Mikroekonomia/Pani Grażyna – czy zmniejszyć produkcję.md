---
typ: zadanie
up: "[[Koszt przeciętny]]"
przykład-z: ["Koszt marginalny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Pani Grażyna wytwarza meble ogrodowe; $TC = 40Q^3 + 10Q^2 + 90$. Produkuje 30 sztuk tygodniowo. Czy z punktu widzenia kosztów przeciętnych to dobra wielkość produkcji?

> [!success]- Rozwiązanie
> $MC = 120Q^2 + 20Q$, $ATC = 40Q^2 + 10Q + \frac{90}{Q}$.
> $MC(30) = 108\,600$, $ATC(30) = 36\,303$ → $MC > ATC$, więc ATC **rośnie** – produkcja leży daleko na prawo od minimum ATC (które wypada przy $Q = 1$, $ATC = 140$).
> **Odpowiedź: zmniejszyć produkcję** (przy tej funkcji kosztów każda kolejna sztuka podnosi koszt przeciętny).

## Jak to się łączy
To zadanie ćwiczy [[Koszt przeciętny]] (AFC, AVC, ATC – przebieg w kształcie U) oraz [Koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny) (przyrost TC z dodatkowej jednostki: MC = TC′).
