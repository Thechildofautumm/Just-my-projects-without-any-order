---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Przy liniowym popycie elastyczność cenowa dla $Q = 150$ wynosi $-4$. Przy jakiej ilości przychód marginalny jest równy zero?

> [!success]- Rozwiązanie
> $-4 = \frac{150 - Q_{max}}{150} \Rightarrow Q_{max} = 750$. $MR = 0$ w połowie: $Q = \mathbf{375}$.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) (przychód całkowity, przeciętny i marginalny (TR, AR, MR)).
