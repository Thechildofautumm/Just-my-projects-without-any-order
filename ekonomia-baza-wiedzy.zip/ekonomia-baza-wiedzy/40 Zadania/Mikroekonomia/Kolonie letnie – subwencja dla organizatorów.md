---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Pozacenowa determinanta podaży"]
powiązane: ["Rynek najmu – dopłata dla wynajmujących"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na kolonie: $P = 800 - 2Q$, podaż: $P = 2Q$. Jaka subwencja $b$ na każde miejsce, wypłacana organizatorom, obniży cenę do 320 zł?

> [!success]- Rozwiązanie
> Równowaga: $800 - 2Q = 2Q \Rightarrow Q_e = 200$, $P_e = 400$.
> Nowa podaż: $P = 2Q - b$. Z popytu przy $P = 320$: $Q' = 240$.
> $320 = 2\cdot 240 - b \Rightarrow b = \mathbf{160}$ zł. Nowa podaż: $P = 2Q - 160$.

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Pozacenowa determinanta podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy) (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)). Podobny schemat rozwiązania ma zadanie [Rynek najmu – dopłata dla wynajmujących](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20najmu%20%E2%80%93%20dop%C5%82ata%20dla%20wynajmuj%C4%85cych).
