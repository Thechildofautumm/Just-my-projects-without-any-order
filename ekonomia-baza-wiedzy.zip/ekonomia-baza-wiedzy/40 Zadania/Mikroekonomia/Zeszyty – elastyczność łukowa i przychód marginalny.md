---
typ: zadanie
up: "[[Elastyczność łukowa]]"
przykład-z: ["Elastyczność a przychód"]
powiązane: ["Batony – przychód marginalny w punkcie i na odcinku"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na zeszyty: $P = -2Q + 700$. Cena spada z 540 do 460 (groszy).
a) Oblicz łukowy współczynnik elastyczności.
b) Oblicz przychód marginalny dla tej zmiany ceny.

> [!success]- Rozwiązanie
> $Q_1 = 80$, $Q_2 = 120$.
> a) $E_Ł = \frac{\Delta Q}{Q_1 + Q_2}\cdot\frac{P_1 + P_2}{\Delta P} = \frac{40}{200}\cdot\frac{1000}{-80} = \mathbf{-2{,}5}$
> b) $P_{śr} = 500$; $MR = P_{śr}\left(1 - \frac{1}{|E|}\right) = 500\cdot 0{,}6 = \mathbf{300}$.
> Kontrola: $TR_1 = 43\,200$, $TR_2 = 55\,200$; $MR = \frac{12\,000}{40} = 300$ ✔

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność łukowa]] (elastyczność na odcinku krzywej – wzór ze średnich) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe). Podobny schemat rozwiązania ma zadanie [Batony – przychód marginalny w punkcie i na odcinku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Batony%20%E2%80%93%20przych%C3%B3d%20marginalny%20w%20punkcie%20i%20na%20odcinku).
