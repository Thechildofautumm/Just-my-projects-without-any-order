---
typ: zadanie
up: "[[Koszty a produktywność]]"
przykład-z: ["Koszt przeciętny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$K = 5$, $Q = 2\sqrt{LK}$, cena kapitału $r = 40$, płaca $w = 10$.
a) Wyznacz ATC, AVC i MC.
b) Wyznacz minimum ATC.

> [!success]- Rozwiązanie
> $FC = 40\cdot 5 = 200$; $Q^2 = 20L \Rightarrow L = \frac{Q^2}{20}$ → $TC = 10\cdot\frac{Q^2}{20} + 200 = \frac{Q^2}{2} + 200$.
> a) $ATC = \frac{Q}{2} + \frac{200}{Q}$, $AVC = \frac{Q}{2}$, $MC = Q$.
> b) $MC = ATC \Rightarrow Q = \frac{Q}{2} + \frac{200}{Q} \Rightarrow Q^2 = 400 \Rightarrow Q = 20$, $ATC_{min} = 10 + 10 = \mathbf{20}$.

## Jak to się łączy
To zadanie ćwiczy [[Koszty a produktywność]] (AVC = w/AP i MC = w/MP – lustrzane odbicie produkcji) oraz [Koszt przeciętny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny) (AFC, AVC, ATC – przebieg w kształcie U).
