---
typ: zadanie
up: "[[Koszt przeciętny]]"
przykład-z: ["Koszt stały i zmienny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TC = 4Q^2 + FC$, a minimum kosztu przeciętnego przypada przy $Q = 6$. Wyznacz FC oraz funkcje ATC, AVC i MC.

> [!success]- Rozwiązanie
> $ATC = 4Q + \frac{FC}{Q}$, $MC = 8Q$. W minimum $MC = ATC$: $8Q = 4Q + \frac{FC}{Q} \Rightarrow FC = 4Q^2 = 4\cdot 36 = \mathbf{144}$.
> $ATC = 4Q + \frac{144}{Q}$, $AVC = 4Q$, $MC = 8Q$; $ATC_{min} = 24 + 24 = 48$.

## Jak to się łączy
To zadanie ćwiczy [[Koszt przeciętny]] (AFC, AVC, ATC – przebieg w kształcie U) oraz [Koszt stały i zmienny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny) (FC, VC i TC = FC + VC w krótkim okresie).
