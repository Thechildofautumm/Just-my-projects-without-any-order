---
typ: zadanie
up: "[[Punkt zamknięcia]]"
przykład-z: ["Maksymalizacja zysku"]
powiązane: ["Konkurencja doskonała – zysk zerowy"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Cena rynkowa $P = 40$, koszt przeciętny $ATC = Q + \frac{500}{Q}$. Wyznacz optymalną produkcję i wynik. Czy w krótkim okresie produkować?

> [!success]- Rozwiązanie
> $TC = Q^2 + 500$ ($FC = 500$, $AVC = Q$), $MC = 2Q = 40 \Rightarrow Q = \mathbf{20}$.
> $TR = 800$, $TC = 900$ → $\pi = \mathbf{-100}$.
> $AVC(20) = 20 < P = 40$, strata (100) < FC (500) → **produkować dalej** – przychód pokrywa koszty zmienne i część stałych.

## Jak to się łączy
To zadanie ćwiczy [[Punkt zamknięcia]] (P = AVCmin, strata = FC; reguła produkować czy zamknąć) oraz [Maksymalizacja zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) (warunek MR = MC i warunek drugiego rzędu). Podobny schemat rozwiązania ma zadanie [Konkurencja doskonała – zysk zerowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a%20%E2%80%93%20zysk%20zerowy).
