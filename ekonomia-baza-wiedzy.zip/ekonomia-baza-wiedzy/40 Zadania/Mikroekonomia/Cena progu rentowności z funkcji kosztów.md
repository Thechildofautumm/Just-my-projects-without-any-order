---
typ: zadanie
up: "[[Próg rentowności]]"
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Firma doskonale konkurencyjna ma koszty $TC = 3Q^3 - 36Q^2 + 200Q$. Wyznacz cenę niwelacji (próg rentowności).

> [!success]- Rozwiązanie
> $FC = 0$ → $ATC = AVC = 3Q^2 - 36Q + 200$; $ATC' = 6Q - 36 = 0 \Rightarrow Q = 6$, $ATC_{min} = 108 - 216 + 200 = 92$.
> **Cena niwelacji P = 92** (bez kosztów stałych pokrywa się z ceną zamknięcia).

## Jak to się łączy
To zadanie ćwiczy [[Próg rentowności]] (BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC)).
