---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Przychód"]
powiązane: ["Elastyczność i przychód przy cenie 20"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przy liniowym popycie przychód marginalny wynosi 40 dla $Q = 6$. Przy cenie 40 elastyczność cenowa wynosi $-3$. Ile wynosi elastyczność dla $Q = 18$?

> [!success]- Rozwiązanie
> MR jest dwa razy bardziej stromy niż popyt: wartość 40 MR osiąga przy $Q = 6$, a popyt – przy $Q = 12$.
> $-3 = \frac{12 - Q_{max}}{12} \Rightarrow Q_{max} = 48$.
> Dla $Q = 18$: $E_p = \frac{18 - 48}{18} = \mathbf{-\tfrac53 \approx -1{,}67}$ (popyt elastyczny – jesteśmy przed połową ilości maksymalnej).

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) (przychód całkowity, przeciętny i marginalny (TR, AR, MR)). Podobny schemat rozwiązania ma zadanie [Elastyczność i przychód przy cenie 20](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20i%20przych%C3%B3d%20przy%20cenie%2020).
