---
typ: zadanie
up: "[[Równowaga monopolu]]"
powiązane: ["Monopol – strata większa od kosztów stałych", "Strata społeczna monopolu – porównanie z konkurencją"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Monopolista: $TC = Q^2 + 20Q + 500$, popyt $P = 500 - Q$. Wyznacz cenę, ilość i zysk.

> [!success]- Rozwiązanie
> $MR = 500 - 2Q$, $MC = 2Q + 20$ → $480 = 4Q \Rightarrow Q = \mathbf{120}$, $P = \mathbf{380}$.
> $TR = 45\,600$; $TC = 14\,400 + 2400 + 500 = 17\,300$; $\pi = \mathbf{28\,300}$; $ATC \approx 144{,}2$, $AVC = 140$.

## Jak to się łączy
To zadanie ćwiczy [[Równowaga monopolu]] (MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży). Podobny schemat rozwiązania ma zadania [Monopol – strata większa od kosztów stałych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20strata%20wi%C4%99ksza%20od%20koszt%C3%B3w%20sta%C5%82ych) i [Strata społeczna monopolu – porównanie z konkurencją](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20spo%C5%82eczna%20monopolu%20%E2%80%93%20por%C3%B3wnanie%20z%20konkurencj%C4%85).
