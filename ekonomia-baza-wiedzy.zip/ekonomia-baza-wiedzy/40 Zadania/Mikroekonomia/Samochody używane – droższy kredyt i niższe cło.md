---
typ: zadanie
up: "[[Pozacenowa determinanta popytu]]"
przykład-z: ["Pozacenowa determinanta podaży"]
powiązane: ["Rynek pelletu – nowe tartaki i droższe kotły"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Banki podniosły oprocentowanie kredytów samochodowych, a jednocześnie obniżono opłaty przy imporcie aut z zagranicy. Co się stanie z ceną i liczbą sprzedanych samochodów używanych?

> [!success]- Rozwiązanie
> - droższy kredyt → **spadek popytu** (D w lewo),
> - tańszy import → **wzrost podaży** (S w prawo).
> Cena **na pewno niższa**; ilość – niejednoznaczna.

## Jak to się łączy
To zadanie ćwiczy [[Pozacenowa determinanta popytu]] (czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…)) oraz [Pozacenowa determinanta podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy) (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)). Podobny schemat rozwiązania ma zadanie [Rynek pelletu – nowe tartaki i droższe kotły](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20pelletu%20%E2%80%93%20nowe%20tartaki%20i%20dro%C5%BCsze%20kot%C5%82y).
