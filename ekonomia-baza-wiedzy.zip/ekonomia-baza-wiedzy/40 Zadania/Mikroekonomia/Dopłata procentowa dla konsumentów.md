---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Pozacenowa determinanta popytu"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Popyt na dobro opisuje funkcja $Q = 1200 - P$. Państwo pokrywa kupującym 20% ceny. Zapisz nową funkcję popytu (względem ceny rynkowej) i opisz zmianę położenia krzywej.

> [!success]- Rozwiązanie
> Konsument płaci $0{,}8P$, więc jego popyt to $Q = 1200 - 0{,}8P$, czyli $P = 1500 - 1{,}25Q$.
> Krzywa popytu przesuwa się w górę, ale **nie równolegle**: rośnie wyraz wolny (1200 → 1500) i zmienia się nachylenie (−1 → −1,25). Ilość maksymalna (przy $P = 0$) się nie zmienia.

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Pozacenowa determinanta popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu) (czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…)).
