---
typ: zadanie
up: "[[Optimum producenta]]"
przykład-z: ["Izokoszta"]
powiązane: ["Piekarnia – minimalny koszt produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = 4L^{1/2}K^{1/2}$, płaca $w = 8$, cena kapitału $r = 2$, budżet 480. Jaką największą produkcję można osiągnąć?

> [!success]- Rozwiązanie
> Optimum: $\frac{MP_L}{MP_K} = \frac{K}{L} = \frac{w}{r} = 4 \Rightarrow K = 4L$.
> $480 = 8L + 2\cdot 4L = 16L \Rightarrow L = 30$, $K = 120$.
> $Q = 4\sqrt{3600} = \mathbf{240}$.

## Jak to się łączy
To zadanie ćwiczy [[Optimum producenta]] (styczność izokwanty i izokoszty: MRTS = w/r; zasada najmniejszego kosztu) oraz [Izokoszta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokoszta) (kombinacje L i K o tym samym koszcie: TC = wL + rK). Podobny schemat rozwiązania ma zadanie [Piekarnia – minimalny koszt produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Piekarnia%20%E2%80%93%20minimalny%20koszt%20produkcji).
