---
typ: zadanie
up: "[[Punkt zamknięcia]]"
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$FC = 90$, $VC = Q^3 - 12Q^2 + 60Q$, $MR = P = 24$. Co powinna zrobić firma?

> [!success]- Rozwiązanie
> $MC = 3Q^2 - 24Q + 60 = 24 \Rightarrow Q^2 - 8Q + 12 = 0 \Rightarrow Q = 2$ lub $Q = 6$ → wybieramy **Q = 6** (rosnąca część MC).
> $AVC = Q^2 - 12Q + 60$, minimum przy $Q = 6$: $AVC = 24 = P$.
> Firma jest w **punkcie zamknięcia**: $TR = 144 = VC$, strata = FC = 90 – tyle samo co przy zamknięciu. Przy każdej niższej cenie trzeba zamknąć.

## Jak to się łączy
To zadanie ćwiczy [[Punkt zamknięcia]] (P = AVCmin, strata = FC; reguła produkować czy zamknąć).
