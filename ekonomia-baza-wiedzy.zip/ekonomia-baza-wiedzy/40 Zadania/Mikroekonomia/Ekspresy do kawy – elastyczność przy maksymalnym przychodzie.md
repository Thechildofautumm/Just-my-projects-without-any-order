---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Elastyczność a przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Producent ekspresów osiąga maksymalny przychód 600 000 zł, sprzedając 500 sztuk (popyt liniowy). Przy jakiej cenie elastyczność cenowa popytu wynosi $-0{,}5$?

> [!success]- Rozwiązanie
> $TR_{max}$ jest w połowie popytu: $P = \frac{600\,000}{500} = 1200 = \frac12P_{max}$ → $P_{max} = 2400$.
> $-0{,}5 = \frac{P}{P - 2400} \Rightarrow -0{,}5P + 1200 = P \Rightarrow P = \mathbf{800}$.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe).
