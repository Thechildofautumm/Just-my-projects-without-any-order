---
typ: zadanie
up: "[[Pozacenowa determinanta popytu]]"
przykład-z: ["Pozacenowa determinanta podaży"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Na rynku smartwatchy ustaliła się nowa równowaga: cena się nie zmieniła, a sprzedaje się mniej sztuk. Jak musiały się zmienić: ceny procesorów do zegarków oraz dochody kupujących?

> [!success]- Rozwiązanie
> Mniejsza ilość przy tej samej cenie oznacza, że **popyt i podaż przesunęły się w lewo** w podobnym stopniu:
> - procesory to czynnik produkcji → ich ceny musiały **wzrosnąć** (spadek podaży),
> - smartwatch to dobro normalne → dochody musiały **spaść** (spadek popytu).

## Jak to się łączy
To zadanie ćwiczy [[Pozacenowa determinanta popytu]] (czynniki przesuwające krzywą popytu (dochód, gusty, ceny innych dóbr…)) oraz [Pozacenowa determinanta podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy) (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)).
