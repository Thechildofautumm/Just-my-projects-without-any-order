---
typ: zadanie
up: "[[Równowaga monopolu]]"
przykład-z: ["Punkt zamknięcia"]
powiązane: ["Monopol – za duża produkcja"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Monopolista: $P = 3{,}2$, $MR = 2{,}4$, $Q = 8000$, $FC = 4800$, $ATC = 4{,}0$, $MC = 2{,}4$. Oceń sytuację.

> [!success]- Rozwiązanie
> $TR = 25\,600$, $TC = 32\,000$ → $\pi = -6400$. $VC = 27\,200$, $AVC = 3{,}4$, $AFC = 0{,}6$.
> Warunek $MR = MC$ jest spełniony, ale $P = 3{,}2 < AVC = 3{,}4$; strata 6400 > FC 4800 → **zamknąć**.

## Jak to się łączy
To zadanie ćwiczy [[Równowaga monopolu]] (MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży) oraz [Punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia) (P = AVCmin, strata = FC; reguła produkować czy zamknąć). Podobny schemat rozwiązania ma zadanie [Monopol – za duża produkcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20za%20du%C5%BCa%20produkcja).
