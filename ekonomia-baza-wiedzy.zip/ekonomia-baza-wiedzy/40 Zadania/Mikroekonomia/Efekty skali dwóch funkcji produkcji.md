---
typ: zadanie
up: "[[Efekty skali]]"
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Określ efekty skali dla funkcji: a) $Q = \sqrt[3]{L} + \sqrt[3]{K}$; b) $Q = 2L^{0,6}K^{0,6}$.

> [!success]- Rozwiązanie
> a) $Q(aL, aK) = a^{1/3}\,Q(L,K) < a\,Q$ → **malejące** efekty skali.
> b) $Q(aL, aK) = 2a^{1,2}L^{0,6}K^{0,6} = a^{1,2}\,Q > a\,Q$ → **rosnące** efekty skali (suma wykładników 1,2 > 1).

## Jak to się łączy
To zadanie ćwiczy [[Efekty skali]] (reakcja produkcji na proporcjonalny wzrost wszystkich nakładów).
