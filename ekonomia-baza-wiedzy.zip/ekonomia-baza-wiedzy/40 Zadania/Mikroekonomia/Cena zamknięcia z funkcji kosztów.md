---
typ: zadanie
up: "[[Punkt zamknięcia]]"
przykład-z: ["Krzywa podaży przedsiębiorstwa"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TC = Q^3 - 6Q^2 + 15Q + 20$ (konkurencja doskonała). Wyznacz cenę zamknięcia.

> [!success]- Rozwiązanie
> $AVC = Q^2 - 6Q + 15$; $AVC' = 2Q - 6 = 0 \Rightarrow Q = 3$, $AVC_{min} = 6$.
> **Punkt zamknięcia: P = 6.** (Cena progu rentowności byłaby wyższa, bo $FC = 20 > 0$.)

## Jak to się łączy
To zadanie ćwiczy [[Punkt zamknięcia]] (P = AVCmin, strata = FC; reguła produkować czy zamknąć) oraz [Krzywa podaży przedsiębiorstwa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20poda%C5%BCy%20przedsi%C4%99biorstwa) (w KD to odcinek MC powyżej AVCmin; suma daje podaż gałęzi).
