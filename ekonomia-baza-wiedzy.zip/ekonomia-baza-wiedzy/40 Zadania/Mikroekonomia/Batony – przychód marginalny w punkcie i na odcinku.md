---
typ: zadanie
up: "[[Przychód]]"
przykład-z: ["Elastyczność łukowa"]
powiązane: ["Zeszyty – elastyczność łukowa i przychód marginalny"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na batony: $P = -2Q + 2000$.
a) Oblicz przychód marginalny przy cenie 400.
b) Oblicz przychód marginalny dla spadku ceny z 1800 do 1600.

> [!success]- Rozwiązanie
> a) $Q = 800$; $MR = -4Q + 2000 = \mathbf{-1200}$ – jesteśmy na nieelastycznym odcinku popytu.
> b) $Q_1 = 100$, $Q_2 = 200$; $E_Ł = \frac{100}{300}\cdot\frac{3400}{-200} = -\frac{17}{3} \approx -5{,}67$; $P_{śr} = 1700$.
> $MR = 1700\left(1 - \frac{3}{17}\right) = \mathbf{1400}$. Kontrola: $\frac{320\,000 - 180\,000}{100} = 1400$ ✔

## Jak to się łączy
To zadanie ćwiczy [[Przychód]] (przychód całkowity, przeciętny i marginalny (TR, AR, MR)) oraz [Elastyczność łukowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20%C5%82ukowa) (elastyczność na odcinku krzywej – wzór ze średnich). Podobny schemat rozwiązania ma zadanie [Zeszyty – elastyczność łukowa i przychód marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zeszyty%20%E2%80%93%20elastyczno%C5%9B%C4%87%20%C5%82ukowa%20i%20przych%C3%B3d%20marginalny).
