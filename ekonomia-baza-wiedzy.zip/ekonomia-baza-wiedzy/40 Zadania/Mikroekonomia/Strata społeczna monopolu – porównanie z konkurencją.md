---
typ: zadanie
up: "[[Strata społeczna monopolu]]"
przykład-z: ["Nadwyżka konsumenta i producenta"]
powiązane: ["Monopol – optymalna cena i zysk"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dla popytu $P = 500 - Q$ i kosztu krańcowego $MC = 2Q + 20$ porównaj rynek konkurencyjny ($P = MC$) z monopolem. Oblicz nadwyżki i stratę społeczną.

> [!success]- Rozwiązanie
> Konkurencja: $500 - Q = 2Q + 20 \Rightarrow Q_k = 160$, $P_k = 340$; CS = 12 800, PS = 25 600, razem 38 400.
> Monopol: $MR = 500 - 2Q = 2Q + 20 \Rightarrow Q_m = 120$, $P_m = 380$, $MC(120) = 260$; CS = 7200, PS = 28 800, razem 36 000.
> **DWL = ½·(380 − 260)·(160 − 120) = 2400** (= 38 400 − 36 000).

## Jak to się łączy
To zadanie ćwiczy [[Strata społeczna monopolu]] (DWL i porównanie monopolu z konkurencją doskonałą) oraz [Nadwyżka konsumenta i producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nadwy%C5%BCka%20konsumenta%20i%20producenta) (korzyści netto kupujących i sprzedających; efektywność wymiany). Podobny schemat rozwiązania ma zadanie [Monopol – optymalna cena i zysk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20optymalna%20cena%20i%20zysk).
