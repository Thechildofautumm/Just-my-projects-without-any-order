---
typ: zadanie
up: "[[Etapy produkcji]]"
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Oceń zdanie: „Racjonalny producent może zatrudniać pracowników do momentu, w którym produkt marginalny staje się ujemny, albo zatrzymać się tam, gdzie produkt przeciętny jeszcze rośnie”. Uzasadnij.

> [!success]- Odpowiedź
> Zdanie jest **fałszywe** w obu częściach. Dopóki AP rośnie (etap I), każdy dodatkowy pracownik podnosi wydajność wszystkich – zatrzymanie się tam marnuje stały czynnik. Przy $MP < 0$ (etap III) dodatkowy pracownik **zmniejsza** produkcję i jeszcze kosztuje. Racjonalny wybór leży w **etapie II**: od maksimum AP do $MP = 0$.

## Jak to się łączy
To zadanie ćwiczy [[Etapy produkcji]] (I, II, III etap wg AP i MP; racjonalny tylko II).
