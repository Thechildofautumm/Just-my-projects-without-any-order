---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Przychód"]
powiązane: ["Elastyczność wyznaczona z przychodu marginalnego"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przy cenie 60 nikt nie kupuje dobra, a przychód marginalny jest równy zero przy sprzedaży 15 sztuk (popyt liniowy). Oblicz elastyczność cenową i przychód całkowity przy cenie 20.

> [!success]- Rozwiązanie
> $P_{max} = 60$; $MR = 0$ przy $\frac12Q_{max} = 15$ → $Q_{max} = 30$, czyli $P = 60 - 2Q$.
> $E_p = \frac{20}{20 - 60} = \mathbf{-0{,}5}$ (popyt nieelastyczny). $Q = \frac{60 - 20}{2} = 20$.
> $TR = 20\cdot 20 = \mathbf{400}$.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) (przychód całkowity, przeciętny i marginalny (TR, AR, MR)). Podobny schemat rozwiązania ma zadanie [Elastyczność wyznaczona z przychodu marginalnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20wyznaczona%20z%20przychodu%20marginalnego).
