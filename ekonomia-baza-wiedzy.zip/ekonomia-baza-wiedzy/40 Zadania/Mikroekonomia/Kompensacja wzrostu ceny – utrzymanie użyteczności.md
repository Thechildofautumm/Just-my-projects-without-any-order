---
typ: zadanie
up: "[[Optimum konsumenta]]"
przykład-z: ["Efekt substytucji i efekt dochodowy"]
powiązane: ["Książki i płyty – optymalny koszyk"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Konsument ma 12 zł, cena gruszek $P_g = 3$, cena śliwek $P_s = 6$, a $TU = Q_g^{0,5}Q_s^{0,5}$.
a) Wyznacz optimum.
b) Cena gruszek rośnie do 12 zł. O ile trzeba zwiększyć budżet, żeby konsument zachował dotychczasową użyteczność?

> [!success]- Rozwiązanie
> a) $\frac{Q_s}{Q_g} = \frac{3}{6} \Rightarrow Q_g = 2Q_s$; $12 = 6Q_s + 6Q_s \Rightarrow Q_s = 1$, $Q_g = 2$; $TU = \sqrt2$.
> b) Nowe ceny: $\frac{Q_s}{Q_g} = \frac{12}{6} \Rightarrow Q_s = 2Q_g$; $\sqrt{Q_g\cdot 2Q_g} = \sqrt2 \Rightarrow Q_g = 1$, $Q_s = 2$.
> $M_2 = 12\cdot 1 + 6\cdot 2 = 24$ → budżet trzeba zwiększyć o **12 zł** (kompensacja efektu dochodowego).

## Jak to się łączy
To zadanie ćwiczy [[Optimum konsumenta]] (styczność krzywej obojętności z linią budżetową: MRS = Px/Py) oraz [Efekt substytucji i efekt dochodowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekt%20substytucji%20i%20efekt%20dochodowy) (dekompozycja reakcji na zmianę ceny). Podobny schemat rozwiązania ma zadanie [Książki i płyty – optymalny koszyk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ksi%C4%85%C5%BCki%20i%20p%C5%82yty%20%E2%80%93%20optymalny%20koszyk).
