---
typ: zadanie
up: "[[Pozacenowa determinanta podaży]]"
przykład-z: ["Interwencja państwa na rynku"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przymrozki zniszczyły część plantacji kawy, a jednocześnie wzrosły stawki transportu morskiego. Jak zmieni się cena i ilość kawy na rynku europejskim?

> [!success]- Rozwiązanie
> Oba zdarzenia działają po stronie **podaży** (mniej surowca, droższy transport) → S wyraźnie w lewo, popyt bez zmian.
> Cena **wyższa**, ilość **niższa** – wynik jednoznaczny.

## Jak to się łączy
To zadanie ćwiczy [[Pozacenowa determinanta podaży]] (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)) oraz [Interwencja państwa na rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interwencja%20pa%C5%84stwa%20na%20rynku) (podatki, dotacje i ceny administracyjne w modelu popytu i podaży).
