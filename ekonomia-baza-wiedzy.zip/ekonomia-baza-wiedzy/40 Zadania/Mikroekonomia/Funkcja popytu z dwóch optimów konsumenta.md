---
typ: zadanie
up: "[[Krzywa cena–konsumpcja]]"
przykład-z: ["Linia budżetowa", "Popyt"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przy budżecie 800 zł i cenach $P_x = 4$, $P_y = 10$ konsument kupuje 80 jednostek X. Gdy $P_x$ rośnie do 10 (reszta bez zmian), kupuje 30 jednostek X. Wyznacz liniową funkcję popytu na X.

> [!success]- Rozwiązanie
> Punkty $(Q; P)$: $(80; 4)$ i $(30; 10)$. $P = aQ + b$:
> $a = \frac{10 - 4}{30 - 80} = -0{,}12$, $b = 4 + 0{,}12\cdot 80 = 13{,}6$.
> $P = 13{,}6 - 0{,}12Q$, czyli $Q \approx 113{,}3 - 8{,}33P$.

## Jak to się łączy
To zadanie ćwiczy [[Krzywa cena–konsumpcja]] (ścieżka optimów przy zmianie ceny X (PCC); wyprowadzenie krzywej popytu), [Linia budżetowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20bud%C5%BCetowa) (koszyki, na które stać konsumenta; przesunięcia i obroty) oraz [Popyt](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) (zależność między ceną a ilością, jaką nabywcy chcą kupić; prawo popytu).
