---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przy $Q = 0$ cena wynosi 600, a przy $Q = 100$ elastyczność cenowa wynosi $-1{,}5$ (popyt liniowy). Zapisz równania AR, MR i TR oraz oblicz $TR_{max}$.

> [!success]- Rozwiązanie
> $-1{,}5 = \frac{100 - Q_{max}}{100} \Rightarrow Q_{max} = 250$.
> $AR = P = 600 - 2{,}4Q$; $TR = 600Q - 2{,}4Q^2$; $MR = 600 - 4{,}8Q$.
> $TR_{max}$ przy $Q = 125$, $P = 300$: $TR_{max} = \mathbf{37\,500}$.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) (przychód całkowity, przeciętny i marginalny (TR, AR, MR)).
