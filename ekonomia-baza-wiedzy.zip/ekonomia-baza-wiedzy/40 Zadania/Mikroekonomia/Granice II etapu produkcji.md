---
typ: zadanie
up: "[[Etapy produkcji]]"
powiązane: ["Granice I i III etapu produkcji", "Wytwórnia przetworów – II etap i powtórna wartość MP"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Krótkookresowa funkcja produkcji: $Q = -2L^3 + 60L^2 + 1800L$. Wyznacz granice racjonalnego etapu produkcji.

> [!success]- Rozwiązanie
> $AP = -2L^2 + 60L + 1800$, $AP' = -4L + 60 = 0 \Rightarrow L = 15$.
> $MP = -6L^2 + 120L + 1800 = 0 \Rightarrow L^2 - 20L - 300 = 0 \Rightarrow (L - 30)(L + 10) = 0 \Rightarrow L = 30$.
> **II etap: $15 \le L \le 30$.**

## Jak to się łączy
To zadanie ćwiczy [[Etapy produkcji]] (I, II, III etap wg AP i MP; racjonalny tylko II). Podobny schemat rozwiązania ma zadania [Granice I i III etapu produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Granice%20I%20i%20III%20etapu%20produkcji) i [Wytwórnia przetworów – II etap i powtórna wartość MP](obsidian://open?vault=ekonomia-baza-wiedzy&file=Wytw%C3%B3rnia%20przetwor%C3%B3w%20%E2%80%93%20II%20etap%20i%20powt%C3%B3rna%20warto%C5%9B%C4%87%20MP).
