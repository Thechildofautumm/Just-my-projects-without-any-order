---
typ: zadanie
up: "[[Maksymalizacja zysku]]"
przykład-z: ["Konkurencja doskonała"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Firma doskonale konkurencyjna: $TC = 0{,}5Q^2 + 4Q + 80$, cena rynkowa $P = 34$. Wyznacz wielkość produkcji maksymalizującą zysk i zysk.

> [!success]- Rozwiązanie
> $MC = Q + 4 = 34 \Rightarrow Q = \mathbf{30}$.
> $TR = 1020$, $TC = 450 + 120 + 80 = 650$ → $\pi = \mathbf{370}$ (zysk ekonomiczny; $ATC \approx 21{,}7 < P$).

## Jak to się łączy
To zadanie ćwiczy [[Maksymalizacja zysku]] (warunek MR = MC i warunek drugiego rzędu) oraz [Konkurencja doskonała](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a) (założenia modelu, popyt firmy (P = MR), równowaga krótko- i długookresowa, cena wyjścia).
