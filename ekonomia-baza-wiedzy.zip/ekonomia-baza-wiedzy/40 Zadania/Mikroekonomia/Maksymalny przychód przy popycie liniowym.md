---
typ: zadanie
up: "[[Przychód]]"
przykład-z: ["Elastyczność a przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt opisuje funkcja $P = -5Q + 2000$. Przy jakiej cenie i ilości przychód całkowity jest największy? Ile wynosi?

> [!success]- Rozwiązanie
> $TR = -5Q^2 + 2000Q$, $MR = -10Q + 2000 = 0 \Rightarrow Q = 200$, $P = 1000$.
> $TR_{max} = 1000\cdot 200 = \mathbf{200\,000}$ (połowa ceny maksymalnej × połowa ilości maksymalnej).

## Jak to się łączy
To zadanie ćwiczy [[Przychód]] (przychód całkowity, przeciętny i marginalny (TR, AR, MR)) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe).
