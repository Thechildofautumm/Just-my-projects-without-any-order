---
typ: zadanie
up: "[[Elastyczność mieszana popytu]]"
przykład-z: ["Równowaga rynkowa"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Rynek margaryny: popyt $P = 500 - 2Q$, podaż $P = 100 + 2Q$. Cena masła wzrosła z 20 do 25 zł, a popyt na margarynę zmienił się na $P = 640 - 2Q$. Oblicz elastyczność mieszaną i określ relację między dobrami.

> [!success]- Rozwiązanie
> Przed: $500 - 2Q = 100 + 2Q \Rightarrow Q_1 = 100$ ($P = 300$). Po: $640 - 2Q = 100 + 2Q \Rightarrow Q_2 = 135$ ($P = 370$).
> $E_m = \frac{\%\Delta Q_{margaryna}}{\%\Delta P_{masło}} = \frac{35\%}{25\%} = \mathbf{1{,}4} > 0$ → **substytuty**.

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność mieszana popytu]] (reakcja popytu na X na cenę Y; rozpoznaje substytuty i komplementy) oraz [Równowaga rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20rynkowa) (cena i ilość, przy których Qd = Qs).
