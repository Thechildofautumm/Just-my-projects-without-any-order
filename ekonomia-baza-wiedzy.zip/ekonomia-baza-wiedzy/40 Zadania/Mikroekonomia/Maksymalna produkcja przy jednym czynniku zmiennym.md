---
typ: zadanie
up: "[[Produkt przeciętny i marginalny]]"
przykład-z: ["Etapy produkcji", "Funkcja produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = -2L^3 + 120L^2 + 3000L$. Przy jakim nakładzie pracy produkcja jest największa i ile wynosi?

> [!success]- Rozwiązanie
> $MP = -6L^2 + 240L + 3000 = 0 \Rightarrow L^2 - 40L - 500 = 0 \Rightarrow (L - 50)(L + 10) = 0 \Rightarrow L = \mathbf{50}$.
> $Q_{max} = -250\,000 + 300\,000 + 150\,000 = \mathbf{200\,000}$.

## Jak to się łączy
To zadanie ćwiczy [[Produkt przeciętny i marginalny]] (TP, AP = Q/L, MP = Q′ i relacje między nimi), [Etapy produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Etapy%20produkcji) (I, II, III etap wg AP i MP; racjonalny tylko II) oraz [Funkcja produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji) (zależność produkcji od nakładów; krótki i długi okres).
