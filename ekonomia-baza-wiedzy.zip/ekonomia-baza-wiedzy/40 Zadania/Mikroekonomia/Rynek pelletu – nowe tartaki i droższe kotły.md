---
typ: zadanie
up: "[[Pozacenowa determinanta podaży]]"
przykład-z: ["Substytucyjność i komplementarność dóbr"]
powiązane: ["Samochody używane – droższy kredyt i niższe cło"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Jednocześnie uruchomiono kilka dużych tartaków (więcej trocin do produkcji pelletu) i wyraźnie zdrożały kotły na pellet. Jak zmieni się równowaga na rynku pelletu?

> [!success]- Rozwiązanie
> - więcej surowca → **wzrost podaży** (S w prawo),
> - kocioł i pellet to dobra **komplementarne** → droższy kocioł → **spadek popytu** na pellet (D w lewo).
> Cena **na pewno spadnie**; ilość zależy od siły obu zmian (może wzrosnąć, spaść albo się nie zmienić).

## Jak to się łączy
To zadanie ćwiczy [[Pozacenowa determinanta podaży]] (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)) oraz [Substytucyjność i komplementarność dóbr](obsidian://open?vault=ekonomia-baza-wiedzy&file=Substytucyjno%C5%9B%C4%87%20i%20komplementarno%C5%9B%C4%87%20d%C3%B3br) (dobra zastępujące się i uzupełniające się). Podobny schemat rozwiązania ma zadanie [Samochody używane – droższy kredyt i niższe cło](obsidian://open?vault=ekonomia-baza-wiedzy&file=Samochody%20u%C5%BCywane%20%E2%80%93%20dro%C5%BCszy%20kredyt%20i%20ni%C5%BCsze%20c%C5%82o).
