---
typ: zadanie
up: "[[Koncentracja rynku]]"
przykład-z: ["Struktura rynkowa"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Udziały firm w rynku: 30%, 22%, 18%, 15%, 10%, 5%. Oblicz CR4 i HHI i oceń strukturę rynku.

> [!success]- Rozwiązanie
> $CR4 = 30 + 22 + 18 + 15 = 85\%$ → **ścisły oligopol** (60–90).
> $HHI = 900 + 484 + 324 + 225 + 100 + 25 = 2058$ → rynek **wysoce skoncentrowany** (powyżej 1800), firmy mają siłę rynkową.

## Jak to się łączy
To zadanie ćwiczy [[Koncentracja rynku]] (CR4 i wskaźnik Herfindahla-Hirschmana (HHI); progi struktur rynku) oraz [Struktura rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa) (typologia rynków wg wpływu firmy na cenę).
