---
typ: zadanie
up: "[[Elastyczność punktowa]]"
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt opisuje funkcja $P = -3Q + 900$. Przy jakiej ilości i cenie współczynnik elastyczności cenowej wynosi $-2$?

> [!success]- Rozwiązanie
> $Q_{max} = 300$, $P_{max} = 900$. Dla popytu liniowego $E_p = \frac{Q - Q_{max}}{Q}$.
> $-2 = \frac{Q - 300}{Q} \Rightarrow -2Q = Q - 300 \Rightarrow Q = \mathbf{100}$, $P = -300 + 900 = \mathbf{600}$.
> Sprawdzenie cenowe: $E_p = \frac{P}{P - P_{max}} = \frac{600}{-300} = -2$ ✔

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)).
