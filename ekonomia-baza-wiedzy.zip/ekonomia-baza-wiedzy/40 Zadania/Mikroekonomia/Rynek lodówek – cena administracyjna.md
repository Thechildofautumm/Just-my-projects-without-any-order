---
typ: zadanie
up: "[[Równowaga rynkowa]]"
przykład-z: ["Nierównowaga rynkowa", "Podaż"]
powiązane: ["Rynek rowerów – równowaga i cena poniżej równowagi"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na lodówki: $P = 5000 - Q$, podaż: $P = 4Q$.
a) Wyznacz równowagę rynkową.
b) Urząd ustala cenę administracyjną 2400 zł. Opisz i oblicz skutek.

> [!success]- Rozwiązanie
> a) $5000 - Q = 4Q \Rightarrow Q_e = \mathbf{1000}$, $P_e = \mathbf{4000}$.
> b) Przy $P = 2400$: $Q_D = 2600$, $Q_S = 600$ → **niedobór 2000 szt.** Sprzedanych zostanie tylko 600 lodówek, pojawią się kolejki i „szara strefa”.

## Jak to się łączy
To zadanie ćwiczy [[Równowaga rynkowa]] (cena i ilość, przy których Qd = Qs), [Nierównowaga rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nier%C3%B3wnowaga%20rynkowa) (niedobór lub nadmiar przy cenie innej niż równowagi; ceny administracyjne) oraz [Podaż](obsidian://open?vault=ekonomia-baza-wiedzy&file=Poda%C5%BC) (zależność między ceną a ilością oferowaną przez producentów; prawo podaży). Podobny schemat rozwiązania ma zadanie [Rynek rowerów – równowaga i cena poniżej równowagi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20rower%C3%B3w%20%E2%80%93%20r%C3%B3wnowaga%20i%20cena%20poni%C5%BCej%20r%C3%B3wnowagi).
