---
typ: zadanie
up: "[[Elastyczność cenowa popytu]]"
przykład-z: ["Elastyczność mieszana popytu", "Elastyczność dochodowa popytu"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Zinterpretuj współczynniki: elastyczności cenowej $E_p = -2{,}5$ i $E_p = -0{,}4$; mieszanej $E_m = -1{,}5$, $E_m = 2$, $E_m = 0$; dochodowej $E_M = 0{,}6$, $E_M = -0{,}3$, $E_M = 1{,}8$.

> [!success]- Rozwiązanie
> - $E_p = -2{,}5$: popyt **elastyczny** – wzrost ceny o 1% zmniejsza ilość o 2,5%; $E_p = -0{,}4$: popyt **nieelastyczny** (spadek o 0,4%).
> - $E_m = -1{,}5$: dobra **komplementarne**; $E_m = 2$: **substytuty**; $E_m = 0$: dobra **niezależne**.
> - $E_M = 0{,}6$: dobro normalne **pierwszej potrzeby**; $E_M = -0{,}3$: dobro **podrzędne**; $E_M = 1{,}8$: dobro **luksusowe** (wyższego rzędu).
> Szczegóły: [[Elastyczność cenowa popytu]], [Elastyczność mieszana popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20mieszana%20popytu), [Elastyczność dochodowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu).

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność cenowa popytu]] (reakcja popytu na cenę własną; klasyfikacja i determinanty), [Elastyczność mieszana popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20mieszana%20popytu) (reakcja popytu na X na cenę Y; rozpoznaje substytuty i komplementy) oraz [Elastyczność dochodowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu) (reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe).
