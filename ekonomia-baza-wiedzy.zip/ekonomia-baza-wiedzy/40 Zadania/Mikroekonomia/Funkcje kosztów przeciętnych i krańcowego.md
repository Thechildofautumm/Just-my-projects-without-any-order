---
typ: zadanie
up: "[[Koszt przeciętny]]"
przykład-z: ["Koszt marginalny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TC = Q^3 - 18Q^2 + 120Q + 800$. Wyznacz ATC, AVC, MC oraz wielkość produkcji przy minimalnym AVC.

> [!success]- Rozwiązanie
> $ATC = Q^2 - 18Q + 120 + \frac{800}{Q}$; $AVC = Q^2 - 18Q + 120$; $MC = 3Q^2 - 36Q + 120$.
> $AVC' = 2Q - 18 = 0 \Rightarrow Q = \mathbf{9}$, $AVC_{min} = \mathbf{39} = MC(9)$ ✔
> Dla porównania: $MC_{min}$ przy $Q = 6$ (MC = 12); $ATC_{min}$ przy $Q \approx 11{,}8$ ($ATC \approx 114{,}6$) – kolejność minimów: MC, AVC, ATC.

## Jak to się łączy
To zadanie ćwiczy [[Koszt przeciętny]] (AFC, AVC, ATC – przebieg w kształcie U) oraz [Koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny) (przyrost TC z dodatkowej jednostki: MC = TC′).
