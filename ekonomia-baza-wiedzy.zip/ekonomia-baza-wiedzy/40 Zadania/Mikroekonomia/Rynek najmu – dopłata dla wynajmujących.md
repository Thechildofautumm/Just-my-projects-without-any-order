---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Pozacenowa determinanta podaży"]
powiązane: ["Kolonie letnie – subwencja dla organizatorów"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Popyt na wynajem mieszkań: $P = 2400 - 0{,}5Q$, podaż: $P = 0{,}5Q$. Gmina chce, żeby czynsz spadł do 900 zł, i w tym celu dopłaca właścicielom stałą kwotę $b$ do każdego wynajętego mieszkania. Ile musi wynosić $b$?

> [!success]- Rozwiązanie
> Równowaga wyjściowa: $2400 - 0{,}5Q = 0{,}5Q \Rightarrow Q_e = 2400$, $P_e = 1200$.
> Dopłata dla sprzedających przesuwa podaż w dół: $P = 0{,}5Q - b$.
> Przy czynszu 900 popyt wynosi: $900 = 2400 - 0{,}5Q \Rightarrow Q' = 3000$.
> Punkt $(3000; 900)$ musi leżeć na nowej podaży: $900 = 1500 - b \Rightarrow b = \mathbf{600}$ zł.

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Pozacenowa determinanta podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy) (czynniki przesuwające krzywą podaży (ceny czynników, technologia, podatki…)). Podobny schemat rozwiązania ma zadanie [Kolonie letnie – subwencja dla organizatorów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kolonie%20letnie%20%E2%80%93%20subwencja%20dla%20organizator%C3%B3w).
