---
typ: zadanie
up: "[[Prawo malejących przychodów]]"
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$Q = -2L^3 + 120L^2 + 1500L$. Od jakiego nakładu pracy zaczyna działać prawo malejących przychodów?

> [!success]- Rozwiązanie
> $MP = -6L^2 + 240L + 1500$; $MP' = -12L + 240 = 0 \Rightarrow L = \mathbf{20}$ (maksimum MP, punkt przegięcia TP).
> Dla $L > 20$ każdy kolejny pracownik zwiększa produkcję o coraz mniej.

## Jak to się łączy
To zadanie ćwiczy [[Prawo malejących przychodów]] (od pewnego poziomu nakładu MP maleje).
