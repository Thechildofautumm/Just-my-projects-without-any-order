---
typ: zadanie
up: "[[Etapy produkcji]]"
powiązane: ["Granice II etapu produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Produkt przeciętny pracy: $AP(L) = -L^2 + 6L + 15$. Wyznacz przedziały nakładu pracy dla I i III etapu produkcji.

> [!success]- Rozwiązanie
> $Q = -L^3 + 6L^2 + 15L$, $MP = -3L^2 + 12L + 15$.
> $AP' = -2L + 6 = 0 \Rightarrow L = 3$; $MP = 0 \Rightarrow L^2 - 4L - 5 = 0 \Rightarrow L = 5$.
> **Etap I: $0 < L < 3$**; (II: 3–5); **Etap III: $L > 5$**.

## Jak to się łączy
To zadanie ćwiczy [[Etapy produkcji]] (I, II, III etap wg AP i MP; racjonalny tylko II). Podobny schemat rozwiązania ma zadanie [Granice II etapu produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Granice%20II%20etapu%20produkcji).
