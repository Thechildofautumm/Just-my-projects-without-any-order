---
typ: zadanie
up: "[[Krzywa Engla]]"
przykład-z: ["Elastyczność dochodowa popytu", "Krzywa dochód–konsumpcja"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
$TU = 2Q_x^{1/4}Q_y^{3/4}$, $P_x = 10$. Wyznacz krzywą Engla dla dobra X i określ rodzaj dobra.

> [!success]- Rozwiązanie
> $\frac{MU_x}{MU_y} = \frac{\frac14 Q_y}{\frac34 Q_x} = \frac{Q_y}{3Q_x} = \frac{10}{P_y} \Rightarrow P_yQ_y = 30Q_x$.
> $M = 10Q_x + 30Q_x = 40Q_x$ → **krzywa Engla: $Q_x = \frac{M}{40}$**.
> Prosta przez początek układu → dobro **normalne**, $E_M = 1$ (na X idzie stale ¼ dochodu).

## Jak to się łączy
To zadanie ćwiczy [[Krzywa Engla]] (ilość dobra jako funkcja dochodu; prawidłowości Engla), [Elastyczność dochodowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu) (reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe) oraz [Krzywa dochód–konsumpcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20doch%C3%B3d%E2%80%93konsumpcja) (ścieżka optimów przy rosnącym dochodzie (ICC)).
