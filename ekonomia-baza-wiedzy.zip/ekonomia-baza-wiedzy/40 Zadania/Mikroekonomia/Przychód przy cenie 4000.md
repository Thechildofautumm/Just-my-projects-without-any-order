---
typ: zadanie
up: "[[Elastyczność punktowa]]"
przykład-z: ["Elastyczność a przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Przy liniowym popycie maksymalny przychód 1 250 000 zł firma osiąga przy sprzedaży 500 sztuk. Ile wyniesie przychód przy cenie 4000 zł?

> [!success]- Rozwiązanie
> $P = \frac{1\,250\,000}{500} = 2500$ → $P_{max} = 5000$, $Q_{max} = 1000$, czyli $P = 5000 - 5Q$.
> Przy $P = 4000$: $Q = 200$; $TR = 4000\cdot 200 = \mathbf{800\,000}$ zł (wyższa cena na elastycznym odcinku obniżyła przychód).

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność punktowa]] (elastyczność w punkcie liniowej krzywej popytu: P/(P−Pmax)) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe).
