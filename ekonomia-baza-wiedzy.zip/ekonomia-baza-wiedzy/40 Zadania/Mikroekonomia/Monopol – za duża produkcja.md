---
typ: zadanie
up: "[[Równowaga monopolu]]"
przykład-z: ["Monopol pełny"]
powiązane: ["Monopol – kiedy zamknąć mimo MR = MC"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Monopolista sprzedaje 5000 sztuk, przychód wynosi 12 500 zł, ATC = 2,2 zł, MC = 2,5 zł. Jaką decyzję powinien podjąć?

> [!success]- Rozwiązanie
> $P = 2{,}5$, $TC = 11\,000$, $\pi = 1500$. W monopolu $MR < P$, więc $MR < 2{,}5 = MC$ → firma produkuje **za dużo**.
> Decyzja: **zmniejszyć produkcję i podnieść cenę**, aż $MR = MC$ (zysk wzrośnie).

## Jak to się łączy
To zadanie ćwiczy [[Równowaga monopolu]] (MR = MC, cena monopolowa z krzywej popytu, brak krzywej podaży) oraz [Monopol pełny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20pe%C5%82ny) (założenia, źródła monopolu, popyt monopolu (P > MR)). Podobny schemat rozwiązania ma zadanie [Monopol – kiedy zamknąć mimo MR = MC](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20kiedy%20zamkn%C4%85%C4%87%20mimo%20MR%20%3D%20MC).
