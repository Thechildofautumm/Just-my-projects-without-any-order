---
typ: zadanie
up: "[[Próg rentowności]]"
powiązane: ["Konkurencja doskonała – strata mniejsza od kosztów stałych"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Cena rynkowa $P = 30$, koszt przeciętny $ATC = Q + \frac{225}{Q}$. Wyznacz wielkość produkcji, zysk i zinterpretuj wynik.

> [!success]- Rozwiązanie
> $TC = Q^2 + 225$, $MC = 2Q = 30 \Rightarrow Q = \mathbf{15}$.
> $TR = 450$, $TC = 450$ → $\pi = \mathbf{0}$: cena równa się $ATC_{min} = 30$, firma jest w **progu rentowności** i osiąga tylko zysk normalny.

## Jak to się łączy
To zadanie ćwiczy [[Próg rentowności]] (BEP w mikroekonomii (P = ATCmin) i w ujęciu ilościowym, wartościowym i procentowym: Q = FC/(P − AVC)). Podobny schemat rozwiązania ma zadanie [Konkurencja doskonała – strata mniejsza od kosztów stałych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a%20%E2%80%93%20strata%20mniejsza%20od%20koszt%C3%B3w%20sta%C5%82ych).
