---
typ: zadanie
up: "[[Elastyczność dochodowa popytu]]"
przykład-z: ["Elastyczność a przychód"]
źródło: ["[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
| Dobro | $E_p$ | $E_M$ |
|---|---|---|
| Masło | −0,30 | 0,40 |
| Łosoś wędzony | −2,20 | 1,90 |
| Ser żółty | −1,20 | 0,80 |

a) Określ, czy dobra są normalne czy podrzędne, oraz czy są pierwszej potrzeby czy luksusowe.
b) Jak sklep powinien zmienić cenę każdego dobra, żeby zwiększyć przychód?

> [!success]- Rozwiązanie
> a) Wszystkie $E_M > 0$ → **normalne**. Masło i ser ($0 < E_M < 1$) – **pierwszej potrzeby**; łosoś ($E_M > 1$) – **luksusowe**.
> b) Masło: popyt nieelastyczny → **podnieść** cenę. Łosoś i ser: popyt elastyczny → **obniżyć** cenę (przy serze efekt będzie niewielki, bo $|E_p|$ jest bliskie 1).

## Jak to się łączy
To zadanie ćwiczy [[Elastyczność dochodowa popytu]] (reakcja popytu na dochód; dobra normalne, podrzędne, podstawowe, luksusowe) oraz [Elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep), TRmax przy |Ep| = 1, decyzje cenowe).
