---
typ: zadanie
up: "[[Optimum konsumenta]]"
przykład-z: ["Linia budżetowa"]
powiązane: ["Kompensacja wzrostu ceny – utrzymanie użyteczności"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Konsument ma 720 zł, książka kosztuje 6 zł (antykwariat), a płyta 9 zł. Użyteczność: $TU = Q_k\cdot Q_p$. Wyznacz optymalny koszyk.

> [!success]- Rozwiązanie
> $MU_k = Q_p$, $MU_p = Q_k$ → warunek optimum $\frac{Q_p}{Q_k} = \frac69 \Rightarrow 6Q_k = 9Q_p$.
> Budżet: $720 = 6Q_k + 9Q_p = 12Q_k \Rightarrow Q_k = \mathbf{60}$, $Q_p = \mathbf{40}$; $TU = 2400$.
> Przy tej funkcji użyteczności na każde dobro idzie połowa dochodu.

## Jak to się łączy
To zadanie ćwiczy [[Optimum konsumenta]] (styczność krzywej obojętności z linią budżetową: MRS = Px/Py) oraz [Linia budżetowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20bud%C5%BCetowa) (koszyki, na które stać konsumenta; przesunięcia i obroty). Podobny schemat rozwiązania ma zadanie [Kompensacja wzrostu ceny – utrzymanie użyteczności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kompensacja%20wzrostu%20ceny%20%E2%80%93%20utrzymanie%20u%C5%BCyteczno%C5%9Bci).
