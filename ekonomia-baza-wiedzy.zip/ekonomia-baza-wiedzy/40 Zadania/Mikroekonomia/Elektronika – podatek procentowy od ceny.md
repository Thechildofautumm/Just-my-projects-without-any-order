---
typ: zadanie
up: "[[Interwencja państwa na rynku]]"
przykład-z: ["Incydencja podatkowa"]
źródło: ["[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Popyt na słuchawki: $P = 1800 - Q$, podaż: $P = 200 + 1{,}5Q$. Wprowadzono podatek, po którym producenci otrzymują tylko 50% ceny płaconej przez kupujących. O ile procent wzrośnie cena rynkowa?

> [!success]- Rozwiązanie
> Przed: $1800 - Q = 200 + 1{,}5Q \Rightarrow Q_e = 640$, $P_e = 1160$.
> Po: producent dostaje $0{,}5P$, więc $0{,}5P = 200 + 1{,}5Q \Rightarrow P = 400 + 3Q$.
> $1800 - Q = 400 + 3Q \Rightarrow Q' = 350$, $P' = 1450$.
> Wzrost ceny: $\frac{1450 - 1160}{1160} = \mathbf{25\%}$. Producent otrzymuje 725 zł, czyli mniej niż przed podatkiem – ciężar podatku dzielą obie strony.

## Jak to się łączy
To zadanie ćwiczy [[Interwencja państwa na rynku]] (podatki, dotacje i ceny administracyjne w modelu popytu i podaży) oraz [Incydencja podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Incydencja%20podatkowa) (kto faktycznie ponosi ciężar podatku; podatnik formalny vs materialny; przerzucalność).
