---
typ: zadanie
up: "[[Użyteczność]]"
przykład-z: ["Analiza marginalna"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
| Seanse w miesiącu | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| TU [zł] | 0 | 40 | 75 | 105 | 130 | 150 | 160 | 165 |

a) Oblicz użyteczność marginalną.
b) Ile seansów wybierze konsument przy cenie biletu 18 zł?
c) Ile – po podwyżce ceny do 26 zł?

> [!success]- Rozwiązanie
> a) $MU = \frac{\Delta TU}{\Delta Q}$: **40, 35, 30, 25, 20, 10, 5**.
> b) Kupuje, dopóki $MU \ge P$: 5. seans ma $MU = 20 \ge 18$, 6. ma $10 < 18$ → **5 seansów**.
> c) $P = 26$: 3. seans ($MU = 30$) tak, 4. ($MU = 25$) już nie → **3 seanse**.

## Jak to się łączy
To zadanie ćwiczy [[Użyteczność]] (zadowolenie z konsumpcji; TU, MU i prawo malejącej użyteczności marginalnej) oraz [Analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) (porównywanie korzyści i kosztów ostatniej jednostki; optimum MB = MC).
