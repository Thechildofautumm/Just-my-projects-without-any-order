---
typ: zadanie
up: "[[Maksymalizacja zysku]]"
przykład-z: ["Koszt przeciętny"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Trzy firmy doskonale konkurencyjne. Uzupełnij tabelę i oceń, czy każda maksymalizuje zysk (MC′ „+” oznacza, że MC rośnie).

| Firma | P | Q | TR | TC | FC | VC | AFC | ATC | AVC | MC | MC′ |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A | | | 12 000 | | 1500 | | | 3,20 | 2,70 | 3,60 | + |
| B | | | 8 400 | | 1500 | | | 3,20 | 2,70 | 3,60 | + |
| C | | | 18 000 | 15 000 | 3000 | | | | min | 6,00 | + |

> [!success]- Rozwiązanie
> **A:** $AFC = 3{,}20 - 2{,}70 = 0{,}50$ → $Q = \frac{1500}{0{,}5} = 3000$; $P = 4$; $TC = 9600$; $VC = 8100$; $\pi = 2400$. $P = 4 > MC = 3{,}6$ → **zwiększyć produkcję**.
> **B:** $Q = 3000$; $P = 2{,}80$; $TC = 9600$; $VC = 8100$; $\pi = -1200$. $P < MC$ → **zmniejszyć produkcję** (cena 2,80 jest wyższa od AVC = 2,70, więc nie zamykać od razu).
> **C:** $VC = 12\,000$; AVC w minimum ⇒ $AVC = MC = 6$ → $Q = 2000$; $P = 9$; $AFC = 1{,}5$; $ATC = 7{,}5$; $\pi = 3000$. $P > MC$ → **zwiększyć produkcję**.

## Jak to się łączy
To zadanie ćwiczy [[Maksymalizacja zysku]] (warunek MR = MC i warunek drugiego rzędu) oraz [Koszt przeciętny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny) (AFC, AVC, ATC – przebieg w kształcie U).
