---
typ: zadanie
up: "[[Hipotetyczne odsetki od kapitału własnego]]"
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Spółka zwiększyła kapitał zapasowy z zysku. Ile hipotetycznych odsetek (NID, art. 15cb ustawy o CIT) może zaliczyć do kosztów, jeśli zatrzymała: a) 3 mln zł, b) 5 mln zł, c) 20 mln zł? Przyjmij stopę (referencyjna NBP + 1 pkt proc.) 5,75% i limit 250 000 zł rocznie.

> [!success]- Rozwiązanie
> a) $3\,000\,000\cdot 5{,}75\% = 172\,500$ zł $< 250\,000$ → koszt **172 500 zł**.
> b) $5\,000\,000\cdot 5{,}75\% = 287\,500$ zł → limit → **250 000 zł**.
> c) $20\,000\,000\cdot 5{,}75\% = 1\,150\,000$ zł → limit → **250 000 zł**.
> Przy 19% CIT największa roczna oszczędność to $250\,000\cdot 19\% = 47\,500$ zł. Limit sprawia, że NID realnie pomaga głównie mniejszym spółkom.

> [!note] Stopa zmienia się w czasie
> Stopa w zadaniu jest przykładowa – przed egzaminem sprawdź aktualną stopę referencyjną NBP i warunki ulgi.

## Jak to się łączy
To zadanie ćwiczy [[Hipotetyczne odsetki od kapitału własnego]] (NID (art. 15cb): stopa ref. NBP + 1 p.p., limit 250 000 zł, podejście przyrostowe).
