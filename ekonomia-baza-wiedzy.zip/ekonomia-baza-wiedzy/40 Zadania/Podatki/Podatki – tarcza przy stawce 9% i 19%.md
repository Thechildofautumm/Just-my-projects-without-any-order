---
typ: zadanie
up: "[[Tarcza podatkowa]]"
przykład-z: ["Preferencyjna stawka CIT"]
źródło: ["[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Spółka może odliczyć od dochodu 25 000 zł. Porównaj wartość tarczy podatkowej przy stawce CIT 9% i 19%. Od czego jeszcze zależy wartość tarczy?

> [!success]- Rozwiązanie
> Tarcza = odliczenie × stawka:
> - przy 9%: $25\,000\cdot 0{,}09 = \mathbf{2250}$ zł,
> - przy 19%: $25\,000\cdot 0{,}19 = \mathbf{4750}$ zł.
>
> To samo odliczenie od dochodu jest **więcej warte** przy wyższej stawce. Wartość tarczy zależy też od wysokości dochodu (czy jest od czego odliczyć), limitów ustawowych i możliwości przeniesienia nieodliczonej kwoty na kolejne lata albo zwrotu.

## Jak to się łączy
To zadanie ćwiczy [[Tarcza podatkowa]] (oszczędność podatkowa z odliczenia = odliczenie × stawka; od czego zależy) oraz [Preferencyjna stawka CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencyjna%20stawka%20CIT) (9% dla małych podatników poza zyskami kapitałowymi; wyłączenia, limity, strategie).
