---
typ: zadanie
up: "[[Rozliczanie straty podatkowej w czasie]]"
źródło: ["[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dochód spółki w 2026 r. wynosi 9 mln zł. Ile straty z 2025 r. można odliczyć w 2026 r. metodą tradycyjną (najwyżej 50% straty w roku) i metodą jednorazową (do 5 mln zł), jeśli strata wynosiła: a) 3 mln zł; b) 18 mln zł?

> [!success]- Rozwiązanie
>
> | Strata 2025 | Metoda tradycyjna (≤ 50%) | Metoda jednorazowa (≤ 5 mln) | Lepsza w 2026 |
> |---|---|---|---|
> | 3 mln | 1,5 mln | **3 mln** | jednorazowa |
> | 18 mln | **9 mln** | 5 mln | tradycyjna |
>
> Przy małej stracie metoda jednorazowa rozlicza ją od razu; przy dużej limit 5 mln jest niższy niż połowa straty. Odliczenie nie może przekroczyć dochodu (w b) 9 mln to akurat cały dochód); reszta straty – w kolejnych latach okresu pięcioletniego.

## Jak to się łączy
To zadanie ćwiczy [[Rozliczanie straty podatkowej w czasie]] (wprzód: 5 lat, max 50% rocznie albo jednorazowo do 5 mln zł; wstecz – wyjątki).
