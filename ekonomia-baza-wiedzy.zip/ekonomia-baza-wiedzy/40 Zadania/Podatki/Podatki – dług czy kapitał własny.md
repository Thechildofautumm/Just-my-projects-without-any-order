---
typ: zadanie
up: "[[Asymetria podatkowa finansowania]]"
przykład-z: ["Tarcza podatkowa"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Spółka ma zysk operacyjny (EBIT) 2 000 000 zł i stawkę CIT 19%. Porównaj podatek przy finansowaniu inwestycji kapitałem własnym oraz pożyczką z odsetkami 300 000 zł rocznie. Skąd różnica?

> [!success]- Rozwiązanie
>
> | | Kapitał własny | Dług |
> |---|---|---|
> | EBIT | 2 000 000 | 2 000 000 |
> | odsetki (koszt podatkowy) | – | 300 000 |
> | podstawa opodatkowania | 2 000 000 | 1 700 000 |
> | **CIT 19%** | **380 000** | **323 000** |
>
> Różnica **57 000 zł** to tarcza odsetkowa ($300\,000\cdot 19\%$). Odsetki są kosztem, a dywidenda – podziałem zysku po opodatkowaniu. Ta **asymetria** (debt–equity bias) zachęca do finansowania długiem.

## Jak to się łączy
To zadanie ćwiczy [[Asymetria podatkowa finansowania]] (odsetki są KUP, dywidendy nie → preferencja długu (debt-equity bias); CBIT) oraz [Tarcza podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa) (oszczędność podatkowa z odliczenia = odliczenie × stawka; od czego zależy).
