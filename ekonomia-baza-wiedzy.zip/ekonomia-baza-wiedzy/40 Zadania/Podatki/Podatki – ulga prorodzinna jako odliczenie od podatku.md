---
typ: zadanie
up: "[[Odliczenie podatkowe]]"
przykład-z: ["Preferencja podatkowa"]
źródło: ["[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Podatek obliczony według skali wynosi 6000 zł, a podatnik wychowuje dwoje dzieci (ulga 1112,04 zł na każde z pierwszych dwojga dzieci). Ile wynosi oszczędność podatkowa? Czym ten typ odliczenia różni się od odliczenia od dochodu?

> [!success]- Rozwiązanie
> Ulga: $2\cdot 1112{,}04 = \mathbf{2224{,}08}$ zł; podatek po uldze $6000 - 2224{,}08 = 3775{,}92$ zł.
> Odliczenie **od podatku** zmniejsza podatek złotówka w złotówkę – oszczędność nie zależy od stawki. Odliczenie **od dochodu** daje oszczędność równą odliczeniu × stawka.
> Wartość odliczenia od podatku ogranicza wysokość podatku, chyba że ulga jest **zwrotna** (nadwyżkę wypłaca się podatnikowi w granicach określonych w ustawie).

## Jak to się łączy
To zadanie ćwiczy [[Odliczenie podatkowe]] (na I etapie (od dochodu/podstawy) vs na II etapie (od podatku)) oraz [Preferencja podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencja%20podatkowa) (ulga, zwolnienie, wyłączenie; tax expenditures).
