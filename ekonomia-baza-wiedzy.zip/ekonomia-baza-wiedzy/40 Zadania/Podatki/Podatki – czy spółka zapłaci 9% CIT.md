---
typ: zadanie
up: "[[Mały podatnik]]"
przykład-z: ["Preferencyjna stawka CIT", "Planowanie podatkowe"]
źródło: ["[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Spółka z o.o. działa od 2022 r. (nie powstała z przekształcenia). Jej przychody ze sprzedaży brutto (z VAT) w 2025 r. wyniosły 7,5 mln zł. W 2026 r. przychody operacyjne netto wyniosą 7,9 mln zł, a dochód operacyjny 1,0 mln zł. Spółka planuje też sprzedać udziały w innej spółce: przychód 0,6 mln zł, dochód 0,2 mln zł. Limity na 2026 r.: status małego podatnika – 8 517 000 zł (przychody brutto roku poprzedniego), stawka 9% – 8 431 000 zł (przychody bieżącego roku).
a) Czy spółka jest w 2026 r. małym podatnikiem?
b) Czy może zastosować stawkę 9%, jeśli sprzeda udziały w 2026 r.?
c) Porównaj CIT za 2026 r. przy sprzedaży udziałów w 2026 r. i przy przesunięciu sprzedaży na 2027 r.

> [!success]- Rozwiązanie
> **a)** $7{,}5 \text{ mln} \le 8{,}517 \text{ mln}$ → **tak**, jest małym podatnikiem.
> **b)** Do limitu stawki 9% wliczają się **wszystkie** przychody, także z zysków kapitałowych: $7{,}9 + 0{,}6 = 8{,}5 \text{ mln} > 8{,}431 \text{ mln}$ → **nie**, cały dochód podlega stawce 19%.
> **c)**
>
> | Wariant | Przychody 2026 | Stawka | CIT 2026 |
> |---|---|---|---|
> | sprzedaż w 2026 | 8,5 mln | 19% od 1,2 mln | **228 000 zł** |
> | sprzedaż w 2027 | 7,9 mln | 9% od 1,0 mln | **90 000 zł** |
>
> Przesunięcie transakcji obniża CIT za 2026 r. o 138 000 zł (zysk kapitałowy zostanie opodatkowany 19% w 2027 r. – 38 000 zł). To typowa strategia planowania podatkowego wokół limitu.

> [!warning] Do weryfikacji
> Ćwiczenie własne zbudowane na zasadach z wykładu (limity na 2026 r.). Sprawdź aktualne limity i warunki przed egzaminem.

## Jak to się łączy
Część a) sprawdza status [[Mały podatnik|małego podatnika]] (przychody roku poprzedniego), a część b) – warunki [preferencyjnej stawki CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencyjna%20stawka%20CIT) (przychody roku bieżącego, łącznie z zyskami kapitałowymi). Część c) to przykład [planowania podatkowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Planowanie%20podatkowe) przez przesunięcie transakcji w czasie.
