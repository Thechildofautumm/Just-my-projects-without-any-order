---
typ: zadanie
up: "[[Limit kosztów finansowania dłużnego]]"
przykład-z: ["Niedostateczna kapitalizacja"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Oceń, czy spółka może zaliczyć do kosztów uzyskania przychodów całe koszty finansowania dłużnego (art. 15c ustawy o CIT):
1) przychody odsetkowe 2 mln zł, koszty finansowania 1,5 mln zł;
2) przychody odsetkowe 1 mln zł, koszty finansowania 8 mln zł, podatkowa EBITDA 20 mln zł.

> [!success]- Rozwiązanie
> Limit dotyczy **nadwyżki** kosztów finansowania nad przychodami odsetkowymi; w kosztach można ująć nadwyżkę do wyższej z kwot: **3 mln zł** albo **30% podatkowej EBITDA**.
> **1)** $1{,}5 < 2$ → brak nadwyżki → **całość w kosztach**.
> **2)** Nadwyżka $8 - 1 = 7$ mln; $30\%\cdot 20 = 6$ mln $> 3$ mln → limit 6 mln.
> Poza kosztami: $7 - 6 = \mathbf{1}$ mln zł – można je rozliczyć w kolejnych **5 latach** w ramach limitów.

## Jak to się łączy
To zadanie ćwiczy [[Limit kosztów finansowania dłużnego]] (art. 15c: nadwyżka kosztów długu ponad max(3 mln zł; 30% EBITDA) jest NKUP; przeniesienie na 5 lat) oraz [Niedostateczna kapitalizacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Niedostateczna%20kapitalizacja) (nadmierne finansowanie długiem wewnętrznym; tradycyjne przepisy (3× kapitał)).
