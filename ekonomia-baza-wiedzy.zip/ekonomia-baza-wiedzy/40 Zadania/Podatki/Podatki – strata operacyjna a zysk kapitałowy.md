---
typ: zadanie
up: "[[Strata podatkowa]]"
przykład-z: ["Źródło przychodów w CIT", "Dochód podatkowy"]
powiązane: ["Podatki – strata spółki a dochód z JDG"]
źródło: ["[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Spółka ma stratę z działalności operacyjnej 250 000 zł. W tym samym roku sprzedała udziały w innej spółce: koszt nabycia 300 000 zł, przychód 450 000 zł. Czy może wykazać łączny wynik $-250\,000 + 150\,000 = -100\,000$ zł?

> [!success]- Rozwiązanie
> **Nie.** W CIT są dwa źródła przychodów: **zyski kapitałowe** i **inne źródła**. Strat z jednego źródła nie łączy się z dochodem z drugiego.
> - zyski kapitałowe: dochód $150\,000$ → CIT 19% = **28 500 zł**,
> - inne źródła: strata **250 000 zł** → do rozliczenia w kolejnych 5 latach z dochodami z tego samego źródła.

## Jak to się łączy
To zadanie ćwiczy [[Strata podatkowa]] (rozliczanie straty tylko w obrębie źródła (CIT i PIT); spółki transparentne), [Źródło przychodów w CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=%C5%B9r%C3%B3d%C5%82o%20przychod%C3%B3w%20w%20CIT) (zyski kapitałowe vs inne źródła; rodzaje spółek; stawki 19% i 9%) oraz [Dochód podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Doch%C3%B3d%20podatkowy) (przychody − koszty uzyskania przychodów (KUP) ze źródła; ujemny wynik = strata). Podobny schemat rozwiązania ma zadanie [Podatki – strata spółki a dochód z JDG](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20strata%20sp%C3%B3%C5%82ki%20a%20doch%C3%B3d%20z%20JDG).
