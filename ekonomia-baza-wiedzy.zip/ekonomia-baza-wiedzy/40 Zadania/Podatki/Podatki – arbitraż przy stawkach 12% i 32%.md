---
typ: zadanie
up: "[[Arbitraż podatkowy]]"
przykład-z: ["Planowanie podatkowe", "Unikanie i uchylanie się od opodatkowania"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Dwie osoby współpracujące w rodzinnym biznesie płacą PIT według skali: osoba A w progu 12%, osoba B w progu 32%. U kogo opłaca się „umieścić” przychód, a u kogo koszt? Pokaż to na przychodzie i koszcie po 15 000 zł.

> [!success]- Rozwiązanie
> - **Przychód** → u osoby z **niższą** stawką (A): podatek $15\,000\cdot 12\% = 1800$ zł zamiast $4800$ zł – oszczędność 3000 zł.
> - **Koszt** → u osoby z **wyższą** stawką (B): tarcza $15\,000\cdot 32\% = 4800$ zł zamiast $1800$ zł – o 3000 zł większa.
>
> To arbitraż między podatnikami w różnych progach. Granica: przesunięcia muszą mieć uzasadnienie gospodarcze – sztuczne konstrukcje mogą zostać uznane za unikanie opodatkowania.

## Jak to się łączy
To zadanie ćwiczy [[Arbitraż podatkowy]] (wykorzystanie różnic w opodatkowaniu podatników lub strumieni dochodu), [Planowanie podatkowe](obsidian://open?vault=ekonomia-baza-wiedzy&file=Planowanie%20podatkowe) (uwzględnianie podatków w planowaniu finansowym; strategia podatkowa jako część strategii firmy) oraz [Unikanie i uchylanie się od opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania) (legalne obniżanie obciążeń vs działania z naruszeniem prawa).
