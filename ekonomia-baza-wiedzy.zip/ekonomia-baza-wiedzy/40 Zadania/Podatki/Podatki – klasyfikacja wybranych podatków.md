---
typ: zadanie
up: "[[Klasyfikacja podatków]]"
przykład-z: ["Podatek", "System podatkowy w Polsce"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Sklasyfikuj podatki: PIT, CIT, VAT, akcyzę, podatek od spadków i darowizn oraz podatek rolny według trzech kryteriów: (1) przedmiot opodatkowania, (2) kto faktycznie ponosi ciężar, (3) komu przypadają wpływy.

> [!success]- Rozwiązanie
>
> | Podatek | Przedmiot | Ciężar | Wpływy |
> |---|---|---|---|
> | PIT | dochodowy | bezpośredni | wspólny (państwo + samorządy) |
> | CIT | dochodowy | bezpośredni | wspólny |
> | VAT | konsumpcyjny | pośredni | państwowy |
> | akcyza | konsumpcyjny | pośredni | państwowy |
> | od spadków i darowizn | majątkowy | bezpośredni | lokalny (gminny) |
> | rolny | majątkowy | bezpośredni | lokalny (gminny) |
>
> Klucz: podatek **pośredni** formalnie płaci sprzedawca, ale ciężar przerzuca na nabywcę w cenie; **bezpośredni** ponosi sam podatnik. O charakterze daniny decyduje jej konstrukcja, a nie nazwa.

## Jak to się łączy
To zadanie ćwiczy [[Klasyfikacja podatków]] (według przedmiotu, ponoszenia ciężaru (bezpośrednie/pośrednie) i adresata wpływów), [Podatek](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek) (przymusowe, bezzwrotne, nieodpłatne, ogólne świadczenie pieniężne na rzecz władzy publicznej) oraz [System podatkowy w Polsce](obsidian://open?vault=ekonomia-baza-wiedzy&file=System%20podatkowy%20w%20Polsce) (katalog podatków, tax mix, podział PIT i CIT z samorządami).
