---
typ: zadanie
up: "[[Strata podatkowa]]"
powiązane: ["Podatki – strata operacyjna a zysk kapitałowy"]
źródło: ["[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Przedsiębiorczyni ma dochód 350 000 zł z jednoosobowej działalności. Czy może wykazać łączny dochód 150 000 zł, jeśli: a) poniosła stratę 200 000 zł jako wspólniczka spółki jawnej (niebędącej podatnikiem CIT); b) strata 200 000 zł dotyczy jej spółki z o.o.?

> [!success]- Rozwiązanie
> **a) Co do zasady tak** – taka spółka jest **transparentna podatkowo**: jej wynik rozlicza wspólnik w PIT, w tym samym źródle (działalność gospodarcza) co JDG.
> **b) Nie** – spółka z o.o. jest odrębnym podatnikiem CIT; jej strata rozlicza się tylko z jej własnymi przyszłymi dochodami.

> [!warning] Do weryfikacji
> Łączenie wyników wymaga, by oba dochody były opodatkowane w ten sam sposób (np. oba według skali albo oba liniowo). Sprawdź też, czy spółka jawna nie stała się podatnikiem CIT.

## Jak to się łączy
To zadanie ćwiczy [[Strata podatkowa]] (rozliczanie straty tylko w obrębie źródła (CIT i PIT); spółki transparentne). Podobny schemat rozwiązania ma zadanie [Podatki – strata operacyjna a zysk kapitałowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20strata%20operacyjna%20a%20zysk%20kapita%C5%82owy).
