---
typ: zadanie
up: "[[Marża wkładu]]"
przykład-z: ["Klasyfikacja kosztów", "Rachunkowość zarządcza a finansowa"]
powiązane: ["Velomia – wielostopniowy rachunek marż", "Velomia – zamówienie specjalne na Urban 5"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
*Velomia S.A. to fikcyjny producent rowerów elektrycznych wymyślony na potrzeby tej bazy.*
Zarząd Velomii pyta trzy działy, ile firma zarabia na rowerze Urban 5 (cena netto 9600 zł). Koszty zmienne wynoszą 5800 zł, koszt wytworzenia według ustawy o rachunkowości 7400 zł, a zespół wdrażający rachunek kosztów działań podaje wynik 700 zł na sztuce (po kosztach gwarancji, obsługi dealerów i logistyki).
a) Oblicz marżę brutto na sprzedaży i marżę wkładu.
b) Wyjaśnij, dlaczego każda z trzech odpowiedzi jest poprawna.
c) Marża wkładu na sztuce wynosi: a) 2200, b) 3800, c) 1600, d) 700.

> [!success]- Rozwiązanie
>
> | Dział | Miara | Obliczenie | Wynik |
> |---|---|---|---|
> | Księgowość | marża brutto na sprzedaży | $9600 - 7400$ | **2200 zł** |
> | Kontroling | marża wkładu | $9600 - 5800$ | **3800 zł** |
> | Zespół ABC | wynik po kosztach działań | z modelu ABC | **700 zł** |
>
> **b)** Każda liczba odpowiada na inne pytanie: 2200 – wycena zapasów i sprawozdawczość; 3800 – ile dodatkowy rower wnosi do pokrycia kosztów stałych (decyzje krótkookresowe, CVP); 700 – rentowność po kosztach obsługi (decyzje asortymentowe i cenowe). To zasada „różne koszty do różnych celów”.
> **c)** **b) 3800 zł.** Pułapka: 2200 to marża po koszcie wytworzenia, a 1600 to stałe koszty produkcji przypadające na sztukę.

## Jak to się łączy
To zadanie ćwiczy [[Marża wkładu]] (cena − koszty zmienne; wielostopniowy rachunek marż), [Klasyfikacja kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Klasyfikacja%20koszt%C3%B3w) („różne koszty do różnych celów” (Clark): rodzaj, funkcja, przypisanie, zachowanie, znaczenie dla decyzji, kontrolowalność) oraz [Rachunkowość zarządcza a finansowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza%20a%20finansowa) (adresat, regulacje, orientacja w czasie, miary, częstotliwość). Podobny schemat rozwiązania ma zadania [Velomia – wielostopniowy rachunek marż](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20wielostopniowy%20rachunek%20mar%C5%BC) i [Velomia – zamówienie specjalne na Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20zam%C3%B3wienie%20specjalne%20na%20Urban%205).
