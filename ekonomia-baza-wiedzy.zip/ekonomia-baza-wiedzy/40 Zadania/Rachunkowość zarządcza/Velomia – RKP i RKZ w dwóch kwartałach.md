---
typ: zadanie
up: "[[Rachunek kosztów zmiennych i pełnych]]"
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Urban 5: cena 9600 zł, zmienne koszty produkcji 5800 zł, zmienne koszty sprzedaży 300 zł/szt., stałe koszty produkcji 6,4 mln zł na kwartał przy normalnych mocach 4000 szt. (stawka 1600 zł/szt.), stałe koszty sprzedaży i zarządu 2,5 mln zł na kwartał. Kw. I: produkcja 4000, sprzedaż 3400; kw. II: produkcja 3500, sprzedaż 4100. Oblicz wyniki w RKZ i RKP i uzgodnij różnicę.

> [!success]- Rozwiązanie
> **RKZ** (marża wkładu $9600 - 5800 - 300 = 3500$ zł/szt.; koszty stałe $6{,}4 + 2{,}5 = 8{,}9$ mln):
> Kw. I: $3500\cdot 3400 = 11{,}90$ mln → **3,00 mln**. Kw. II: $3500\cdot 4100 = 14{,}35$ mln → **5,45 mln**.
> **RKP** (koszt wytworzenia $5800 + 1600 = 7400$; marża brutto 2200 zł/szt.):
> Kw. I: $2200\cdot 3400 = 7{,}48$; sprzedaż i zarząd $0{,}3\cdot 3400/1000 + 2{,}5 = 3{,}52$ → **3,96 mln**.
> Kw. II: $2200\cdot 4100 = 9{,}02$; niewykorzystane moce $500\cdot 1600 = 0{,}80$; sprzedaż i zarząd $3{,}73$ → **4,49 mln**.
> **Uzgodnienie:** Δ zapasu × stawka: kw. I $+600\cdot 1600 = +0{,}96$ mln; kw. II $-600\cdot 1600 = -0{,}96$ mln. Łącznie oba rachunki dają **8,45 mln**.
> Wniosek: w RKP produkcja na zapas „poprawia” wynik okresu; RKZ zależy tylko od sprzedaży.

## Jak to się łączy
To zadanie ćwiczy [[Rachunek kosztów zmiennych i pełnych]] (RKZ vs RKP: gdzie trafiają stałe koszty pośrednie; uzgodnienie wyników).
