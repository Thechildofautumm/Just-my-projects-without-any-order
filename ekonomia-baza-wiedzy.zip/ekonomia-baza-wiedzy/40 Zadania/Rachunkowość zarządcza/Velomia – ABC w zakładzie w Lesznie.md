---
typ: zadanie
up: "[[Rachunek kosztów działań]]"
przykład-z: ["Hierarchia kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Zakład w Lesznie rozlicza 8 mln zł kosztów pośrednich na rowery towarowe Cargo 6 (1200 szt., 48 partii po 25 szt.) i Cargo 8 (240 szt., 48 partii po 5 szt.).

| Działanie | Koszt (mln) | Nośnik | Cargo 6 | Cargo 8 |
|---|---|---|---|---|
| Przezbrojenia i przygotowanie partii | 1,92 | liczba partii | 48 | 48 |
| Inżynieria i konfiguracja | 3,20 | godziny inżynierii | 2000 | 3000 |
| Testy i kontrola jakości | 1,20 | liczba testów | 1200 | 480 |
| Obsługa linii | 1,68 | maszynogodziny | 6000 | 1600 |

Oblicz stawki działań i koszt pośredni na sztukę. Cargo 8 kosztuje 16 000 zł, a koszty bezpośrednie wynoszą 9000 zł – jaki jest wynik na sztuce? Porównaj z rozliczeniem jedną stawką na roboczogodzinę (Cargo 6 – 30 rbh/szt., Cargo 8 – 35 rbh/szt.).

> [!success]- Rozwiązanie
> Stawki: 20 000 zł/partia; 640 zł/h; 714,29 zł/test; 221,05 zł/mh.
>
> | Działanie | Cargo 6 (tys. zł) | Cargo 8 (tys. zł) |
> |---|---|---|
> | przezbrojenia | 960 | 960 |
> | inżynieria | 1280 | 1920 |
> | testy | 857,1 | 342,9 |
> | obsługa linii | 1326,3 | 353,7 |
> | **razem** | **4423,5** | **3576,5** |
> | **na sztukę** | **3686 zł** | **14 902 zł** |
>
> Wynik Cargo 8 w ABC: $16\,000 - 9000 - 14\,902 = \mathbf{-7902}$ zł/szt.
> Jedna stawka: $8\,000\,000 / 44\,400 \text{ rbh} = 180{,}18$ zł/rbh → Cargo 8: $35\cdot 180{,}18 = 6306$ zł → wynik **+694 zł**.
> Przyczyna różnicy: Cargo 8 w małych partiach zużywa tyle przezbrojeń co Cargo 6 i więcej godzin inżynierii przy pięciokrotnie mniejszym wolumenie. Klucz roboczogodzin tego nie widzi → **subsydiowanie skrośne** (Cargo 6 „dopłaca” do Cargo 8).

## Jak to się łączy
To zadanie ćwiczy [[Rachunek kosztów działań]] (ABC: zasoby → działania → obiekty; nośniki kosztów, 5 kroków) oraz [Hierarchia kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Hierarchia%20koszt%C3%B3w) (poziom jednostki, partii, produktu, klienta i organizacji (Cooper)).
