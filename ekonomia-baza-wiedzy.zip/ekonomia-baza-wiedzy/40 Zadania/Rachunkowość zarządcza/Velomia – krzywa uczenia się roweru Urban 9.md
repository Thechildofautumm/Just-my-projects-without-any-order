---
typ: zadanie
up: "[[Krzywa uczenia się]]"
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Montaż pierwszego egzemplarza nowego roweru Urban 9 trwa 80 roboczogodzin, a współczynnik uczenia się wynosi 80% (model Wrighta: skumulowany średni czas $y = a\cdot x^b$).
a) Oblicz wykładnik $b$.
b) Oblicz średni i łączny czas dla 8, 16 i 32 sztuk.
c) Ile godzin zajmą sztuki 17–32?
d) Ile wynosi średni czas dla 20 sztuk?

> [!success]- Rozwiązanie
> **a)** $b = \frac{\log 0{,}8}{\log 2} = \mathbf{-0{,}3219}$.
> **b)** Każde podwojenie produkcji skumulowanej obniża średni czas do 80%:
>
> | Sztuki | Średni czas (h) | Czas łączny (h) |
> |---|---|---|
> | 1 | 80,0 | 80,0 |
> | 8 | 40,96 | 327,7 |
> | 16 | 32,77 | 524,3 |
> | 32 | 26,21 | 838,9 |
>
> **c)** $838{,}9 - 524{,}3 = \mathbf{314{,}6}$ h, czyli ok. **19,7 h/szt.** – czas kolejnych sztuk jest dużo niższy od średniej skumulowanej.
> **d)** $y(20) = 80\cdot 20^{-0{,}3219} \approx \mathbf{30{,}5}$ h; łącznie ok. 610 h.

## Jak to się łączy
To zadanie ćwiczy [[Krzywa uczenia się]] (model Wrighta y = a·x^b, b = log r / log 2).
