---
typ: zadanie
up: "[[Zachowanie kosztów]]"
przykład-z: ["Szacowanie funkcji kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Po wygaśnięciu programu dopłat do rowerów elektrycznych sprzedaż Velomii spadnie o 20%. Koszty sprzedaży i ogólnego zarządu wynoszą obecnie 60 mln zł. Badania nad zachowaniem kosztów (Anderson, Banker, Janakiraman 2003) pokazują, że takie koszty rosną średnio o 0,55% przy wzroście przychodów o 1%, a spadają tylko o 0,35% przy ich spadku o 1%.
a) Ile wyniosą koszty według budżetu zakładającego symetryczną reakcję (0,55% na 1%)?
b) Ile wyniosą, jeśli zachowają się jak koszty sztywne?
c) O ile budżet symetryczny przeszacuje wynik?

> [!success]- Rozwiązanie
> **a)** $-20\%\cdot 0{,}55 = -11\%$ → $60\cdot 0{,}89 = \mathbf{53{,}4}$ mln zł.
> **b)** $-20\%\cdot 0{,}35 = -7\%$ → $60\cdot 0{,}93 = \mathbf{55{,}8}$ mln zł.
> **c)** Różnica **2,4 mln zł** – o tyle budżet symetryczny zaniża koszty i zawyża wynik.
> Przyczyny sztywności: koszty dostosowania zasobów (zwolnienia, wypowiedzenia umów), oczekiwanie na odbicie popytu, motywy menedżerów.

## Jak to się łączy
To zadanie ćwiczy [[Zachowanie kosztów]] (przedział istotności, koszty zaangażowane i uznaniowe, schodkowe, koszty sztywne (sticky costs)) oraz [Szacowanie funkcji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Szacowanie%20funkcji%20koszt%C3%B3w) (y = a + bx: analiza techniczna, kont, wielkości skrajnych, regresja (MNK) i jej ocena).
