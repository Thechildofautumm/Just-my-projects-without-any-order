---
typ: zadanie
up: "[[Szacowanie funkcji kosztów]]"
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Koszty utrzymania ruchu w zakładzie Velomii w Kaliszu oszacowano na danych z 12 miesięcy. Regresja liniowa dała $y = 152\,300 + 36{,}40x$ ($R^2 = 0{,}92$, $x$ – maszynogodziny). Miesiąc najmniej aktywny: 4000 mh i 291 000 zł; najbardziej aktywny: 7600 mh i 418 000 zł.
a) Wyznacz funkcję kosztów metodą wielkości skrajnych.
b) Prognozuj koszty dla 8000 mh obiema metodami.
c) Skąd różnica i na ile wiarygodna jest prognoza?

> [!success]- Rozwiązanie
> **a)** $b = \frac{418\,000 - 291\,000}{7600 - 4000} = \frac{127\,000}{3600} \approx \mathbf{35{,}28}$ zł/mh; $a = 418\,000 - 35{,}28\cdot 7600 \approx \mathbf{149\,889}$ zł.
> **b)** Regresja: $152\,300 + 36{,}40\cdot 8000 = \mathbf{443{,}5}$ tys. zł; wielkości skrajne: $\approx \mathbf{432{,}1}$ tys. zł.
> **c)** Oba skrajne miesiące leżą **pod** linią regresji (297,9 i 428,9 tys. zł według regresji), więc metoda skrajnych opiera się na dwóch nietypowych punktach. Regresja wykorzystuje wszystkie obserwacje i daje miary jakości ($R^2$, błąd standardowy). 8000 mh leży jednak **poza** obserwowanym przedziałem 4000–7600 – to ekstrapolacja, więc obie prognozy są niepewne.

## Jak to się łączy
To zadanie ćwiczy [[Szacowanie funkcji kosztów]] (y = a + bx: analiza techniczna, kont, wielkości skrajnych, regresja (MNK) i jej ocena).
