---
typ: zadanie
up: "[[Rachunek kosztów działań sterowany czasem]]"
przykład-z: ["Rentowność klientów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Wsparcie techniczne Velomia Serwis kosztuje 1 440 000 zł rocznie; pracuje w nim 8 konsultantów po 1680 h, a praktyczna zdolność to 80% czasu. Równanie czasu zgłoszenia (min): $t = 15 + 20C + 45U + 60E$ ($C$ – rower Cargo, $U$ – konfiguracja z serwisantem, $E$ – eskalacja do działu konstrukcyjnego; zmienne 0/1). Rocznie jest 14 000 zgłoszeń, w tym 20% dotyczy Cargo, 5000 konfiguracji i 600 eskalacji.
a) Oblicz stawkę kosztu zdolności.
b) Oblicz koszt: prostego pytania o rower Urban, konfiguracji Urban z serwisantem oraz konfiguracji Cargo z eskalacją.
c) Oblicz wykorzystanie zdolności i koszt niewykorzystanych mocy.

> [!success]- Rozwiązanie
> **a)** Zdolność praktyczna: $8\cdot 1680\cdot 60\cdot 0{,}8 = 645\,120$ min; stawka $= \frac{1\,440\,000}{645\,120} \approx \mathbf{2{,}23}$ zł/min.
> **b)** Proste pytanie: 15 min → **33,48 zł**; konfiguracja Urban: 60 min → **133,93 zł**; Cargo z konfiguracją i eskalacją: $15 + 20 + 45 + 60 = 140$ min → **312,50 zł**.
> **c)** Zużycie: $14\,000\cdot 15 + 2800\cdot 20 + 5000\cdot 45 + 600\cdot 60 = 527\,000$ min → **81,7%**. Niewykorzystane $118\,120$ min $\approx$ **264 tys. zł**.
> Kosztu niewykorzystanych mocy **nie przypisujemy** produktom ani klientom – to informacja dla zarządu o nadmiarze zasobów.

## Jak to się łączy
To zadanie ćwiczy [[Rachunek kosztów działań sterowany czasem]] (TDABC: stawka kosztu zdolności, równania czasu, koszt niewykorzystanych mocy) oraz [Rentowność klientów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rentowno%C5%9B%C4%87%20klient%C3%B3w) (krzywa wieloryba; działania wobec nierentownych klientów).
