---
typ: zadanie
up: "[[Marża wkładu]]"
przykład-z: ["Koszt relewantny"]
powiązane: ["Velomia – trzy marże roweru Urban 5"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/gotowe"]
---
## Treść
Na podstawie wielostopniowego rachunku marż Velomii (mln zł) wskaż produkt, który nie pokrywa swoich kosztów stałych, i oceń, czy go wycofać.

| | Urban 3 | Urban 5 | Urban 7 | Cargo 6 | Cargo 8 | Serwis | Razem |
|---|---|---|---|---|---|---|---|
| Przychody | 82,0 | 96,0 | 74,0 | 21,0 | 6,4 | 55,0 | 334,4 |
| Koszty zmienne | 49,0 | 58,0 | 45,0 | 12,5 | 3,6 | 22,0 | 190,1 |
| Koszty stałe modelu | 4,0 | 5,0 | 6,0 | 2,0 | 3,5 | 11,0 | 31,5 |
| Koszty stałe zakładu | 60,0 (Kalisz) ||| 4,5 (Leszno) || 9,0 | 73,5 |
| Koszty stałe centrali | | | | | | | 30,0 |

> [!success]- Rozwiązanie
> - Marża I (wkładu): $334{,}4 - 190{,}1 = 144{,}3$; Cargo 8: $6{,}4 - 3{,}6 = 2{,}8$.
> - Marża II: razem 112,8; **Cargo 8: $2{,}8 - 3{,}5 = -0{,}7$**.
> - Marża III: Kalisz $85 - 60 = 25{,}0$; Leszno $5{,}8 - 4{,}5 = 1{,}3$; Serwis $22 - 9 = 13{,}0$ → razem 39,3.
> - Wynik operacyjny: $39{,}3 - 30{,}0 = \mathbf{9{,}3}$ mln.
>
> Cargo 8 pokrywa koszty zmienne, ale nie swoje koszty stałe. Wycofanie ma sens tylko wtedy, gdy da się **uniknąć** więcej niż 2,8 mln z 3,5 mln kosztów stałych modelu. Koszty stałe przypisujemy na najniższym poziomie, na którym da się ich uniknąć – bez kluczy podziałowych.

## Jak to się łączy
To zadanie ćwiczy [[Marża wkładu]] (cena − koszty zmienne; wielostopniowy rachunek marż) oraz [Koszt relewantny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20relewantny) (przyszły koszt różnicowy; koszty utopione i stałe pomijamy w decyzji). Podobny schemat rozwiązania ma zadanie [Velomia – trzy marże roweru Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20trzy%20mar%C5%BCe%20roweru%20Urban%205).
