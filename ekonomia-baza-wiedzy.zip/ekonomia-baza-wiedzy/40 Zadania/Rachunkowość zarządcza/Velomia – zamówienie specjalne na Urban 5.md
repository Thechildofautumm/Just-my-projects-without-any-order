---
typ: zadanie
up: "[[Koszt relewantny]]"
przykład-z: ["Marża wkładu"]
powiązane: ["Velomia – trzy marże roweru Urban 5"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść
Sieć wypożyczalni proponuje Velomii jednorazowy zakup 400 rowerów Urban 5 po cenie o 20% niższej od cennikowej (9600 zł). Zmienne koszty produkcji to 5800 zł/szt., zmienne koszty sprzedaży 300 zł/szt., a koszt wytworzenia według UoR 7400 zł/szt. (w tym 1600 zł stałych kosztów produkcji). Zakład ma wolne moce (w ostatnim kwartale wyprodukował 3500 szt. przy normalnych mocach 4000 szt.).
a) Czy przyjąć zamówienie? Które koszty są relewantne?
b) Jak zmieni się decyzja, jeśli wolnych mocy nie ma i każdy rower dla sieci oznacza utratę sprzedaży po cenie cennikowej?

> [!success]- Rozwiązanie
> Cena zamówienia: $9600\cdot 0{,}8 = 7680$ zł.
> **a)** Relewantne są tylko przyszłe koszty różnicowe: $5800 + 300 = 6100$ zł. Stałe koszty produkcji (1600 zł/szt.) wystąpią i bez zamówienia.
> Przyrost wyniku: $(7680 - 6100)\cdot 400 = \mathbf{632\,000}$ zł → **przyjąć**.
> Pułapka: porównanie z kosztem wytworzenia (7400 zł) zaniża korzyść (przy dodatkowym koszcie sprzedaży 300 zł daje tylko $-20$ zł/szt. i błędne „nie”).
> **b)** Bez wolnych mocy dochodzi koszt alternatywny – utracona marża wkładu $9600 - 6100 = 3500$ zł/szt.
> $7680 - 6100 - 3500 = -1920$ zł/szt. → **odrzucić** (strata 768 000 zł).
> Poza liczbami: ryzyko, że inni klienci zażądają podobnych rabatów.

## Jak to się łączy
To zadanie ćwiczy [[Koszt relewantny]] (przyszły koszt różnicowy; koszty utopione i stałe pomijamy w decyzji) oraz [Marża wkładu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mar%C5%BCa%20wk%C5%82adu) (cena − koszty zmienne; wielostopniowy rachunek marż). Podobny schemat rozwiązania ma zadanie [Velomia – trzy marże roweru Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20trzy%20mar%C5%BCe%20roweru%20Urban%205).
