# Ekonomia – baza wiedzy w Obsidianie

Studencka baza wiedzy do nauki czterech przedmiotów ekonomicznych, zbudowana jako sejf (vault) programu [Obsidian](https://obsidian.md):

- **Mikroekonomia** – rynek, elastyczność, konsument, producent, koszty, konkurencja doskonała i monopol,
- **Ekonomia menedżerska** – optymalizacja zysku, polityka cenowa, produkcja i koszty, struktury rynkowe (Cournot, Stackelberg, firma dominująca),
- **Rachunkowość zarządcza** – klasyfikacja i zachowanie kosztów, RKZ/RKP, rachunek marż, ABC i TDABC,
- **Podatki i strategie podatkowe** – system podatkowy, reakcje podatników, tarcza podatkowa, finansowanie a CIT, straty podatkowe, mały podatnik.

To moje notatki z nauki, nie podręcznik. Mogą zawierać błędy. Przed egzaminem sprawdzaj je z materiałami z zajęć i z aktualnymi przepisami.

## Co jest w środku

| Folder | Zawartość |
|---|---|
| `00 Start` | strona główna |
| `10 MOC` | mapy obszarów wiedzy (Maps of Content) |
| `20 Pojęcia` | ok. 120 notatek pojęć w 9 podfolderach (po jednym na obszar wiedzy): definicja → wyjaśnienie → przykład → „Na egzaminie” → zadania → powiązania |
| `30 Źródła` | przewodniki po przedmiotach i opisy źródeł (bibliografia) |
| `40 Zadania` | ok. 120 zadań z rozwiązaniami (zwinięte callouty), w podfolderach według przedmiotu |
| `45 Wzory` | tabela wzorów |
| `50 Pomoce` | słownik, fiszki, bank pytań, schematy rozwiązywania zadań, indeks zadań, atlas wykresów, kanwy |
| `80 Załączniki` | wykresy (wygenerowane samodzielnie w Pythonie / matplotlib) |
| `90 Szablony` | szablony nowych notatek |

Każda notatka ma właściwości YAML: `typ`, `up` (jeden rodzic w hierarchii), relacje (`powiązane`, `wymaga`, `część-z`, `przeciwieństwo`, `przykład-z`), `źródło`, `przedmiot` i tagi `typ/…` oraz `status/…`.

## Jak otworzyć

1. Pobierz repozytorium (`git clone` albo *Code → Download ZIP*).
2. Folder powinien nazywać się **`ekonomia-baza-wiedzy`** – linki między pojęciami używają adresów `obsidian://open?vault=ekonomia-baza-wiedzy&file=…` (dzięki temu graf pokazuje czystą hierarchię). Jeśli zmienisz nazwę folderu, te linki przestaną działać, a zwykłe linki `[[…]]` – nadal będą.
3. W Obsidianie: *Open folder as vault* → wybierz folder.
4. Zacznij od notatki **Start**. Widok grafu jest skonfigurowany tak, żeby pokazywał hierarchię: Start → obszary (MOC) → pojęcia → zadania.

Wzory są zapisane w LaTeX (MathJax), więc dobrze wyglądają w Obsidianie; na stronie GitHuba część formatowania (callouty, linki `[[…]]`) nie będzie działać.

## Źródła i prawa autorskie

Baza powstała w trakcie nauki na podstawie wykładów, podręczników i zbiorów zadań. Wersja publiczna została przygotowana tak, żeby **nie kopiować cudzych utworów**:

- **Nie ma tu** prezentacji z zajęć, zdjęć rozwiązań z tablicy, skanów ani przepisanych treści zadań ze zbiorów.
- **Notatki pojęć** są moim własnym opracowaniem. Krótkie definicje cytowane dosłownie są oznaczone nazwiskiem autora (prawo cytatu, art. 29 ustawy o prawie autorskim).
- **Wszystkie zadania** w folderze `40 Zadania` oraz przykłady liczbowe w notatkach pojęć to **własne warianty** typowych zadań: z innymi danymi, własną treścią i własnymi rozwiązaniami. Wykresy z danymi liczbowymi pokazują dane z tych własnych zadań. Źródła, na których wzorowałem typy zadań, są podane w notatkach w folderze `30 Źródła`.
- **Firma Velomia S.A.** (rachunkowość zarządcza) jest fikcyjna i wymyślona na potrzeby tej bazy; wszystkie jej dane są zmyślone.
- Same idee, metody, wzory i pojęcia matematyczne nie są chronione prawem autorskim (art. 1 ust. 2¹ ustawy), a przepisy prawa podatkowego są materiałem urzędowym (art. 4).
- Nazwiska prowadzących zajęcia i nazwy plików z materiałami zostały usunięte.

Jeśli jesteś autorem materiału i uważasz, że coś narusza Twoje prawa – otwórz *issue*, a usunę lub poprawię dany fragment.

### Bibliografia (do samodzielnej nauki)

- Rekowski M. (2011), *Mikroekonomia*, Wydawnictwo Akademia, Poznań.
- Kalinowski S. (red.) (2017), *Zbiór zadań z mikroekonomii*, Wydawnictwo UEP, Poznań.
- Solek A. (2017), *Optymalne decyzje. Ekonomia menedżerska w zadaniach*, Wydawnictwo UEK, Kraków.
- Samuelson W.F., Marks S.G. (2009), *Ekonomia menedżerska*, PWE, Warszawa.
- Johnson H.T., Kaplan R.S. (1987), *Relevance Lost: The Rise and Fall of Management Accounting*, Harvard Business School Press.
- Kaplan R.S., Cooper R. (1998), *Cost & Effect*, Harvard Business School Press.
- Kaplan R.S., Anderson S.R. (2004), Time-Driven Activity-Based Costing, *Harvard Business Review*.
- Anderson M.C., Banker R.D., Janakiraman S.N. (2003), Are Selling, General, and Administrative Costs „Sticky”?, *Journal of Accounting Research*.
- Ustawa z 15 lutego 1992 r. o podatku dochodowym od osób prawnych; ustawa z 26 lipca 1991 r. o podatku dochodowym od osób fizycznych.

## Jak powstała

Strukturę bazy (Zettelkasten + MOC), notatki, zadania i wykresy przygotowałem z pomocą asystenta AI (Claude), a następnie przeglądałem i poprawiałem. Wyniki liczbowe zadań zostały sprawdzone automatycznie (skrypt w Pythonie z biblioteką SymPy, 108 kontroli). Notatki oznaczone tagiem `#status/do-weryfikacji` wymagają jeszcze sprawdzenia.

Kwoty i limity podatkowe dotyczą 2026 r. – co roku się zmieniają.

## Licencja

Treść notatek: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.pl) – możesz kopiować i przerabiać materiały w celach niekomercyjnych, podając autora i udostępniając zmiany na tej samej licencji. Szczegóły w pliku `LICENSE`.
