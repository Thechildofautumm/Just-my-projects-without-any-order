---
typ: pomoc
up: "[[MOC Pomoce do nauki]]"
tags: ["typ/pomoc"]
aliases: ["Wzory", "Ściąga"]
---
Wszystkie wzory potrzebne na zaliczenia z czterech przedmiotów, pogrupowane jak obszary wiedzy. Kolumna „Pojęcie” prowadzi do notatki, w której wzór jest wyjaśniony i pokazany na wykresie.

> [!tip] Dwa narzędzia, które działają wszędzie
> **Pochodna:** $y = a\,x^n \Rightarrow y' = a\,n\,x^{n-1}$; stała → 0. Ekstremum: $f'(x) = 0$; maksimum gdy $f''(x) < 0$, minimum gdy $f''(x) > 0$.
> **„Marginalny” = pochodna wielkości całkowitej** ($MR = TR'$, $MC = TC'$, $MP = Q'(L)$, $MU = TU'$, $M\Pi = \Pi'$). **„Przeciętny” = całkowity / ilość** ($AR = TR/Q$, $ATC = TC/Q$, $AP = Q/L$).

## Podstawy gospodarowania i optymalizacja
| Co | Wzór | Pojęcie |
|---|---|---|
| Koszt alternatywny | wartość najlepszej odrzuconej opcji; na PPF: $\left\lvert\dfrac{\Delta Y}{\Delta X}\right\rvert$ | [[Koszt alternatywny]] |
| Zysk | $\Pi = TR - TC$ | [[Zysk marginalny]] |
| Zysk marginalny | $M\Pi = \Pi' = MR - MC$ | [[Zysk marginalny]] |
| Max zysku (1 zmienna) | $M\Pi = 0 \iff MR = MC$; $\Pi'' < 0$ | [[Analiza marginalna]] |
| Max (2 zmienne) | $\Pi_x = \Pi_y = 0$; $\Pi_{xx} < 0$, $\Pi_{yy} < 0$; $\Pi_{xx}\Pi_{yy} - \Pi_{xy}^2 > 0$ | [[Optymalizacja funkcji dwóch zmiennych]] |
| Funkcja Lagrange'a | $Z = f(x, y) + \lambda\,g(x, y)$; $Z_x = Z_y = Z_\lambda = 0$ | [[Metoda mnożników Lagrange'a]] |
| Interpretacja $\lambda$ | przyrost funkcji celu przy poluzowaniu ograniczenia o 1 | [[Metoda mnożników Lagrange'a]] |

## Rynek
| Co | Wzór | Pojęcie |
|---|---|---|
| Równowaga | $Q_D = Q_S$; rozwiąż $P = f_D(Q)$ i $P = f_S(Q)$ | [[Równowaga rynkowa]] |
| $P_{max}$ / $Q_{max}$ | $Q = 0$ / $P = 0$ w funkcji popytu | [[Popyt]] |
| Niedobór / nadwyżka przy $\bar P$ | $Q_D - Q_S$ (gdy $\bar P < P_e$) / $Q_S - Q_D$ (gdy $\bar P > P_e$) | [[Nierównowaga rynkowa]] |
| Wydatki konsumentów | $P_e\cdot Q_e$ | [[Równowaga rynkowa]] |
| Podatek kwotowy $t$ na producenta | $P = f_S(Q) + t$ | [[Interwencja państwa na rynku]] |
| Podatek procentowy $s$ od ceny | $(1 - s)P = f_S(Q)$ | [[Interwencja państwa na rynku]] |
| Dotacja $b$ dla producenta | $P = f_S(Q) - b$ | [[Interwencja państwa na rynku]] |
| Dotacja $d$ dla konsumenta | $P = f_D(Q) + d$; procentowa: $(1 - s)P = f_D(Q)$ | [[Interwencja państwa na rynku]] |
| Różniczka zupełna popytu | $dQ = Q'_P\,dP + Q'_I\,dI + Q'_{P_y}\,dP_y + \dots$ | [[Funkcja popytu wielu zmiennych]] |

## Elastyczność i przychody
| Co | Wzór | Pojęcie |
|---|---|---|
| Elastyczność (ogólnie) | $E = \dfrac{\%\Delta Q}{\%\Delta Z} = \dfrac{\Delta Q}{\Delta Z}\cdot\dfrac{Z}{Q} = Q'(Z)\cdot\dfrac{Z}{Q}$ | [[Elastyczność popytu]] |
| Cenowa | $E_p = Q'(P)\cdot\dfrac{P}{Q}$ (< 0) | [[Elastyczność cenowa popytu]] |
| Punktowa – liniowy popyt | $E_p = \dfrac{P}{P - P_{max}} = \dfrac{Q - Q_{max}}{Q}$ | [[Elastyczność punktowa]] |
| Łukowa | $E_Ł = \dfrac{Q_2 - Q_1}{Q_2 + Q_1}\cdot\dfrac{P_2 + P_1}{P_2 - P_1}$ | [[Elastyczność łukowa]] |
| Mieszana | $E_M = Q'(P_y)\cdot\dfrac{P_y}{Q_x}$ (>0 substytuty, <0 komplementy) | [[Elastyczność mieszana popytu]] |
| Dochodowa | $E_I = Q'(I)\cdot\dfrac{I}{Q}$ (<0 podrzędne, 0–1 podstawowe, >1 luksusowe) | [[Elastyczność dochodowa popytu]] |
| Wpływ kilku czynników | $\%\Delta Q = E_p\,\%\Delta P + E_I\,\%\Delta I + E_M\,\%\Delta P_y$ | [[Elastyczność popytu]] |
| Popyt potęgowy | $Q = kP^{\alpha}I^{\beta}\dots \Rightarrow E_p = \alpha$, $E_I = \beta$ (stałe) | [[Funkcja popytu o stałej elastyczności]] |
| Przychód | $TR = P\cdot Q$; $AR = P$; $MR = TR'$ | [[Przychód]] |
| Liniowy popyt $P = a - bQ$ | $TR = aQ - bQ^2$, $MR = a - 2bQ$ | [[Przychód]] |
| MR a elastyczność | $MR = P\left(1 + \dfrac{1}{E_p}\right)$ | [[Elastyczność a przychód]] |
| Max przychodu | $MR = 0 \iff E_p = -1$; $TR_{max} = \tfrac12P_{max}\cdot\tfrac12Q_{max}$ | [[Maksymalizacja przychodu]] |
| Cena z narzutem | $P = MC\cdot\dfrac{E_p}{E_p + 1}$ | [[Narzut ceny na koszt krańcowy]] |

## Wybór konsumenta
| Co | Wzór | Pojęcie |
|---|---|---|
| Użyteczność marginalna | $MU = \dfrac{\Delta TU}{\Delta Q}$ lub $\dfrac{\partial TU}{\partial Q}$ | [[Użyteczność]] |
| MRS | $MRS = -\dfrac{\Delta Q_y}{\Delta Q_x} = \dfrac{MU_x}{MU_y}$ | [[Krańcowa stopa substytucji]] |
| Linia budżetowa | $I = P_xQ_x + P_yQ_y$; nachylenie $-\dfrac{P_x}{P_y}$ | [[Linia budżetowa]] |
| Optimum konsumenta | $\dfrac{MU_x}{P_x} = \dfrac{MU_y}{P_y}$, czyli $MRS = \dfrac{P_x}{P_y}$ | [[Optimum konsumenta]] |
| Efekty cenowe (Słucki/Hicks) | efekt całkowity = efekt substytucyjny + efekt dochodowy | [[Efekt substytucji i efekt dochodowy]] |

## Produkcja i koszty
| Co | Wzór | Pojęcie |
|---|---|---|
| Produkt przeciętny / marginalny | $AP_L = \dfrac{Q}{L}$; $MP_L = Q'(L)$ | [[Produkt przeciętny i marginalny]] |
| Etapy produkcji | I: do $AP_{max}$ ($MP = AP$); II: do $MP = 0$; III: $MP < 0$ | [[Etapy produkcji]] |
| Efekty skali | $Q(aL, aK)$ vs $a\,Q(L, K)$; dla $AL^\alpha K^\beta$: $\alpha + \beta \gtrless 1$ | [[Efekty skali]] |
| MRTS | $MRTS = -\dfrac{\Delta K}{\Delta L} = \dfrac{MP_L}{MP_K}$ | [[Krańcowa stopa technicznej substytucji]] |
| Izokoszta | $TC = wL + rK$; nachylenie $-\dfrac{w}{r}$ | [[Izokoszta]] |
| Optimum producenta | $\dfrac{MP_L}{w} = \dfrac{MP_K}{r}$ | [[Optimum producenta]] |
| Optymalne zatrudnienie | $MRP_L = P\cdot MP_L = w$ | [[Krańcowy przychód z pracy]] |
| Koszty krótkookresowe | $TC = FC + VC$; $ATC = AFC + AVC$; $MC = TC' = VC'$ | [[Koszt stały i zmienny]] |
| Minima kosztów przeciętnych | $AVC' = 0$ i $ATC' = 0$; w minimum $MC = AVC$, $MC = ATC$ | [[Koszt przeciętny]] |
| Koszty a produktywność | $AVC = \dfrac{w}{AP_L}$; $MC = \dfrac{w}{MP_L}$ | [[Koszty a produktywność]] |
| Zysk ekonomiczny | $\Pi_e = TR - (\text{koszty jawne} + \text{koszty niejawne})$ | [[Zysk ekonomiczny]] |

## Struktury rynkowe i decyzje firmy
| Co | Wzór | Pojęcie |
|---|---|---|
| Max zysku – każda struktura | $MR = MC$, $MC$ rosnący szybciej niż $MR$ | [[Maksymalizacja zysku]] |
| Konkurencja doskonała | $P = MR = MC$ | [[Konkurencja doskonała]] |
| Cena niwelacji (BEP) | $P = ATC_{min}$; długi okres: $P = AC_{min}$ | [[Próg rentowności]] |
| BEP przy liniowych kosztach | $Q_{BEP} = \dfrac{FC}{P - AVC}$; $TR_{BEP} = P\cdot Q_{BEP}$; $\dfrac{Q_{BEP}}{Q_{max}}\cdot 100\%$ | [[Próg rentowności]] |
| Cena zamknięcia | $P = AVC_{min}$ | [[Punkt zamknięcia]] |
| Monopol | $MR = MC$ → $Q_m$; cena z funkcji popytu | [[Równowaga monopolu]] |
| Indeks Lernera | $L = \dfrac{P - MC}{P} = -\dfrac{1}{E_p}$ | [[Monopol pełny]] |
| Koncentracja | $CR_4 = s_1 + s_2 + s_3 + s_4$; $HHI = \sum s_i^2$ (udziały w %) | [[Koncentracja rynku]] |
| Cournot | $MR_i(q_i, q_j) = MC_i$ dla obu firm → układ funkcji reakcji | [[Model Cournota]] |
| Stackelberg | funkcja reakcji naśladowcy podstawiona do popytu przywódcy | [[Model Stackelberga]] |
| Firma dominująca | $MR_D = MC_D$ na popycie rezydualnym; reszta = $Q(P) - q_D$ | [[Model firmy dominującej]] |
| Nadwyżki (liniowy popyt) | $CS = \tfrac12(P_{max} - P)Q$; $PS = \tfrac12(P - P_{min})Q$ | [[Nadwyżka konsumenta i producenta]] |
| Strata społeczna monopolu | $DWL = \tfrac12(P_m - MC)(Q_k - Q_m)$ | [[Strata społeczna monopolu]] |

## Rachunek kosztów
| Co | Wzór | Pojęcie |
|---|---|---|
| Funkcja kosztów | $y = a + bx$ ($a$ – koszt stały, $b$ – koszt zmienny na jednostkę nośnika) | [[Szacowanie funkcji kosztów]] |
| Metoda wielkości skrajnych | $b = \dfrac{y_{max} - y_{min}}{x_{max} - x_{min}}$; $a = y_{max} - b\,x_{max}$ | [[Szacowanie funkcji kosztów]] |
| Krzywa uczenia się | $y = a\,x^b$, $b = \dfrac{\log r}{\log 2}$; łącznie $= x\cdot y$ | [[Krzywa uczenia się]] |
| Marża wkładu | $P - AVC$ (na sztukę); $TR - VC$ (łącznie) | [[Marża wkładu]] |
| Uzgodnienie RKP i RKZ | $W_{RKP} - W_{RKZ} = \Delta\text{zapasu}\cdot\dfrac{\text{stałe koszty produkcji}}{\text{normalne moce}}$ | [[Rachunek kosztów zmiennych i pełnych]] |
| Stawka ABC | $\dfrac{\text{koszt działania}}{\text{wielkość nośnika}}$ | [[Rachunek kosztów działań]] |
| Stawka TDABC | $\dfrac{\text{koszt zdolności}}{\text{praktyczna zdolność (min)}}$; czas $t = \beta_0 + \beta_1X_1 + \dots$ | [[Rachunek kosztów działań sterowany czasem]] |
| Koszt niewykorzystanych mocy | (zdolność − wykorzystanie) × stawka | [[Rachunek kosztów działań sterowany czasem]] |

## Podatki
| Co | Wzór | Pojęcie |
|---|---|---|
| Dochód podatkowy | przychody − koszty uzyskania przychodów (w ramach źródła) | [[Dochód podatkowy]] |
| Tarcza – odliczenie od dochodu | odliczenie × stawka | [[Tarcza podatkowa]] |
| Odliczenie od podatku | oszczędność = odliczenie (do wysokości podatku) | [[Odliczenie podatkowe]] |
| Tarcza odsetkowa | odsetki × stawka CIT | [[Asymetria podatkowa finansowania]] |
| Limit kosztów finansowania | NKUP = nadwyżka − max(3 mln zł; 30% EBITDA podatkowej) | [[Limit kosztów finansowania dłużnego]] |
| NID | min(przyrost kapitału × (stopa ref. NBP + 1 pkt proc.); 250 000 zł) | [[Hipotetyczne odsetki od kapitału własnego]] |
| Strata – metoda tradycyjna | ≤ 50% straty rocznie przez 5 lat | [[Rozliczanie straty podatkowej w czasie]] |
| Strata – metoda jednorazowa | jednorazowo ≤ 5 mln zł, reszta ≤ 50% rocznie | [[Rozliczanie straty podatkowej w czasie]] |
| Stawki CIT | 19% ogólna; 9% dla małego podatnika (przychody ≤ 2 mln euro) | [[Preferencyjna stawka CIT]] |
