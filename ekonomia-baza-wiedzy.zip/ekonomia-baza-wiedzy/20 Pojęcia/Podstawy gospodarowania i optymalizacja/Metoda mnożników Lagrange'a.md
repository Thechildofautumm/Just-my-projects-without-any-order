---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Optimum konsumenta", "Optimum producenta"]
wymaga: ["Optymalizacja funkcji dwóch zmiennych"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Solek – Optymalne decyzje]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Lagrange", "Optymalizacja z ograniczeniem", "Mnożnik Lagrange'a"]
---
> [!abstract] Definicja
> Metoda mnożników Lagrange'a pozwala znaleźć maksimum (minimum) funkcji celu, gdy zmienne muszą spełniać ograniczenie g(x₁, x₂, …) = 0.

## Wyjaśnienie
Kroki (Solek):
1. zapisz ograniczenie w postaci $g(x_1, x_2) = 0$,
2. utwórz funkcję Lagrange'a $Z(x_1, x_2, \lambda) = f(x_1, x_2) + \lambda\, g(x_1, x_2)$,
3. policz pochodne cząstkowe Z po wszystkich zmiennych **i po λ**, przyrównaj do zera,
4. rozwiąż układ równań.

**Interpretacja λ:** o ile wzrośnie funkcja celu, gdy ograniczenie poluzujemy o jednostkę (np. wartość dodatkowej jednostki mocy produkcyjnej).

![[e07_lagrange_dwa_segmenty.png]]

## Przykład
Dwa segmenty, moce ≤ 25 tys. szt.: $\Pi = (20Q_1 - 0{,}5Q_1^2) + (40Q_2 - Q_2^2)$.
Bez ograniczenia: Q₁ = 20, Q₂ = 20 (razem 40 > 25), więc ograniczenie wiąże.
$Z = \Pi + \lambda(25 - Q_1 - Q_2)$: $20 - Q_1 - \lambda = 0$, $40 - 2Q_2 - \lambda = 0$, $Q_1 + Q_2 = 25$ → **Q₁ = 10, Q₂ = 15, λ = 10**, Π = 525. Dodatkowa jednostka mocy dałaby ok. 10 jednostek zysku więcej.

## Na egzaminie
> [!question] Pytanie teoretyczne
> Co oznacza mnożnik λ w rozwiązaniu? *Odp.: krańcową wartość ograniczenia – przyrost funkcji celu przy jego poluzowaniu o jednostkę.*

> [!warning] Pułapka
> Najpierw sprawdź, czy rozwiązanie bez ograniczenia go nie spełnia – jeśli spełnia, ograniczenie nie wiąże i Lagrange nie jest potrzebny.

## Zadania
Zadania do tego pojęcia: [[Dwa segmenty rynku z ograniczeniem zdolności – metoda Lagrange'a]] i [[Praca i kapitał przy liniowej funkcji produkcji]].

## Jak to się łączy
Metoda rozszerza [optymalizację funkcji dwóch zmiennych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optymalizacja%20funkcji%20dw%C3%B3ch%20zmiennych) o ograniczenie. W mikroekonomii dokładnie taki problem rozwiązuje konsument – maksymalizuje użyteczność przy ograniczeniu budżetowym, co prowadzi do [optimum konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta) – oraz producent, który minimalizuje koszt danej produkcji w [optimum producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20producenta). Warunek styczności MRS = Px/Py wynika właśnie z warunków Lagrange'a.
