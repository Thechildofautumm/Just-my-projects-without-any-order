---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Izokoszta", "Pozacenowa determinanta podaży"]
część-z: ["Funkcja produkcji"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Czynniki produkcji", "Zasoby", "Praca", "Kapitał", "L", "K"]
---
> [!abstract] Definicja
> Czynnik produkcji to zasób służący jako nakład do wytwarzania dóbr: praca (L), ziemia/zasoby naturalne oraz kapitał (K).

## Wyjaśnienie
| Zasób | Symbol | Cena czynnika | Przykład |
|---|---|---|---|
| ludzki – praca | L | płaca **w** | roboczogodziny, pracownicy |
| naturalny – ziemia | – | renta | grunt, surowce |
| kapitałowy | K | cena kapitału **r** | maszyny, budynki, leasing |

- W **krótkim okresie** przynajmniej jeden czynnik jest stały (zwykle K), w **długim** – wszystkie są zmienne.
- Firma płaci za czynniki – stąd koszty: $TC = w\cdot L + r\cdot K$.
- Ceny czynników są jedną z determinant podaży: droższy czynnik → wyższe koszty → mniejsza podaż.

> [!warning] Pułapka terminologiczna
> „Kapitał” w ekonomii to **dobra kapitałowe** (maszyny, budynki). W finansach i rachunkowości „kapitał” oznacza **źródło finansowania** (kapitał własny, kapitał obcy).

## Przykład
Restauracja: L – kucharze i kelnerzy, K – kuchnia i lokal. W krótkim okresie właściciel może zatrudnić więcej kelnerów, ale nie powiększy sali.

## Na egzaminie
> [!question] Pytanie testowe
> Który czynnik produkcji jest zwykle traktowany jako stały w krótkim okresie? **Kapitał (K).**

## Jak to się łączy
Czynniki produkcji są argumentami [funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji) $Q = f(L, K)$. Ich ceny w i r wyznaczają położenie i nachylenie [izokoszty](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokoszta), czyli zbioru kombinacji L i K o tym samym koszcie. Zmiana cen czynników to jedna z [pozacenowych determinant podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy) – przesuwa krzywą podaży całego rynku.
