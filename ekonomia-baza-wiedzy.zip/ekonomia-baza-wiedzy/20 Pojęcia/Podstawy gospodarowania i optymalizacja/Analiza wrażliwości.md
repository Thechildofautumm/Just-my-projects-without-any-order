---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Koszt stały i zmienny", "Pozacenowa determinanta popytu"]
wymaga: ["Zysk marginalny"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Wrażliwość decyzji"]
---
> [!abstract] Definicja
> Analiza wrażliwości bada, jak zmienia się optymalna decyzja i wynik, gdy zmieniają się parametry: koszty stałe, koszty zmienne albo popyt.

## Wyjaśnienie
Procedura: wyznacz optimum dla wariantu bazowego, zmień jeden parametr, wyznacz optimum ponownie i porównaj.

| Zmiana | Wpływ na MR lub MC | Optymalne Q | Zysk |
|---|---|---|---|
| ↑ koszty stałe (FC) | brak | **bez zmian** | ↓ o ΔFC |
| ↑ jednostkowy koszt zmienny | MC ↑ | ↓ | ↓ |
| ↑ popyt (D w prawo) | MR ↑ | ↑ | ↑ |

![[e02_analiza_wrazliwosci.png]]

## Przykład
Mikroprocesory (bazowo Q* = 3,3; Π = 117,8):
a) FC 100 → 112: Q* = 3,3; Π = 105,8 (spadek dokładnie o 12),
b) koszt partii 38 → 46: Q* = 3,1; Π = 92,2,
c) popyt P = 190 − 20Q: Q* = 3,8; Π = 188,8.

## Na egzaminie
> [!question] Pytanie otwarte
> Dlaczego wzrost kosztów stałych nie zmienia optymalnej wielkości produkcji? *Odp.: bo FC nie wpływa na koszt marginalny – warunek MR = MC się nie zmienia; spada tylko poziom zysku.*

> [!warning] Pułapka
> Wzrost FC zmienia decyzję tylko w jednym przypadku – gdy zysk staje się ujemny i trzeba ocenić, czy kontynuować działalność (porównanie straty z FC).

## Zadania
Zadania do tego pojęcia: [[Producent dronów – analiza wrażliwości]].

## Jak to się łączy
Każdy wariant rozwiązujemy tym samym warunkiem MΠ = 0 opisanym w [zysku marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20marginalny). Kluczowy wniosek analizy dotyczy podziału na [koszty stałe i zmienne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny): tylko koszty zmienne zmieniają optymalną decyzję. Zmiana popytu to w praktyce działanie [pozacenowej determinanty popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu), która przesuwa krzywą popytu, a z nią MR.
