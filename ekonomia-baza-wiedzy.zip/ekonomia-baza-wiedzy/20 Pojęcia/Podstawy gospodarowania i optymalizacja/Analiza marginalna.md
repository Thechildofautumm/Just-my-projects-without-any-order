---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Użyteczność", "Koszt marginalny", "Maksymalizacja zysku", "Optimum konsumenta"]
część-z: ["Mikroekonomia"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[EM – Wprowadzenie, analiza marginalna]]", "[[EM – Metody optymalizacji]]", "[[Rekowski – Mikroekonomia]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Optimum MB = MC", "Zasada marginalna", "Równowaga podmiotu gospodarczego"]
---
> [!abstract] Definicja
> Analiza marginalna to porównywanie korzyści i kosztów **ostatniej (dodatkowej) jednostki** działania; optimum osiąga się, gdy korzyść marginalna równa się kosztowi marginalnemu.

## Wyjaśnienie
„Marginalny” (krańcowy) = dotyczący ostatniej, dodatkowej jednostki; matematycznie – **pochodna** wielkości całkowitej.

$$\boxed{MB = MC}$$

- **zasada malejących korzyści marginalnych** – każda kolejna jednostka przynosi mniej,
- **zasada rosnącego kosztu marginalnego** – każda kolejna jednostka kosztuje więcej,
- jeśli MB > MC → zwiększ działalność; MB < MC → zmniejsz; MB = MC → **punkt równowagi podmiotu** (najlepszy możliwy poziom działalności).

![[01_PPF_i_analiza_marginalna.png]]

Kategorie marginalne (ekonomia menedżerska) – zawsze pochodne kategorii całkowitych:

| Całkowita | Marginalna |
|---|---|
| $TR(Q)$ | $MR = TR'$ |
| $TC(Q)$ | $MC = TC'$ |
| $Q(L)$ | $MP_L = Q'(L)$ |
| $\Pi(Q)$ | $M\Pi = \Pi'$ |
| $TU(Q)$ | $MU = TU'$ |

> [!tip] Pochodna – jedyna reguła, której potrzebujesz
> $y = a\,x^n \Rightarrow y' = a\cdot n\cdot x^{n-1}$, stała → 0. Np. $TC = 5Q^2 + 250Q + 2500 \Rightarrow MC = 10Q + 250$.

## Przykład
Zbiór EM 1.4: $TR = -6Q^2 + 900Q \Rightarrow MR = -12Q + 900$; $Q(L) = -4L^3 + 60L^2 + 8000L \Rightarrow MP_L = -12L^2 + 120L + 8000$.

## Na egzaminie
> [!question] Pytanie otwarte (Zbiór EM 1.3)
> Wyjaśnij istotę analizy marginalnej: w jakim celu jest stosowana, jakie zmienne wykorzystuje i jaką zasadą kieruje się decydent?
> *Odp.: służy podjęciu optymalnej decyzji; wykorzystuje kategorie marginalne (MR, MC, MΠ); decydent zwiększa lub ogranicza działalność do momentu uzyskania rozwiązania optymalnego (MB = MC).*

## Zadania
Pojęcie przydaje się też w: [Bilety do kina – użyteczność marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Bilety%20do%20kina%20%E2%80%93%20u%C5%BCyteczno%C5%9B%C4%87%20marginalna), [Kategorie marginalne i warunki maksimum zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kategorie%20marginalne%20i%20warunki%20maksimum%20zysku).

## Jak to się łączy
Analiza marginalna to podstawowa metoda, którą posługuje się [mikroekonomia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mikroekonomia). U konsumenta malejąca korzyść marginalna to malejąca [użyteczność marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=U%C5%BCyteczno%C5%9B%C4%87), a warunek optimum przybiera postać MU/P równego dla wszystkich dóbr – patrz [optimum konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta). U firmy rosnący koszt marginalny opisuje krzywa [kosztu marginalnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny), a zasada MB = MC staje się regułą [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC.
