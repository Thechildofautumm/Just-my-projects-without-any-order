---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Maksymalizacja zysku", "Przychód", "Koszt marginalny"]
wymaga: ["Analiza marginalna"]
źródło: ["[[EM – Wprowadzenie, analiza marginalna]]", "[[EM – Metody optymalizacji]]", "[[Samuelson i Marks – Ekonomia menedżerska]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MΠ", "Funkcja zysku", "Warunek konieczny i wystarczający", "Funkcja celu"]
---
> [!abstract] Definicja
> Zysk marginalny (MΠ) to przyrost zysku całkowitego wywołany niewielkim zwiększeniem zmiennej decyzyjnej – pochodna funkcji zysku: $M\Pi = \Pi' = MR - MC$.

## Wyjaśnienie
Funkcja celu menedżera: $\Pi = TR - TC$.

| Warunek | Zapis | Interpretacja |
|---|---|---|
| **konieczny** | $M\Pi = 0 \Leftrightarrow MR = MC$ | styczna do krzywej zysku jest pozioma |
| **wystarczający** (maksimum) | $\Pi'' < 0 \Leftrightarrow MR' < MC'$ | funkcja zysku jest wklęsła |

![[e01_funkcja_zysku.png]]

Reguła postępowania (Samuelson): *zmieniaj wielkość produkcji w kierunku, który zwiększa zysk, i zatrzymaj się, gdy dalsze zmiany go nie poprawiają.*
- styczna rośnie (MΠ > 0) → zwiększ Q,
- styczna opada (MΠ < 0) → zmniejsz Q,
- styczna pozioma (MΠ = 0) → maksimum.

> [!note] Minimum zamiast maksimum
> Gdy funkcją celu jest np. koszt przeciętny (funkcja wypukła), szukamy minimum: $AC' = 0$ i $AC'' > 0$.

## Przykład
Mikroprocesory: $P = 170 - 20Q$, $TC = 100 + 38Q$ → $\Pi = -20Q^2 + 132Q - 100$.
$M\Pi = -40Q + 132 = 0 \Rightarrow Q^* = 3{,}3$; $\Pi'' = -40 < 0$ → maksimum; $\Pi_{max} = 117{,}8$; cena $P = 170 - 66 = 104$.

## Na egzaminie
> [!question] Zadanie typowe
> Dla $\Pi(Q) = -0{,}5Q^2 + 250Q - 1600$ wyznacz MΠ i optymalne Q. *Odp.: MΠ = −Q + 250; Q* = 250.*

> [!warning] Pułapka
> Sam warunek MΠ = 0 nie wystarcza – sprawdź drugą pochodną, bo MΠ = 0 jest też w minimum zysku.

## Zadania
Zadania do tego pojęcia: [[Kategorie marginalne i warunki maksimum zysku]], [[Producent dronów – funkcja zysku]] i [[Optymalna produkcja – dwa warianty funkcji]].

## Jak to się łączy
Zysk marginalny to [analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) zastosowana wprost do funkcji zysku. Rozpisanie $M\Pi = MR - MC$ pokazuje, że warunek MΠ = 0 to dokładnie reguła [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC, gdzie MR pochodzi z funkcji [przychodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d), a MC z funkcji kosztów – patrz [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny).
