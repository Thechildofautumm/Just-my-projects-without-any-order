---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Koszt alternatywny", "Granica możliwości produkcyjnych"]
wymaga: ["Czynnik produkcji"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Problem rzadkości", "Ograniczoność zasobów"]
---
> [!abstract] Definicja
> Rzadkość to sytuacja, w której potrzeby ludzi są nieograniczone, a zasoby potrzebne do ich zaspokojenia – ograniczone, więc ilość dóbr pożądanych przewyższa zdolność ich wytworzenia.

## Wyjaśnienie
$$\text{ZAPOTRZEBOWANIE (ilość dóbr, które ludzie chcieliby mieć)} \;>\; \text{ZDOLNOŚĆ WYTWORZENIA}$$

Skutki rzadkości:
- konieczność **gospodarowania** – podejmowania wyborów ekonomicznych,
- każda decyzja ma **korzyści** i **koszty alternatywne**,
- podmioty dążą do **optymalizacji** – najlepszego wyniku z danych zasobów.

**Technologia produkcji** wyznacza, ile i jakich zasobów trzeba, by wytworzyć dany produkt, oraz w jakich proporcjach je łączyć (przykład z wykładu: „technologia produkcji ciastka” to przepis – proporcje mąki, cukru, pracy i piekarnika).

## Przykład
Państwo z danym budżetem może zbudować szpital albo drogę. Rzadkość środków oznacza, że wybierając szpital, rezygnuje z drogi – tej rezygnacji nie da się uniknąć, można ją tylko świadomie wybrać.

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij, dlaczego problem rzadkości dotyczy także bogatych społeczeństw.
> *Wskazówka:* bo rzadkość jest relacją potrzeb do zasobów, a nie bezwzględną ilością zasobów; zawsze ograniczony jest m.in. czas.

## Jak to się łączy
Rzadkie zasoby to [czynniki produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Czynnik%20produkcji) – praca, ziemia i kapitał. Ponieważ zasobów brakuje, każdy wybór oznacza rezygnację z czegoś innego, a wartość tej rezygnacji mierzy [koszt alternatywny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny). Graficznym obrazem rzadkości jest [granica możliwości produkcyjnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Granica%20mo%C5%BCliwo%C5%9Bci%20produkcyjnych) – poza nią produkcja jest nieosiągalna.
