---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Granica możliwości produkcyjnych", "Zysk ekonomiczny", "Koszt relewantny"]
część-z: ["Koszt księgowy a koszt ekonomiczny"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska", "Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszt utraconych korzyści", "Opportunity cost"]
---
> [!abstract] Definicja
> Koszt alternatywny (koszt utraconych korzyści) to wartość najlepszej możliwości, z której rezygnujemy, dokonując wyboru.

## Wyjaśnienie
- Wynika wprost z rzadkości: wybór A oznacza rezygnację z B.
- Liczy się tylko **najlepsza** odrzucona opcja, nie suma wszystkich.
- W ekonomii menedżerskiej koszty alternatywne to koszty **niejawne (implicite)**: utracone dochody z zasobów, które są naszą własnością (własny lokal, własny kapitał, własna praca).
- W rachunkowości zarządczej koszt alternatywny jest jedną z kategorii kosztów ważnych dla decyzji; w rachunkowości finansowej się go nie ujmuje.

| Zasób własny | Koszt alternatywny |
|---|---|
| własny lokal | czynsz, który można by uzyskać z wynajmu |
| własne pieniądze | odsetki z lokaty |
| własna praca | wynagrodzenie w najlepszej alternatywnej pracy |

## Przykład
Tomasz (przykład własny) prowadzi pracownię rowerową we własnym garażu (rynkowy czynsz 24 000 zł), zainwestował 80 000 zł (lokata 8% → 6 400 zł) i rezygnuje z etatu za 45 000 zł. Jego koszty alternatywne = **75 400 zł**, choć w księgach ich nie ma.

## Na egzaminie
> [!question] Pytanie testowe
> Student rezygnuje z pracy za 3 000 zł/mies., by studiować dziennie; czesne wynosi 1 000 zł/mies. Jaki jest miesięczny koszt ekonomiczny studiów? **4 000 zł** (czesne + utracona pensja).

> [!warning] Pułapka
> Kosztem alternatywnym nie jest suma wszystkich odrzuconych opcji – tylko wartość najlepszej z nich.

## Zadania
Pojęcie przydaje się też w: [Food truck – przy jakiej stopie procentowej się opłaca](obsidian://open?vault=ekonomia-baza-wiedzy&file=Food%20truck%20%E2%80%93%20przy%20jakiej%20stopie%20procentowej%20si%C4%99%20op%C5%82aca).

## Jak to się łączy
Na [granicy możliwości produkcyjnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Granica%20mo%C5%BCliwo%C5%9Bci%20produkcyjnych) koszt alternatywny jest widoczny jako nachylenie krzywej: ile dobra Y tracimy za dodatkową jednostkę X. Koszty alternatywne są tą częścią kosztu ekonomicznego, której brakuje w kosztach księgowych – patrz [Koszt księgowy a koszt ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20ksi%C4%99gowy%20a%20koszt%20ekonomiczny). Dlatego [zysk ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny) równy zero oznacza zysk normalny: przychód pokrywa koszty alternatywne właściciela. W rachunkach decyzyjnych koszt alternatywny jest zawsze [kosztem relewantnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20relewantny), chociaż nie przechodzi przez księgi.
