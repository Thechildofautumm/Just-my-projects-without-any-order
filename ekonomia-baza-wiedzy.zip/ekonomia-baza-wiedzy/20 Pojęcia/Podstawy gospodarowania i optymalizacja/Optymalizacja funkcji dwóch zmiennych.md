---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Metoda mnożników Lagrange'a", "Dyskryminacja cenowa"]
wymaga: ["Zysk marginalny"]
źródło: ["[[EM – Metody optymalizacji]]", "[[Solek – Optymalne decyzje]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Funkcja celu dwóch zmiennych", "Hesjan", "Pochodna cząstkowa"]
---
> [!abstract] Definicja
> Optymalizacja funkcji dwóch zmiennych to szukanie maksimum (minimum) funkcji celu f(x, y) przez przyrównanie obu pochodnych cząstkowych do zera i sprawdzenie warunków drugiego rzędu.

## Wyjaśnienie
Warunki maksimum (Solek):
1. $f'_x = 0$ i $f'_y = 0$ (warunki konieczne),
2. $f''_{xx} < 0$ i $f''_{yy} < 0$,
3. wyznacznik macierzy drugich pochodnych (hesjanu) jest dodatni:
$$\det H = f''_{xx}\,f''_{yy} - (f''_{xy})^2 > 0$$

![[e06_poziomice_zysku_cena_reklama.png]]

Zastosowania: firma wytwarzająca dwa produkty, zysk zależny od ceny i reklamy, sprzedaż na dwóch rynkach, model Cournota (każda firma optymalizuje po swojej zmiennej).

## Przykład
$\Pi = 20 + 2P - 2P^2 + 4A - A^2 + 2PA$:
$\Pi'_P = 2 - 4P + 2A = 0$, $\Pi'_A = 4 - 2A + 2P = 0$ → $P = 3$, $A = 5$.
Hesjan: $(-4)(-2) - 2^2 = 4 > 0$, $\Pi''_{PP} < 0$ → maksimum, $\Pi = 33$.

## Na egzaminie
> [!question] Zadanie typowe
> Firma wytwarza dwa substytuty: $\Pi = -2x^3 - y^3 + 6x + 12y$. Ile produkować? *Odp.: x = 1, y = 2, Π = 20 (odrzucamy rozwiązania ujemne).*

> [!warning] Pułapka
> Przy funkcjach sześciennych układ ma kilka rozwiązań – wybierz to, które spełnia warunki drugiego rzędu i ma sens ekonomiczny (ilości ≥ 0).

## Zadania
Zadania do tego pojęcia: [[Zysk z dwóch produktów – optymalizacja dwóch zmiennych]], [[Cena i budżet reklamowy – zysk z dwiema zmiennymi]] i [[Sprzedaż na dwóch rynkach z łączną funkcją kosztów]].

## Jak to się łączy
To uogólnienie warunków z jednej zmiennej opisanych w [zysku marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20marginalny): zamiast jednej pochodnej mamy dwie cząstkowe. Gdy zmienne muszą spełniać dodatkowe ograniczenie (np. limit produkcji), stosujemy [metodę mnożników Lagrange'a](obsidian://open?vault=ekonomia-baza-wiedzy&file=Metoda%20mno%C5%BCnik%C3%B3w%20Lagrange%27a). Typowym przykładem z dwiema zmiennymi jest sprzedaż na dwóch rynkach – podstawa [dyskryminacji cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dyskryminacja%20cenowa), gdzie zysk maksymalizujemy jednocześnie po Q₁ i Q₂.
