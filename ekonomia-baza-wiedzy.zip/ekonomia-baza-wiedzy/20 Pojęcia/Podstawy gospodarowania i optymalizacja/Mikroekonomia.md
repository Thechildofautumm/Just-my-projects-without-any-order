---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Rzadkość zasobów", "Analiza marginalna", "Rynek"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Rekowski – Mikroekonomia]]", "[[Syllabus – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Ekonomia", "Makroekonomia"]
---
> [!abstract] Definicja
> Mikroekonomia to dział ekonomii badający decyzje pojedynczych podmiotów – konsumentów i przedsiębiorstw – oraz funkcjonowanie poszczególnych rynków.

## Wyjaśnienie
Ekonomia „zajmuje się problemem, w jaki sposób społeczeństwo rozdziela (dokonuje alokacji) stosunkowo rzadkie zasoby, posiadające różnorodne zastosowania, w celu produkowania dóbr oraz w jaki sposób dzieli wytworzone dobra między członków tego społeczeństwa” (Rekowski).

| Poziom analizy | Przedmiot | Typowe pytania |
|---|---|---|
| **Mikroekonomia** | konsument, przedsiębiorstwo, pojedynczy rynek | Ile kupić? Ile wyprodukować? Jaką ustalić cenę? |
| **Makroekonomia** | gospodarka narodowa jako całość | PKB, inflacja, bezrobocie, polityka pieniężna |

Każdy podmiot gospodaruje, czyli **wybiera** między alternatywami i dąży do **optymalizacji**: konsument – maksymalnej użyteczności, firma – maksymalnego zysku. Ekonomia menedżerska stosuje te same narzędzia do decyzji kierownictwa firmy.

```mermaid
flowchart LR
  R["Rzadkość zasobów"] --> W["Konieczność wyboru"]
  W --> K["Koszt alternatywny"]
  W --> M["Analiza marginalna: MB = MC"]
  M --> KON["Konsument: max użyteczności"]
  M --> F["Firma: max zysku"]
  KON --> RY["Rynek: popyt + podaż → cena"]
  F --> RY
```

## Przykład
Decyzja „ile godzin uczyć się do kolokwium” to problem mikroekonomiczny: masz ograniczony czas (rzadki zasób), każda godzina nauki to utracona godzina pracy (koszt alternatywny), a kolejne godziny dają coraz mniejszy przyrost wyniku (malejąca korzyść krańcowa).

## Na egzaminie
> [!question] Typowe pytanie
> Czym różni się mikroekonomia od makroekonomii? Podaj po dwa przykładowe problemy z każdego zakresu.

> [!success]- Odpowiedź (szkic)
> Mikroekonomia bada decyzje pojedynczych podmiotów i rynków (np. jak firma ustala cenę, jak podatek zmienia równowagę na rynku paliw). Makroekonomia bada gospodarkę jako całość (np. przyczyny inflacji, wpływ stóp procentowych na PKB i bezrobocie).

## Jak to się łączy
Cała mikroekonomia wynika z faktu, że występuje [rzadkość zasobów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rzadko%C5%9B%C4%87%20zasob%C3%B3w) – gdyby zasobów było pod dostatkiem, nie trzeba byłoby wybierać. Podstawową metodą, którą mikroekonomia podejmuje te wybory, jest [analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna). Głównym przedmiotem badań jest [rynek](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek), na którym decyzje konsumentów i firm spotykają się i wyznaczają cenę.
