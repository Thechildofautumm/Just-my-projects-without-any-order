---
typ: pojęcie
up: "[[MOC Podstawy gospodarowania i optymalizacja]]"
powiązane: ["Koszt alternatywny", "Czynnik produkcji"]
wymaga: ["Rzadkość zasobów"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["PPF", "Krzywa transformacji"]
---
> [!abstract] Definicja
> Granica możliwości produkcyjnych (PPF) to zbiór wszystkich efektywnych kombinacji dwóch dóbr, które gospodarka może wytworzyć przy danych zasobach i technologii.

## Wyjaśnienie
![[01_PPF_i_analiza_marginalna.png]]

| Punkt | Położenie | Znaczenie |
|---|---|---|
| A | na krzywej | efektywne wykorzystanie zasobów |
| B | pod krzywą | zasoby niewykorzystane (nieefektywność) |
| C | nad krzywą | nieosiągalne przy obecnych zasobach i technologii |

- **Wklęsły kształt** = rosnący koszt alternatywny: każda kolejna jednostka X wymaga rezygnacji z coraz większej ilości Y (zasoby nie są idealnie przydatne do obu produkcji).
- **Przesunięcie PPF na zewnątrz** – wzrost zasobów lub postęp technologiczny.

## Przykład
Gospodarka produkuje żywność i komputery. Przejście z punktu A (dużo żywności) do punktu z większą liczbą komputerów oznacza ruch wzdłuż krzywej – zyskujemy komputery kosztem żywności.

## Na egzaminie
> [!question] Pytanie otwarte
> Co oznacza punkt leżący wewnątrz PPF i jak gospodarka może przejść na krzywą? *Odp.: niewykorzystane zasoby (np. bezrobocie); przez ich zatrudnienie – bez rezygnowania z produkcji innego dobra.*

## Jak to się łączy
PPF istnieje dlatego, że [zasoby są rzadkie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rzadko%C5%9B%C4%87%20zasob%C3%B3w) – bez ograniczeń granicy by nie było. Nachylenie krzywej pokazuje [koszt alternatywny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny) jednego dobra wyrażony w drugim. Położenie krzywej zależy od ilości i jakości dostępnych [czynników produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Czynnik%20produkcji).
