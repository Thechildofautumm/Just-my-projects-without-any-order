---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Punkt zamknięcia", "Strata społeczna monopolu", "Dyskryminacja cenowa"]
wymaga: ["Maksymalizacja zysku", "Elastyczność a przychód"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cena monopolowa", "Optimum monopolu"]
---
> [!abstract] Definicja
> Monopol maksymalizuje zysk przy wielkości produkcji, dla której MR = MC, a cenę monopolową odczytuje z krzywej popytu nad tą wielkością.

## Wyjaśnienie
$$MR = MC, \quad \text{MC rosnący lub MC malejący wolniej niż MR}$$
- $Q_e$ z warunku MR = MC, **cena z krzywej popytu** (nie z MC!),
- zysk: $\pi = (P_m - ATC)\cdot Q_e$; możliwa też strata,
- strata > FC (P < AVC) → zamknąć,
- **monopol nie ma krzywej podaży** – ta sama ilość może iść po różnych cenach zależnie od popytu.

![[24_monopol_zysk.png]]

![[25_monopol_strata.png]]

## Przykład
Przykład: $TC = Q^2 + 20Q + 500$, $P = 500 - Q$ → $500 - 2Q = 2Q + 20$ → **Q = 120, P = 380**, π = 28 300.
Przykład: $TC = \frac13Q^3 - 6Q^2 + 60Q + 250$, $P = 32 - \frac12Q$ → Q = 7, P = 28,5, strata ≈ 290,8 > FC = 250 → **zamknąć**.

## Na egzaminie
> [!question] Pytanie testowe
> Monopol: P = 2,5, MC = 2,5, zysk dodatni. Co zrobić? **Skoro MR < P = MC, to MR < MC → zmniejszyć produkcję i podnieść cenę.**

> [!warning] Pułapka
> Przy sześciennym TC równanie MR = MC ma dwa pierwiastki – odrzuć ten, przy którym MC spada szybciej niż MR.

## Zadania
Zadania do tego pojęcia: [[Monopol – optymalna cena i zysk]], [[Monopol – strata większa od kosztów stałych]], [[Monopol – za duża produkcja]] i [[Monopol – kiedy zamknąć mimo MR = MC]].

## Jak to się łączy
Warunek równowagi to ogólna reguła [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku). Ponieważ MR = P(1 + 1/Ep) – patrz [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) – monopol zawsze działa na elastycznym odcinku popytu. Monopol też zamyka działalność, gdy cena spada poniżej AVC – patrz [punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia). Ograniczenie produkcji poniżej poziomu konkurencyjnego powoduje [stratę społeczną](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20spo%C5%82eczna%20monopolu). Siła rynkowa pozwala też na [dyskryminację cenową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dyskryminacja%20cenowa).
