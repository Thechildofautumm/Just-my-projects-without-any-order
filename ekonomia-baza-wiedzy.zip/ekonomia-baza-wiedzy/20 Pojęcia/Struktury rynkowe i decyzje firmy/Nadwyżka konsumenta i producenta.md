---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Strata społeczna monopolu", "Popyt"]
wymaga: ["Równowaga rynkowa"]
źródło: ["[[Syllabus – Mikroekonomia]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: ["Nadwyżka konsumenta", "Nadwyżka producenta", "CS", "PS", "Efektywność wymiany"]
---
> [!warning] Do weryfikacji
> Część treści pochodzi spoza materiałów z zajęć (podręcznik lub opracowanie własne) – sprawdź z prowadzącym.

> [!abstract] Definicja
> Nadwyżka konsumenta to różnica między ceną, jaką kupujący byli skłonni zapłacić, a ceną zapłaconą; nadwyżka producenta – różnica między ceną otrzymaną a minimalną ceną, za którą sprzedawcy by sprzedali.

## Wyjaśnienie
| | Na wykresie | Liniowo |
|---|---|---|
| nadwyżka konsumenta CS | pole pod D, nad ceną | $\tfrac12(P_{max} - P_e)\cdot Q_e$ |
| nadwyżka producenta PS | pole nad S (MC), pod ceną | $\tfrac12(P_e - P_{min})\cdot Q_e$ |
| nadwyżka całkowita | CS + PS | – |

![[26_nadwyzki_konsumenta_producenta.png]]

**Efektywność wymiany:** w równowadze konkurencyjnej wyprodukowana zostaje każda jednostka, dla której skłonność do zapłaty ≥ koszt krańcowy → nadwyżka całkowita jest maksymalna (P = MC – efektywność alokacyjna). Każde odejście od Qe (ceny administracyjne, podatki, monopol) zmniejsza nadwyżkę.

## Przykład
Przykład (rynek rowerów): E = (120; 20), Pmax = 60 → **CS = ½·40·120 = 2400**, **PS = ½·20·120 = 1200**.

![[m17_nadwyzki.png]]

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij, dlaczego równowaga konkurencyjna jest efektywna. *Odp.: maksymalizuje sumę nadwyżek – nie ma transakcji korzystnych dla obu stron, które by się nie odbyły.*

## Zadania
Pojęcie przydaje się też w: [Strata społeczna monopolu – porównanie z konkurencją](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20spo%C5%82eczna%20monopolu%20%E2%80%93%20por%C3%B3wnanie%20z%20konkurencj%C4%85).

## Jak to się łączy
Nadwyżki liczymy w punkcie [równowagi rynkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20rynkowa). Krzywa [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) pokazuje skłonność nabywców do zapłaty, stąd CS to pole pod nią. Ograniczenie produkcji przez monopol powoduje utratę części nadwyżki – [stratę społeczną](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20spo%C5%82eczna%20monopolu).
