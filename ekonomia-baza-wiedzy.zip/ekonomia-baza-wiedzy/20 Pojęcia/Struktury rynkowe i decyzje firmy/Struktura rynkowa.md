---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Rynek", "Koncentracja rynku", "Oligopol", "Konkurencja monopolistyczna"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[EM – Struktury rynkowe I]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[Rekowski – Mikroekonomia]]", "[[Samuelson i Marks – Ekonomia menedżerska]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Formy rynku"]
---
> [!abstract] Definicja
> Struktura rynkowa to forma organizacji rynku, wyróżniana według stopnia wpływu firmy na cenę: konkurencja doskonała, konkurencja monopolistyczna, oligopol, monopol.

## Wyjaśnienie
Modele są uproszczeniem rzeczywistości; wspólne założenie – firma **maksymalizuje zysk** (MR = MC).

![[m15_struktury_spektrum.png]]

| Cecha | Konkurencja doskonała | Konkurencja monopolistyczna | Oligopol | Monopol |
|---|---|---|---|---|
| liczba firm | bardzo wiele | wiele, małych | kilka dużych | jedna |
| produkt | jednorodny | zróżnicowany | jednorodny lub zróżnicowany | bez bliskich substytutów |
| bariery wejścia | brak | niewielkie/brak | umiarkowane lub wysokie | nie do pokonania |
| wpływ na cenę | brak (cenobiorca) | pewien | znaczny, współzależność | duży (cenodawca) |
| krzywa popytu firmy | pozioma | lekko opadająca | opadająca | = popyt rynkowy |
| zysk w długim okresie | 0 | 0 | może być > 0 | może być > 0 |

## Przykład
Rynek zbóż – blisko konkurencji doskonałej; fryzjerzy, restauracje – konkurencja monopolistyczna; paliwa, telekomunikacja – oligopol; sieć wodociągowa – monopol naturalny.

## Na egzaminie
> [!question] Pytanie testowe
> Jakie jest kryterium podziału struktur rynkowych? **Stopień wpływu firmy na cenę (zdarzenia rynkowe).**

## Zadania
Pojęcie przydaje się też w: [Koncentracja rynku – CR4 i HHI](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koncentracja%20rynku%20%E2%80%93%20CR4%20i%20HHI).

## Jak to się łączy
Struktura rynkowa to forma organizacji [rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek). Do jej rozpoznania służą miary [koncentracji rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koncentracja%20rynku) (CR4, HHI). Między biegunami – konkurencją doskonałą i monopolem – leżą [konkurencja monopolistyczna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20monopolistyczna) i [oligopol](obsidian://open?vault=ekonomia-baza-wiedzy&file=Oligopol).
