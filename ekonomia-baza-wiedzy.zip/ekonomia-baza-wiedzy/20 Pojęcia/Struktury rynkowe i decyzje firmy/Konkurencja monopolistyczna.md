---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Konkurencja doskonała", "Monopol pełny"]
część-z: ["Struktura rynkowa"]
źródło: ["[[EM – Struktury rynkowe, zestawienie]]", "[[EM – Struktury rynkowe I]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Rynek konkurencji monopolistycznej"]
---
> [!abstract] Definicja
> Konkurencja monopolistyczna to rynek z dużą liczbą niewielkich firm sprzedających zróżnicowane produkty (bliskie substytuty) przy niewielkich barierach wejścia.

## Wyjaśnienie
**Cechy:**
- zróżnicowany produkt, serwis, usługi posprzedażowe; ważna reklama i marketing,
- pewien stopień wpływu na cenę – krzywa popytu lekko opada (popyt względnie, ale nie doskonale elastyczny),
- niewielkie bariery wejścia lub ich brak,
- maksymalizacja zysku: MR = MC.

![[e15_konkurencja_monopolistyczna.png]]

| Okres | Sytuacja typowej firmy |
|---|---|
| krótki | zysk ekonomiczny (nadzwyczajny) |
| długi | wejście nowych firm → popyt na produkty przeciętnej firmy spada (krzywa w lewo) → zysk ekonomiczny = 0 (styczność popytu z ATC) |

## Przykład
Kawiarnie w centrum miasta: każda ma nieco inny produkt i klimat, może trochę podnieść cenę, ale klienci łatwo przejdą do konkurencji; nowe kawiarnie łatwo się otwierają.

## Na egzaminie
> [!question] Pytanie otwarte
> Porównaj równowagę długookresową w konkurencji monopolistycznej i doskonałej. *Odp.: w obu zysk = 0, ale w konkurencji monopolistycznej P > MC i firma nie produkuje przy ATCmin.*

## Jak to się łączy
To jedna z form pośrednich [struktur rynkowych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa). Z [konkurencją doskonałą](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a) łączy ją swobodne wejście, przez które zysk w długim okresie znika. Z [monopolem](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20pe%C5%82ny) – opadająca krzywa popytu i P > MR.
