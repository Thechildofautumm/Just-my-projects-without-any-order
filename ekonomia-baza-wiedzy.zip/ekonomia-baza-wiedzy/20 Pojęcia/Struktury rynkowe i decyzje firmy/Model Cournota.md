---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Model Stackelberga", "Optymalizacja funkcji dwóch zmiennych"]
część-z: ["Oligopol"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cournot", "Funkcja reakcji"]
---
> [!abstract] Definicja
> W modelu Cournota oligopoliści o podobnej sile jednocześnie wybierają wielkość produkcji, przyjmując produkcję rywali za daną; cena zależy od łącznej produkcji.

## Wyjaśnienie
Dla każdej firmy i: $MR_i = MC_i$, gdzie $TR_i = P(q_1 + q_2)\cdot q_i$ i MR liczymy jako pochodną cząstkową po $q_i$. Każde równanie to **funkcja reakcji**; równowaga = przecięcie funkcji reakcji (rozwiązanie układu).
Warunek wystarczający: $MR_i' < MC_i'$.

![[e13_cournot_stackelberg.png]]

## Przykład
Przykład (kamieniołomy): $P = 20 - q_1 - q_2$, $TC_1 = 5q_1 + 10$, $TC_2 = 5q_2 + 6$.
$20 - 2q_1 - q_2 = 5$ i $20 - q_1 - 2q_2 = 5$ → **q₁ = q₂ = 5**, P = 10, π₁ = 15, π₂ = 19.

## Na egzaminie
> [!question] Zadanie typowe
> MC = 20, $P = 200 - q_1 - q_2$. *Odp.: q₁ = q₂ = 60, P = 80.*

## Zadania
Zadania do tego pojęcia: [[Dwa kamieniołomy – duopol Cournota z kosztami stałymi]], [[Duopol Cournota – porównanie z konkurencją i monopolem]] i [[Producenci autobusów – Cournot i Stackelberg]].

## Jak to się łączy
To podstawowy model [oligopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Oligopol). Jego wersją sekwencyjną jest [model Stackelberga](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20Stackelberga). Matematycznie to układ warunków pierwszego rzędu, jak w [optymalizacji funkcji dwóch zmiennych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optymalizacja%20funkcji%20dw%C3%B3ch%20zmiennych) – z tą różnicą, że każdą zmienną optymalizuje inna firma.
