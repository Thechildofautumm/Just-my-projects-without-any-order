---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
wymaga: ["Nadwyżka konsumenta i producenta", "Równowaga monopolu"]
przeciwieństwo: ["Konkurencja doskonała"]
źródło: ["[[Syllabus – Mikroekonomia]]", "[[Prezentacja – Monopol pełny]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: ["DWL", "Deadweight loss", "Nieefektywność monopolu"]
---
> [!warning] Do weryfikacji
> Część treści pochodzi spoza materiałów z zajęć (podręcznik lub opracowanie własne) – sprawdź z prowadzącym.

> [!abstract] Definicja
> Strata społeczna (deadweight loss, DWL) to utracona nadwyżka całkowita z transakcji, do których nie dochodzi, bo monopol produkuje mniej niż rynek konkurencyjny.

## Wyjaśnienie
Monopol: $Q_m < Q_k$, $P_m > P_k$ i $P > MC$. Społeczne skutki monopolizacji:
1. mniejsza produkcja, wyższa cena,
2. **transfer** części nadwyżki konsumenta do monopolisty,
3. **DWL** – trójkąt między D i MC od $Q_m$ do $Q_k$,
4. brak presji konkurencji → ryzyko nieefektywności kosztowej,
5. przeciwdziałanie: prawo antymonopolowe, regulacja cen, liberalizacja.

$$DWL = \tfrac12\,(P_m - MC(Q_m))\cdot(Q_k - Q_m)$$

![[27_monopol_vs_KD_DWL.png]]

## Przykład
Przykład: popyt $P = 500 - Q$, $MC = 2Q + 20$: KD – Q = 160, P = 340; monopol – Q = 120, P = 380, MC(120) = 260 → **DWL = ½·120·40 = 2400**; nadwyżka całkowita spada z 38 400 do 36 000.

## Na egzaminie
> [!question] Pytanie otwarte
> Przedstaw graficznie i omów społeczne skutki monopolizacji rynku.

> [!success]- Odpowiedź (szkic)
> Monopolista ustala $MR = MC$, więc produkuje mniej ($Q_m < Q_k$) i drożej ($P_m > MC$) niż rynek konkurencyjny. Część nadwyżki konsumenta przechodzi do producenta, a trójkąt między popytem a $MC$ od $Q_m$ do $Q_k$ znika – to strata społeczna (DWL), czyli nieefektywność alokacyjna.

## Zadania
Zadania do tego pojęcia: [[Strata społeczna monopolu – porównanie z konkurencją]].

## Jak to się łączy
DWL mierzymy jako ubytek [nadwyżki konsumenta i producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nadwy%C5%BCka%20konsumenta%20i%20producenta) wynikający z [równowagi monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20monopolu) (Qm < Qk). Punktem odniesienia jest efektywna [konkurencja doskonała](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a), w której DWL = 0.
