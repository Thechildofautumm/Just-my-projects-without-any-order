---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Punkt zamknięcia", "Zysk ekonomiczny", "Marża wkładu"]
wymaga: ["Koszt przeciętny"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[EM – Struktury rynkowe I]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska", "Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Punkt niwelacji", "Cena niwelacji", "BEP"]
---
> [!abstract] Definicja
> Próg rentowności (punkt niwelacji, BEP) to poziom ceny lub sprzedaży, przy którym przychody równają się kosztom, a zysk ekonomiczny wynosi zero.

## Wyjaśnienie
**Mikroekonomia (KD):** $P = ATC_{min} = MR = MC$ → π = 0, TR = TC (firma ma zysk normalny).

**Ekonomia menedżerska – trzy ujęcia** (z $TR = TC$, $P\cdot Q = AVC\cdot Q + FC$):

| Ujęcie | Wzór |
|---|---|
| ilościowe | $Q_{BEP} = \dfrac{FC}{P - AVC}$ |
| wartościowe | $TR_{BEP} = P\cdot Q_{BEP} = \dfrac{P\cdot FC}{P - AVC}$ |
| procentowe | $\dfrac{Q_{BEP}}{Q_c}\cdot 100\% = \dfrac{FC}{(P - AVC)\cdot Q_c}\cdot 100\%$ |

$P - AVC$ to marża wkładu na sztukę; $Q_c$ – zdolności produkcyjne. Cena progu rentowności: $P_{BEP} = ATC$.

![[e10_prog_rentownosci_liniowy.png]]

![[23_KD_punkty_graniczne_podaz.png]]

## Przykład
Przykład: FC = 12 000, AVC = 9, P = 12, zdolność 20 000 → **Q = 4000, TR = 48 000, 20%** mocy.
Przykład: $TC = 3Q^3 - 36Q^2 + 200Q$ → ATCmin przy Q = 6 → **cena niwelacji 92**.

## Na egzaminie
> [!question] Zadanie typowe
> $TC = 25Q + 48\,000$, P = 31. Od jakiej produkcji zysk nadzwyczajny? *Odp.: Q > 48 000/6 = 8000.*

## Zadania
Zadania do tego pojęcia: [[Konkurencja doskonała – zysk zerowy]], [[Cena progu rentowności z funkcji kosztów]], [[Próg rentowności przy liniowych kosztach]] i [[Próg rentowności ilościowy, wartościowy i procentowy]].

## Jak to się łączy
W mikroekonomii próg wyznacza minimum [kosztu przeciętnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny). Drugim punktem granicznym jest [punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia). „Zysk równy zero” to [zysk ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny) równy zero, czyli zysk normalny. Mianownik wzoru ilościowego to [marża wkładu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mar%C5%BCa%20wk%C5%82adu) na sztukę – pojęcie z rachunkowości zarządczej.
