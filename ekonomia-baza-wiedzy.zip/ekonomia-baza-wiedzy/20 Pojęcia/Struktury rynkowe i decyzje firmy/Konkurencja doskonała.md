---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Elastyczność cenowa popytu", "Maksymalizacja zysku"]
część-z: ["Struktura rynkowa"]
przeciwieństwo: ["Monopol pełny"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[EM – Struktury rynkowe I]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["KD", "Rynek doskonale konkurencyjny", "Cenobiorca"]
---
> [!abstract] Definicja
> Konkurencja doskonała to struktura rynku z bardzo wieloma firmami sprzedającymi jednorodny produkt bez barier wejścia; każda firma jest cenobiorcą, więc P = AR = MR.

## Wyjaśnienie
**Założenia:** jednorodny produkt, pełna mobilność czynników (brak barier), bardzo wielu kupujących i sprzedających, doskonała informacja, brak wpływu na cenę.

![[21_KD_rynek_a_firma.png]]

- popyt na produkt firmy doskonale elastyczny ($E_p = -\infty$): $P = AR = MR$, $TR = P_E\cdot Q$,
- maksymalizacja zysku: $P = MC$ przy rosnącym MC ($MC' > 0$).

**Krótki okres:** zysk, zysk normalny albo strata akceptowalna (P > AVC) – patrz drzewo decyzji w notatce o punkcie zamknięcia.

**Długi okres:** zysk ekonomiczny przyciąga nowe firmy → podaż gałęzi rośnie → cena spada do **P = ACmin**; zysk ekonomiczny = 0. Cena, poniżej której firma wychodzi z gałęzi, to **cena wyjścia = ACmin**.

![[e11_KD_dlugi_okres.png]]

## Przykład
Przykład: $TC = 0{,}2Q^3 - 4Q^2 + 50Q$ → $AC = 0{,}2Q^2 - 4Q + 50$, $AC' = 0$ → Q = 10, **P = AC = 30** – przy tej cenie ustaje wejście firm.
Przykład: $TC = 0{,}5Q^2 + 4Q + 80$, P = 34 → MC = Q + 4 = 34 → Q = 30, π = 370.

![[m16_KD_zysk.png]]

## Na egzaminie
> [!question] Pytanie otwarte
> Dlaczego w długim okresie firma w konkurencji doskonałej osiąga zysk ekonomiczny równy zero? *Odp.: brak barier wejścia – zysk przyciąga nowe firmy, aż cena spadnie do ACmin.*

## Zadania
Zadania do tego pojęcia: [[Cena, przy której ustaje wejście do gałęzi]] i [[Cena wyjścia z gałęzi w długim okresie]].

Pojęcie przydaje się też w: [Konkurencja doskonała – produkcja przy cenie 34](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a%20%E2%80%93%20produkcja%20przy%20cenie%2034).

## Jak to się łączy
To biegun [struktur rynkowych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa) bez wpływu na cenę, przeciwieństwo [monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20pe%C5%82ny). Pozioma krzywa popytu firmy to skrajny przypadek [elastyczności cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu) (|Ep| = ∞). Ponieważ MR = P, ogólny warunek [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC przyjmuje postać P = MC.
