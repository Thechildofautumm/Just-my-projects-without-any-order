---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Próg rentowności", "Krzywa podaży przedsiębiorstwa"]
wymaga: ["Koszt przeciętny", "Koszt stały i zmienny"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Prezentacja – Monopol pełny]]", "[[EM – Struktury rynkowe I]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cena zamknięcia", "Decyzja o zamknięciu"]
---
> [!abstract] Definicja
> Punkt zamknięcia to cena równa minimum przeciętnego kosztu zmiennego (P = AVCmin), przy której strata firmy równa się kosztom stałym; poniżej niej firma powinna wstrzymać produkcję.

## Wyjaśnienie
Po wstrzymaniu produkcji w krótkim okresie firma nie ma przychodu ani kosztów zmiennych, ale ponosi FC: $\pi(0) = -FC$. Produkuje mimo straty, jeśli strata < FC, czyli **P > AVC**.

```mermaid
flowchart TD
  A["Q z warunku MR = MC (MC rosnący)"] --> B{"P ≥ ATC?"}
  B -- "tak" --> C["zysk lub zysk normalny → produkuj"]
  B -- "nie" --> D{"P ≥ AVC?"}
  D -- "tak" --> E["strata < FC → produkuj w krótkim okresie"]
  D -- "nie" --> F["strata > FC → zamknij (Q = 0)"]
```

![[22_KD_trzy_sytuacje_firmy.png]]

| Punkt | Warunek | Wynik |
|---|---|---|
| próg rentowności | P = ATCmin | π = 0 |
| punkt zamknięcia | P = AVCmin | strata = FC (TR = VC) |
| długi okres – cena wyjścia | P = ACmin | firma wychodzi z gałęzi |

## Przykład
Przykład: $TC = Q^3 - 6Q^2 + 15Q + 20$ → $AVC = Q^2 - 6Q + 15$, min przy Q = 3 → **P zamknięcia = 6**.
Przykład: P = 40, Q = 20, strata 100 < FC 500, P > AVC = 20 → **produkować**.

## Na egzaminie
> [!question] Pytanie testowe
> Strata firmy jest większa od kosztów stałych. Co zrobić? **Zamknąć – produkując traci więcej niż przy Q = 0.**

## Zadania
Zadania do tego pojęcia: [[Konkurencja doskonała – strata mniejsza od kosztów stałych]], [[Konkurencja doskonała – decyzja przy MR = 24]] i [[Cena zamknięcia z funkcji kosztów]].

Pojęcie przydaje się też w: [Monopol – strata większa od kosztów stałych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20strata%20wi%C4%99ksza%20od%20koszt%C3%B3w%20sta%C5%82ych), [Monopol – kiedy zamknąć mimo MR = MC](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20kiedy%20zamkn%C4%85%C4%87%20mimo%20MR%20%3D%20MC), [Wzrost kosztów stałych a decyzja o produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Wzrost%20koszt%C3%B3w%20sta%C5%82ych%20a%20decyzja%20o%20produkcji).

## Jak to się łączy
Punkt zamknięcia wyznacza minimum [kosztu przeciętnego zmiennego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny), a decyzja opiera się na porównaniu straty z [kosztami stałymi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny). Drugim punktem granicznym jest [próg rentowności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci). Od punktu zamknięcia zaczyna się [krzywa podaży przedsiębiorstwa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20poda%C5%BCy%20przedsi%C4%99biorstwa).
