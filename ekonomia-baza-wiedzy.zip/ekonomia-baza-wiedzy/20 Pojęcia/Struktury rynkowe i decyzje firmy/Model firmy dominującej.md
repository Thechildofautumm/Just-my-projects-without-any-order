---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Równowaga monopolu", "Konkurencja doskonała"]
część-z: ["Oligopol"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Przywództwo cenowe", "Firma dominująca"]
---
> [!abstract] Definicja
> W modelu firmy dominującej jedna duża firma ustala cenę jak monopolista (MR = MC na swojej krzywej popytu), a mniejsze firmy przyjmują tę cenę za daną i zaspokajają resztę popytu rynkowego.

## Wyjaśnienie
Kroki:
1. lider: MR = MC na **swojej** krzywej popytu → q lidera,
2. cena: z krzywej popytu lidera przy tym q,
3. popyt rynkowy przy tej cenie → Q,
4. pozostałe firmy: Q − q; udział lidera: q/Q.

![[e14_firma_dominujaca.png]]

## Przykład
Przykład (gaz płynny): rynek $P = -0{,}01Q + 15$; lider $TC = 0{,}01q^2 + 3q + 20$, popyt $P = -0{,}02q + 12$.
MR = 12 − 0,04q = MC = 0,02q + 3 → **q = 150**, P = 9; rynek: 9 = 15 − 0,01Q → Q = 600; pozostali: **450**; udział lidera **25%**.

## Na egzaminie
> [!question] Pytanie testowe
> Jak zachowują się małe firmy w modelu firmy dominującej? **Jak w konkurencji doskonałej – przyjmują cenę lidera za daną.**

## Zadania
Zadania do tego pojęcia: [[Model firmy dominującej – cena i podział rynku]] i [[Rynek gazu płynnego – firma dominująca]].

## Jak to się łączy
To jeden z modeli [oligopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Oligopol). Lider postępuje dokładnie jak w [równowadze monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20monopolu) (MR = MC, cena z popytu), a pozostałe firmy – jak w [konkurencji doskonałej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a).
