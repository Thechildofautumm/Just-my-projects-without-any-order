---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Monopol pełny"]
część-z: ["Struktura rynkowa"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[EM – Struktury rynkowe I]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[Samuelson i Marks – Ekonomia menedżerska]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["CR4", "CR1", "HHI", "Wskaźnik Herfindahla-Hirschmana", "Współczynnik koncentracji"]
---
> [!abstract] Definicja
> Koncentracja rynku to stopień, w jakim sprzedaż skupia się w rękach niewielu firm; mierzą ją współczynnik koncentracji CR4 i wskaźnik Herfindahla-Hirschmana HHI.

## Wyjaśnienie
**CR4** – suma udziałów (%) czterech największych firm:

| Forma rynku | CR4 |
|---|---|
| konkurencja (rynek efektywnie konkurencyjny) | 0–40 |
| luźny oligopol | 40–60 |
| ścisły oligopol | 60–90 |
| efektywny monopol | 90–100 (wg Samuelsona: CR1 > 90%) |

**HHI** – suma kwadratów udziałów **wszystkich** firm: $HHI = \sum s_i^2$ (od ≈0 do 10 000).

| HHI | Rynek | Siła rynkowa |
|---|---|---|
| 0–1000 | nieskoncentrowany | nie ma |
| 1000–1800 | umiarkowanie skoncentrowany | jest |
| 1800–10 000 | wysoce skoncentrowany | jest (> 2400 bardzo wysokie) |

HHI rośnie, gdy podział rynku jest nierównomierny, a maleje wraz z liczbą firm.

![[e12_CR4_HHI.png]]

## Przykład
Przykład (pralki): udziały 24, 18, 14, 11, 9, 7, 6, 5, 3, 3 → **CR4 = 67** (ścisły oligopol), **HHI = 1426** (umiarkowanie skoncentrowany).

## Na egzaminie
> [!question] Zadanie typowe
> HHI dla: monopolu (10 000), udziałów 60/40 (5200), trzech równych (≈ 3333), dwudziestu równych (500).

> [!warning] Pułapka
> CR4 i HHI mogą dawać różne oceny tego samego rynku – HHI uwzględnia wszystkie firmy i nierówność udziałów.

## Zadania
Zadania do tego pojęcia: [[Koncentracja rynku – CR4 i HHI]], [[Rynek pralek – CR4 i HHI]] i [[HHI dla modelowych struktur rynku]].

## Jak to się łączy
Miary koncentracji to narzędzie klasyfikacji [struktur rynkowych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa). Skrajna koncentracja (CR1 > 90%, HHI = 10 000) oznacza [monopol](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20pe%C5%82ny).
