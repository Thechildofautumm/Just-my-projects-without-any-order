---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Równowaga monopolu"]
część-z: ["Struktura rynkowa"]
przeciwieństwo: ["Konkurencja doskonała"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Monopol", "Monopol naturalny", "Cenodawca"]
---
> [!abstract] Definicja
> Monopol pełny to rynek z jednym sprzedawcą produktu bez bliskich substytutów i z zablokowanym wejściem; jego krzywa popytu jest krzywą popytu rynkowego, więc P = AR > MR.

## Wyjaśnienie
**Założenia:** jeden sprzedający i wielu kupujących, brak bliskich substytutów, bariery wejścia (techniczne, ekonomiczne, administracyjno-prawne), doskonała informacja.

**Źródła monopolu:** monopol naturalny (sieci: elektryczność, gaz, woda), kontrola produkcji (spirytus, tytoń, zbrojenia), ochrona patentowa, kontrola zasobów.

- popyt monopolu = popyt rynkowy (opadający, elastyczność od 0 do −∞),
- $P = AR > MR$; dla $P = aQ + b$: $MR = 2aQ + b$.

**Monopol w gospodarce:** ocena praktyk monopolistycznych, prawo antymonopolowe, regulacja cen usług publicznych, względny charakter pozycji (czas, terytorium, liberalizacja).

| | Konkurencja doskonała | Monopol |
|---|---|---|
| produkcja | $Q_k$ większa | $Q_m < Q_k$ |
| cena | $P_k$ niższa | $P_m > P_k$ |
| zysk | $Z_k$ | $Z_m > Z_k$ |

## Przykład
Lokalne przedsiębiorstwo wodociągowe: budowa drugiej sieci rur byłaby nieopłacalna – monopol naturalny.

## Na egzaminie
> [!question] Pytanie testowe
> Dlaczego w monopolu MR < P? **Bo żeby sprzedać więcej, monopolista musi obniżyć cenę wszystkich sprzedawanych jednostek.**

## Zadania
Pojęcie przydaje się też w: [Monopol – za duża produkcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20%E2%80%93%20za%20du%C5%BCa%20produkcja).

## Jak to się łączy
Monopol to biegun [struktur rynkowych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa) o pełnym wpływie na cenę – przeciwieństwo [konkurencji doskonałej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a). Jak monopolista ustala ilość i cenę, opisuje [równowaga monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20monopolu).
