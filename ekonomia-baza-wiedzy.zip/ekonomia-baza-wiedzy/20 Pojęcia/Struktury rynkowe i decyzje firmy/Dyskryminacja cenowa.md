---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Elastyczność cenowa popytu", "Nadwyżka konsumenta i producenta"]
część-z: ["Monopol pełny"]
źródło: ["[[Prezentacja – Monopol pełny]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: ["Różnicowanie cen", "Dyskryminacja cenowa III stopnia"]
---
> [!warning] Do weryfikacji
> Część treści pochodzi spoza materiałów z zajęć (podręcznik lub opracowanie własne) – sprawdź z prowadzącym.

> [!abstract] Definicja
> Dyskryminacja cenowa to ustalanie różnych cen na ten sam produkt dla różnych nabywców lub rynków.

## Wyjaśnienie
Przykłady z wykładu: niższe ceny dla uczniów, różne ceny energii dla gospodarstw domowych i firm. Skutek: redystrybucja dochodu, najczęściej na korzyść producenta (większy zysk monopolu).

**Warunki:** siła rynkowa, możliwość rozdzielenia rynków (brak odsprzedaży), różne elastyczności popytu.

![[28_dyskryminacja_cenowa.png]]

| Stopień *(uzupełnienie)* | Mechanizm | Efekt |
|---|---|---|
| I (doskonała) | każdy płaci swoją cenę maksymalną | CS = 0, brak DWL |
| II | cena zależy od ilości (rabaty, pakiety) | część CS przejęta |
| III | różne ceny dla segmentów | $MR_1 = MR_2 = MC$; wyższa cena w mniej elastycznym segmencie |

## Przykład
Przykład: $P_x = 100 - Q_x$, $P_y = 60 - 2Q_y$, wspólna funkcja kosztów → Qx = 4, Qy = 3; ceny **96 i 54** – różne ceny na dwóch rynkach, zysk 188.

## Na egzaminie
> [!question] Pytanie testowe
> Na którym rynku monopolista dyskryminujący ustali wyższą cenę? **Tam, gdzie popyt jest mniej elastyczny.**

## Zadania
Pojęcie przydaje się też w: [Sprzedaż na dwóch rynkach z łączną funkcją kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Sprzeda%C5%BC%20na%20dw%C3%B3ch%20rynkach%20z%20%C5%82%C4%85czn%C4%85%20funkcj%C4%85%20koszt%C3%B3w).

## Jak to się łączy
Dyskryminacja cenowa to praktyka podmiotu z siłą rynkową, typowo [monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Monopol%20pe%C5%82ny). Podział cen opiera się na różnej [elastyczności cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu) segmentów. Jej skutkiem jest przejęcie części [nadwyżki konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nadwy%C5%BCka%20konsumenta%20i%20producenta) przez producenta.
