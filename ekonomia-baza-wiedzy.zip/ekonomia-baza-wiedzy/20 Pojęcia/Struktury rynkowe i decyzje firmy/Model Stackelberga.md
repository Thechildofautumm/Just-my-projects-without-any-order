---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Model Cournota"]
część-z: ["Oligopol"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Stackelberg", "Przywódca i naśladowca"]
---
> [!abstract] Definicja
> W modelu Stackelberga przywódca wybiera produkcję pierwszy, uwzględniając funkcję reakcji naśladowcy, i dzięki temu narzuca mu warunki gry.

## Wyjaśnienie
Kroki:
1. funkcja reakcji naśladowcy (firma 2): $MR_2 = MC_2$ → $q_2(q_1)$,
2. podstaw $q_2(q_1)$ do ceny → popyt rezydualny przywódcy,
3. przywódca: $MR_1 = MC_1$ → q₁; potem q₂ i P.

Przywódca produkuje więcej niż w Cournocie, naśladowca mniej; cena jest niższa.

## Przykład
Przykład: $P = 20 - q_1 - q_2$, MC = 5. Reakcja: $q_2 = 7{,}5 - 0{,}5q_1$; $P = 12{,}5 - 0{,}5q_1$, $MR_1 = 12{,}5 - q_1 = 5$ → **q₁ = 7,5; q₂ = 3,75**; P = 8,75 (w Cournocie 5 i 5, P = 10).

## Na egzaminie
> [!question] Zadanie typowe
> $P = 50 - q_1 - q_2$, $TC_1 = 12q_1 + 40$, $TC_2 = 10q_2 + 30$. *Odp.: Cournot q₁ = 12, q₂ = 14, P = 24; Stackelberg (lider 1) q₁ = 18, q₂ = 11, P = 21.*

## Zadania
Zadania do tego pojęcia: [[Model Stackelberga – przewaga pierwszego ruchu]].

Pojęcie przydaje się też w: [Producenci autobusów – Cournot i Stackelberg](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producenci%20autobus%C3%B3w%20%E2%80%93%20Cournot%20i%20Stackelberg).

## Jak to się łączy
To model [oligopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Oligopol) z decyzjami sekwencyjnymi; przywódca wykorzystuje funkcję reakcji z [modelu Cournota](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20Cournota).
