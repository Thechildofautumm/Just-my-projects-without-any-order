---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Koncentracja rynku", "Model Cournota"]
część-z: ["Struktura rynkowa"]
źródło: ["[[EM – Struktury rynkowe II]]", "[[EM – Struktury rynkowe, zestawienie]]", "[[EM – Struktury rynkowe I]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Duopol", "Rynek oligopolistyczny"]
---
> [!abstract] Definicja
> Oligopol to rynek zdominowany przez niewielką liczbę dużych firm, których decyzje są współzależne – każda bierze pod uwagę reakcje rywali.

## Wyjaśnienie
**Cechy:** mała liczba sprzedawców (duopol = 2), produkt identyczny lub zróżnicowany, umiarkowanie wysokie lub wysokie bariery wejścia, **współzależność** decyzji, współpraca albo konkurencja.

| Model | Konkurencja | Założenie |
|---|---|---|
| firmy dominującej | lider + naśladowcy | lider jak monopolista, reszta jak cenobiorcy |
| Cournota | ilościowa, jednoczesna | każda firma przyjmuje produkcję rywali za daną |
| Stackelberga | ilościowa, sekwencyjna | przywódca decyduje pierwszy |
| złamanej krzywej popytu, wojny cenowe | cenowa | (wymienione na wykładzie) |

## Przykład
Rynek paliw: jedna duża firma ustala cenę, mniejsze stacje ją akceptują – model firmy dominującej.

## Na egzaminie
> [!question] Pytanie testowe
> Cechą wyróżniającą oligopol jest… **współzależność decyzji firm.**

## Zadania
Pojęcie przydaje się też w: [Producenci autobusów – Cournot i Stackelberg](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producenci%20autobus%C3%B3w%20%E2%80%93%20Cournot%20i%20Stackelberg).

## Jak to się łączy
Oligopol to forma pośrednia [struktur rynkowych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa). Rozpoznajemy go po [koncentracji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koncentracja%20rynku) (CR4 > 40%, HHI > 1000). Podstawowym modelem konkurencji ilościowej jest [model Cournota](obsidian://open?vault=ekonomia-baza-wiedzy&file=Model%20Cournota).
