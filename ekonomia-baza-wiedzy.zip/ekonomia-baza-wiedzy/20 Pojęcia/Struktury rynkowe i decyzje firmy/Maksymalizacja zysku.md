---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Analiza marginalna"]
wymaga: ["Przychód", "Koszt marginalny"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Prezentacja – Monopol pełny]]", "[[EM – Wprowadzenie, analiza marginalna]]", "[[EM – Metody optymalizacji]]", "[[EM – Struktury rynkowe I]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MR = MC", "Warunek maksymalizacji zysku"]
---
> [!abstract] Definicja
> Firma maksymalizuje zysk przy takiej wielkości produkcji, dla której przychód marginalny równa się kosztowi marginalnemu (MR = MC), a funkcja zysku ma maksimum (MR′ < MC′).

## Wyjaśnienie
| Struktura | MR | Warunek |
|---|---|---|
| konkurencja doskonała | MR = P | P = MC, MC rosnący |
| monopol | MR < P | MR = MC, MC rosnący lub malejący wolniej niż MR |
| oligopol (Cournot) | MR po własnej zmiennej | $MR_i = MC_i$ dla każdej firmy |

Warunek konieczny: $M\Pi = MR - MC = 0$; wystarczający: $MR' < MC'$.

> [!warning] Pułapka
> Maksymalizacja zysku ≠ maksymalizacja przychodu (MR = 0) ≠ minimalizacja kosztu przeciętnego (ATCmin).

## Przykład
Przykład: $P = 48 - 0{,}5Q$, $TC = 0{,}5Q^2 + 8Q + 200$ → $48 - Q = Q + 8$ → **Q = 20, P = 38**, π = 200; $MR' = -1 < MC' = 1$ ✔.

## Na egzaminie
> [!question] Pytanie testowe
> P = MR = 4, MC = 3,5 i MC rośnie. Co zrobić z produkcją? **Zwiększyć – każda dodatkowa jednostka podnosi zysk.**

## Zadania
Zadania do tego pojęcia: [[Konkurencja doskonała – produkcja przy cenie 34]] i [[Odtwarzanie tabeli kosztów trzech firm]].

Pojęcie przydaje się też w: [Konkurencja doskonała – strata mniejsza od kosztów stałych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a%20%E2%80%93%20strata%20mniejsza%20od%20koszt%C3%B3w%20sta%C5%82ych), [Optymalna produkcja – dwa warianty funkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optymalna%20produkcja%20%E2%80%93%20dwa%20warianty%20funkcji).

## Jak to się łączy
Do warunku potrzebny jest [przychód marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) i [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny). To najważniejsze zastosowanie [analizy marginalnej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) (MB = MC).
