---
typ: pojęcie
up: "[[MOC Struktury rynkowe i decyzje firmy]]"
powiązane: ["Podaż"]
wymaga: ["Koszt marginalny", "Punkt zamknięcia"]
źródło: ["[[Prezentacja – Konkurencja doskonała]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Podaż firmy", "Podaż gałęzi"]
---
> [!abstract] Definicja
> W konkurencji doskonałej krzywa podaży przedsiębiorstwa w krótkim okresie to odcinek krzywej kosztu marginalnego leżący powyżej minimum AVC.

## Wyjaśnienie
- dla każdej ceny P ≥ AVCmin firma wybiera Q z warunku P = MC → para (P, Q) leży na MC,
- poniżej AVCmin firma nic nie produkuje (Q = 0),
- **podaż gałęzi** = suma (pozioma) krzywych podaży firm.

![[23_KD_punkty_graniczne_podaz.png]]

![[m04_podaz_galezi_suma_MC.png]]

> [!note] Monopol
> Monopol nie ma krzywej podaży – nie istnieje jednoznaczna zależność między ceną a oferowaną ilością.

## Przykład
Firma z MC = 2 + q przy cenie 6 oferuje 4 jednostki, a druga (MC = 2 + q/2) – 8; podaż rynkowa przy P = 6 to 12.

## Na egzaminie
> [!question] Pytanie testowe
> Od jakiej ceny zaczyna się krzywa podaży firmy w KD? **Od ceny równej minimum AVC (punkt zamknięcia).**

## Zadania
Pojęcie przydaje się też w: [Cena zamknięcia z funkcji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%20zamkni%C4%99cia%20z%20funkcji%20koszt%C3%B3w).

## Jak to się łączy
Kształt krzywej podaży to rosnący [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny), a jej początek wyznacza [punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia). Sumując krzywe wszystkich firm, dostajemy rynkową [podaż](obsidian://open?vault=ekonomia-baza-wiedzy&file=Poda%C5%BC) – tak teoria kosztów „zasila” rynek.
