---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Koszt relewantny", "Rola kontrolera"]
część-z: ["Rachunkowość zarządcza"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Zasady CGMA", "Funkcje RZ"]
---
> [!abstract] Definicja
> Rachunkowość zarządcza pełni cztery funkcje – planowanie, wspomaganie decyzji, kontrolę oraz motywowanie i ocenę – a dobra informacja zarządcza spełnia cztery zasady CGMA.

## Wyjaśnienie
| Funkcja | Treść |
|---|---|
| planowanie | strategia, budżet, prognozy, cele dla centrów odpowiedzialności |
| podejmowanie decyzji | wybór wariantu na podstawie **przyszłych, różnicowych** przepływów |
| kontrola | porównanie wykonania z planem, analiza odchyleń, korekty |
| motywowanie i ocena | cele, mierniki, systemy premiowe zgodne z celami firmy |

Klasyczny podział (Anthony 1965): planowanie strategiczne, kontrola zarządcza, kontrola operacyjna.

**Zasady CGMA (CIMA i AICPA, 2014):**
1. komunikacja dostarcza informacji, która **wpływa na decyzje**,
2. informacja jest **istotna** (przyszła, różnicowa, właściwej jakości),
3. analizowany jest **wpływ na wartość** (scenariusze, ryzyko, długi horyzont),
4. **odpowiedzialne zarządzanie buduje zaufanie** (etyka, rozliczalność).

## Przykład
Pytania zarządu Velomii i narzędzia: koszt roweru → ABC/TDABC; ile rowerów sprzedać, gdy skończą się dopłaty → CVP; czy przyjąć zamówienie o 20% taniej → koszty relewantne; odchylenia kosztu → koszty standardowe; koszt nowego modelu → koszt docelowy.

## Na egzaminie
> [!question] Pytanie testowe
> Do decyzji o cenie jednorazowej oferty CGMA zaleca użyć… **kosztów relewantnych (przyszłych, różnicowych), a nie kosztu wytworzenia.**

## Jak to się łączy
Funkcje opisują cele [rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza). Zasada „informacja ma być istotna dla decyzji” to w praktyce posługiwanie się [kosztem relewantnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20relewantny). Funkcje realizuje kontroler – patrz [rola kontrolera](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rola%20kontrolera).
