---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Unikanie i uchylanie się od opodatkowania"]
część-z: ["Rola kontrolera"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Kodeks IMA", "Etyka zawodowa"]
---
> [!abstract] Definicja
> Etyka kontrolera to zasady i standardy zawodowe (kodeks IMA, CIMA, ACCA), które chronią wiarygodność informacji zarządczej – zwłaszcza gdy liczby „powinny” wyglądać inaczej.

## Wyjaśnienie
**Kodeks IMA:**
- zasady nadrzędne: uczciwość, rzetelność, obiektywizm, odpowiedzialność,
- standardy: kompetencje, poufność, integralność, wiarygodność.

Podobne zasady w kodeksach CIMA i ACCA (oparte na IESBA): uczciwość, obiektywizm, kompetencje i należyta staranność, poufność, profesjonalne postępowanie.

| Dylemat (Velomia) | Zagrożony standard |
|---|---|
| zawyżenie normy zużycia aluminium „na bufor” | integralność, wiarygodność |
| przesunięcie kosztów gwarancji przed wypłatą premii (wygładzanie wyniku) | uczciwość, obiektywizm |
| optymistyczna prognoza dla banku (kowenanty) | wiarygodność, uczciwość |

## Przykład
Kontroler nie „poprawia” prognozy pod oczekiwania zarządu – to zasada CGMA nr 4 (odpowiedzialne zarządzanie buduje zaufanie).

## Na egzaminie
> [!question] Pytanie otwarte
> Dyrektor zakładu prosi o zawyżenie normatywnego zużycia materiału. Które standardy są zagrożone i co powinien zrobić kontroler?

> [!success]- Odpowiedź (szkic)
> Zagrożone standardy: integralność i wiarygodność (kodeks IMA), a także uczciwość i obiektywizm.
> Kontroler powinien odmówić zawyżenia normy, udokumentować rzeczywiste dane, wyjaśnić skutki (zniekształcone odchylenia, błędne decyzje) i w razie nacisku przekazać sprawę wyżej zgodnie z procedurą – zachowując niezależność osądu.

## Jak to się łączy
Etyka jest warunkiem wiarygodności [roli kontrolera](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rola%20kontrolera). Podobna granica – między działaniem zgodnym z zasadami a ich naruszeniem – wyznacza różnicę między [unikaniem a uchylaniem się od opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania).
