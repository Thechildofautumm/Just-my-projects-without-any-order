---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Rachunek kosztów działań", "Cyfryzacja i ESG w rachunkowości zarządczej"]
część-z: ["Rachunkowość zarządcza"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Relevance Lost", "Etapy rozwoju RZ"]
---
> [!abstract] Definicja
> Rachunkowość zarządcza rozwijała się w czterech etapach (IFAC): od ustalania kosztów, przez informację do planowania i ograniczanie marnotrawstwa, do tworzenia wartości; jej kryzys opisała krytyka „Relevance Lost”.

## Wyjaśnienie
![[r01_ewolucja_RZ.png]]

| Etap (IFAC 1998) | Okres | Narzędzia |
|---|---|---|
| 1. ustalanie kosztów i kontrola finansowa | do ~1950 | kalkulacja, budżety, koszty standardowe |
| 2. informacja do planowania i kontroli | do ~1965 | rachunki decyzyjne, CVP, rachunek odpowiedzialności |
| 3. ograniczanie marnotrawstwa zasobów | do ~1985 | analiza procesów, TQM, JIT |
| 4. tworzenie wartości | do ~1995 | ABC/ABM, zrównoważona karta wyników, EVA |
| (5.) cyfryzacja, partner biznesowy | dziś | analityka, AI |

Etapy się **nakładają**, nie zastępują.

**„Relevance Lost” (Johnson, Kaplan 1987)** – krytyka: systemy kosztów podporządkowane sprawozdawczości finansowej; koszty pośrednie rozliczane kluczem roboczogodzin; informacja spóźniona i zbyt zagregowana; krótkookresowe miary finansowe.
**Odpowiedź:** ABC (Cooper, Kaplan), zrównoważona karta wyników (Kaplan, Norton 1992), koszt docelowy, kaizen, rachunek przepustowości (Goldratt).

## Przykład
Klucz roboczogodzin zaniża koszt roweru towarowego Cargo 8 produkowanego w małych partiach – dokładnie problem wskazany w „Relevance Lost”.

## Na egzaminie
> [!question] Pytanie otwarte
> Na czym polegała krytyka „Relevance Lost” i jakie narzędzia były na nią odpowiedzią?

> [!success]- Odpowiedź (szkic)
> „Relevance Lost” (Johnson, Kaplan 1987): systemy kosztów podporządkowane sprawozdawczości finansowej, rozliczanie kosztów pośrednich kluczem roboczogodzin, informacja spóźniona i zbyt zagregowana, krótkookresowe miary finansowe.
> Odpowiedź: rachunek kosztów działań (ABC), zrównoważona karta wyników, koszt docelowy, kaizen, rachunek przepustowości.

## Jak to się łączy
To historia [rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza). Najważniejszą odpowiedzią na „Relevance Lost” był [rachunek kosztów działań](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20dzia%C5%82a%C5%84). Współczesny, piąty etap opisuje [cyfryzacja i ESG](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cyfryzacja%20i%20ESG%20w%20rachunkowo%C5%9Bci%20zarz%C4%85dczej).
