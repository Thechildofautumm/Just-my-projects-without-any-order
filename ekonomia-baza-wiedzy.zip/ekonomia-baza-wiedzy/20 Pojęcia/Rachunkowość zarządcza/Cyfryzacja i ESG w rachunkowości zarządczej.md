---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Ewolucja rachunkowości zarządczej", "Rola kontrolera"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Kierunki rozwoju RZ", "ESG", "Rachunek kosztów środowiskowych"]
---
> [!abstract] Definicja
> Współczesne kierunki rozwoju rachunkowości zarządczej to cyfryzacja (ERP, BI, planowanie oparte na czynnikach, AI) i zrównoważony rozwój (koszty środowiskowe, dane ESG, cena CO₂).

## Wyjaśnienie
**Cyfryzacja:**
- jedno źródło danych (ERP, hurtownie danych) – mniej uzgadniania, więcej analizy,
- samoobsługowa analityka (BI) – kontroler projektuje modele i definicje miar,
- planowanie oparte na czynnikach, prognozy kroczące zamiast rocznego budżetu,
- automatyzacja i AI (zamknięcie miesiąca, wykrywanie anomalii, asystenci do analizy odchyleń).

> [!warning] Ryzyko
> Więcej danych nie oznacza lepszych decyzji – bez dobrze zdefiniowanych pojęć kosztowych dashboard „szybciej pokazuje błędne liczby”.

**Zrównoważony rozwój:**
- rachunek kosztów środowiskowych (energia, odpady, emisje przypisane do produktów),
- dane do sprawozdawczości ESRS (zakres obowiązku ograniczony w 2025 r. pakietem Omnibus),
- wewnętrzna cena CO₂ w rachunkach decyzyjnych, mierniki ESG w karcie wyników.

## Przykład
Velomia: koszt recyklingu akumulatorów przypisany do modelu roweru; ślad węglowy roweru w cyklu życia; wybór dostawcy ram z uwzględnieniem emisji.

## Na egzaminie
> [!question] Pytanie otwarte
> Jak cyfryzacja zmienia rolę kontrolera? Wskaż szansę i ryzyko.

> [!success]- Odpowiedź (szkic)
> Rola: mniej rejestrowania i uzgadniania (ERP, automatyzacja), więcej interpretacji i doradztwa – kontroler projektuje modele i definicje miar jako partner biznesowy.
> Szansa: szybsza, bardziej szczegółowa informacja (BI, prognozy kroczące, wykrywanie anomalii).
> Ryzyko: bez dobrze zdefiniowanych pojęć kosztowych dashboard „szybciej pokazuje błędne liczby”; zależność od jakości danych.

## Jak to się łączy
To współczesny, piąty etap [ewolucji rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ewolucja%20rachunkowo%C5%9Bci%20zarz%C4%85dczej). Wymaga od kontrolera nowych kompetencji – patrz [rola kontrolera](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rola%20kontrolera).
