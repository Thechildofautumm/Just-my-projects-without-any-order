---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Rachunkowość zarządcza a finansowa", "Funkcja rachunkowości zarządczej", "Klasyfikacja kosztów"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["RZ", "Management accounting"]
---
> [!abstract] Definicja
> Rachunkowość zarządcza to pozyskiwanie, analiza, komunikowanie i wykorzystanie istotnych dla decyzji informacji finansowych i niefinansowych w celu tworzenia i ochrony wartości organizacji (CIMA/AICPA, 2014).

## Wyjaśnienie
| Organizacja | Definicja | Słowa kluczowe |
|---|---|---|
| CIMA i AICPA (2014) | pozyskiwanie, analiza, komunikowanie i wykorzystanie informacji istotnych dla decyzji, by tworzyć i chronić wartość | wartość, decyzje, informacje niefinansowe |
| IMA (2008) | partnerski udział w decyzjach, projektowanie systemów planowania i zarządzania wynikami, wiedza o sprawozdawczości i kontroli – by realizować strategię | partnerstwo, systemy, strategia |

**Tradycja polska:** rachunkowość zarządcza = rachunek kosztów + rachunki decyzyjne + budżetowanie i kontrola; silny związek z **kontrolingiem** (kontroling – koncepcja zarządzania, RZ – jego system informacyjny).

Zmiana akcentu: od „dostarczania informacji” do „tworzenia i ochrony wartości”, od funkcji usługowej do partnerskiej.

## Przykład
Velomia S.A. (fikcyjny producent rowerów elektrycznych, przykład własny): zarząd pyta, ile firma zarabia na rowerze Urban 5 (cena 9 600 zł). Księgowość: 2 200 zł (marża brutto wg kosztu wytworzenia), kontroling: 3 800 zł (marża wkładu), zespół ABC: 700 zł. Każda odpowiedź jest poprawna – na inne pytanie. **RZ zaczyna się od pytania „do jakiej decyzji potrzebna jest informacja?”**

## Na egzaminie
> [!question] Pytanie otwarte
> Porównaj definicje rachunkowości zarządczej CIMA/AICPA i IMA. Co je łączy, a co różni?

> [!success]- Odpowiedź (szkic)
> Łączy je cel: informacja wspierająca decyzje i tworzenie wartości. CIMA/AICPA kładą nacisk na wartość, decyzje i informacje niefinansowe; IMA – na partnerski udział w decyzjach, projektowanie systemów planowania i realizację strategii.

## Jak to się łączy
Granice dziedziny najlepiej widać w porównaniu – patrz [rachunkowość zarządcza a finansowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza%20a%20finansowa). Do czego RZ służy, opisuje [funkcja rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20rachunkowo%C5%9Bci%20zarz%C4%85dczej). Fundamentem wszystkich funkcji jest pomiar kosztów i ich właściwa [klasyfikacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Klasyfikacja%20koszt%C3%B3w).
