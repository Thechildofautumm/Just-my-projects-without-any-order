---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Etyka kontrolera", "Funkcja rachunkowości zarządczej"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Kontroler", "Kontroling", "Partner biznesowy"]
---
> [!abstract] Definicja
> Kontroler łączy trzy role informacji księgowej – rejestrowanie, kierowanie uwagi i rozwiązywanie problemów (Simon i in. 1954) – a współcześnie działa jako partner biznesowy kierownictwa.

## Wyjaśnienie
| Rola (Simon) | Pytanie | Narzędzia |
|---|---|---|
| rejestrowanie (score-keeping) | czy wyniki są dobre czy złe? | ewidencja, kalkulacja, raporty |
| kierowanie uwagi (attention-directing) | na co zwrócić uwagę? | analiza odchyleń, wskaźniki, sygnały ostrzegawcze |
| rozwiązywanie problemów (problem-solving) | który wariant jest najlepszy? | rachunki decyzyjne, scenariusze, modele |

**Partner biznesowy** współtworzy decyzje: zna procesy, kwestionuje założenia, przekłada strategię na liczby. Automatyzacja przejmuje rejestrowanie – wartość kontrolera leży w interpretacji i doradztwie, przy zachowaniu **niezależności osądu**.

**Organizacja:** kontroler zakładu często raportuje podwójnie – do dyrektora zakładu i do CFO; to napięcie między rolą partnera a „strażnika”.

**Kompetencje:** warsztat (rachunek kosztów, budżetowanie, modelowanie), narzędzia (Excel, BI, SQL, ERP, agenci AI), biznes (procesy, strategia), kompetencje miękkie; kwalifikacje CIMA (CGMA), ACCA, IMA (CMA).

## Przykład
Typowe pytanie: rola „kierowania uwagi” polega głównie na **wskazywaniu odchyleń i obszarów wymagających reakcji**.

## Na egzaminie
> [!question] Pytanie testowe
> Wybór najlepszego wariantu decyzji to rola… **rozwiązywania problemów (problem-solving).**

## Jak to się łączy
Niezależność osądu kontrolera chroni [etyka zawodowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Etyka%20kontrolera). Role kontrolera są sposobem realizacji [funkcji rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20rachunkowo%C5%9Bci%20zarz%C4%85dczej).
