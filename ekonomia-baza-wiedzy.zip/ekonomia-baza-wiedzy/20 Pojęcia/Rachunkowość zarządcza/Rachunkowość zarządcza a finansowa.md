---
typ: pojęcie
up: "[[MOC Rachunkowość zarządcza]]"
powiązane: ["Koszt księgowy a koszt ekonomiczny", "Rachunek kosztów zmiennych i pełnych"]
część-z: ["Rachunkowość zarządcza"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Rachunkowość finansowa"]
---
> [!abstract] Definicja
> Rachunkowość zarządcza dostarcza informacji dla menedżerów wewnątrz firmy, bez obowiązków regulacyjnych i z orientacją na przyszłość; rachunkowość finansowa – dla odbiorców zewnętrznych, zgodnie z przepisami i z orientacją na przeszłość.

## Wyjaśnienie
| Kryterium | Rachunkowość zarządcza | Rachunkowość finansowa |
|---|---|---|
| adresat | zarząd i menedżerowie | inwestorzy, kredytodawcy, fiskus, regulatorzy |
| regulacje | brak obowiązku – forma wynika z potrzeb | ustawa o rachunkowości, MSSF, przepisy podatkowe |
| orientacja w czasie | **przyszłość**: plany, prognozy, scenariusze | **przeszłość**: zdarzenia zaistniałe |
| obiekt | produkty, klienci, kanały, działania, projekty | jednostka jako całość |
| miary | pieniężne i niepieniężne, koszty alternatywne i relewantne | pieniężne, zgodne z zasadami wyceny |
| kryterium jakości | użyteczność dla decyzji, terminowość | wiarygodność, porównywalność, zgodność z przepisami |
| częstotliwość | ciągła, na żądanie | okresowa (miesiąc, kwartał, rok) |

Wspólna baza danych (ERP, księga główna), ale różne cele i ujęcia – te same koszty bywają ujmowane inaczej.

## Przykład
Do bilansu zapasy wycenia się w koszcie wytworzenia (z kosztami stałymi produkcji – RKP), a do decyzji o przyjęciu zamówienia liczy się tylko koszty zmienne i różnicowe.

## Na egzaminie
> [!question] Pytanie testowe
> Która cecha dotyczy rachunkowości zarządczej? a) obowiązek ustawowy b) orientacja na przyszłość c) adresat zewnętrzny d) okresowość roczna. **b**

## Zadania
Pojęcie przydaje się też w: [Velomia – trzy marże roweru Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20trzy%20mar%C5%BCe%20roweru%20Urban%205).

## Jak to się łączy
To porównanie wyznacza granice [rachunkowości zarządczej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza). Rachunkowość finansowa mierzy koszty jawne, a zarządcza także alternatywne i relewantne – to ta sama różnica co w [koszcie księgowym a ekonomicznym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20ksi%C4%99gowy%20a%20koszt%20ekonomiczny). Przykładem różnych ujęć tych samych kosztów jest [rachunek kosztów zmiennych i pełnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20zmiennych%20i%20pe%C5%82nych).
