---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Koszt przeciętny", "Prawo malejących przychodów", "Maksymalizacja zysku", "Krzywa podaży przedsiębiorstwa"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MC", "Koszt krańcowy"]
---
> [!abstract] Definicja
> Koszt marginalny (MC) to przyrost kosztu całkowitego wywołany wytworzeniem dodatkowej jednostki produktu: MC = ΔTC/ΔQ = TC′.

## Wyjaśnienie
$$MC = \frac{\Delta TC}{\Delta Q} = \frac{\Delta VC}{\Delta Q} = TC'$$

**Relacje MC – koszty przeciętne:**
1. MC przecina AVC i ATC w ich **minimach**,
2. MC < AVC (ATC) ⇒ AVC (ATC) maleją; MC > AVC (ATC) ⇒ rosną,
3. MC i AFC **nie są powiązane** (koszty stałe nie wpływają na MC),
4. AVC osiąga minimum wcześniej niż ATC.

![[20_koszty_przecietne_i_MC.png]]

## Przykład
$TC = Q^3 - 24Q^2 + 192Q + 1000$ → $MC = 3Q^2 - 48Q + 192$; MCmin przy Q = 8; MC(12) = 48 = AVCmin ✔.

## Na egzaminie
> [!question] Pytanie testowe
> MC jest niższy od ATC. Co dzieje się z ATC przy wzroście produkcji? **Maleje.**

## Zadania
Pojęcie przydaje się też w: [Funkcje kosztów przeciętnych i krańcowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcje%20koszt%C3%B3w%20przeci%C4%99tnych%20i%20kra%C5%84cowego), [Pani Grażyna – czy zmniejszyć produkcję](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pani%20Gra%C5%BCyna%20%E2%80%93%20czy%20zmniejszy%C4%87%20produkcj%C4%99).

## Jak to się łączy
MC przecina minima [kosztów przeciętnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny). Rosnący MC wynika z [prawa malejących przychodów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Prawo%20malej%C4%85cych%20przychod%C3%B3w) (MC = w/MP). MC jest prawą stroną warunku [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC. W konkurencji doskonałej odcinek MC powyżej AVCmin to [krzywa podaży przedsiębiorstwa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20poda%C5%BCy%20przedsi%C4%99biorstwa).
