---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Koszt marginalny", "Próg rentowności"]
wymaga: ["Koszt stały i zmienny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["ATC", "AVC", "AFC", "Koszt jednostkowy"]
---
> [!abstract] Definicja
> Koszt przeciętny to koszt przypadający na jednostkę produkcji: stały AFC = FC/Q, zmienny AVC = VC/Q i całkowity ATC = TC/Q = AFC + AVC.

## Wyjaśnienie
| Koszt | Wzór | Przebieg |
|---|---|---|
| AFC | FC/Q | stale maleje (hiperbola) |
| AVC | VC/Q | kształt U |
| ATC | TC/Q = AFC + AVC | kształt U, minimum później niż AVC |

![[20_koszty_przecietne_i_MC.png]]

Minima: $AVC_{min}$: $AVC' = 0$ lub MC = AVC; $ATC_{min}$: $ATC' = 0$ lub MC = ATC.

## Przykład
Przykład: $AVC = Q^2 - 18Q + 120$ → $AVC' = 2Q - 18 = 0$ → Q = 9, **AVCmin = 39**.
Przykład: $TC = 4Q^2 + FC$, ATCmin przy Q = 6 → $ATC = 4Q + FC/Q$, $4 - FC/36 = 0$ → **FC = 144**.

## Na egzaminie
> [!question] Pytanie testowe
> Pionowa odległość między ATC a AVC to… **AFC – maleje wraz z Q.**

## Zadania
Zadania do tego pojęcia: [[Funkcje kosztów przeciętnych i krańcowego]], [[Koszty stałe z położenia minimum ATC]] i [[Pani Grażyna – czy zmniejszyć produkcję]].

Pojęcie przydaje się też w: [Od funkcji produkcji do funkcji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Od%20funkcji%20produkcji%20do%20funkcji%20koszt%C3%B3w), [Odtwarzanie tabeli kosztów trzech firm](obsidian://open?vault=ekonomia-baza-wiedzy&file=Odtwarzanie%20tabeli%20koszt%C3%B3w%20trzech%20firm).

## Jak to się łączy
Koszty przeciętne powstają z [kosztów stałych i zmiennych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny) podzielonych przez Q. Ich minima przecina krzywa [kosztu marginalnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny). Minimum ATC wyznacza [próg rentowności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci) w konkurencji doskonałej.
