---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
wymaga: ["Produkt przeciętny i marginalny", "Koszt przeciętny", "Koszt marginalny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Dualność produkcji i kosztów", "AVC = w/AP"]
---
> [!abstract] Definicja
> Koszty są lustrzanym odbiciem produktywności: przy stałej płacy w przeciętny koszt zmienny AVC = w/AP_L, a koszt marginalny MC = w/MP_L.

## Wyjaśnienie
$$AVC = w\cdot\frac{1}{AP_L}, \qquad MC = w\cdot\frac{1}{MP_L}$$
- APmax ↔ AVCmin; MPmax ↔ MCmin,
- malejący MP (prawo malejących przychodów) ↔ rosnący MC.

![[m13_lustro_produkcja_koszty.png]]

**Od funkcji produkcji do funkcji kosztów:** $TC = wL + rK$, wyraź L przez Q z funkcji produkcji.

## Przykład
Przykład: $Q = -2L^3 + 60L^2 + 1800L$, w = 4000 → MPmax przy L = 10: MP = 2400 → **MCmin = 4000/2400 ≈ 1,67**.
Przykład: $Q = 2\sqrt{5L}$, w = 10, r = 40, K = 5 → $L = Q^2/20$ → $TC = Q^2/2 + 200$.

![[m14_koszty_z_funkcji_produkcji.png]]

## Na egzaminie
> [!question] Pytanie testowe
> Przy jakim L koszt marginalny jest najniższy? **Przy L, dla którego produkt marginalny jest maksymalny.**

## Zadania
Zadania do tego pojęcia: [[Najniższy koszt krańcowy z funkcji produkcji]] i [[Od funkcji produkcji do funkcji kosztów]].

## Jak to się łączy
Notatka łączy [produkt przeciętny i marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny) z [kosztem przeciętnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny) i [kosztem marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny) – to most między teorią produkcji a teorią kosztów.
