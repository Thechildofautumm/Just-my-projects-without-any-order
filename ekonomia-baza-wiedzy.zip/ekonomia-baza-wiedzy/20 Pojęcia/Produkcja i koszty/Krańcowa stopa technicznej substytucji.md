---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Krańcowa stopa substytucji"]
wymaga: ["Produkt przeciętny i marginalny"]
część-z: ["Izokwanta"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MRTS", "Marginalna stopa technicznej substytucji"]
---
> [!abstract] Definicja
> Krańcowa stopa technicznej substytucji (MRTS) to ilość kapitału, którą można zastąpić jednostką pracy tak, by produkcja się nie zmieniła.

## Wyjaśnienie
$$\boxed{MRTS = -\frac{\Delta K}{\Delta L} = \frac{MP_L}{MP_K}}$$
- MRTS = (bezwzględne) nachylenie izokwanty,
- **malejąca MRTS**: im więcej pracy już używamy, tym mniej kapitału zastąpi każda kolejna jednostka pracy.

Dla $Q = LK$: $MP_L = K$, $MP_K = L$ → $MRTS = K/L$.

## Przykład
Przykład: L·K = 600, L = 30 → K = 20 → **MRTS = 20/30 ≈ 0,67**.

## Na egzaminie
> [!question] Pytanie testowe
> MRTS = 2 oznacza, że… **jedna dodatkowa jednostka pracy zastępuje 2 jednostki kapitału przy tej samej produkcji.**

## Zadania
Zadania do tego pojęcia: [[Krańcowa stopa substytucji technicznej na izokwancie]].

## Jak to się łączy
MRTS jest nachyleniem [izokwanty](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokwanta) i liczymy ją z [produktów marginalnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny) obu czynników. To dokładny odpowiednik [krańcowej stopy substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20substytucji) konsumenta (MRS = MUx/MUy).
