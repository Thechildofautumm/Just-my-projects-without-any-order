---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Prawo malejących przychodów"]
wymaga: ["Produkt przeciętny i marginalny"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Etap II produkcji", "Racjonalny obszar produkcji"]
---
> [!abstract] Definicja
> Etapy produkcji to trzy przedziały nakładu czynnika zmiennego wyznaczone przez przebieg AP i MP; racjonalny producent działa tylko w II etapie.

## Wyjaśnienie
| Etap | Zakres L | Co się dzieje | Ocena |
|---|---|---|---|
| **I** | 0 → APmax | AP rośnie, MP > AP | nieracjonalny – opłaca się zwiększać L |
| **II** | APmax → MP = 0 | AP i MP maleją, MP > 0 | **racjonalny** |
| **III** | MP < 0 | TP spada | nieracjonalny |

> [!tip] Algorytm
> Lewa granica: $AP' = 0$ (lub MP = AP). Prawa granica: MP = 0 (dodatni pierwiastek).

## Przykład
Przykład: $Q = -2L^3 + 60L^2 + 1800L$ → $AP' = -4L + 60 = 0$ → L = 15; $MP = -6L^2 + 120L + 1800 = 0$ → L = 30 → **II etap: 15 ≤ L ≤ 30**.
Przykład (namioty): II etap L ∈ (45; 83,9).

## Na egzaminie
> [!question] Pytanie otwarte
> „Racjonalny producent może zatrudniać do momentu, w którym MP staje się ujemny, albo zatrzymać się tam, gdzie AP jeszcze rośnie.” Oceń. *Odp.: fałsz – oba obszary (III i I etap) są nieracjonalne.*

## Zadania
Zadania do tego pojęcia: [[Granice I i III etapu produkcji]], [[Gdzie działa racjonalny producent]], [[Granice II etapu produkcji]] i [[Wytwórnia przetworów – II etap i powtórna wartość MP]].

Pojęcie przydaje się też w: [Maksymalna produkcja przy jednym czynniku zmiennym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalna%20produkcja%20przy%20jednym%20czynniku%20zmiennym), [Producent namiotów – zatrudnienie, zysk i etapy produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producent%20namiot%C3%B3w%20%E2%80%93%20zatrudnienie%2C%20zysk%20i%20etapy%20produkcji).

## Jak to się łączy
Granice etapów wyznaczają wielkości opisane w [produkcie przeciętnym i marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny) (APmax, MP = 0). Spadek MP w II etapie to działanie [prawa malejących przychodów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Prawo%20malej%C4%85cych%20przychod%C3%B3w).
