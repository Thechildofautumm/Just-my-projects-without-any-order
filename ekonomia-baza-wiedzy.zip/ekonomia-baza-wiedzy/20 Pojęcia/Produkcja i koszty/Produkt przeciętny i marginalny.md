---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Prawo malejących przychodów", "Koszty a produktywność"]
część-z: ["Funkcja produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["AP", "MP", "TP", "Produkt całkowity", "Produkt krańcowy"]
---
> [!abstract] Definicja
> Produkt przeciętny pracy (AP) to produkcja na jednego pracownika, a produkt marginalny (MP) – przyrost produkcji z dodatkowej jednostki pracy.

## Wyjaśnienie
| Pojęcie | Wzór | Opis |
|---|---|---|
| produkt całkowity TP | $Q(L)$ | produkcja przy danym zatrudnieniu |
| produkt przeciętny | $AP_L = Q/L$ | podziel przez L |
| produkt marginalny | $MP_L = \Delta Q/\Delta L = Q'(L)$ | pochodna |

![[16_funkcja_produkcji_TP_AP_MP.png]]

**Relacje (jak ocena i średnia):**
- MP > AP ⇒ AP rośnie; MP < AP ⇒ AP spada; **MP = AP ⇔ APmax**,
- MPmax = punkt przegięcia TP; **MP = 0 ⇔ TPmax**.

## Przykład
$Q = -4L^3 + 240L^2 + 2700L$ → $AP = -4L^2 + 240L + 2700$, $MP = -12L^2 + 480L + 2700$.
Przykład (firma Kowal): $Q = -2L^2 + 128L - 32$ (K = 16) → $MP = -4L + 128$, $AP = -2L + 128 - 32/L$; APmax przy $L = 4$ (AP = MP = 112).

## Na egzaminie
> [!question] Pytanie testowe
> Gdy produkt przeciętny rośnie, to produkt marginalny jest… **większy od przeciętnego.**

## Zadania
Zadania do tego pojęcia: [[Produkt przeciętny i krańcowy z funkcji produkcji]], [[Firma Kowal – maksimum produktu przeciętnego]] i [[Maksymalna produkcja przy jednym czynniku zmiennym]].

Pojęcie przydaje się też w: [Wytwórnia przetworów – II etap i powtórna wartość MP](obsidian://open?vault=ekonomia-baza-wiedzy&file=Wytw%C3%B3rnia%20przetwor%C3%B3w%20%E2%80%93%20II%20etap%20i%20powt%C3%B3rna%20warto%C5%9B%C4%87%20MP).

## Jak to się łączy
AP i MP to wielkości wyprowadzone z [funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji). Spadek MP od pewnego poziomu nakładu to [prawo malejących przychodów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Prawo%20malej%C4%85cych%20przychod%C3%B3w). AP i MP mają lustrzane odbicie w kosztach: AVC = w/AP, MC = w/MP – patrz [koszty a produktywność](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszty%20a%20produktywno%C5%9B%C4%87).
