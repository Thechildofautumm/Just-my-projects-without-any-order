---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Prawo malejących przychodów", "Koszt przeciętny"]
część-z: ["Funkcja produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: ["Korzyści skali", "Rosnące efekty skali", "Malejące efekty skali"]
---
> [!warning] Do weryfikacji
> Część treści pochodzi spoza materiałów z zajęć (podręcznik lub opracowanie własne) – sprawdź z prowadzącym.

> [!abstract] Definicja
> Efekty skali opisują, jak zmienia się produkcja, gdy wszystkie nakłady rosną proporcjonalnie (a-krotnie) w długim okresie.

## Wyjaśnienie
| Efekty skali | Warunek (a > 1) | Cobb–Douglas $AL^{\alpha}K^{\beta}$ |
|---|---|---|
| rosnące | $Q(aL, aK) > a\,Q$ | $\alpha + \beta > 1$ |
| stałe | $Q(aL, aK) = a\,Q$ | $\alpha + \beta = 1$ |
| malejące | $Q(aL, aK) < a\,Q$ | $\alpha + \beta < 1$ |

![[18_efekty_skali.png]]

W długim okresie efekty skali kształtują długookresowy koszt przeciętny: rosnące → LATC maleje, malejące → LATC rośnie *(ten wniosek – uzupełnienie podręcznikowe)*.

## Przykład
Przykład: $Q = \sqrt[3]{L} + \sqrt[3]{K}$ → $Q(aL, aK) = a^{1/3}Q < aQ$ → **malejące** efekty skali.

## Na egzaminie
> [!question] Pytanie testowe
> $Q = 2L^{0{,}5}K^{0{,}5}$. Jakie efekty skali? **Stałe (0,5 + 0,5 = 1).**

> [!warning] Pułapka
> Efekty skali ≠ prawo malejących przychodów (jeden czynnik zmienny) ≠ krzywa uczenia się (doświadczenie, nie skala).

## Zadania
Zadania do tego pojęcia: [[Efekty skali dwóch funkcji produkcji]].

## Jak to się łączy
Efekty skali to cecha [funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji) w długim okresie. Trzeba je odróżniać od [prawa malejących przychodów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Prawo%20malej%C4%85cych%20przychod%C3%B3w), które dotyczy jednego czynnika w krótkim okresie. W długim okresie efekty skali przekładają się na przebieg [kosztu przeciętnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny).
