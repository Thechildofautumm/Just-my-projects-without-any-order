---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Produkt przeciętny i marginalny", "Izokwanta"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Q = f(L,K)", "Technologia produkcji", "Krótki okres", "Długi okres"]
---
> [!abstract] Definicja
> Funkcja produkcji opisuje zależność między nakładami czynników produkcji a maksymalną wielkością produkcji przy danej technologii: Q = f(L, K).

## Wyjaśnienie
**Produkcja** – proces przekształcania czynników w wyroby gotowe: `NAKŁADY → PRZEDSIĘBIORSTWO → WYNIKI`.

$$Q = f(F_1, F_2, \dots, F_n), \qquad Q = f(L), \qquad Q = f(L, K)$$

| Okres | Czynniki | Narzędzia analizy |
|---|---|---|
| **krótki** | co najmniej jeden stały (zwykle K) | TP, AP, MP, etapy produkcji, optymalne zatrudnienie |
| **długi** | wszystkie zmienne | izokwanty, izokoszty, efekty skali |

Typowe postaci w zadaniach:
- sześcienna (krótki okres): $Q = -4L^3 + 240L^2 + 2700L$,
- Cobba–Douglasa: $Q = A\,L^{\alpha}K^{\beta}$ (np. $Q = 2L^{0{,}5}K^{0{,}5}$, $Q = 80L^{0{,}4}K^{0{,}6}$),
- liniowa: $Q = 2L + 3K$ (czynniki doskonale substytucyjne).

Cel firmy: $\pi = TR - TC = P\cdot Q - ATC\cdot Q$ – technologia wyznacza Q, a ceny czynników – koszty.

## Przykład
$Q = 2\sqrt{LK}$ przy K = 10: $Q = 2\sqrt{10L}$ – funkcja krótkookresowa, w której zmienia się już tylko L.

## Na egzaminie
> [!question] Pytanie testowe
> Czym różni się krótki okres od długiego w teorii produkcji? **W krótkim co najmniej jeden czynnik jest stały, w długim wszystkie są zmienne.**

## Zadania
Pojęcie przydaje się też w: [Produkt przeciętny i krańcowy z funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20kra%C5%84cowy%20z%20funkcji%20produkcji), [Maksymalna produkcja przy jednym czynniku zmiennym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalna%20produkcja%20przy%20jednym%20czynniku%20zmiennym).

## Jak to się łączy
Z funkcji produkcji wyprowadzamy wielkości przeciętne i marginalne – patrz [produkt przeciętny i marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny). Przekrój funkcji dwuczynnikowej na stałym poziomie Q to [izokwanta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokwanta).
