---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Koszt marginalny", "Etapy produkcji"]
wymaga: ["Produkt przeciętny i marginalny"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Prawo malejącego produktu marginalnego", "Prawo malejących przychodów krańcowych"]
---
> [!abstract] Definicja
> Prawo malejących przychodów mówi, że gdy zwiększamy nakład jednego czynnika przy stałych pozostałych, to od pewnego momentu przyrosty produkcji (MP) maleją.

## Wyjaśnienie
- dotyczy **krótkiego okresu** (jeden czynnik zmienny),
- na wykresie TP – **punkt przegięcia**: TP rośnie coraz wolniej,
- w zadaniu: prawo zaczyna działać tam, gdzie **MP osiąga maksimum** ($MP' = 0$); jeśli MP maleje od początku – działa od początku.

![[m09_prawo_malejacych_przychodow_slupki.png]]

## Przykład
Przykład: $Q = -2L^3 + 120L^2 + 1500L$ → $MP = -6L^2 + 240L + 1500$, $MP' = -12L + 240 = 0$ → **L = 20**.
Przykład: $Q = 2\sqrt{KL}$, K = 9 → $MP_L = \frac{3}{\sqrt L}$: L = 1 → 3; L = 4 → 1,5; L = 9 → 1 – prawo działa od początku.

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij sens prawa malejących przychodów i pokaż, jak odzwierciedla się w przebiegu krzywej produktu całkowitego.

> [!warning] Pułapka
> Nie myl z malejącymi **efektami skali** – te dotyczą proporcjonalnego wzrostu **wszystkich** czynników w długim okresie.

## Zadania
Zadania do tego pojęcia: [[Od którego pracownika działa prawo malejących przychodów]] i [[Prawo malejących przychodów dla Q = 2√(KL)]].

Pojęcie przydaje się też w: [Kawiarnia – optymalne zatrudnienie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kawiarnia%20%E2%80%93%20optymalne%20zatrudnienie).

## Jak to się łączy
Prawo opisuje przebieg [produktu marginalnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny). Ponieważ MC = w/MP, malejący MP oznacza rosnący [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny) – stąd rosnąca krzywa podaży. Prawo wyznacza też granice [etapów produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Etapy%20produkcji).
