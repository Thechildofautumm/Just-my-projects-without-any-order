---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Krzywa obojętności", "Krańcowa stopa technicznej substytucji"]
część-z: ["Funkcja produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Krzywa jednakowego produktu"]
---
> [!abstract] Definicja
> Izokwanta to zbiór wszystkich efektywnych kombinacji pracy i kapitału, które dają taką samą wielkość produkcji.

## Wyjaśnienie
Cechy (jak krzywe obojętności): ujemne nachylenie, nie przecinają się, wypukłe, wyżej = większa produkcja.

Warunek pozostania na izokwancie: $\Delta L\cdot MP_L = -\Delta K\cdot MP_K$.

![[m10_MRTS_schodki.png]]

Postaci: $L\cdot K = 400$ → $K = 400/L$; dla $Q = L^{1/2}C^{1/2} = 200$ → $C = 40\,000/L$.

## Przykład
Q = L·K = 400: kombinacje (10; 40), (20; 20), (40; 10) dają tę samą produkcję.

## Na egzaminie
> [!question] Pytanie testowe
> Dlaczego izokwanta ma ujemne nachylenie? **Bo zmniejszenie jednego czynnika trzeba zrekompensować zwiększeniem drugiego, by produkcja się nie zmieniła.**

## Zadania
Pojęcie przydaje się też w: [Krańcowa stopa substytucji technicznej na izokwancie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20substytucji%20technicznej%20na%20izokwancie).

## Jak to się łączy
Izokwanta to przekrój dwuczynnikowej [funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20produkcji) na stałym poziomie Q. Jest odpowiednikiem [krzywej obojętności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20oboj%C4%99tno%C5%9Bci) u konsumenta. Nachylenie izokwanty to [krańcowa stopa technicznej substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20technicznej%20substytucji).
