---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Optimum konsumenta", "Krańcowy przychód z pracy"]
wymaga: ["Izokwanta", "Izokoszta", "Krańcowa stopa technicznej substytucji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Zasada najmniejszego kosztu", "Równowaga producenta"]
---
> [!abstract] Definicja
> Optimum producenta to kombinacja czynników, która przy danym koszcie daje maksymalną produkcję albo daną produkcję wytwarza najtaniej – punkt styczności izokwanty z izokosztą.

## Wyjaśnienie
$$\boxed{MRTS = \frac{MP_L}{MP_K} = \frac{w}{r} \quad\Longleftrightarrow\quad \frac{MP_L}{w} = \frac{MP_K}{r}}$$
**Zasada najmniejszego kosztu:** ostatnia złotówka wydana na każdy czynnik daje ten sam przyrost produkcji.

![[17_izokwanty_izokoszt_optimum.png]]

| Problem | Procedura |
|---|---|
| max Q przy danym TC | relacja K(L) z warunku → podstaw do $TC = wL + rK$ → L, K → Q |
| min TC przy danym Q | relacja K(L) → podstaw do funkcji produkcji = Q → L, K → TC |

![[m12_optimum_producenta_min_koszt.png]]

## Przykład
Przykład (pracownia ceramiki): $Q = 4L^{0{,}5}K^{0{,}5}$, w = 8, r = 2, TC = 480 → K/L = 4 → L = 30, K = 120, **Q = 240**.
Przykład: $Q = 50\sqrt{LK} = 2000$, w = 30, r = 120 → L = 4K → **L = 80, K = 20**, TC = 4800.

## Na egzaminie
> [!question] Pytanie otwarte
> MPL/w > MPK/r. Jak zmienić kombinację czynników? *Odp.: zastępować kapitał pracą, aż ilorazy się zrównają.*

## Zadania
Zadania do tego pojęcia: [[Pracownia ceramiki – maksymalna produkcja przy danym budżecie]], [[Piekarnia – minimalny koszt produkcji]], [[Najtańsza technika dla funkcji Cobba-Douglasa]] i [[Najtańsza kombinacja nakładów dla Q = 50√(LK)]].

Pojęcie przydaje się też w: [Praca i kapitał przy liniowej funkcji produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Praca%20i%20kapita%C5%82%20przy%20liniowej%20funkcji%20produkcji).

## Jak to się łączy
Optimum łączy możliwości techniczne, czyli [izokwantę](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokwanta), z ograniczeniem kosztowym, czyli [izokosztą](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokoszta); warunkiem styczności jest równość [MRTS](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20technicznej%20substytucji) i relacji cen czynników. Logika jest identyczna jak w [optimum konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta). Przy cenie produktu P warunek przybiera postać $P\cdot MP_L = w$ i $P\cdot MP_K = r$ – to [krańcowy przychód z pracy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowy%20przych%C3%B3d%20z%20pracy) zastosowany do obu czynników.
