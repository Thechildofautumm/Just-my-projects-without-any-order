---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Koszt alternatywny", "Zysk ekonomiczny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska", "Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszt księgowy", "Koszt ekonomiczny", "Koszty explicite", "Koszty implicite", "Koszt rachunkowy"]
---
> [!abstract] Definicja
> Koszt księgowy obejmuje tylko faktycznie poniesione wydatki (jawne), a koszt ekonomiczny – wartość wszystkich zasobów użytych w produkcji: koszty jawne plus niejawne (alternatywne).

## Wyjaśnienie
$$\text{koszt ekonomiczny} = \underbrace{\text{koszty jawne (explicite)}}_{\text{= koszt księgowy}} + \underbrace{\text{koszty niejawne (implicite)}}_{\text{utracone dochody z własnych zasobów}}$$

| | Koszt księgowy | Koszt ekonomiczny |
|---|---|---|
| charakter | historyczny, jawny | jawny + alternatywny |
| obejmuje | wydatki na zasoby wynajęte na rynku | także utracone dochody z zasobów własnych |
| wynik | zysk księgowy | zysk ekonomiczny |

Inne podziały kosztów z wykładu: **prywatne i społeczne**, **alternatywne**.

![[e09_zysk_ksiegowy_ekonomiczny.png]]

## Przykład
Pracownia Tomasza: koszt księgowy 90 000 zł; koszty niejawne 75 400 zł (czynsz 24 000, odsetki 6 400, pensja 45 000) → koszt ekonomiczny **165 400 zł**.

## Na egzaminie
> [!question] Pytanie testowe
> Który koszt zawsze jest większy lub równy drugiemu? **Ekonomiczny ≥ księgowy.**

> [!warning] Pułapka
> W rachunkowości finansowej nie ujmuje się kosztów alternatywnych; w rachunkowości zarządczej – tak, gdy są istotne dla decyzji.

## Zadania
Zadania do tego pojęcia: [[Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny]].

## Jak to się łączy
Różnicę między oboma kosztami stanowi [koszt alternatywny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny) zasobów właściciela. Od wyboru ujęcia kosztów zależy, jaki [zysk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny) liczymy – księgowy czy ekonomiczny.
