---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Próg rentowności", "Maksymalizacja zysku", "Koszt relewantny"]
wymaga: ["Przychód", "Koszt księgowy a koszt ekonomiczny"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Zysk", "Zysk normalny", "Zysk księgowy", "π", "Zysk nadzwyczajny"]
---
> [!abstract] Definicja
> Zysk ekonomiczny to różnica między przychodem całkowitym a kosztami ekonomicznymi (jawnymi i niejawnymi): π = TR − TC.

## Wyjaśnienie
| Pojęcie | Wzór | Znaczenie |
|---|---|---|
| zysk księgowy | TR − koszty jawne | wynik w księgach |
| zysk ekonomiczny | TR − koszty jawne − niejawne | czy wybrana opcja jest najlepsza |
| **zysk nadzwyczajny** | zysk ekonomiczny > 0 | opcja lepsza od najlepszej alternatywy – bodziec do działania |
| **zysk normalny** | zysk ekonomiczny = 0 | opłacalność równa najlepszej alternatywie – minimum potrzebne, by zostać w branży |

$$\pi = TR - TC = (P - ATC)\cdot Q$$

W ocenie opłacalności przedsięwzięcia: uwzględniamy tylko koszty **istotne (przyrostowe)**, pomijamy koszty stałe niezależne od wyboru i koszty **utopione**.

## Przykład
Przykład (food truck): przychody 150 000, koszty jawne 111 000 → zysk księgowy 39 000; koszty niejawne = pensja 36 000 + odsetki od 60 000. Zysk ekonomiczny = 0 przy odsetkach 3 000 → stopa 5%. Działalność opłaca się przy **r < 5%**.

## Na egzaminie
> [!question] Pytanie testowe
> Firma ma zysk ekonomiczny równy zero. Czy powinna zamknąć działalność? **Nie – osiąga zysk normalny, tyle co w najlepszej alternatywie.**

## Zadania
Zadania do tego pojęcia: [[Food truck – przy jakiej stopie procentowej się opłaca]].

Pojęcie przydaje się też w: [Pracownia rowerowa Tomasza – zysk księgowy a ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pracownia%20rowerowa%20Tomasza%20%E2%80%93%20zysk%20ksi%C4%99gowy%20a%20ekonomiczny).

## Jak to się łączy
Zysk wymaga znajomości [przychodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d) i właściwego ujęcia kosztów – patrz [koszt księgowy a koszt ekonomiczny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20ksi%C4%99gowy%20a%20koszt%20ekonomiczny). Zysk ekonomiczny równy zero to [próg rentowności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci). Firma dąży do jego maksimum – [maksymalizacja zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku). Przy ocenie decyzji liczy się tylko [koszt relewantny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20relewantny).
