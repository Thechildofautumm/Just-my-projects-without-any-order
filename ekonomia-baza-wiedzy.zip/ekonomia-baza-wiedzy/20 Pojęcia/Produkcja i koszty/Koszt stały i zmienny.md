---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Koszt przeciętny", "Punkt zamknięcia", "Marża wkładu"]
źródło: ["[[Prezentacja – Koszty produkcji]]", "[[EM – Produkcja i koszty]]", "[[RZ – Temat 2, koszty w ujęciu zarządczym]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska", "Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["FC", "VC", "TC", "Koszt stały", "Koszt zmienny", "Koszt całkowity"]
---
> [!abstract] Definicja
> Koszt stały (FC) nie zależy od wielkości produkcji w krótkim okresie, koszt zmienny (VC) rośnie wraz z produkcją; razem tworzą koszt całkowity TC = FC + VC.

## Wyjaśnienie
| Koszt | Symbol | Cechy |
|---|---|---|
| stały całkowity | FC | ponoszony nawet przy Q = 0 (czynsz, leasing, amortyzacja) |
| zmienny całkowity | VC | VC(0) = 0 (materiały, energia, płace akordowe) |
| całkowity | TC = FC + VC | |

![[19_koszty_FC_VC_TC.png]]

> [!tip] Rozkład funkcji TC w zadaniu
> Wyraz wolny = FC, reszta = VC. $TC = Q^3 - 24Q^2 + 192Q + 1000$ → FC = 1000, VC = Q³ − 24Q² + 192Q.

- W **długim okresie** wszystkie koszty są zmienne.
- W rachunkowości zarządczej: podział obowiązuje w **przedziale istotności** (relevant range), wyróżnia się też koszty mieszane i schodkowe.

## Przykład
Przykład: FC rośnie o 250 zł → optymalne Q się nie zmienia (MC bez zmian), zysk spada z 200 do −50; strata 50 < FC = 450 → produkować dalej.

## Na egzaminie
> [!question] Pytanie testowe
> Czy wzrost kosztów stałych zmienia optymalną wielkość produkcji? **Nie – nie zmienia MC.**

## Zadania
Zadania do tego pojęcia: [[Wzrost kosztów stałych a decyzja o produkcji]].

Pojęcie przydaje się też w: [Koszty stałe z położenia minimum ATC](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszty%20sta%C5%82e%20z%20po%C5%82o%C5%BCenia%20minimum%20ATC).

## Jak to się łączy
Dzieląc FC i VC przez Q dostajemy [koszty przeciętne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny) (AFC, AVC). Podział jest kluczowy dla decyzji o zamknięciu: firma porównuje stratę z FC – patrz [punkt zamknięcia](obsidian://open?vault=ekonomia-baza-wiedzy&file=Punkt%20zamkni%C4%99cia). W rachunkowości zarządczej ten sam podział daje [marżę wkładu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mar%C5%BCa%20wk%C5%82adu) = cena − koszty zmienne.
