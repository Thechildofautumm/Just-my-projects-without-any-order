---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Analiza marginalna", "Etapy produkcji"]
wymaga: ["Produkt przeciętny i marginalny", "Przychód"]
źródło: ["[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MRP", "MRPL", "Optymalne zatrudnienie", "Krańcowy koszt pracy"]
---
> [!abstract] Definicja
> Krańcowy przychód z pracy (MRP_L) to przyrost przychodu dzięki zatrudnieniu dodatkowej jednostki pracy: MRP_L = MR·MP_L; firma zatrudnia, dopóki MRP_L ≥ koszt krańcowy pracy.

## Wyjaśnienie
$$MRP_L = \frac{\Delta TR}{\Delta L} = \frac{\Delta TR}{\Delta Q}\cdot\frac{\Delta Q}{\Delta L} = MR\cdot MP_L$$
Optymalne zatrudnienie: $M\pi_L = MRP_L - MC_L = 0$:
$$\boxed{MRP_L = MC_L}, \qquad \text{w KD i przy stałej płacy: } P\cdot MP_L = w$$
„Firma powinna zwiększać nakład czynnika zmiennego, dopóki krańcowy przychód z tego czynnika nie zrówna się z jego kosztem krańcowym.”

![[e08_MRP_zatrudnienie.png]]

W długim okresie analogicznie dla kapitału: $P\cdot MP_K = r$.

## Przykład
Przykład (kawiarnia): $Q = 40L - L^2$, P = 5, w = 50 → $5(40 - 2L) = 50$ → **L = 15**.
Zadanie EM: $Q = 60L - L^2$, P = 2, w = 16 → $120 - 4L = 16$ → L = 26, Q = 884, π = 1352.

## Na egzaminie
> [!question] Pytanie testowe
> P = 10, MP ostatniego pracownika = 5, płaca = 60. Zatrudnić go? **Nie: MRP = 50 < 60.**

## Zadania
Zadania do tego pojęcia: [[Kawiarnia – optymalne zatrudnienie]], [[Optymalna liczba roboczogodzin z MRP]] i [[Producent namiotów – zatrudnienie, zysk i etapy produkcji]].

## Jak to się łączy
MRP łączy produktywność, czyli [produkt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Produkt%20przeci%C4%99tny%20i%20marginalny), z [przychodem marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d). To [analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) zastosowana do czynnika produkcji. Optymalne zatrudnienie zawsze wypada w II [etapie produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Etapy%20produkcji), bo MP musi być dodatni.
