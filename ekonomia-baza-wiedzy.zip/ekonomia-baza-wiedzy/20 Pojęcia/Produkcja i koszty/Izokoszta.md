---
typ: pojęcie
up: "[[MOC Produkcja i koszty]]"
powiązane: ["Linia budżetowa", "Czynnik produkcji"]
źródło: ["[[Prezentacja – Funkcja produkcji]]", "[[EM – Produkcja i koszty]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Linia jednakowego kosztu"]
---
> [!abstract] Definicja
> Izokoszta (linia jednakowego kosztu) to zbiór kombinacji pracy i kapitału, które można kupić za daną kwotę: TC = wL + rK.

## Wyjaśnienie
$$TC = w\cdot L + r\cdot K \quad\Longrightarrow\quad K = \frac{TC}{r} - \frac{w}{r}L$$
- przecięcia: $TC/w$ (oś L), $TC/r$ (oś K),
- nachylenie: $-w/r$.

![[m11_izokoszta_zmiany.png]]

## Przykład
Przykład (pracownia ceramiki): w = 8, r = 2, TC = 480 → maksymalnie 60 jednostek pracy albo 240 jednostek kapitału.

## Na egzaminie
> [!question] Pytanie testowe
> Rośnie płaca w. Co z izokosztą? **Obraca się wokół punktu TC/r – staje się bardziej stroma.**

## Zadania
Pojęcie przydaje się też w: [Pracownia ceramiki – maksymalna produkcja przy danym budżecie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pracownia%20ceramiki%20%E2%80%93%20maksymalna%20produkcja%20przy%20danym%20bud%C5%BCecie).

## Jak to się łączy
Izokoszta to odpowiednik [linii budżetowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20bud%C5%BCetowa) konsumenta. Jej położenie wyznaczają ceny [czynników produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Czynnik%20produkcji) (w, r).
