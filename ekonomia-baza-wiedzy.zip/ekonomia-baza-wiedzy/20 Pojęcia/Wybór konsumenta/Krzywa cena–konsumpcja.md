---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Popyt", "Efekt substytucji i efekt dochodowy"]
wymaga: ["Optimum konsumenta", "Linia budżetowa"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["PCC", "Popyt indywidualny"]
---
> [!abstract] Definicja
> Krzywa cena–konsumpcja (PCC) to zbiór punktów równowagi konsumenta przy zmieniającej się cenie jednego dobra (dochód, cena drugiego dobra i preferencje stałe); z niej wyprowadzamy krzywą popytu.

## Wyjaśnienie
Zmiana ceny X = **obrót** linii budżetowej wokół $M/P_y$. Łącząc optima dostajemy PCC; pary (Px, Qx) z kolejnych optimów tworzą **krzywą popytu indywidualnego**.

![[14_PCC_i_krzywa_popytu.png]]

Popyt rynkowy = suma (pozioma) popytów indywidualnych.

## Przykład
Przykład: przy $P_x = 4$ konsument kupuje 80 szt., przy $P_x = 10$ – 30 szt. Dwa punkty krzywej popytu: $P = 13{,}6 - 0{,}12Q$.

## Na egzaminie
> [!question] Pytanie testowe
> Z której krzywej wyprowadzamy krzywą popytu indywidualnego? **Z krzywej cena–konsumpcja.**

## Zadania
Zadania do tego pojęcia: [[Funkcja popytu z dwóch optimów konsumenta]].

## Jak to się łączy
PCC to zbiór [optimów konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta) przy obracającej się [linii budżetowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20bud%C5%BCetowa). Wynikiem tej konstrukcji jest krzywa [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) – tak teoria konsumenta „zasila” rynek. Ruch wzdłuż PCC rozkładamy na dwa efekty – patrz [efekt substytucji i efekt dochodowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekt%20substytucji%20i%20efekt%20dochodowy).
