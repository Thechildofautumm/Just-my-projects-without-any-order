---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Krzywa obojętności", "Użyteczność"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["System preferencji", "Racjonalność konsumenta"]
---
> [!abstract] Definicja
> System preferencji to uporządkowanie wszystkich koszyków dóbr według zadowolenia, jakie dają konsumentowi, spełniające założenia kompletności, przechodniości i nienasycenia.

## Wyjaśnienie
Główne elementy teorii konsumenta: wybory **świadome i racjonalne**, oparte na dostępnych **informacjach**, z możliwością **substytucji** między dobrami.

| Założenie | Treść |
|---|---|
| **kompletność** | konsument potrafi porównać dowolne dwa koszyki: A ≻ B, B ≻ A albo A ~ B |
| **przechodniość** | jeśli A ≻ B i B ≻ C, to A ≻ C |
| **nienasycenie** | więcej dobra jest lepsze niż mniej |

Z tych założeń wynikają cechy krzywych obojętności (ujemne nachylenie, brak przecięć).

## Przykład
Jeśli wolisz kawę od herbaty, a herbatę od soku, to – zgodnie z przechodniością – wolisz kawę od soku.

## Na egzaminie
> [!question] Pytanie testowe
> Które założenie wyklucza przecinanie się krzywych obojętności? **Przechodniość (razem z nienasyceniem).**

## Jak to się łączy
Graficznym zapisem preferencji jest mapa [krzywych obojętności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20oboj%C4%99tno%C5%9Bci). Liczbowo preferencje porządkuje [użyteczność](obsidian://open?vault=ekonomia-baza-wiedzy&file=U%C5%BCyteczno%C5%9B%C4%87) – koszyk preferowany ma wyższą użyteczność.
