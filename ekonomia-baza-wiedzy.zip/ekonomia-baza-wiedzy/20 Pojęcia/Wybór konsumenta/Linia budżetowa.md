---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Optimum konsumenta", "Izokoszta"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Ograniczenie budżetowe", "Budżet konsumenta"]
---
> [!abstract] Definicja
> Linia budżetowa to zbiór koszyków dwóch dóbr, na które konsument wydaje cały dochód przy danych cenach.

## Wyjaśnienie
$$M = P_xQ_x + P_yQ_y \quad\Longrightarrow\quad Q_y = \frac{M}{P_y} - \frac{P_x}{P_y}Q_x$$
- przecięcia z osiami: $M/P_x$ i $M/P_y$,
- nachylenie: $-P_x/P_y$ (rynkowa „stopa wymiany” dóbr).

![[12_linia_budzetowa_zmiany.png]]

| Zmiana | Efekt |
|---|---|
| dochód ↑ (ceny stałe) | przesunięcie **równoległe** na zewnątrz |
| cena X ↓ | **obrót** wokół $M/P_y$ (przecięcie z osią X oddala się) |
| cena Y ↑ | obrót wokół $M/P_x$ |

## Przykład
Przykład (książki i płyty): $720 = 6Q_k + 9Q_p$ → maksymalnie 120 książek albo 80 płyt.

## Na egzaminie
> [!question] Pytanie testowe
> Ceny obu dóbr i dochód wzrosły dwukrotnie. Co z linią budżetową? **Nie zmienia się.**

## Zadania
Pojęcie przydaje się też w: [Książki i płyty – optymalny koszyk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ksi%C4%85%C5%BCki%20i%20p%C5%82yty%20%E2%80%93%20optymalny%20koszyk), [Funkcja popytu z dwóch optimów konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20popytu%20z%20dw%C3%B3ch%20optim%C3%B3w%20konsumenta).

## Jak to się łączy
Linia budżetowa wyznacza obiektywne ograniczenia wyboru, w ramach których konsument szuka [optimum](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta). Jej odpowiednikiem po stronie producenta jest [izokoszta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokoszta) – kombinacje czynników o tym samym koszcie.
