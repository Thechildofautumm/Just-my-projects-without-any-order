---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Krańcowa stopa substytucji", "Izokwanta"]
wymaga: ["Preferencje konsumenta"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Mapa obojętności", "Izokwanta użyteczności"]
---
> [!abstract] Definicja
> Krzywa obojętności to zbiór wszystkich kombinacji dwóch dóbr dających konsumentowi taki sam poziom zadowolenia (tę samą użyteczność).

## Wyjaśnienie
Cechy krzywych obojętności:
1. nachylenie **ujemne** – więcej X wymaga mniej Y, by zadowolenie się nie zmieniło,
2. **nie przecinają się**,
3. **wypukłe** względem początku układu (malejąca MRS),
4. jest ich **nieskończenie wiele** (mapa obojętności); dalej od 0 = wyższa użyteczność.

![[m06_krzywe_obojetnosci_nie_przecinaja_sie.png]]

Typowa postać w zadaniach: $TU = Q_x\cdot Q_y$ → krzywa $Q_y = TU/Q_x$ (hiperbola), np. $Q_c = 900/Q_h$.

## Przykład
Dla $TU = Q_k\cdot Q_p = 2400$ koszyki (60; 40) i (40; 60) leżą na tej samej krzywej – konsument jest między nimi obojętny.

## Na egzaminie
> [!question] Pytanie otwarte
> Uzasadnij, dlaczego krzywe obojętności nie mogą się przecinać. *Odp.: punkt przecięcia leżałby na dwóch poziomach użyteczności jednocześnie – sprzeczność z przechodniością i nienasyceniem (rysunek powyżej).*

## Zadania
Pojęcie przydaje się też w: [Herbata i ciastka – krańcowa stopa substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Herbata%20i%20ciastka%20%E2%80%93%20kra%C5%84cowa%20stopa%20substytucji).

## Jak to się łączy
Kształt i właściwości krzywych wynikają z [założeń o preferencjach](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencje%20konsumenta). Nachylenie krzywej w każdym punkcie to [krańcowa stopa substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20substytucji). Po stronie producenta dokładnie taką samą rolę pełni [izokwanta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Izokwanta) – krzywa jednakowej produkcji.
