---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Elastyczność dochodowa popytu", "Dobro Giffena"]
wymaga: ["Optimum konsumenta"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Efekt substytucyjny", "Efekt dochodowy", "Dekompozycja Hicksa"]
---
> [!abstract] Definicja
> Reakcję popytu na zmianę ceny rozkładamy na efekt substytucji (zastępowanie dobra relatywnie droższego tańszym) i efekt dochodowy (zmiana siły nabywczej dochodu).

## Wyjaśnienie
Gdy **rośnie cena X**:
1. **efekt substytucji** – X jest relatywnie droższe → konsument zastępuje X dobrem Y; działa **zawsze przeciwnie do zmiany ceny**,
2. **efekt dochodowy** – spada dochód realny → zmienia się popyt na X; kierunek zależy od rodzaju dobra.

![[15_efekt_substytucji_i_dochodowy.png]]

A → B: efekt substytucji (ruch po tej samej krzywej obojętności do nachylenia nowych cen; linia skompensowana). B → C: efekt dochodowy (równoległe przesunięcie do faktycznej linii budżetowej).

| Dobro | ES (↑Px) | ED (↑Px) | Łącznie |
|---|---|---|---|
| normalne | Qx ↓ | Qx ↓ | ↓ |
| podrzędne | Qx ↓ | Qx ↑ (słabiej) | ↓ |
| Giffena | Qx ↓ | Qx ↑ (**silniej**) | **↑** |

![[m08_giffen_wodospad.png]]

## Przykład
Przykład: po wzroście ceny gruszek z 3 do 12 zł konsument potrzebuje budżetu 24 zł (zamiast 12), by utrzymać dotychczasowe zadowolenie – ta kompensacja odpowiada linii skompensowanej z rysunku.

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij, dlaczego dla dobra podrzędnego krzywa popytu nadal zwykle opada. *Odp.: efekt substytucji (spadek Q) przeważa nad przeciwnym efektem dochodowym.*

## Zadania
Pojęcie przydaje się też w: [Kompensacja wzrostu ceny – utrzymanie użyteczności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kompensacja%20wzrostu%20ceny%20%E2%80%93%20utrzymanie%20u%C5%BCyteczno%C5%9Bci).

## Jak to się łączy
Dekompozycja porównuje dwa [optima konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta) (przed i po zmianie ceny) z punktem pośrednim. Kierunek efektu dochodowego wyznacza [elastyczność dochodowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu) – dodatnia dla dóbr normalnych, ujemna dla podrzędnych. Gdy efekt dochodowy przeważa nad efektem substytucji, powstaje [dobro Giffena](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dobro%20Giffena).
