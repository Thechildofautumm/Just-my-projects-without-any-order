---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Efekt substytucji i efekt dochodowy"]
część-z: ["Elastyczność dochodowa popytu"]
przeciwieństwo: ["Popyt"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Paradoks Giffena"]
---
> [!abstract] Definicja
> Dobro Giffena to silnie podrzędne dobro, na które popyt rośnie wraz ze wzrostem jego ceny, bo ujemny efekt dochodowy przewyższa efekt substytucji.

## Wyjaśnienie
- Zjawisko zaobserwowane w Irlandii: wzrost ceny chleba (ziemniaków) zwiększył popyt na nie (**paradoks Giffena**).
- Warunki: dobro stanowi **dużą część konsumpcji** biednych gospodarstw i **nie ma substytutów**.
- Krzywa popytu ma (na pewnym odcinku) **dodatnie nachylenie**.

> [!important] Zapamiętaj
> Każde dobro Giffena jest dobrem podrzędnym, ale nie każde dobro podrzędne jest dobrem Giffena.

## Przykład
Ubogie gospodarstwo wydaje większość dochodu na ziemniaki. Gdy ziemniaki drożeją, nie stać go już na mięso – rezygnuje z mięsa i kupuje… jeszcze więcej ziemniaków.

## Na egzaminie
> [!question] Pytanie testowe
> Dla dobra Giffena: efekt substytucji jest… **ujemny (jak zawsze), a dodatni efekt dochodowy jest od niego silniejszy.**

## Jak to się łączy
Dobro Giffena to skrajny przypadek dobra podrzędnego, opisanego przez ujemną [elastyczność dochodową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu). Jest wyjątkiem od prawa [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) – krzywa popytu rośnie. Wyjaśnia go [rozkład na efekt substytucji i dochodowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekt%20substytucji%20i%20efekt%20dochodowy).
