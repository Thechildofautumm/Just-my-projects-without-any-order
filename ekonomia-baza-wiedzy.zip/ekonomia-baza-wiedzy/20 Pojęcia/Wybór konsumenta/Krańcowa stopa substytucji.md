---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Krańcowa stopa technicznej substytucji"]
wymaga: ["Użyteczność"]
część-z: ["Krzywa obojętności"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MRS", "Marginalna stopa substytucji"]
---
> [!abstract] Definicja
> Krańcowa stopa substytucji (MRS) to ilość dobra Y, z której konsument zrezygnuje w zamian za dodatkową jednostkę dobra X, pozostając na tej samej krzywej obojętności.

## Wyjaśnienie
$$\boxed{MRS = -\frac{\Delta Q_y}{\Delta Q_x} = \frac{MU_x}{MU_y}}$$
- MRS = (bezwzględne) nachylenie krzywej obojętności,
- **prawo malejącej MRS**: konsument oddaje coraz mniej Y za każdą kolejną jednostkę X, bo maleją użyteczności marginalne.

![[m05_MRS_schodki.png]]

Dla $TU = Q_x\cdot Q_y$: $MU_x = Q_y$, $MU_y = Q_x$ → $MRS = Q_y/Q_x$.

## Przykład
Przykład (herbata i ciastka): $Q_c = 900/Q_h$; herbaty 15 → 45, ciastka 60 → 20:
$MRS = -\frac{20 - 60}{45 - 15} = \frac{40}{30} \approx 1{,}33$.

## Na egzaminie
> [!question] Pytanie testowe
> MRS = 3 oznacza, że… **konsument zrezygnuje z 3 jednostek Y za 1 dodatkową jednostkę X przy niezmienionym zadowoleniu.**

## Zadania
Zadania do tego pojęcia: [[Herbata i ciastka – krańcowa stopa substytucji]].

## Jak to się łączy
MRS wyprowadzamy z [użyteczności marginalnych](obsidian://open?vault=ekonomia-baza-wiedzy&file=U%C5%BCyteczno%C5%9B%C4%87) (MUx/MUy) i jest ona nachyleniem [krzywej obojętności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20oboj%C4%99tno%C5%9Bci). Jej odpowiednikiem u producenta jest [krańcowa stopa technicznej substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20technicznej%20substytucji) – MRTS = MPL/MPK, liczona identycznie.
