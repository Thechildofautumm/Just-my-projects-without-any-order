---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Elastyczność dochodowa popytu"]
wymaga: ["Krzywa dochód–konsumpcja"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Prawo Engla", "Krzywe Engla"]
---
> [!abstract] Definicja
> Krzywa Engla pokazuje, jak optymalna ilość kupowanego dobra zmienia się wraz z dochodem konsumenta przy stałych cenach.

## Wyjaśnienie
Ernest Engel (XIX w.) badał statystycznie zależność wydatków od dochodów. Krzywą Engla wyprowadzamy z ICC.

![[13_ICC_i_krzywe_Engla.png]]

| Kształt | $E_M$ | Rodzaj dobra |
|---|---|---|
| rośnie coraz wolniej (wklęsła) | 0–1 | podstawowe |
| prosta przez 0 | 1 | normalne, stały udział w budżecie |
| rośnie coraz szybciej (wypukła) | > 1 | luksusowe (wyższego rzędu) |
| opada | < 0 | podrzędne |

**Prawo Engla:** wraz ze wzrostem dochodu udział wydatków na żywność maleje, a na dobra wyższego rzędu – rośnie.

## Przykład
Przykład: $TU = 2Q_x^{1/4}Q_y^{3/4}$, $P_x = 10$ → na X idzie ¼ dochodu: **$Q_x = M/40$** – prosta przez 0, dobro normalne ($E_M = 1$).

## Na egzaminie
> [!question] Pytanie otwarte
> Narysuj krzywe Engla dla dobra podstawowego i luksusowego i wyjaśnij różnicę.

> [!success]- Odpowiedź (szkic)
> Dobro podstawowe: krzywa Engla rośnie coraz wolniej (wklęsła), $0 < E_M < 1$ – udział wydatków w dochodzie maleje. Dobro luksusowe: krzywa rośnie coraz szybciej (wypukła), $E_M > 1$ – udział wydatków rośnie. Dla dobra podrzędnego krzywa od pewnego dochodu opada ($E_M < 0$).

## Zadania
Zadania do tego pojęcia: [[Krzywa Engla dla funkcji Cobba-Douglasa]].

## Jak to się łączy
Krzywą Engla wyprowadzamy z [krzywej dochód–konsumpcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20doch%C3%B3d%E2%80%93konsumpcja). Jej kształt jest graficznym odpowiednikiem [elastyczności dochodowej popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu).
