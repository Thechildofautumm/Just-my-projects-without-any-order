---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Optimum producenta"]
wymaga: ["Krzywa obojętności", "Linia budżetowa", "Krańcowa stopa substytucji"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Równowaga konsumenta", "Koszyk optymalny"]
---
> [!abstract] Definicja
> Optimum (równowaga) konsumenta to koszyk na najwyższej osiągalnej krzywej obojętności – punkt styczności krzywej obojętności z linią budżetową.

## Wyjaśnienie
$$\boxed{MRS = \frac{MU_x}{MU_y} = \frac{P_x}{P_y} \quad\Longleftrightarrow\quad \frac{MU_x}{P_x} = \frac{MU_y}{P_y}}$$
„Ostatnia złotówka wydana na każde dobro daje tę samą użyteczność.”

![[11_optimum_konsumenta.png]]

> [!tip] Algorytm
> 1. $MU_x$, $MU_y$ (pochodne cząstkowe TU).
> 2. Układ: $M = P_xQ_x + P_yQ_y$ oraz $MU_x/MU_y = P_x/P_y$.
> 3. Wyznacz $Q_y$ przez $Q_x$, podstaw do budżetu, policz TU.
> 4. Rysunek: linia budżetowa + styczna krzywa obojętności.

> [!note] Skrót dla funkcji Cobba–Douglasa
> Dla $TU = Q_x^{\alpha}Q_y^{\beta}$: na X wydajemy udział $\frac{\alpha}{\alpha+\beta}$ dochodu: $Q_x = \frac{\alpha}{\alpha+\beta}\cdot\frac{M}{P_x}$.

## Przykład
Przykład (książki i płyty): $M = 720$, $P_k = 6$, $P_p = 9$, $TU = Q_k Q_p$ → $\frac{Q_p}{Q_k} = \frac69$, $720 = 12Q_k$ → **Qk = 60; Qp = 40**; TU = 2400.

## Na egzaminie
> [!question] Pytanie otwarte
> Co zrobi konsument, gdy MUx/Px > MUy/Py? *Odp.: przesunie wydatki z Y na X – złotówka wydana na X daje więcej zadowolenia.*

## Zadania
Zadania do tego pojęcia: [[Książki i płyty – optymalny koszyk]] i [[Kompensacja wzrostu ceny – utrzymanie użyteczności]].

## Jak to się łączy
Optimum łączy preferencje, czyli [krzywą obojętności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20oboj%C4%99tno%C5%9Bci), z możliwościami, czyli [linią budżetową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20bud%C5%BCetowa); warunkiem styczności jest równość [MRS](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20substytucji) i relacji cen. Matematycznie to ten sam problem co [optimum producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20producenta) (MRTS = w/r) – oba rozwiązuje metoda Lagrange'a.
