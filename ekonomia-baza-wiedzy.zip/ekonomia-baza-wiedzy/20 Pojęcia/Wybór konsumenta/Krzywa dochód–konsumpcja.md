---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Krzywa Engla", "Krzywa cena–konsumpcja"]
wymaga: ["Optimum konsumenta"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["ICC", "Ścieżka ekspansji dochodowej"]
---
> [!abstract] Definicja
> Krzywa dochód–konsumpcja (ICC) to zbiór punktów równowagi konsumenta dla wszystkich poziomów dochodu przy stałych cenach i preferencjach.

## Wyjaśnienie
Zmiana dochodu przy stałych cenach = **równoległe** przesunięcia linii budżetowej; łącząc kolejne optima dostajemy ICC.

![[m07_ICC_trzy_warianty.png]]

| Kształt ICC | Rodzaj dóbr |
|---|---|
| nachylenie dodatnie | X i Y normalne |
| zawija ku osi Y (wklęsła względem osi rzędnych) | X podrzędne |
| nachylenie ujemne | Y podrzędne |

Konsument przechodzący na wyższy dochód **zmienia strukturę** konsumpcji.

## Przykład
Dla $TU = Q_xQ_y$ i równych cen ICC to prosta przez początek układu – na każde dobro idzie połowa dochodu.

## Na egzaminie
> [!question] Pytanie testowe
> ICC ma nachylenie ujemne. Co to oznacza? **Jedno z dóbr (to, którego ilość maleje) jest podrzędne.**

## Zadania
Pojęcie przydaje się też w: [Krzywa Engla dla funkcji Cobba-Douglasa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20Engla%20dla%20funkcji%20Cobba-Douglasa).

## Jak to się łączy
ICC powstaje z kolejnych [optimów konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Optimum%20konsumenta). Przenosząc ilość jednego dobra i odpowiadający jej dochód na nowy wykres, dostajemy [krzywą Engla](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20Engla). Analogiczną konstrukcję, ale dla zmian ceny, daje [krzywa cena–konsumpcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20cena%E2%80%93konsumpcja).
