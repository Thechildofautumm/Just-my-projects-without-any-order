---
typ: pojęcie
up: "[[MOC Wybór konsumenta]]"
powiązane: ["Analiza marginalna", "Krańcowa stopa substytucji", "Preferencje konsumenta"]
źródło: ["[[Prezentacja – Decyzje konsumenta i popyt]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["TU", "MU", "Użyteczność marginalna", "Prawo malejącej użyteczności marginalnej"]
---
> [!abstract] Definicja
> Użyteczność to zadowolenie, jakie konsument osiąga z konsumpcji lub posiadania dobra; użyteczność marginalna (MU) to zadowolenie z ostatniej, dodatkowej jednostki.

## Wyjaśnienie
- kategoria **abstrakcyjna, porządkowa, subiektywna**; odzwierciedla uporządkowany system preferencji,
- konsument wybiera kombinację dóbr dającą największe możliwe zadowolenie.

| Pojęcie | Wzór |
|---|---|
| użyteczność całkowita | TU |
| użyteczność marginalna | $MU = \Delta TU/\Delta Q$ (lub $TU'$) |

> [!important] Prawo malejącej użyteczności marginalnej
> Każda kolejna jednostka dobra daje coraz mniejszy przyrost zadowolenia; TU rośnie coraz wolniej.

**Optimum dla jednego dobra:** kupuj, dopóki $MU \ge P$ → optimum $MU = P$.

![[10_uzytecznosc_TU_MU.png]]

## Przykład
Przykład (bilety do kina): MU = 40, 35, 30, 25, 20, 10, 5. Przy P = 18 optimum to **5 seansów** (5.: MU = 20 ≥ 18; 6.: MU = 10 < 18). Po podwyżce do 26 zł – **3 seanse**.

## Na egzaminie
> [!question] Pytanie testowe
> Gdy MU kolejnej jednostki jest niższa od ceny, racjonalny konsument… **nie kupuje tej jednostki.**

## Zadania
Zadania do tego pojęcia: [[Bilety do kina – użyteczność marginalna]].

## Jak to się łączy
Reguła „kupuj, dopóki MU ≥ P” to [analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) w wykonaniu konsumenta. Dla dwóch dóbr stosunek użyteczności marginalnych tworzy [krańcową stopę substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kra%C5%84cowa%20stopa%20substytucji): MRS = MUx/MUy. Użyteczność jest liczbowym zapisem [preferencji konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencje%20konsumenta).
