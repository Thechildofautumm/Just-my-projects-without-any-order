---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Rachunek kosztów działań"]
część-z: ["Klasyfikacja kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Poziomy kosztów"]
---
> [!abstract] Definicja
> Hierarchia kosztów (Cooper, 1990) dzieli koszty według poziomu działalności, na którym powstają: jednostki, partii, produktu, klienta/kanału i organizacji.

## Wyjaśnienie
![[r02_hierarchia_kosztow.png]]

| Poziom | Przykłady | Nośnik |
|---|---|---|
| jednostki | energia linii, materiały pomocnicze, test każdej sztuki | maszynogodziny, sztuki |
| partii | przezbrojenie, pobranie materiałów, kontrola pierwszej sztuki | liczba partii |
| produktu | dokumentacja, certyfikacja, inżynieria aplikacyjna | liczba modeli, godziny inżynierii |
| klienta / kanału | szkolenia serwisantów, wsparcie, logistyka małych zamówień | liczba zgłoszeń, dostaw |
| organizacji | zarząd, audyt, IT centralne | brak sensownego nośnika |

Klucz wolumenowy (roboczogodziny, maszynogodziny) poprawnie rozlicza tylko **pierwszy poziom**; im wyżej w hierarchii, tym bardziej zniekształca koszt produktów niskoseryjnych.

## Przykład
Pytanie egzaminacyjne RZ: koszty przezbrojenia linii należą do kosztów poziomu **partii**.

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij, dlaczego klucz roboczogodzin zaniża koszt produktów wytwarzanych w małych partiach.

> [!success]- Odpowiedź (szkic)
> Koszty przezbrojeń, przygotowania partii i inżynierii zależą od liczby partii i modeli, a nie od liczby godzin. Klucz roboczogodzin rozdziela je proporcjonalnie do wolumenu, więc produkty wielkoseryjne „dopłacają” do małoseryjnych (subsydiowanie skrośne) – koszt produktów z małych partii jest zaniżony (Cargo 8 w przykładzie Velomii).

## Zadania
Pojęcie przydaje się też w: [Velomia – ABC w zakładzie w Lesznie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20ABC%20w%20zak%C5%82adzie%20w%20Lesznie).

## Jak to się łączy
Hierarchia rozwija podział na koszty bezpośrednie i pośrednie z [klasyfikacji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Klasyfikacja%20koszt%C3%B3w). Na niej opiera się [rachunek kosztów działań](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20dzia%C5%82a%C5%84), który przypisuje koszty na właściwym poziomie.
