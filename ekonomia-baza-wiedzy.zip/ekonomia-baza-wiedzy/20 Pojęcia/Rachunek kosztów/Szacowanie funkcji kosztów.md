---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Koszt stały i zmienny", "Krzywa uczenia się"]
wymaga: ["Zachowanie kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Metoda wielkości skrajnych", "Regresja kosztów", "Funkcja kosztów y = a + bx"]
---
> [!abstract] Definicja
> Szacowanie funkcji kosztów to wyznaczanie zależności y = a + bx (a – koszty stałe, b – koszt zmienny na jednostkę nośnika) metodami technicznymi, analizy kont, wielkości skrajnych lub regresji.

## Wyjaśnienie
| Metoda | Na czym polega | Ocena |
|---|---|---|
| analiza techniczna | normy zużycia z dokumentacji i pomiarów | dokładna dla kosztów bezpośrednich, droga |
| analiza kont | ekspert klasyfikuje konta | szybka, subiektywna |
| **wielkości skrajne** | dwa punkty: najwyższa i najniższa aktywność | prosta; zależy od dwóch, często nietypowych obserwacji |
| **regresja liniowa (MNK)** | linia minimalizująca sumę kwadratów odchyleń | wszystkie dane; miary jakości (R², t) |
| regresja wieloraka | $y = a + b_1x_1 + b_2x_2$ | zgodna z hierarchią kosztów; ryzyko współliniowości |

**Metoda wielkości skrajnych:**
$$b = \frac{y_{max} - y_{min}}{x_{max} - x_{min}}, \qquad a = y_{max} - b\,x_{max}$$

**Czy funkcji można zaufać?** wiarygodność ekonomiczna (korelacja ≠ przyczynowość), dopasowanie (R²), istotność (|t| > 2), zakres (nie ekstrapoluj), jakość danych.

![[r04_regresja_vs_skrajne.png]]

## Przykład
Utrzymanie ruchu: 5 200 mh → 406 tys. zł, 8 800 mh → 528 tys. zł → $b = 122\,000/3600 = 33{,}89$, $a = 229\,778$. Regresja: $y = 188\,774 + 40{,}68x$ (R² = 0,937). Prognoza dla 9 000 mh: 534,8 vs 554,9 tys. zł.

## Na egzaminie
> [!question] Zadanie typowe
> Policz funkcję kosztów metodą wielkości skrajnych i wskaż jej słabość.

> [!success]- Odpowiedź (szkic)
> $b = \frac{y_{max} - y_{min}}{x_{max} - x_{min}}$, $a = y_{max} - b\,x_{max}$. Słabość: wynik zależy tylko od dwóch, często nietypowych obserwacji; brak miar jakości dopasowania (w przeciwieństwie do regresji).

## Zadania
Zadania do tego pojęcia: [[Velomia – regresja a metoda wielkości skrajnych]].

Pojęcie przydaje się też w: [Velomia – koszty sztywne po spadku sprzedaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20koszty%20sztywne%20po%20spadku%20sprzeda%C5%BCy).

## Jak to się łączy
Szacujemy to, co opisuje [zachowanie kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zachowanie%20koszt%C3%B3w). Parametry funkcji odpowiadają podziałowi na [koszty stałe i zmienne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny): a to FC, b to jednostkowy koszt zmienny. Szczególną, nieliniową funkcją kosztów pracy jest [krzywa uczenia się](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20uczenia%20si%C4%99).
