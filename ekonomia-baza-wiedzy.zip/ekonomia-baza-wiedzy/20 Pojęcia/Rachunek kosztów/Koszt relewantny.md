---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Koszt alternatywny", "Analiza marginalna", "Koszt księgowy a koszt ekonomiczny"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[RZ – Temat 2, koszty w ujęciu zarządczym]]", "[[EM – Produkcja i koszty]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Rachunkowość zarządcza", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszt istotny", "Koszt utopiony", "Koszt uniknięty", "Koszt różnicowy"]
---
> [!abstract] Definicja
> Koszt relewantny (istotny) to przyszły koszt różnicowy – taki, który zmienia się zależnie od wybranego wariantu decyzji; kosztów utopionych i niezmiennych między wariantami nie uwzględniamy.

## Wyjaśnienie
| Kategoria | Czy uwzględniać w decyzji? |
|---|---|
| koszt istotny (przyrostowy, różnicowy) | **tak** |
| koszt alternatywny | **tak** (choć nie jest księgowany) |
| koszt uniknięty (zniknie po wyborze wariantu) | **tak** |
| koszt utopiony (poniesiony w przeszłości) | **nie** – nie zmieni go żadna decyzja |
| koszt stały niezależny od wyboru | **nie** |

Zasada (ekonomia menedżerska, Solek): w analizie opłacalności bierzemy pod uwagę wyłącznie koszty istotne, pomijamy stałe niezależne od opcji i utopione.

## Przykład
Pytanie egzaminacyjne RZ: do oceny, czy przyjąć jednorazowe zamówienie przy wolnych mocach, kontroler powinien użyć **przyszłych kosztów różnicowych tego zamówienia** – nie kosztu wytworzenia ani pełnego kosztu.

## Na egzaminie
> [!question] Pytanie testowe
> Firma wydała 50 000 zł na badanie rynku nowego produktu. Czy uwzględnić tę kwotę przy decyzji o wprowadzeniu produktu? **Nie – to koszt utopiony.**

## Zadania
Zadania do tego pojęcia: [[Velomia – zamówienie specjalne na Urban 5]].

Pojęcie przydaje się też w: [Velomia – wielostopniowy rachunek marż](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20wielostopniowy%20rachunek%20mar%C5%BC).

## Jak to się łączy
[Koszt alternatywny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny) jest kosztem relewantnym, mimo że nie widać go w księgach. Wybór między wariantami to [analiza marginalna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Analiza%20marginalna) – liczą się tylko zmiany wywołane decyzją. Dlatego [koszt księgowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20ksi%C4%99gowy%20a%20koszt%20ekonomiczny) bywa dla decyzji nieistotny (np. utopiony).
