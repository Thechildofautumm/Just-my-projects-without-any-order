---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Rachunek kosztów działań sterowany czasem", "Klasyfikacja kosztów"]
wymaga: ["Hierarchia kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["ABC", "Activity-based costing", "Nośnik kosztów"]
---
> [!abstract] Definicja
> Rachunek kosztów działań (ABC) przypisuje koszty zasobów do działań, a koszty działań – do obiektów kosztów według zużycia nośników kosztów.

## Wyjaśnienie
```mermaid
flowchart LR
  Z["Zasoby: płace, amortyzacja, energia, IT<br/>(co zużywamy?)"] -->|nośniki zasobów| D["Działania: przezbrojenia, inżynieria, testy<br/>(na co?)"]
  D -->|nośniki działań| O["Obiekty: modele, partie, klienci<br/>(dlaczego?)"]
```

**Pięć kroków:**
1. zidentyfikuj główne działania i ich poziom w hierarchii,
2. przypisz koszty zasobów do działań,
3. wybierz nośnik dla każdego działania (transakcyjny, czasowy, intensywności),
4. oblicz stawkę: **koszt działania / wielkość nośnika** (najlepiej przy praktycznej zdolności),
5. przypisz koszty działań do obiektów według zużycia nośników.

| Działanie (Leszno) | Koszt | Nośnik | Stawka |
|---|---|---|---|
| przezbrojenia | 1,92 mln | liczba partii (96) | 20 000 / partia |
| inżynieria i konfiguracja | 3,2 mln | godziny (5 000) | 640 / h |
| testy | 1,2 mln | liczba testów (1 680) | 714,29 / test |
| obsługa linii | 1,68 mln | maszynogodziny (7 600) | 221,05 / mh |

**Kiedy warto:** wysoki udział kosztów pośrednich, duże zróżnicowanie produktów i klientów, decyzje cenowe oparte na kosztach, dostępne dane. **Kiedy nie:** niewielkie koszty pośrednie, jednorodny asortyment, koszt wdrożenia > korzyści.

## Przykład
Cargo 8 (240 szt.): koszty działań 3,58 mln → **14 902 zł/szt.**, wynik −7 902 zł; Cargo 6: koszt działań 3 686 zł/szt. Przy jednej stawce na roboczogodzinę Cargo 6 subsydiuje Cargo 8 (subsydiowanie skrośne).

## Na egzaminie
> [!question] Pytanie otwarte
> Opisz kroki rachunku kosztów działań i wyjaśnij, czym różnią się nośniki transakcyjne od czasowych.

> [!success]- Odpowiedź (szkic)
> Kroki: (1) identyfikacja działań i ich poziomu w hierarchii kosztów, (2) przypisanie kosztów zasobów do działań, (3) wybór nośników działań, (4) obliczenie stawek (koszt działania / wielkość nośnika), (5) przypisanie kosztów do obiektów według zużycia nośników.
> Nośnik transakcyjny liczy wystąpienia (liczba przezbrojeń) – tani, ale zakłada jednakowy koszt każdego wystąpienia; czasowy mierzy czas (godziny przezbrojeń) – dokładniejszy, droższy w pomiarze.

## Zadania
Zadania do tego pojęcia: [[Velomia – ABC w zakładzie w Lesznie]].

## Jak to się łączy
ABC przypisuje koszty na właściwych poziomach [hierarchii kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Hierarchia%20koszt%C3%B3w). Uproszczoną, łatwiejszą w aktualizacji wersją jest [TDABC](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20dzia%C5%82a%C5%84%20sterowany%20czasem). ABC precyzyjniej przypisuje koszty pośrednie niż klucze wolumenowe z tradycyjnej [klasyfikacji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Klasyfikacja%20koszt%C3%B3w).
