---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Marża wkładu", "Rachunkowość zarządcza a finansowa"]
wymaga: ["Koszt stały i zmienny"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["RKZ", "RKP", "Rachunek kosztów zmiennych", "Rachunek kosztów pełnych", "Koszt niewykorzystanych mocy"]
---
> [!abstract] Definicja
> Rachunek kosztów pełnych (RKP) wlicza stałe koszty pośrednie produkcji do kosztu wytworzenia i zapasów, a rachunek kosztów zmiennych (RKZ) traktuje je w całości jako koszt okresu.

## Wyjaśnienie
| | RKP | RKZ |
|---|---|---|
| stałe koszty pośrednie produkcji | w koszcie wytworzenia i zapasach | koszt okresu (100%) |
| wycena zapasów | pełny koszt wytworzenia (wymagana do bilansu: art. 28 ust. 3 UoR, MSR 2) | tylko koszty zmienne (cele zarządcze) |
| koszt niewykorzystanych mocy | koszt okresu | – |
| wynik zależy od | produkcji i sprzedaży | tylko sprzedaży |

```mermaid
flowchart LR
  FC["Stałe koszty pośrednie produkcji"] -->|RKP: stawka = FC / normalne moce| KW["Koszt wytworzenia"]
  KW --> ZAP["Zapas (bilans)"]
  KW --> KS["Koszt sprzedanych (RZiS)"]
  FC -->|RKP: niewykorzystane moce| KO["Koszt okresu (RZiS)"]
  FC -->|RKZ: 100%| KO
```

$$\boxed{\text{Wynik RKP} - \text{Wynik RKZ} = (Z_{końc} - Z_{pocz})\cdot\text{stałe koszty pośrednie na sztukę}}$$

![[r06_RKP_RKZ_kwartaly.png]]

## Przykład
Urban 5, stawka 1 600 zł/szt. Kw. I: produkcja 4000, sprzedaż 3400 → zapas +600 → RKP wyższy o 0,96 mln (3,96 vs 3,00). Kw. II: zapas −600 i niewykorzystane moce 500 szt. → RKP niższy o 0,96 mln. Łącznie wyniki równe (8,45).

## Na egzaminie
> [!question] Pytanie testowe
> Zapasy wyrobów gotowych wzrosły. Wynik RKP w porównaniu z RKZ będzie… **wyższy.**

> [!warning] Pułapka
> W RKP menedżer może „produkować na wynik” – zwiększanie zapasów przenosi koszty stałe do bilansu.

## Zadania
Zadania do tego pojęcia: [[Velomia – RKP i RKZ w dwóch kwartałach]].

## Jak to się łączy
Różnica dotyczy wyłącznie [kosztów stałych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny) produkcji. RKZ prezentuje wynik przez [marżę wkładu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mar%C5%BCa%20wk%C5%82adu). RKP jest wymagany do wyceny bilansowej, co dobrze ilustruje różnicę opisaną w [rachunkowości zarządczej a finansowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunkowo%C5%9B%C4%87%20zarz%C4%85dcza%20a%20finansowa).
