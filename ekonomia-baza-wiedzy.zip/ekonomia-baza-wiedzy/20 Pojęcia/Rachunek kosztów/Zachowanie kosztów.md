---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Szacowanie funkcji kosztów", "Efekty skali"]
wymaga: ["Koszt stały i zmienny"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszty sztywne", "Sticky costs", "Relevant range", "Koszty mieszane", "Koszty schodkowe"]
---
> [!abstract] Definicja
> Zachowanie kosztów to sposób, w jaki koszty reagują na zmiany aktywności; podział na stałe i zmienne obowiązuje tylko w określonym przedziale i horyzoncie, a w praktyce koszty bywają mieszane, schodkowe i sztywne.

## Wyjaśnienie
- **Przedział istotności (relevant range):** podział stałe/zmienne obowiązuje w danym przedziale aktywności – druga zmiana produkcji skokowo zmienia „stałe” koszty nadzoru (koszty schodkowe).
- **Koszty zaangażowane vs uznaniowe:** zaangażowane wynikają z decyzji o mocach (leasing linii, etaty), uznaniowe można zmienić w budżecie rocznym (szkolenia, marketing).
- **Horyzont:** w długim okresie prawie wszystkie koszty są zmienne (założenie ABC).
- **Koszty sztywne (sticky costs):** rosną szybciej przy wzroście aktywności, niż spadają przy jej spadku.

![[r03_koszty_sztywne.png]]

Anderson, Banker, Janakiraman (2003): koszty sprzedaży i zarządu rosły średnio o 0,55% przy wzroście przychodów o 1%, a spadały o 0,35% przy spadku o 1%.

## Przykład
Velomia po wygaśnięciu dopłat: sprzedaż −20%, a koszty stałe spadają z opóźnieniem – budżet oparty na symetrycznej funkcji kosztów **przeszacuje wynik**.

## Na egzaminie
> [!question] Pytanie testowe
> Koszty sztywne oznaczają, że… **koszty spadają słabiej przy spadku aktywności, niż rosną przy jej wzroście.**

## Zadania
Zadania do tego pojęcia: [[Velomia – koszty sztywne po spadku sprzedaży]].

## Jak to się łączy
Notatka uściśla podstawowy podział na [koszty stałe i zmienne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny). Jak zachowanie kosztów zmierzyć w danych, pokazuje [szacowanie funkcji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Szacowanie%20funkcji%20koszt%C3%B3w). Teza „w długim okresie wszystkie koszty są zmienne” to ta sama obserwacja co w ekonomii – patrz [efekty skali](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekty%20skali) i długookresowe koszty.
