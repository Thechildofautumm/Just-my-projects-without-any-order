---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Próg rentowności", "Rachunek kosztów zmiennych i pełnych"]
wymaga: ["Koszt stały i zmienny"]
źródło: ["[[RZ – Temat 1, istota rachunkowości zarządczej]]", "[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Marża brutto", "Marża pokrycia", "Contribution margin", "Wielostopniowy rachunek marż"]
---
> [!abstract] Definicja
> Marża wkładu (marża pokrycia) to cena minus koszty zmienne – kwota, którą każda sprzedana jednostka wnosi do pokrycia kosztów stałych i zysku.

## Wyjaśnienie
$$\text{marża wkładu na sztukę} = P - AVC, \qquad \text{marża wkładu łącznie} = TR - VC$$

**Wielostopniowy rachunek marż** (tradycja niemiecka: Agthe, Riebel) – koszty stałe przypisujemy na najniższym poziomie, na którym da się ich uniknąć, bez kluczy:

| Poziom | Odejmujemy |
|---|---|
| Marża I (wkładu) | przychody − koszty zmienne |
| Marża II | − koszty stałe modelu / usługi |
| Marża III | − koszty stałe zakładu / sieci |
| Wynik operacyjny | − koszty stałe centrali |

![[r07_rachunek_marz_kaskada.png]]

## Przykład
Urban 5: cena 9 600 zł, koszty zmienne 5 800 zł → **marża wkładu 3 800 zł**. Cargo 8 ma dodatnią marżę I (2,8 mln), ale ujemną marżę II (−0,7 mln) – nie pokrywa kosztów stałych modelu.

## Na egzaminie
> [!question] Pytanie problemowe
> Czy wycofać Cargo 8 z ujemną marżą II? *Odp.: zależy, ile z 3,5 mln kosztów stałych modelu da się uniknąć – to decyzja na kosztach relewantnych.*

## Zadania
Zadania do tego pojęcia: [[Velomia – trzy marże roweru Urban 5]] i [[Velomia – wielostopniowy rachunek marż]].

Pojęcie przydaje się też w: [Próg rentowności ilościowy, wartościowy i procentowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci%20ilo%C5%9Bciowy%2C%20warto%C5%9Bciowy%20i%20procentowy), [Velomia – zamówienie specjalne na Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20zam%C3%B3wienie%20specjalne%20na%20Urban%205).

## Jak to się łączy
Marżę liczymy z podziału na [koszty stałe i zmienne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny) (P − AVC). Dzieląc koszty stałe przez marżę na sztukę, otrzymujemy [próg rentowności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pr%C3%B3g%20rentowno%C5%9Bci): $Q_{BEP} = FC/(P - AVC)$. Marża jest podstawą prezentacji wyniku w [rachunku kosztów zmiennych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20zmiennych%20i%20pe%C5%82nych).
