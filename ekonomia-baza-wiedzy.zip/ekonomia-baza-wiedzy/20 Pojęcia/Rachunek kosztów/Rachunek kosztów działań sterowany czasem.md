---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Rentowność klientów"]
część-z: ["Rachunek kosztów działań"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["TDABC", "Równanie czasu", "Praktyczna zdolność"]
---
> [!abstract] Definicja
> TDABC (Kaplan, Anderson 2004) zastępuje ankiety o podziale czasu dwoma parametrami: stawką kosztu zdolności i równaniami czasu działań; koszt niewykorzystanych mocy widać wprost.

## Wyjaśnienie
1. **Stawka kosztu zdolności** = koszt zdolności / praktyczna zdolność (zwykle 80–85% czasu opłaconego).
2. **Równanie czasu** dla działania, np. $t = 20 + 30G + 60U + 90E$ (zmienne 0/1).
3. Koszt obiektu = czas × stawka.
4. Niewykorzystane moce = (zdolność − wykorzystanie) × stawka – **nie trafiają do produktów**.

![[r09_TDABC_wykorzystanie.png]]

| Cecha | ABC | TDABC |
|---|---|---|
| przypisanie zasobów | ankiety, wywiady | stawka i równania czasu |
| niewykorzystane moce | ukryte w stawkach | widoczne wprost |
| aktualizacja | kosztowna | zmiana równania lub stawki |

> [!warning] Dlaczego praktyczna zdolność?
> Stawka liczona na rzeczywistym wykorzystaniu przerzuca koszt nieużywanych zasobów na produkty – przy spadku popytu stawki rosną, ceny rosną, popyt spada dalej („spirala śmierci”).

## Przykład
Wsparcie techniczne Velomii: 1 440 000 zł / 645 120 min = **2,23 zł/min**. Zgłoszenie 60 min → **133,93 zł**. Wykorzystanie 527 000 min (81,7%), niewykorzystane 118 120 min ≈ 264 tys. zł.

## Na egzaminie
> [!question] Pytanie testowe
> Koszt działu 1 200 000 zł, zdolność 600 000 min. Koszt zgłoszenia 45 min? **90 zł** (stawka 2 zł/min).

## Zadania
Zadania do tego pojęcia: [[Velomia – TDABC działu wsparcia technicznego]].

## Jak to się łączy
TDABC to wariant [rachunku kosztów działań](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20dzia%C5%82a%C5%84). Liczy koszt obsługi każdego klienta, co pozwala ocenić [rentowność klientów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rentowno%C5%9B%C4%87%20klient%C3%B3w).
