---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Koszt stały i zmienny", "Koszt relewantny", "Hierarchia kosztów"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]", "[[RZ – Temat 1, istota rachunkowości zarządczej]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszty bezpośrednie i pośrednie", "Układ rodzajowy", "Obiekt kosztów"]
---
> [!abstract] Definicja
> Klasyfikacja kosztów to podział kosztów według kryterium dobranego do celu – „różne koszty do różnych celów” (J.M. Clark, 1923): nie istnieje jeden „prawdziwy” koszt produktu.

## Wyjaśnienie
| Kryterium | Przykłady (Velomia) | Zastosowanie |
|---|---|---|
| rodzaj (układ rodzajowy, zespół 4) | amortyzacja, materiały, usługi obce, wynagrodzenia | sprawozdawczość, struktura kosztów |
| funkcja i miejsce powstania (zespół 5) | produkcja, inżynieria, serwis, sprzedaż, zarząd | kontrola miejsc powstawania kosztów |
| przypisanie do obiektu | **bezpośrednie** i **pośrednie** wobec roweru, partii, klienta | kalkulacja |
| zachowanie wobec aktywności | zmienne, stałe, mieszane, schodkowe, sztywne | CVP, budżet elastyczny |
| znaczenie dla decyzji | istotne, utopione, alternatywne, uniknione | rachunki decyzyjne |
| kontrolowalność | kontrolowane / niekontrolowane przez kierownika | ocena menedżerów |

**Obiekt kosztów** – to, czego koszt mierzymy (produkt, partia, klient, kanał, projekt).

## Przykład
Ten sam rower Cargo 8 przy trzech metodach rozliczenia 8 mln zł kosztów pośrednich daje wynik +694 zł, −4 784 zł albo −7 902 zł – każdy wynika z innego założenia o tym, co kreuje koszty.

![[r08_ABC_trzy_metody.png]]

## Na egzaminie
> [!question] Pytanie otwarte
> Wyjaśnij zasadę „różne koszty do różnych celów” na przykładzie trzech klasyfikacji kosztów.

> [!success]- Odpowiedź (szkic)
> Ten sam koszt opisujemy różnie w zależności od pytania, np.: (1) według zachowania (stałe/zmienne) – do CVP i budżetu elastycznego; (2) według przypisania do obiektu (bezpośrednie/pośrednie) – do kalkulacji kosztu produktu; (3) według znaczenia dla decyzji (relewantne/utopione) – do rachunków decyzyjnych. Nie istnieje jeden „prawdziwy” koszt produktu (Clark).

## Zadania
Pojęcie przydaje się też w: [Velomia – trzy marże roweru Urban 5](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20trzy%20mar%C5%BCe%20roweru%20Urban%205).

## Jak to się łączy
Klasyfikacja według zachowania wobec aktywności to podział na [koszty stałe i zmienne](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny). Klasyfikacja według znaczenia dla decyzji wyodrębnia [koszt relewantny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20relewantny). Podział na koszty bezpośrednie i pośrednie rozwija [hierarchia kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Hierarchia%20koszt%C3%B3w).
