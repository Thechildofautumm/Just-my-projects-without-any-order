---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Hierarchia kosztów"]
wymaga: ["Rachunek kosztów działań sterowany czasem"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Krzywa wieloryba", "Whale curve"]
---
> [!abstract] Definicja
> Rentowność klientów to wynik na poszczególnych klientach po uwzględnieniu kosztów ich obsługi; uszeregowana tworzy krzywą wieloryba – niewielka grupa klientów generuje ponad 100% zysku.

## Wyjaśnienie
**Krzywa wieloryba** (Kaplan, Cooper 1998): klienci od najbardziej do najmniej rentownego, na osi pionowej skumulowany wynik. Typowo 20% najlepszych klientów generuje 150–300% zysku, a pozostali część go „oddają”.

![[r10_krzywa_wieloryba.png]]

**Działania wobec nierentownych klientów:** minimalna wartość zamówienia, płatne wsparcie poza standardem, szkolenia ograniczające liczbę zgłoszeń, przeniesienie najmniejszych klientów do dystrybutorów.

## Przykład
Velomia Serwis: 900 sklepów partnerskich; po TDABC 35% najlepszych przynosi 210% wyniku, pozostali „oddają” 110 p.p.

## Na egzaminie
> [!question] Pytanie otwarte
> Co pokazuje krzywa wieloryba i jakie decyzje może uzasadnić?

> [!success]- Odpowiedź (szkic)
> Krzywa wieloryba to skumulowany zysk z klientów uszeregowanych od najbardziej do najmniej rentownych: najlepsi dają ponad 100% zysku, reszta część go „oddaje” (w przykładzie Velomii 35% sklepów partnerskich daje 210% wyniku).
> Decyzje: minimalna wartość zamówienia, płatne wsparcie ponad standard, szkolenia ograniczające liczbę zgłoszeń, przeniesienie najmniejszych klientów do dystrybutorów.

## Zadania
Pojęcie przydaje się też w: [Velomia – TDABC działu wsparcia technicznego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Velomia%20%E2%80%93%20TDABC%20dzia%C5%82u%20wsparcia%20technicznego).

## Jak to się łączy
Koszty obsługi klientów liczy [TDABC](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rachunek%20koszt%C3%B3w%20dzia%C5%82a%C5%84%20sterowany%20czasem). To koszty poziomu klienta w [hierarchii kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Hierarchia%20koszt%C3%B3w).
