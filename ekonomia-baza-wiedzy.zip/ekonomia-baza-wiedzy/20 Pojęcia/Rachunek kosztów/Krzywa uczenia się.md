---
typ: pojęcie
up: "[[MOC Rachunek kosztów]]"
powiązane: ["Szacowanie funkcji kosztów", "Efekty skali", "Koszt przeciętny"]
źródło: ["[[RZ – Temat 2, koszty w ujęciu zarządczym]]"]
przedmiot: ["Rachunkowość zarządcza"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Efekt uczenia się", "Model Wrighta"]
---
> [!abstract] Definicja
> Krzywa uczenia się opisuje spadek średniego czasu (kosztu) pracy na sztukę wraz ze wzrostem skumulowanej produkcji; w modelu Wrighta przy każdym podwojeniu produkcji średni czas spada do r% poprzedniego poziomu.

## Wyjaśnienie
$$y = a\cdot x^{b}, \qquad b = \frac{\log r}{\log 2}$$
y – skumulowany średni czas na sztukę, a – czas pierwszej sztuki, x – skumulowana liczba sztuk, r – współczynnik uczenia się.

![[r05_krzywa_uczenia.png]]

| Sztuki | Średni czas | Czas łączny |
|---|---|---|
| 1 | 80,0 | 80,0 |
| 8 | 40,96 | 327,7 |
| 16 | 32,77 | 524,3 |
| 32 | 26,21 | 838,9 |

Zastosowania: wycena pierwszych zleceń, budżet pracy, koszt docelowy. Efekt wygasa, gdy proces się stabilizuje lub jest silnie zautomatyzowany.

## Przykład
Urban 9: a = 80 h, r = 80% → b = −0,3219. Sztuki 17–32: 838,9 − 524,3 = **314,6 h**, czyli 19,7 h/szt.

## Na egzaminie
> [!question] Zadanie typowe
> Ile wyniesie średni czas na sztukę dla 4 sztuk przy a = 100 h i r = 80%? *Odp.: 100 × 0,8² = 64 h.*

> [!warning] Pułapka
> Czas łączny kolejnej partii = czas łączny (po partii) − czas łączny (przed partią), a nie średnia × liczba sztuk w partii.

## Zadania
Zadania do tego pojęcia: [[Velomia – krzywa uczenia się roweru Urban 9]].

## Jak to się łączy
To szczególny przypadek [szacowania funkcji kosztów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Szacowanie%20funkcji%20koszt%C3%B3w) (funkcja potęgowa). Nie należy mylić jej z [efektami skali](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekty%20skali) – tu koszt spada dzięki doświadczeniu, a nie skali. Uczenie się obniża [koszt przeciętny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20przeci%C4%99tny) na sztukę w czasie.
