---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność mieszana popytu", "Pozacenowa determinanta popytu", "Efekt substytucji i efekt dochodowy"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Elastyczność popytu i przychody]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Substytut", "Dobro komplementarne", "Dobra niezależne"]
---
> [!abstract] Definicja
> Substytuty to dobra zaspokajające tę samą potrzebę i zastępujące się nawzajem; dobra komplementarne to dobra używane razem, uzupełniające się.

## Wyjaśnienie
| Relacja | Wzrost ceny Y → popyt na X | Elastyczność mieszana | Przykład |
|---|---|---|---|
| **substytuty** | rośnie | $E_m > 0$ | masło – margaryna, jabłka – pomarańcze |
| **komplementy** | spada | $E_m < 0$ | samochód – benzyna, piec gazowy – gaz |
| **niezależne** | bez zmian | $E_m = 0$ | chleb – telewizor |

W teorii konsumenta substytucyjność jest też ogólną cechą wyboru: konsument może zastępować jedne dobra innymi, zachowując zadowolenie (krzywa obojętności).

## Przykład
Przykład (masło i margaryna): cena masła rośnie z 20 do 25 zł (+25%), ilość margaryny rośnie ze 100 do 135 (+35%) → $E_m = 1{,}4 > 0$ → **substytuty**.

## Na egzaminie
> [!question] Pytanie testowe
> $E_m = -5$. Jakie to dobra? **Komplementarne.**

## Zadania
Pojęcie przydaje się też w: [Rynek pelletu – nowe tartaki i droższe kotły](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20pelletu%20%E2%80%93%20nowe%20tartaki%20i%20dro%C5%BCsze%20kot%C5%82y), [Krem z filtrem – łączny wpływ determinant popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krem%20z%20filtrem%20%E2%80%93%20%C5%82%C4%85czny%20wp%C5%82yw%20determinant%20popytu).

## Jak to się łączy
Rodzaj powiązania rozpoznajemy po znaku [elastyczności mieszanej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20mieszana%20popytu). Zmiana ceny substytutu lub komplementu jest [pozacenową determinantą popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu) – przesuwa krzywą D. Z tego samego zjawiska – zastępowania dobra droższego tańszym – wynika [efekt substytucji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Efekt%20substytucji%20i%20efekt%20dochodowy) w teorii konsumenta.
