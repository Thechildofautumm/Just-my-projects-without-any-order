---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność cenowa popytu", "Krzywa cena–konsumpcja"]
część-z: ["Rynek"]
przeciwieństwo: ["Podaż"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Prawo popytu", "Krzywa popytu", "Funkcja popytu", "Wielkość popytu", "Popyt rynkowy", "D"]
---
> [!abstract] Definicja
> Popyt to zależność między ceną dobra a ilością, jaką nabywcy chcą i mogą kupić w danym okresie (ceteris paribus).

## Wyjaśnienie
**Prawo popytu:** wraz ze wzrostem ceny wielkość popytu maleje, a wraz ze spadkiem – rośnie (zależność odwrotna).

> [!warning] Popyt ≠ wielkość popytu
> **Popyt** (funkcja popytu) to cała krzywa D. **Wielkość popytu** to ilość przy konkretnej cenie (punkt na krzywej). Zmiana ceny = ruch **wzdłuż** krzywej; zmiana innego czynnika = **przesunięcie** krzywej. Zawsze podawaj okres (tydzień, miesiąc, rok).

Typowe zapisy liniowe:
$$Q_D = a - bP \;\Longleftrightarrow\; P = \frac{a}{b} - \frac{1}{b}Q \quad\text{(odwrócona funkcja popytu)}$$
- $P_{max}$ – podstaw Q = 0; $Q_{max}$ – podstaw P = 0.
- Przykład: $Q = 120 - 2P \Rightarrow P = 60 - 0{,}5Q$.

**Popyt rynkowy** = suma (pozioma) popytów indywidualnych przy tej samej cenie.

![[m03_popyt_rynkowy_suma.png]]

## Przykład
Popyt na papierosy $Q = 60 - P$: przy P = 20 nabywcy chcą kupić 40 paczek, przy P = 45 – tylko 15.

## Na egzaminie
> [!question] Pytanie testowe
> Wzrost ceny kawy spowodował spadek kupowanej ilości kawy. Czy zmienił się popyt na kawę? **Nie – zmieniła się wielkość popytu (ruch wzdłuż krzywej).**

## Zadania
Pojęcie przydaje się też w: [Rynek rowerów – równowaga i cena poniżej równowagi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20rower%C3%B3w%20%E2%80%93%20r%C3%B3wnowaga%20i%20cena%20poni%C5%BCej%20r%C3%B3wnowagi), [Funkcja popytu z dwóch optimów konsumenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20popytu%20z%20dw%C3%B3ch%20optim%C3%B3w%20konsumenta).

## Jak to się łączy
Popyt jest jednym z elementów [rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek), a jego przeciwną stroną jest [podaż](obsidian://open?vault=ekonomia-baza-wiedzy&file=Poda%C5%BC) – razem wyznaczają cenę. Siłę reakcji popytu na cenę mierzy [elastyczność cenowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu). Skąd bierze się opadająca krzywa popytu, pokazuje teoria konsumenta: krzywą popytu indywidualnego wyprowadzamy z [krzywej cena–konsumpcja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20cena%E2%80%93konsumpcja).
