---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Równowaga monopolu", "Koszt marginalny"]
wymaga: ["Elastyczność a przychód", "Maksymalizacja zysku"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Mark-up", "Współczynnik narzutu", "Cena optymalna"]
---
> [!abstract] Definicja
> Cena maksymalizująca zysk to koszt krańcowy pomnożony przez współczynnik narzutu zależny od elastyczności: P = MC·Ep/(Ep + 1).

## Wyjaśnienie
Z $MR = P(1 + 1/E_p)$ i $MR = MC$:
$$P = \frac{MC}{1 + 1/E_p} = MC\cdot\frac{E_p}{E_p + 1}$$

| $E_p$ | Współczynnik narzutu | Cena |
|---|---|---|
| −1,4 | 3,5 | 3,5 × MC |
| −1,5 | 3 | 3 × MC |
| −2 | 2 | 2 × MC |
| −2,5 | 1,67 | 1,67 × MC |
| → −∞ | → 1 | → MC (konkurencja doskonała) |

![[e04_narzut_vs_elastycznosc.png]]

Im bardziej elastyczny popyt (więcej substytutów), tym mniejszy narzut.

## Przykład
Przykład (kubki): MC = 4, Ep = −3 → $P = 4\cdot\frac{-3}{-2} = 6$ zł.
Przykład (puzzle): MC = 15, Ep = −1,25 → $P = 15\cdot\frac{-1{,}25}{-0{,}25} = 75$ zł.

## Na egzaminie
> [!question] Pytanie testowe
> Dlaczego wzoru nie da się użyć przy |Ep| < 1? *Odp.: wychodzi ujemny narzut – przy nieelastycznym popycie MR < 0, więc firma maksymalizująca zysk nie wybiera takiego punktu.*

## Zadania
Zadania do tego pojęcia: [[Kubki z nadrukiem – cena z narzutem na koszt krańcowy]] i [[Puzzle – wysoki narzut przy słabo elastycznym popycie]].

Pojęcie przydaje się też w: [Słuchawki bezprzewodowe – stała elastyczność i narzut](obsidian://open?vault=ekonomia-baza-wiedzy&file=S%C5%82uchawki%20bezprzewodowe%20%E2%80%93%20sta%C5%82a%20elastyczno%C5%9B%C4%87%20i%20narzut).

## Jak to się łączy
Wzór łączy dwie zależności: [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = P(1 + 1/Ep)) oraz warunek [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC. Bazą narzutu jest [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny), a nie koszt przeciętny. To praktyczna wersja [równowagi monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20monopolu): firma z siłą rynkową ustala cenę powyżej MC tym wyżej, im mniej elastyczny jest popyt.
