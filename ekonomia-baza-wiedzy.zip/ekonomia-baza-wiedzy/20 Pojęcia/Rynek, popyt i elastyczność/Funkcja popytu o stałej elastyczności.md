---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność punktowa", "Narzut ceny na koszt krańcowy"]
część-z: ["Elastyczność cenowa popytu"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Potęgowa funkcja popytu", "Stała elastyczność"]
---
> [!abstract] Definicja
> Funkcja popytu o stałej elastyczności ma postać potęgową Q = k·P^α; w każdym jej punkcie elastyczność cenowa równa się wykładnikowi α.

## Wyjaśnienie
Dla $Q = kP^{\alpha}$: $E_p = Q'(P)\cdot\frac{P}{Q} = \alpha k P^{\alpha-1}\cdot\frac{P}{kP^{\alpha}} = \alpha$.

Gdy funkcja ma kilka zmiennych w postaci potęgowej, **każdy wykładnik to elastyczność względem danej zmiennej**:
$$Q = 1{,}5\,I^{0{,}2}P^{-0{,}8}P_y^{0{,}9}m^{0{,}7}$$
→ $E_I = 0{,}2$ (normalne), $E_p = -0{,}8$ (nieelastyczny), $E_m = 0{,}9$ (inne alkohole to substytuty), elastyczność względem mocy piwa 0,7.

![[e05_popyt_stala_elastycznosc.png]]

## Przykład
Przykład (słuchawki): $Q = 20P^{-3}$ → $E_p = -3$ (elastyczny). Wzrost ceny o 10% → spadek sprzedaży o ok. 30%. Narzut: $\frac{-3}{-2} = 1{,}5$ → przy MC = 200 → **P = 300**.

## Na egzaminie
> [!question] Pytanie testowe
> Jaka jest elastyczność cenowa popytu $Q = 50P^{-1{,}5}$ przy P = 4? **−1,5 – taka sama w każdym punkcie.**

## Zadania
Zadania do tego pojęcia: [[Kawa mrożona – potęgowa funkcja popytu]] i [[Słuchawki bezprzewodowe – stała elastyczność i narzut]].

## Jak to się łączy
To szczególny kształt krzywej popytu w ramach [elastyczności cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu). Stanowi przeciwieństwo popytu liniowego, dla którego [elastyczność punktowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20punktowa) zmienia się w każdym punkcie. Ponieważ Ep jest stała, stały jest też optymalny [narzut ceny na koszt krańcowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Narzut%20ceny%20na%20koszt%20kra%C5%84cowy).
