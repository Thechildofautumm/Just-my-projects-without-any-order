---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność a przychód", "Konkurencja doskonała"]
część-z: ["Elastyczność popytu"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Ep", "Popyt elastyczny", "Popyt nieelastyczny"]
---
> [!abstract] Definicja
> Elastyczność cenowa popytu mierzy, o ile procent zmieni się wielkość popytu na dobro, gdy jego cena zmieni się o 1% (ceteris paribus).

## Wyjaśnienie
$$E_p = \frac{\Delta Q_x}{\Delta P_x}\cdot\frac{P_x}{Q_x} = Q'(P)\cdot\frac{P}{Q} \quad (E_p < 0)$$

| $\lvert E_p\rvert$ | Popyt | Reakcja |
|---|---|---|
| 0 | doskonale nieelastyczny | pionowa krzywa |
| (0; 1) | **nieelastyczny** | %ΔQ < %ΔP |
| 1 | jednostkowy | %ΔQ = %ΔP |
| > 1 | **elastyczny** | %ΔQ > %ΔP |
| ∞ | doskonale elastyczny | pozioma krzywa |

![[07_elastycznosc_przypadki_skrajne.png]]

**Determinanty:** dostępność **substytutów** (więcej → bardziej elastyczny), **udział wydatków w dochodzie** (większy → bardziej elastyczny), **czas** (w dłuższym okresie – bardziej elastyczny).

## Przykład
$E_p = -2$: wzrost ceny o 1% → spadek wielkości popytu o 2% (elastyczny). $E_p = -0{,}5$: spadek o 0,5% (nieelastyczny).

## Na egzaminie
> [!question] Pytanie testowe
> Dlaczego popyt na sól jest nieelastyczny? *Odp.: brak bliskich substytutów i znikomy udział w budżecie.*

## Zadania
Zadania do tego pojęcia: [[Interpretacja współczynników elastyczności]] i [[Olej napędowy – łączny wpływ ceny i dochodu]].

Pojęcie przydaje się też w: [Miesięcznik podróżniczy – elastyczności mieszane](obsidian://open?vault=ekonomia-baza-wiedzy&file=Miesi%C4%99cznik%20podr%C3%B3%C5%BCniczy%20%E2%80%93%20elastyczno%C5%9Bci%20mieszane).

## Jak to się łączy
To najważniejszy z trzech rodzajów [elastyczności popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu). Od wartości |Ep| zależy, czy obniżka ceny zwiększy, czy zmniejszy przychód – patrz [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d). Skrajny przypadek |Ep| = ∞ to popyt na produkt pojedynczej firmy w [konkurencji doskonałej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Konkurencja%20doskona%C5%82a).
