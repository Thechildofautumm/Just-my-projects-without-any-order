---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Krzywa podaży przedsiębiorstwa", "Koszt marginalny"]
część-z: ["Rynek"]
przeciwieństwo: ["Popyt"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Prawo podaży", "Krzywa podaży", "Funkcja podaży", "S"]
---
> [!abstract] Definicja
> Podaż to zależność między ceną dobra a ilością, jaką producenci chcą i mogą zaoferować w danym okresie (ceteris paribus).

## Wyjaśnienie
**Prawo podaży:** wzrost ceny rynkowej prowadzi do wzrostu oferowanej ilości, spadek ceny – do jej zmniejszenia (zależność wprost).

Zapis liniowy: $P = c + dQ_S$ (np. $P = 0{,}25Q$, $P = 2Q + 2$).

Dlaczego krzywa podaży rośnie? Bo producent zwiększa produkcję tylko wtedy, gdy cena pokrywa rosnący koszt wytworzenia kolejnej jednostki – w konkurencji doskonałej krzywa podaży firmy to część krzywej MC.

![[m04_podaz_galezi_suma_MC.png]]

## Przykład
Podaż pralek $P = 4Q$: przy cenie 4800 producenci oferują 1200 sztuk, przy cenie 2000 – tylko 500.

## Na egzaminie
> [!question] Pytanie testowe
> Spadek ceny stali obniżył koszty producentów samochodów. Czy to ruch wzdłuż krzywej podaży samochodów? **Nie – przesunięcie krzywej podaży w prawo (zmiana ceny czynnika produkcji).**

## Zadania
Pojęcie przydaje się też w: [Rynek lodówek – cena administracyjna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20lod%C3%B3wek%20%E2%80%93%20cena%20administracyjna).

## Jak to się łączy
Podaż jest drugim, obok popytu, elementem [rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek), a jej przeciwnością jest [popyt](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt). Podaż gałęzi to suma krzywych [podaży poszczególnych przedsiębiorstw](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20poda%C5%BCy%20przedsi%C4%99biorstwa), a każda z nich odzwierciedla rosnący [koszt marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20marginalny).
