---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Równowaga monopolu"]
wymaga: ["Elastyczność cenowa popytu", "Przychód"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["MR a elastyczność", "TR max"]
---
> [!abstract] Definicja
> Przychód marginalny zależy od ceny i elastyczności: MR = P(1 + 1/Ep), dlatego to elastyczność decyduje, czy obniżka ceny zwiększy przychód.

## Wyjaśnienie
$$\boxed{MR = P\left(1 + \frac{1}{E_p}\right)}$$

| $\lvert E_p\rvert$ | MR | Obniżka ceny | Podwyżka ceny |
|---|---|---|---|
| > 1 (elastyczny) | > 0 | **TR ↑** | TR ↓ |
| = 1 | = 0 | TR max | TR max |
| < 1 (nieelastyczny) | < 0 | TR ↓ | **TR ↑** |

![[09_elastycznosc_a_przychody.png]]

**MR dla łuku:** za P bierzemy cenę średnią, za Ep – elastyczność łukową: $MR = P_{śr}(1 + 1/E_Ł)$; kontrola: $MR = \Delta TR/\Delta Q$.

## Przykład
Przykład (zeszyty): $P_{śr} = 500$, $E_Ł = -2{,}5$ → $MR = 500(1 - 0{,}4) = 300$. Kontrola: $\frac{55\,200 - 43\,200}{120 - 80} = 300$ ✔.

## Na egzaminie
> [!question] Pytanie otwarte
> Co powinien zrobić sklep z ceną masła (Ep = −0,3) i łososia (Ep = −2,2), by zwiększyć przychody? *Odp.: masło – podnieść cenę; łosoś – obniżyć.*

> [!warning] Pułapka
> Maksymalizacja przychodu (MR = 0) to nie to samo co maksymalizacja zysku (MR = MC).

## Zadania
Pojęcie przydaje się też w: [Masło, łosoś i ser – rodzaj dobra i polityka cenowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mas%C5%82o%2C%20%C5%82oso%C5%9B%20i%20ser%20%E2%80%93%20rodzaj%20dobra%20i%20polityka%20cenowa), [Zeszyty – elastyczność łukowa i przychód marginalny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zeszyty%20%E2%80%93%20elastyczno%C5%9B%C4%87%20%C5%82ukowa%20i%20przych%C3%B3d%20marginalny), [Maksymalny przychód przy popycie liniowym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalny%20przych%C3%B3d%20przy%20popycie%20liniowym), [Ekspresy do kawy – elastyczność przy maksymalnym przychodzie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ekspresy%20do%20kawy%20%E2%80%93%20elastyczno%C5%9B%C4%87%20przy%20maksymalnym%20przychodzie), [Przychód przy cenie 4000](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d%20przy%20cenie%204000), [Cena maksymalizująca utarg – dwa rynki](obsidian://open?vault=ekonomia-baza-wiedzy&file=Cena%20maksymalizuj%C4%85ca%20utarg%20%E2%80%93%20dwa%20rynki), [Linia promowa – podnieść czy obniżyć cenę](obsidian://open?vault=ekonomia-baza-wiedzy&file=Linia%20promowa%20%E2%80%93%20podnie%C5%9B%C4%87%20czy%20obni%C5%BCy%C4%87%20cen%C4%99).

## Jak to się łączy
Wzór łączy [elastyczność cenową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu) z przychodem marginalnym opisanym w notatce [Przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d). Z niego wynika ważny wniosek dla [równowagi monopolu](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20monopolu): ponieważ MC > 0, a w optimum MR = MC, monopol zawsze działa na **elastycznym** odcinku popytu (gdzie MR > 0).
