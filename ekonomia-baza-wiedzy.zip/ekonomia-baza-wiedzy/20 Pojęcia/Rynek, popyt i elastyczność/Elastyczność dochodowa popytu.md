---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Krzywa Engla", "Dobro Giffena"]
część-z: ["Elastyczność popytu"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Decyzje konsumenta i popyt]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Dobro normalne", "Dobro podrzędne", "Dobro luksusowe", "Dobro podstawowe"]
---
> [!abstract] Definicja
> Elastyczność dochodowa mierzy, o ile procent zmieni się popyt na dobro, gdy dochód konsumenta wzrośnie o 1%; jej wartość wyznacza rodzaj dobra.

## Wyjaśnienie
$$E_M = \frac{\Delta Q}{\Delta M}\cdot\frac{M}{Q} = Q'(M)\cdot\frac{M}{Q}$$

```mermaid
flowchart TD
  EM["Elastyczność dochodowa E_M"] --> N{"E_M > 0?"}
  N -- "tak: dobro NORMALNE" --> L{"E_M > 1?"}
  N -- "nie: dobro PODRZĘDNE" --> G["skrajny przypadek: dobro Giffena"]
  L -- "tak" --> LUX["LUKSUSOWE (wyższego rzędu)"]
  L -- "nie" --> POD["PODSTAWOWE (pierwszej potrzeby)"]
```

**Prawidłowości z badań (Engel):** żywność $E_M < 1$ (udział w budżecie maleje wraz z bogaceniem się); odzież, mieszkanie, energia $E_M \approx 1$; samochody, elektronika, edukacja, podróże $E_M > 1$.

## Przykład
Przykład: masło $E_M = 0{,}4$ (pierwszej potrzeby), łosoś 1,9 (luksusowe), ser żółty 0,8 (pierwszej potrzeby) – wszystkie normalne.

## Na egzaminie
> [!question] Pytanie testowe
> $E_M = -0{,}8$. Jakie to dobro? **Podrzędne.** $E_M = 1{,}5$? **Normalne, luksusowe.**

> [!warning] Pułapka
> Dobro podstawowe jest **normalne** (EM > 0) – nie myl „podstawowego” z „podrzędnym”.

## Zadania
Zadania do tego pojęcia: [[Masło, łosoś i ser – rodzaj dobra i polityka cenowa]].

Pojęcie przydaje się też w: [Interpretacja współczynników elastyczności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interpretacja%20wsp%C3%B3%C5%82czynnik%C3%B3w%20elastyczno%C5%9Bci), [Krzywa Engla dla funkcji Cobba-Douglasa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20Engla%20dla%20funkcji%20Cobba-Douglasa), [Olej napędowy – łączny wpływ ceny i dochodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Olej%20nap%C4%99dowy%20%E2%80%93%20%C5%82%C4%85czny%20wp%C5%82yw%20ceny%20i%20dochodu).

## Jak to się łączy
To trzeci rodzaj [elastyczności popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu). Graficznie przedstawia ją [krzywa Engla](obsidian://open?vault=ekonomia-baza-wiedzy&file=Krzywa%20Engla): jej kształt (wypukła, liniowa, wklęsła, opadająca) odpowiada wartości EM. Skrajnym przypadkiem dobra podrzędnego jest [dobro Giffena](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dobro%20Giffena).
