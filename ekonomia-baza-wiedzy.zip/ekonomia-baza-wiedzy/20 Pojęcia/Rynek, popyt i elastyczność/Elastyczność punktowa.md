---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność łukowa", "Przychód"]
część-z: ["Elastyczność cenowa popytu"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Elastyczność w punkcie"]
---
> [!abstract] Definicja
> Elastyczność punktowa mierzy reakcję popytu w konkretnym punkcie krzywej popytu; dla liniowej krzywej zmienia się od −∞ do 0.

## Wyjaśnienie
Dla liniowego popytu (formuły z wykładu):
$$\boxed{E_p = \frac{P}{P - P_{max}} = \frac{Q - Q_{max}}{Q}}$$
- formuła „na osi pionowej” – potrzebujesz P i Pmax,
- formuła „na osi poziomej” – potrzebujesz Q i Qmax,
- ogólnie: $E_p = Q'(P)\cdot P/Q$.

![[06_elastycznosc_na_krzywej_liniowej.png]]

W połowie krzywej ($\tfrac12 P_{max}$, $\tfrac12 Q_{max}$): |Ep| = 1. Powyżej – popyt elastyczny, poniżej – nieelastyczny. Geometrycznie |Ep| to stosunek odcinków na osiach:

![[m01_elastycznosc_punktowa_geometria.png]]

## Przykład
Przykład: $P = -3Q + 900$ → $Q_{max} = 300$, $P_{max} = 900$. Gdzie $E_p = -2$?
$-2 = \frac{Q - 300}{Q} \Rightarrow Q = 100$; $-2 = \frac{P}{P - 900} \Rightarrow P = 600$.

## Na egzaminie
> [!question] Zadanie typowe
> Dla P = 60 popyt Q = 0, a MR = 0 przy Q = 15. Podaj Ep przy P = 20. *Odp.: Pmax = 60, Ep = 20/(20 − 60) = −0,5.*

> [!warning] Pułapka
> Liniowa krzywa popytu **nie** ma stałej elastyczności, mimo stałego nachylenia. Nachylenie ≠ elastyczność.

## Zadania
Zadania do tego pojęcia: [[Ilość, przy której elastyczność wynosi −2]], [[Ekspresy do kawy – elastyczność przy maksymalnym przychodzie]], [[Elastyczność i przychód przy cenie 20]], [[Elastyczność wyznaczona z przychodu marginalnego]], [[Przychód przy cenie 4000]], [[Ilość przy zerowym przychodzie marginalnym]] i [[Równania AR, MR i TR z dwóch informacji]].

## Jak to się łączy
To jeden ze sposobów pomiaru [elastyczności cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu); drugi – dla odcinka – to [elastyczność łukowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20%C5%82ukowa). Punkt |Ep| = 1 nie jest przypadkowy: dokładnie tam przychód całkowity osiąga maksimum, bo MR = 0 – patrz [przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d).
