---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Popyt", "Elastyczność a przychód"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Elastyczność", "Współczynnik elastyczności"]
---
> [!abstract] Definicja
> Elastyczność popytu to miara względnej reakcji popytu: stosunek procentowej zmiany wielkości popytu do procentowej zmiany czynnika, który ją wywołał.

## Wyjaśnienie
$$E = \frac{\%\Delta Q}{\%\Delta Z} = \frac{\Delta Q}{\Delta Z}\cdot\frac{Z}{Q} = Q'(Z)\cdot\frac{Z}{Q}$$

| Rodzaj | Czynnik Z | Klasyfikacja |
|---|---|---|
| cenowa $E_p$ | cena tego dobra | zawsze < 0 |
| mieszana $E_m$ | cena innego dobra | > 0 substytuty, < 0 komplementy, = 0 niezależne |
| dochodowa $E_M$ ($E_I$) | dochód | < 0 podrzędne; 0–1 podstawowe; > 1 luksusowe |

> [!info] Interpretacja – zawsze tak samo
> „Jeżeli Z wzrośnie o **1%**, wielkość popytu zmieni się o **E%** (ceteris paribus).”

**Łączny wpływ kilku zmian** (ekonomia menedżerska): procentowe efekty sumujemy:
$$\%\Delta Q \approx E_p\cdot\%\Delta P + E_M\cdot\%\Delta I + E_m\cdot\%\Delta P_y$$

## Przykład
Przykład (olej napędowy): $E_p = -0{,}25$, $E_I = 0{,}3$; cena −8%, dochody +5%:
$x = -0{,}25\cdot(-8\%) = 2\%$, $y = 0{,}3\cdot 5\% = 1{,}5\%$ → popyt rośnie o **3,5%**.

## Na egzaminie
> [!question] Zadanie typowe
> Miesięcznik: $E_p = -0{,}6$; $E_m$ względem konkurenta 1,5; względem przewodników −0,4. Cena własna −10%, konkurenta −12%, przewodników −15%. *Odp.: 6% − 18% + 6% = **−6%**.*

> [!warning] Pułapka
> Uważaj na znaki: spadek ceny (−10%) pomnożony przez ujemną Ep daje **dodatni** efekt.

## Zadania
Pojęcie przydaje się też w: [Olej napędowy – łączny wpływ ceny i dochodu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Olej%20nap%C4%99dowy%20%E2%80%93%20%C5%82%C4%85czny%20wp%C5%82yw%20ceny%20i%20dochodu).

## Jak to się łączy
Elastyczność opisuje kształt i reakcję krzywej [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) w liczbach względnych, niezależnych od jednostek. Jej najważniejszym zastosowaniem praktycznym jest przewidywanie, jak zmiana ceny wpłynie na przychody firmy – patrz [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d).
