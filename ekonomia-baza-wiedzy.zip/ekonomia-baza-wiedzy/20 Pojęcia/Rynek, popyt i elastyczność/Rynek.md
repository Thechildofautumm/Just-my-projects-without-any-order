---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Równowaga rynkowa", "Struktura rynkowa"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Gospodarka rynkowa", "Mechanizm rynkowy"]
---
> [!abstract] Definicja
> Rynek to miejsce i proces koordynowania decyzji kupujących i sprzedających za pomocą cen – mechanizm, który decyduje o alokacji zasobów.

## Wyjaśnienie
Rynek to jednocześnie:
1. miejsce transakcji kupna–sprzedaży dóbr lub czynników produkcji,
2. proces koordynowania decyzji kupujących i sprzedających (sygnałem są **ceny**),
3. mechanizm rynkowy decydujący o alokacji zasobów.

**Model gospodarki rynkowej** (większość zasobów jest własnością prywatną): dwie grupy podmiotów – gospodarstwa domowe i przedsiębiorstwa – oraz dwa rynki – dóbr (konsumpcyjnych i kapitałowych) i zasobów (czynników produkcji).

```mermaid
flowchart LR
  GD["Gospodarstwa domowe"] -- "wydatki" --> RD["Rynek dóbr"]
  RD -- "przychody" --> P["Przedsiębiorstwa"]
  P -- "dobra i usługi" --> RD
  RD -- "dobra i usługi" --> GD
  GD -- "praca, kapitał, ziemia" --> RZ["Rynek zasobów"]
  RZ -- "czynniki produkcji" --> P
  P -- "płace, odsetki, renty" --> RZ
  RZ -- "dochody" --> GD
```

Elementy rynku: **popyt, podaż, cena**.

## Przykład
Na rynku pracy gospodarstwa domowe są sprzedawcami (oferują pracę), a firmy – kupującymi; na rynku dóbr role się odwracają.

## Na egzaminie
> [!question] Pytanie testowe
> Wymień trzy elementy rynku. **Popyt, podaż, cena.**

## Jak to się łączy
Mechanizm rynkowy prowadzi do stanu, w którym plany kupujących i sprzedających są zgodne – to [równowaga rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20rynkowa). Rynki różnią się liczbą firm, rodzajem produktu i barierami wejścia, czyli [strukturą rynkową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Struktura%20rynkowa) – od konkurencji doskonałej po monopol.
