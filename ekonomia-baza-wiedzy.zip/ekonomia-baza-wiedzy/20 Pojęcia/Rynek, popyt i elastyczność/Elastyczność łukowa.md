---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność punktowa", "Elastyczność a przychód"]
część-z: ["Elastyczność cenowa popytu"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Elastyczność odcinkowa", "EŁ"]
---
> [!abstract] Definicja
> Elastyczność łukowa mierzy reakcję popytu na odcinku (łuku) krzywej między dwoma punktami, licząc zmiany względem średnich wartości.

## Wyjaśnienie
$$\boxed{E_Ł = \frac{Q_2 - Q_1}{Q_2 + Q_1}\cdot\frac{P_2 + P_1}{P_2 - P_1}}$$
Dzięki średnim wynik nie zależy od kierunku zmiany (500→460 daje to samo co 460→500).

**Procedura:** 1) z funkcji popytu policz Q₁ i Q₂, 2) podstaw do wzoru, 3) zinterpretuj.

![[m02_elastycznosc_lukowa.png]]

## Przykład
Przykład (zeszyty): $P = -2Q + 700$, cena 540 → 460 ⇒ Q₁ = 80, Q₂ = 120:
$E_Ł = \frac{40}{200}\cdot\frac{1000}{-80} = -2{,}5$ → popyt elastyczny na tym odcinku.

## Na egzaminie
> [!question] Pytanie testowe
> Dlaczego w elastyczności łukowej używa się sum (średnich) zamiast wartości początkowych? *Odp.: żeby wynik był taki sam niezależnie od kierunku zmiany.*

## Zadania
Zadania do tego pojęcia: [[Zeszyty – elastyczność łukowa i przychód marginalny]].

Pojęcie przydaje się też w: [Batony – przychód marginalny w punkcie i na odcinku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Batony%20%E2%80%93%20przych%C3%B3d%20marginalny%20w%20punkcie%20i%20na%20odcinku).

## Jak to się łączy
Jest drugą, obok [elastyczności punktowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20punktowa), metodą pomiaru [elastyczności cenowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu) – stosujemy ją, gdy znamy dwa punkty, a nie jeden. Elastyczność łukowa jest potrzebna do policzenia przychodu marginalnego dla zmiany ceny: $MR = P_{śr}(1 + 1/E_Ł)$ – patrz [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d).
