---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Koszt stały i zmienny"]
wymaga: ["Elastyczność a przychód"]
przeciwieństwo: ["Maksymalizacja zysku"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Maksymalizacja utargu", "TRmax"]
---
> [!abstract] Definicja
> Maksymalizacja przychodu (utargu) to wybór ceny i ilości, przy których TR jest największy: MR = 0, czyli Ep = −1.

## Wyjaśnienie
Warunek: $MR = 0 \Leftrightarrow E_p = Q'(P)\cdot\frac{P}{Q} = -1$.

Celem menedżera powinien być **zysk**, a nie przychód. Oba cele pokrywają się tylko, gdy:
- firma w danym okresie **nie ponosi kosztów produkcji** (np. sprzedaje zapasy z poprzedniego okresu),
- firma ponosi **wyłącznie koszty stałe**, niezależne od Q (koncert w hali, przewoźnik na regularnej linii).

![[e03_max_przychodu_vs_zysku.png]]

## Przykład
Przykład (festiwal): $Q = -20P + 9000$, amfiteatr na 7000 miejsc.
$E_p = \frac{-20P}{-20P + 9000} = -1 \Rightarrow P = 225$, Q = 4500, **TR = 1 012 500**.
Gdyby zapełnić amfiteatr: P = 100, TR = 700 000 – mniej!

## Na egzaminie
> [!question] Pytanie otwarte
> Armator ponosi tylko koszty stałe; przy obecnej cenie Ep = −0,6. Co zrobić z ceną? *Odp.: maksymalizacja zysku = maksymalizacja utargu; popyt nieelastyczny → podnieść cenę, aż |Ep| = 1.*

## Zadania
Zadania do tego pojęcia: [[Festiwal w amfiteatrze – cena maksymalizująca wpływy]], [[Cena maksymalizująca utarg – dwa rynki]] i [[Linia promowa – podnieść czy obniżyć cenę]].

Pojęcie przydaje się też w: [Producent dronów – funkcja zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Producent%20dron%C3%B3w%20%E2%80%93%20funkcja%20zysku).

## Jak to się łączy
Warunek TRmax wynika bezpośrednio z relacji opisanej w [elastyczności a przychodzie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d) (MR = 0 przy |Ep| = 1). Jest przeciwieństwem [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) – inny cel daje inne Q (np. producent dronów: 4,2 vs 3). Cele zbiegają się tylko wtedy, gdy firma ma wyłącznie koszty stałe – patrz [koszt stały i zmienny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20sta%C5%82y%20i%20zmienny).
