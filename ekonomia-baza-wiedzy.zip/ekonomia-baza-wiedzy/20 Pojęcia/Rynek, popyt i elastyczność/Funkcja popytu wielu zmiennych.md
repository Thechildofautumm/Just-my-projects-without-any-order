---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Pozacenowa determinanta popytu", "Elastyczność popytu"]
część-z: ["Popyt"]
źródło: ["[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Różniczka zupełna", "Determinanty popytu – ujęcie analityczne"]
---
> [!abstract] Definicja
> Funkcja popytu wielu zmiennych opisuje ilość nabywaną jako funkcję wszystkich determinant: Q = f(P, I, Py, N, A, …); łączną zmianę popytu liczymy z różniczki zupełnej.

## Wyjaśnienie
Determinanty: cena dobra P, dochód I, ceny substytutów i komplementów Py, liczba konsumentów N, wydatki na reklamę A i inne.

Gdy zmienia się kilka determinant jednocześnie:
$$dQ = \frac{\partial Q}{\partial P}dP + \frac{\partial Q}{\partial I}dI + \frac{\partial Q}{\partial P_y}dP_y + \dots$$
(suma iloczynów pochodnych cząstkowych i zmian zmiennych).

Znak współczynnika mówi o rodzaju zależności: dodatni przy cenie innego dobra → substytut, ujemny → komplement; dodatni przy dochodzie → dobro normalne.

## Przykład
Przykład (truskawki): $Q = -3P + 0{,}2I + 0{,}4P_y$; cena +1 zł, dochód −40 zł, cena malin +10 zł:
$dQ = -3\cdot 1 + 0{,}2\cdot(-40) + 0{,}4\cdot 10 = -7$ → popyt spada o **7 jednostek**.

## Na egzaminie
> [!question] Zadanie typowe
> $Q = -30P + 2I + 25P_s - 10P_k + 0{,}1A + 500$. Łączny wpływ: P +4, I +300, Ps −2, Pk −6, A +8000. *Odp.: dQ = −120 + 600 − 50 + 60 + 800 = +1290.*

> [!warning] Pułapka
> Uważaj na znaki zmian: spadek ceny komplementu (dPk = −10) przy współczynniku −15 daje **wzrost** popytu (+150).

## Zadania
Zadania do tego pojęcia: [[Truskawki – różniczka zupełna popytu]] i [[Krem z filtrem – łączny wpływ determinant popytu]].

## Jak to się łączy
To pełny, analityczny zapis [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt): krzywa popytu P–Q jest tylko jego przekrojem przy stałych pozostałych zmiennych. Każdy argument funkcji poza ceną to [pozacenowa determinanta popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu). Pochodne cząstkowe tej funkcji są podstawą do liczenia elastyczności – patrz [elastyczność popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu): $E = Q'(x)\cdot x/Q$.
