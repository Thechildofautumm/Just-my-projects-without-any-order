---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Interwencja państwa na rynku"]
przeciwieństwo: ["Równowaga rynkowa"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Niedobór", "Nadmiar", "Nadwyżka podaży", "Cena maksymalna", "Cena minimalna"]
---
> [!abstract] Definicja
> Nierównowaga rynkowa występuje, gdy cena różni się od ceny równowagi: przy cenie niższej powstaje niedobór (Qd > Qs), przy wyższej – nadmiar (Qs > Qd).

## Wyjaśnienie
| Cena | Skutek | Nazwa | Przykład przyczyny |
|---|---|---|---|
| $P < P_e$ | $Q_D > Q_S$ | **niedobór** (nadwyżka wielkości popytu) | cena maksymalna |
| $P > P_e$ | $Q_S > Q_D$ | **nadmiar** (nadwyżka wielkości podaży) | cena minimalna |

- Rozmiar nierównowagi = $|Q_D - Q_S|$.
- Przy cenie narzuconej **sprzedana ilość** = mniejsza z dwóch wielkości: $\min(Q_D, Q_S)$.

## Przykład
Przykład (lodówki): $P = 5000 - Q$, $P = 4Q$, cena administracyjna 2400 → $Q_D = 2600$, $Q_S = 600$ → **niedobór 2000 szt.**; sprzedanych zostanie tylko 600.

## Na egzaminie
> [!question] Pytanie otwarte
> Rząd ustalił cenę maksymalną poniżej ceny równowagi. Opisz skutki dla kupujących i sprzedających. *Odp.: niedobór, kolejki, mniejsza sprzedana ilość (= Qs), ryzyko szarej strefy.*

> [!warning] Pułapka
> Cena maksymalna **powyżej** ceny równowagi nic nie zmienia (nie jest wiążąca).

## Zadania
Pojęcie przydaje się też w: [Rynek rowerów – równowaga i cena poniżej równowagi](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20rower%C3%B3w%20%E2%80%93%20r%C3%B3wnowaga%20i%20cena%20poni%C5%BCej%20r%C3%B3wnowagi), [Rynek lodówek – cena administracyjna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20lod%C3%B3wek%20%E2%80%93%20cena%20administracyjna).

## Jak to się łączy
Nierównowaga jest przeciwieństwem [równowagi rynkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnowaga%20rynkowa) – opisuje sytuację, w której mechanizm cenowy nie może zadziałać. Najczęściej powstaje wskutek [interwencji państwa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interwencja%20pa%C5%84stwa%20na%20rynku), np. ceny maksymalnej lub minimalnej.
