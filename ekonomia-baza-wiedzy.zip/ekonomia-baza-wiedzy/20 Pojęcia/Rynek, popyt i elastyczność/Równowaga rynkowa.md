---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Nadwyżka konsumenta i producenta"]
wymaga: ["Popyt", "Podaż"]
przeciwieństwo: ["Nierównowaga rynkowa"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[Rekowski – Mikroekonomia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cena równowagi", "Punkt równowagi", "Pe", "Qe"]
---
> [!abstract] Definicja
> Równowaga rynkowa to stan, w którym przy danej cenie wielkość popytu równa się wielkości podaży (Qd = Qs) – cena „czyści rynek”.

## Wyjaśnienie
$$Q_e = Q_D = Q_S \quad\Rightarrow\quad \begin{cases} P = f_D(Q) \\ P = f_S(Q)\end{cases}$$

![[02_rownowaga_niedobor_nadwyzka.png]]

Mechanizm rynkowy sam prowadzi do punktu E: przy cenie za niskiej rośnie presja na wzrost ceny (niedobór), przy za wysokiej – na spadek (nadmiar).

**Jednoczesne przesunięcie D i S:**

| Zmiana | $P_e$ | $Q_e$ |
|---|---|---|
| D↑, S↑ | ? | ↑ |
| D↓, S↓ | ? | ↓ |
| D↑, S↓ | ↑ | ? |
| D↓, S↑ | ↓ | ? |

„?” – zależy od siły działania czynników.

## Przykład
Przykład (rynek rowerów): $P = 60 - \frac13Q$, $P = \frac16Q$ → $60 - \frac13Q = \frac16Q$ → **Qe = 120, Pe = 20**.

![[04_rownowaga_liczbowo.png]]

## Na egzaminie
> [!question] Pytanie testowe
> Rośnie podaż i jednocześnie spada popyt. Co na pewno stanie się z ceną równowagi? **Spadnie; ilość – nie wiadomo.**

> [!warning] Pułapka
> Gdy przesuwają się obie krzywe, na rysunku często jedna wielkość „się nie zmienia”, ale w odpowiedzi pisz, że może wzrosnąć, spaść lub pozostać bez zmian.

## Zadania
Zadania do tego pojęcia: [[Rynek rowerów – równowaga i cena poniżej równowagi]] i [[Rynek lodówek – cena administracyjna]].

Pojęcie przydaje się też w: [Masło i margaryna – elastyczność mieszana](obsidian://open?vault=ekonomia-baza-wiedzy&file=Mas%C5%82o%20i%20margaryna%20%E2%80%93%20elastyczno%C5%9B%C4%87%20mieszana).

## Jak to się łączy
Równowaga wymaga obu stron rynku – [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) i [podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Poda%C5%BC) – bo jest punktem przecięcia ich krzywych. Jej przeciwieństwem jest [nierównowaga rynkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nier%C3%B3wnowaga%20rynkowa), gdy cena odbiega od Pe. W punkcie równowagi suma korzyści kupujących i sprzedających jest największa – pokazuje to [nadwyżka konsumenta i producenta](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nadwy%C5%BCka%20konsumenta%20i%20producenta).
