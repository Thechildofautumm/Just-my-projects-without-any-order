---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Czynnik produkcji", "Interwencja państwa na rynku"]
część-z: ["Podaż"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Determinanty podaży", "Przesunięcie krzywej podaży"]
---
> [!abstract] Definicja
> Pozacenowa determinanta podaży to czynnik inny niż cena dobra, którego zmiana przesuwa całą krzywą podaży.

## Wyjaśnienie
| Determinanta | Wzrost czynnika → |
|---|---|
| ceny czynników produkcji (surowce, praca) | S↓ (lewo) |
| postęp technologiczny | S↑ (prawo) |
| podatki | S↓ |
| subsydia, dotacje | S↑ |
| przewidywania wzrostu cen | S↓ teraz (producenci wstrzymują sprzedaż) |
| liczba firm w gałęzi | S↑ |

Zapis w zadaniach: wzrost kosztów o t na jednostkę → $P = f_S(Q) + t$; dotacja b → $P = f_S(Q) - b$.

## Przykład
Przykład (kawa): przymrozki i droższy fracht morski – oba czynniki zmniejszają podaż → cena **wyższa**, ilość **niższa** (jednoznacznie).

## Na egzaminie
> [!question] Pytanie testowe
> Wzrost liczby firm w gałęzi spowoduje… **przesunięcie krzywej podaży w prawo.**

## Zadania
Zadania do tego pojęcia: [[Rynek pelletu – nowe tartaki i droższe kotły]] i [[Rynek kawy – przymrozki i drogi fracht]].

Pojęcie przydaje się też w: [Rynek najmu – dopłata dla wynajmujących](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20najmu%20%E2%80%93%20dop%C5%82ata%20dla%20wynajmuj%C4%85cych), [Kolonie letnie – subwencja dla organizatorów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Kolonie%20letnie%20%E2%80%93%20subwencja%20dla%20organizator%C3%B3w), [Smartwatche – ta sama cena, mniejsza ilość](obsidian://open?vault=ekonomia-baza-wiedzy&file=Smartwatche%20%E2%80%93%20ta%20sama%20cena%2C%20mniejsza%20ilo%C5%9B%C4%87), [Samochody używane – droższy kredyt i niższe cło](obsidian://open?vault=ekonomia-baza-wiedzy&file=Samochody%20u%C5%BCywane%20%E2%80%93%20dro%C5%BCszy%20kredyt%20i%20ni%C5%BCsze%20c%C5%82o).

## Jak to się łączy
Determinanty przesuwają krzywą [podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Poda%C5%BC), a nie powodują ruchu wzdłuż niej. Najważniejszą z nich są ceny [czynników produkcji](obsidian://open?vault=ekonomia-baza-wiedzy&file=Czynnik%20produkcji), bo wpływają na koszty każdej jednostki. Podatki i dotacje to narzędzia [interwencji państwa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interwencja%20pa%C5%84stwa%20na%20rynku), które działają właśnie przez przesunięcie podaży.
