---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Elastyczność a przychód", "Zysk ekonomiczny", "Maksymalizacja zysku"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["TR", "AR", "MR", "Przychód marginalny", "Przychód całkowity"]
---
> [!abstract] Definicja
> Przychód firmy to wpływy ze sprzedaży: całkowity TR = P·Q, przeciętny AR = TR/Q = P oraz marginalny MR = TR′ – przyrost TR z dodatkowej sprzedanej jednostki.

## Wyjaśnienie
| Przychód | Wzór | Znaczenie |
|---|---|---|
| całkowity TR | $P\cdot Q$ | = wydatki nabywców na dobro |
| przeciętny AR | $TR/Q = P$ | zawsze równy cenie |
| marginalny MR | $\Delta TR/\Delta Q = TR'$ | przyrost TR z dodatkowej jednostki |

Dla liniowego popytu $P = aQ + b$ ($a < 0$):
$$TR = aQ^2 + bQ, \qquad MR = 2aQ + b$$
MR ma to samo przecięcie z osią P co popyt, ale **dwa razy większe nachylenie** – przecina oś Q w ½Qmax.

![[08_przychody_TR_AR_MR.png]]

$$TR_{max} \Leftrightarrow MR = 0 \Leftrightarrow \lvert E_p\rvert = 1, \qquad TR_{max} = \tfrac12 P_{max}\cdot\tfrac12 Q_{max}$$

## Przykład
Przykład: $P = -5Q + 2000$ → $TR = -5Q^2 + 2000Q$, $MR = -10Q + 2000 = 0$ → Q = 200, P = 1000, **TRmax = 200 000**.

## Na egzaminie
> [!question] Zadanie typowe
> $P = -2Q + 2000$. Ile wynosi MR przy P = 400? *Odp.: Q = 800, MR = −4Q + 2000 = −1200 (odcinek nieelastyczny).*

> [!warning] Pułapka
> W rachunkowości i podatkach „przychód” to kategoria księgowo-prawna (memoriał, przychody podatkowe), a nie funkcja TR(Q).

## Zadania
Zadania do tego pojęcia: [[Maksymalny przychód przy popycie liniowym]] i [[Batony – przychód marginalny w punkcie i na odcinku]].

Pojęcie przydaje się też w: [Elastyczność i przychód przy cenie 20](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20i%20przych%C3%B3d%20przy%20cenie%2020), [Elastyczność wyznaczona z przychodu marginalnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20wyznaczona%20z%20przychodu%20marginalnego), [Ilość przy zerowym przychodzie marginalnym](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ilo%C5%9B%C4%87%20przy%20zerowym%20przychodzie%20marginalnym), [Równania AR, MR i TR z dwóch informacji](obsidian://open?vault=ekonomia-baza-wiedzy&file=R%C3%B3wnania%20AR%2C%20MR%20i%20TR%20z%20dw%C3%B3ch%20informacji).

## Jak to się łączy
MR zależy od elastyczności popytu – związek ten opisuje [elastyczność a przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20a%20przych%C3%B3d). Odejmując od przychodu koszty, dostajemy [zysk](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny): π = TR − TC. Przychód marginalny jest lewą stroną warunku [maksymalizacji zysku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Maksymalizacja%20zysku) MR = MC.
