---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Substytucyjność i komplementarność dóbr", "Elastyczność dochodowa popytu"]
część-z: ["Popyt"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Rekowski – Mikroekonomia]]", "[[Solek – Optymalne decyzje]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Determinanty popytu", "Przesunięcie krzywej popytu", "Czynniki pozacenowe popytu"]
---
> [!abstract] Definicja
> Pozacenowa determinanta popytu to każdy czynnik inny niż cena danego dobra, którego zmiana przesuwa całą krzywą popytu.

## Wyjaśnienie
| Determinanta | Kierunek (wzrost czynnika) |
|---|---|
| dochód konsumentów | D↑ dla dóbr normalnych, D↓ dla podrzędnych |
| gusty i preferencje | zgodnie ze zmianą gustu |
| cena substytutu | D↑ |
| cena dobra komplementarnego | D↓ |
| przewidywania wzrostu cen | D↑ (teraz) |
| liczba ludności (nabywców) | D↑ |
| efekty naśladownictwa i demonstracji | zwykle D↑ |
| reklama (ekonomia menedżerska) | D↑ |

![[03_przesuniecia_D_S.png]]

## Przykład
Przykład (napoje energetyczne): po kampanii konsumenci kupują tylko po cenach o 8 zł niższych: $P = 80 - Q$ → $P = 72 - Q$ (D w lewo). Nowa równowaga z podażą $P = 3Q$: Q = 18, P = 54.

## Na egzaminie
> [!question] Pytanie testowe
> Podrożały piece gazowe. Co się stanie z popytem na gaz ziemny? **Spadnie – piece i gaz to dobra komplementarne.**

## Zadania
Zadania do tego pojęcia: [[Smartwatche – ta sama cena, mniejsza ilość]] i [[Samochody używane – droższy kredyt i niższe cło]].

Pojęcie przydaje się też w: [Napoje energetyczne – cena maksymalna i kampania społeczna](obsidian://open?vault=ekonomia-baza-wiedzy&file=Napoje%20energetyczne%20%E2%80%93%20cena%20maksymalna%20i%20kampania%20spo%C5%82eczna), [Sok jabłkowy – dopłata dla konsumentów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Sok%20jab%C5%82kowy%20%E2%80%93%20dop%C5%82ata%20dla%20konsument%C3%B3w), [Dopłata procentowa dla konsumentów](obsidian://open?vault=ekonomia-baza-wiedzy&file=Dop%C5%82ata%20procentowa%20dla%20konsument%C3%B3w).

## Jak to się łączy
Determinanty pozacenowe to wszystkie argumenty funkcji [popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Popyt) poza ceną własną – ich zmiana przesuwa krzywą. Wpływ cen innych dóbr zależy od tego, czy są to substytuty, czy komplementy – patrz [Substytucyjność i komplementarność dóbr](obsidian://open?vault=ekonomia-baza-wiedzy&file=Substytucyjno%C5%9B%C4%87%20i%20komplementarno%C5%9B%C4%87%20d%C3%B3br). Kierunek wpływu dochodu określa [elastyczność dochodowa popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20dochodowa%20popytu): dla dóbr normalnych wzrost dochodu zwiększa popyt, dla podrzędnych – zmniejsza.
