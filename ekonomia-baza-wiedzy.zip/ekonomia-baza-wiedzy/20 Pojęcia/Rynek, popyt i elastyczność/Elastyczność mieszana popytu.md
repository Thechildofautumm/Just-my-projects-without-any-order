---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Substytucyjność i komplementarność dóbr"]
część-z: ["Elastyczność popytu"]
źródło: ["[[Prezentacja – Elastyczność popytu i przychody]]", "[[Prezentacja – Elastyczność, ćwiczenia]]", "[[EM – Popyt, elastyczność, polityka cenowa]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]"]
przedmiot: ["Mikroekonomia", "Ekonomia menedżerska"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Em", "Elastyczność krzyżowa"]
---
> [!abstract] Definicja
> Elastyczność mieszana (krzyżowa) mierzy, o ile procent zmieni się popyt na dobro X, gdy cena dobra Y zmieni się o 1%.

## Wyjaśnienie
$$E_m = \frac{\Delta Q_x}{\Delta P_y}\cdot\frac{P_y}{Q_x} = Q'(P_y)\cdot\frac{P_y}{Q_x}$$
Gdy znamy dwa stany:
$$E_m = \frac{\frac{Q_{x2}-Q_{x1}}{Q_{x1}}\cdot 100\%}{\frac{P_{y2}-P_{y1}}{P_{y1}}\cdot 100\%}$$

| Znak | Relacja |
|---|---|
| $E_m > 0$ | substytuty |
| $E_m = 0$ | dobra niezależne |
| $E_m < 0$ | komplementy |

## Przykład
$E_m = -2$: wzrost ceny Y o 1% → spadek popytu na X o 2% (komplementy). $E_m = 2$: wzrost o 2% (substytuty).

## Na egzaminie
> [!question] Zadanie typowe
> Rynek margaryny: $P = 500 - 2Q$, $P = 100 + 2Q$. Po wzroście ceny masła z 20 do 25 zł popyt na margarynę: $P = 640 - 2Q$. Oblicz Em. *Odp.: Q ze 100 do 135 (+35%), cena +25% → Em = 1,4 (substytuty).*

## Zadania
Zadania do tego pojęcia: [[Masło i margaryna – elastyczność mieszana]] i [[Miesięcznik podróżniczy – elastyczności mieszane]].

Pojęcie przydaje się też w: [Interpretacja współczynników elastyczności](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interpretacja%20wsp%C3%B3%C5%82czynnik%C3%B3w%20elastyczno%C5%9Bci).

## Jak to się łączy
Jest jednym z trzech rodzajów [elastyczności popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu). Jej znak to formalne kryterium, czy dobra są substytutami czy komplementami – patrz [Substytucyjność i komplementarność dóbr](obsidian://open?vault=ekonomia-baza-wiedzy&file=Substytucyjno%C5%9B%C4%87%20i%20komplementarno%C5%9B%C4%87%20d%C3%B3br).
