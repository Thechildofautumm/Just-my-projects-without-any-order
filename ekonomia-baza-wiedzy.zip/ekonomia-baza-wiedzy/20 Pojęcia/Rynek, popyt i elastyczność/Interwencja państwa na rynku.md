---
typ: pojęcie
up: "[[MOC Rynek, popyt i elastyczność]]"
powiązane: ["Nierównowaga rynkowa", "Pozacenowa determinanta podaży", "Pozacenowa determinanta popytu", "Incydencja podatkowa"]
źródło: ["[[Prezentacja – Wprowadzenie i rynek]]", "[[Prezentacja – Rynek, ćwiczenia]]", "[[Kalinowski – Zbiór zadań z mikroekonomii]]", "[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Mikroekonomia", "Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Dotacja", "Subwencja", "Akcyza"]
---
> [!abstract] Definicja
> Interwencja państwa na rynku to działania zmieniające wynik mechanizmu rynkowego: podatki, dotacje (subwencje) oraz ceny administracyjne.

## Wyjaśnienie
![[05_podatek_dotacja.png]]

| Narzędzie | Zapis w zadaniu | Efekt |
|---|---|---|
| podatek kwotowy t na producenta | $P = f_S(Q) + t$ | S w górę/lewo; P↑, Q↓ |
| podatek procentowy s od ceny | $(1 - s)P = f_S(Q)$ | S w lewo i bardziej stroma |
| dotacja b dla producenta | $P = f_S(Q) - b$ | S w dół/prawo; P↓, Q↑ |
| dotacja kwotowa d dla konsumenta | $P = f_D(Q) + d$ | D w górę/prawo; P↑, Q↑ |
| dopłata procentowa s dla konsumenta | $(1 - s)P = f_D(Q)$ | D w prawo, zmienia nachylenie |
| cena maksymalna < Pe | – | niedobór |
| cena minimalna > Pe | – | nadmiar |

![[m18_podatek_procentowy.png]]

## Przykład
Przykład (kolonie): $P = 800 - 2Q$, podaż $P = 2Q$; jaka subwencja b obniży cenę do 320? Z popytu: Q′ = 240; z nowej podaży $320 = 2\cdot 240 - b$ → **b = 160**.

## Na egzaminie
> [!question] Pytanie otwarte
> Porównaj skutki podatku nałożonego na producentów i dotacji dla konsumentów dla ceny i ilości równowagi.

> [!warning] Pułapka
> Gdy znana jest docelowa cena po interwencji, licz Q z **niezmienionej** krzywej, a potem parametr interwencji z krzywej zmodyfikowanej.

## Zadania
Zadania do tego pojęcia: [[Napoje energetyczne – cena maksymalna i kampania społeczna]], [[Sok jabłkowy – dopłata dla konsumentów]], [[Rynek najmu – dopłata dla wynajmujących]], [[Kolonie letnie – subwencja dla organizatorów]], [[Elektronika – podatek procentowy od ceny]] i [[Dopłata procentowa dla konsumentów]].

Pojęcie przydaje się też w: [Rynek kawy – przymrozki i drogi fracht](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rynek%20kawy%20%E2%80%93%20przymrozki%20i%20drogi%20fracht).

## Jak to się łączy
Ceny administracyjne wywołują [nierównowagę rynkową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Nier%C3%B3wnowaga%20rynkowa). Podatki i dotacje dla producentów działają jak [pozacenowa determinanta podaży](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20poda%C5%BCy), a dopłaty dla nabywców – jak [determinanta popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Pozacenowa%20determinanta%20popytu). To, kto faktycznie zapłaci podatek – nabywcy czy sprzedawcy – zależy od elastyczności i opisuje to [incydencja podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Incydencja%20podatkowa).
