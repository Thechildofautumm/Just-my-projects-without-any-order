---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Zysk ekonomiczny", "Przychód", "Strata podatkowa"]
źródło: ["[[Podatki – Straty podatkowe]]", "[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Koszt uzyskania przychodu", "KUP", "NKUP", "Podstawa opodatkowania CIT"]
---
> [!abstract] Definicja
> Dochodem ze źródła przychodów jest nadwyżka sumy przychodów z tego źródła nad kosztami ich uzyskania (KUP) w roku podatkowym; gdy koszty przekraczają przychody, różnica jest stratą.

## Wyjaśnienie
$$\text{dochód} = \text{przychody} - \text{KUP}, \qquad \text{podatek} = (\text{podstawa}) \cdot \text{stawka} - \text{odliczenia od podatku}$$

- **KUP** – koszty uzyskania przychodów; **NKUP** – wydatki niebędące KUP (np. odsetki ponad limit).
- Niekiedy opodatkowany jest **przychód**, nie dochód (np. dywidendy).

| | Zysk ekonomiczny | Dochód podatkowy |
|---|---|---|
| koszty | jawne + alternatywne | KUP wg ustawy |
| koszt kapitału własnego | tak (koszt alternatywny) | nie (wyjątek: NID) |
| cel | ocena opłacalności | podstawa opodatkowania |

## Przykład
Przychody 1 000 000 zł, KUP 800 000 zł (w tym odsetki 50 000 zł) → dochód 200 000 zł; CIT 19% = 38 000 zł.

## Na egzaminie
> [!question] Pytanie testowe
> Czy dywidenda wypłacona wspólnikom jest kosztem uzyskania przychodu spółki? **Nie – wypłaca się ją z zysku po opodatkowaniu.**

## Zadania
Pojęcie przydaje się też w: [Podatki – strata operacyjna a zysk kapitałowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20strata%20operacyjna%20a%20zysk%20kapita%C5%82owy).

## Jak to się łączy
Dochód podatkowy różni się od [zysku ekonomicznego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Zysk%20ekonomiczny), bo nie uwzględnia kosztów alternatywnych. Słowo „przychód” ma tu sens prawny, inny niż TR w mikroekonomii – patrz [przychód](obsidian://open?vault=ekonomia-baza-wiedzy&file=Przych%C3%B3d). Ujemny dochód to [strata podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20podatkowa).
