---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Dochód podatkowy", "Rozliczanie straty podatkowej w czasie"]
wymaga: ["Asymetria podatkowa finansowania"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Earnings stripping", "Art. 15c UPDOP", "ATAD", "Nadwyżka kosztów finansowania dłużnego"]
---
> [!abstract] Definicja
> Zgodnie z art. 15c UPDOP do KUP nie zalicza się nadwyżki kosztów finansowania dłużnego w części przekraczającej wyższą z kwot: 3 mln zł albo 30% podatkowej EBITDA.

## Wyjaśnienie
$$\text{nadwyżka} = \text{koszty finansowania dłużnego} - \text{przychody odsetkowe}$$
$$\text{NKUP} = \max\big(0;\ \text{nadwyżka} - \max(3\ \text{mln};\ 30\%\cdot EBITDA)\big)$$

- reguła typu **earnings stripping** – oparta na relacji odsetek netto do zysku operacyjnego, dotyczy długu ogółem; wdraża dyrektywę **ATAD** (2016/1164),
- według ekonomistów skuteczniejsza od reguł cienkiej kapitalizacji: trudniejsza do obejścia, nie powoduje zastępowania długu wewnętrznego zewnętrznym,
- wyłączone koszty można zaliczyć do KUP w **następnych 5 latach** w ramach limitów,
- skutki w badaniach: mniej długu, substytucja, ograniczenie inwestycji.

![[p05_limit_odsetek_kaskada.png]]

## Przykład
Przykład 1: przychody odsetkowe 2 mln, koszty finansowania 1,5 mln → brak nadwyżki → całość KUP.
Przykład 2: koszty 8 mln, przychody odsetkowe 1 mln → nadwyżka 7 mln; EBITDA 20 mln → limit max(3; 6) = 6 mln → **NKUP 1 mln**.

## Na egzaminie
> [!question] Zadanie typowe
> Nadwyżka kosztów długu 5 mln zł, EBITDA 8 mln zł. Ile odsetek jest NKUP? *Odp.: limit max(3; 2,4) = 3 mln → NKUP 2 mln zł.*

> [!warning] Pułapka
> Limit to **wyższa** z dwóch kwot, a porównujemy z nim **nadwyżkę** (po odjęciu przychodów odsetkowych), nie same koszty odsetek.

## Zadania
Zadania do tego pojęcia: [[Podatki – limit kosztów finansowania dłużnego]].

## Jak to się łączy
Celem regulacji jest ograniczenie skutków [asymetrii podatkowej finansowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Asymetria%20podatkowa%20finansowania). Wyłączenie odsetek z KUP zwiększa [dochód podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Doch%C3%B3d%20podatkowy). Przenoszenie nadwyżki na 5 lat przypomina mechanizm [rozliczania straty w czasie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rozliczanie%20straty%20podatkowej%20w%20czasie).
