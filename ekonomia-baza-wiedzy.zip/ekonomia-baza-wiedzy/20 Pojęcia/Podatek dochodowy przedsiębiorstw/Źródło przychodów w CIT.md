---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Preferencyjna stawka CIT", "Strata podatkowa"]
wymaga: ["Dochód podatkowy"]
źródło: ["[[Podatki – Mały podatnik i obniżona stawka CIT]]", "[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Zyski kapitałowe", "Inne źródła przychodów", "Podatek dochodowy od osób prawnych", "CIT"]
---
> [!abstract] Definicja
> W CIT przedmiotem opodatkowania jest suma dochodów z dwóch źródeł: zysków kapitałowych i innych źródeł przychodów (głównie działalności operacyjnej), liczonych osobno.

## Wyjaśnienie
**Podatnicy CIT:** spółki kapitałowe (z o.o., akcyjna, prosta spółka akcyjna) i niektóre osobowe (komandytowa, komandytowo-akcyjna). **Stawki:** 19% standardowa, 9% obniżona.

| Zyski kapitałowe (zawsze 19%) | Inne źródła (9% lub 19%) |
|---|---|
| dywidendy, przychody z licencji, z papierów wartościowych i ich sprzedaży, z funduszy inwestycyjnych, z przekształceń, podziałów, łączenia | działalność operacyjna |

Dochód z każdego źródła liczymy osobno; strata z jednego źródła **nie** pomniejsza dochodu z drugiego.

## Przykład
Spółka ma stratę operacyjną 400 000 zł i zysk ze sprzedaży udziałów 80 000 zł. Nie może policzyć −400 000 + 80 000 = −320 000 – zapłaci CIT od 80 000 zł zysków kapitałowych.

## Na egzaminie
> [!question] Pytanie testowe
> Jaka stawka CIT dotyczy dywidend otrzymanych przez małego podatnika? **19% – zyski kapitałowe nie korzystają ze stawki 9%.**

## Zadania
Pojęcie przydaje się też w: [Podatki – strata operacyjna a zysk kapitałowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20strata%20operacyjna%20a%20zysk%20kapita%C5%82owy).

## Jak to się łączy
Dla każdego źródła osobno liczymy [dochód podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Doch%C3%B3d%20podatkowy). Stawka 9% obejmuje tylko inne źródła – patrz [preferencyjna stawka CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencyjna%20stawka%20CIT). Rozdział źródeł ogranicza rozliczanie [straty podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20podatkowa).
