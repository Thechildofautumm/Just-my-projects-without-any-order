---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Tarcza podatkowa", "Niedostateczna kapitalizacja", "Hipotetyczne odsetki od kapitału własnego"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Debt-equity bias", "Dyskryminacja kapitału własnego", "CBIT"]
---
> [!abstract] Definicja
> Asymetria podatkowa finansowania (debt-equity bias) polega na tym, że odsetki od długu są kosztem uzyskania przychodu, a dywidendy dla właścicieli wypłaca się z zysku po opodatkowaniu – kapitał własny jest podatkowo dyskryminowany.

## Wyjaśnienie
| | Kapitał własny | Kapitał obcy |
|---|---|---|
| wynagrodzenie dawcy | dywidenda z zysku netto | odsetki |
| KUP? | **nie** | **tak** → tarcza odsetkowa |

**Skutki:**
- mikro: zachęta do zadłużania, szczególnie **długiem wewnętrznym** (od podmiotów powiązanych) → niedostateczna kapitalizacja,
- makro: ryzyko kryzysu finansowego (MFW),
- finanse publiczne: erozja podstawy opodatkowania,
- polityka podatkowa: szukanie rozwiązań – estoński CIT, limity odsetek, NID, **CBIT** (Comprehensive Business Income Tax: opodatkowanie zwrotu z całego kapitału, bez odliczania odsetek i NID, bez opodatkowania na poziomie osoby fizycznej).

## Przykład
*(ćwiczenie własne)* EBIT 2 000 000 zł. Finansowanie kapitałem: CIT = 380 000. Dług z odsetkami 300 000: CIT = (2 000 000 − 300 000)·19% = 323 000 → różnica 57 000 zł = tarcza odsetkowa.

## Na egzaminie
> [!question] Pytanie otwarte
> Dlaczego z perspektywy CIT często opłaca się finansować kapitałem obcym? Jakie są skutki i jak państwa temu przeciwdziałają?

> [!success]- Odpowiedź (szkic)
> Odsetki od długu są kosztem uzyskania przychodów, a dywidendy wypłaca się z zysku po opodatkowaniu – dług daje tarczę podatkową (debt–equity bias).
> Skutki: mikro – zachęta do zadłużania, zwłaszcza długiem od podmiotów powiązanych; makro – ryzyko kryzysu finansowego; finanse publiczne – erozja podstawy opodatkowania.
> Przeciwdziałanie: limity kosztów finansowania dłużnego (30% EBITDA / 3 mln zł), dawne przepisy o cienkiej kapitalizacji, hipotetyczne odsetki od kapitału własnego (NID), estoński CIT, koncepcja CBIT.

## Zadania
Zadania do tego pojęcia: [[Podatki – dług czy kapitał własny]].

## Jak to się łączy
Źródłem asymetrii jest [tarcza podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa) na odsetkach. Jej skutkiem jest [niedostateczna kapitalizacja](obsidian://open?vault=ekonomia-baza-wiedzy&file=Niedostateczna%20kapitalizacja). Jednym ze sposobów zniwelowania asymetrii są [hipotetyczne odsetki od kapitału własnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Hipotetyczne%20odsetki%20od%20kapita%C5%82u%20w%C5%82asnego).
