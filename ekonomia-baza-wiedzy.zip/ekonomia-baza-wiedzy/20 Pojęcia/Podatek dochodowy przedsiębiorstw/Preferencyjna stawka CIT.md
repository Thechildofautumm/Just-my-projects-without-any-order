---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Tarcza podatkowa"]
wymaga: ["Mały podatnik", "Źródło przychodów w CIT"]
źródło: ["[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["CIT 9%", "Obniżona stawka CIT"]
---
> [!abstract] Definicja
> Stawka 9% CIT przysługuje małym podatnikom od dochodów innych niż zyski kapitałowe, jeśli przychody w roku podatkowym nie przekroczyły równowartości 2 mln euro (art. 19 UPDOP).

> [!info] Dane zależne od roku
> Kwoty limitów i stopy procentowe w tej notatce dotyczą 2026 r. – co roku sprawdź aktualne wartości (kurs euro, stopa referencyjna NBP).

## Wyjaśnienie
- limit bieżących przychodów (bez VAT) w 2026 r.: **8 431 000 zł** (kurs z pierwszego dnia roboczego stycznia),
- formy: sp. z o.o., komandytowa, komandytowo-akcyjna, akcyjna, prosta spółka akcyjna,
- **wyłączenia:** w roku rozpoczęcia działalności i w następnym, jeśli podatnik powstał z przekształcenia, połączenia lub podziału (wyjątek: przekształcenie spółki w spółkę) albo przez wniesienie przedsiębiorstwa o wartości ≥ 10 000 euro (np. JDG, spółka cywilna, jawna, partnerska → sp. z o.o.: nie może).

**Blaski i cienie:** zachęta do prowadzenia mniejszej działalności w sp. z o.o.; ale przychody z zysków kapitałowych (19%) liczą się do limitu; udział w zysku spółki transparentnej też; trzeba pilnować zawiłych limitów.

**Strategie:** przesunięcie sprzedaży na kolejny rok, przyspieszenie kosztów, podział spółki (naturalny – inaczej GAAR), optymalizacja roku podatkowego.

```mermaid
flowchart TD
  A["Czy podatnik ma status małego podatnika?"] -- nie --> X["19%"]
  A -- tak --> B["Czy przychody bieżącego roku ≤ 2 mln euro?"]
  B -- nie --> X
  B -- tak --> C["Czy podlega wyłączeniu (przekształcenie, wniesienie przedsiębiorstwa)?"]
  C -- tak --> X
  C -- nie --> D["Dochody z innych źródeł: 9%; zyski kapitałowe: 19%"]
```

## Przykład
Odliczenie 25 000 zł daje przy 9% tarczę 2 250 zł, przy 19% – 4 750 zł: niższa stawka zmniejsza korzyść z każdego odliczenia.

## Na egzaminie
> [!question] Pytanie testowe
> Spółka z o.o. powstała z przekształcenia spółki jawnej. Czy w pierwszym roku może stosować 9%? **Nie.**

## Zadania
Pojęcie przydaje się też w: [Podatki – tarcza przy stawce 9% i 19%](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20tarcza%20przy%20stawce%209%25%20i%2019%25), [Podatki – czy spółka zapłaci 9% CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20czy%20sp%C3%B3%C5%82ka%20zap%C5%82aci%209%25%20CIT).

## Jak to się łączy
Stawkę można stosować tylko mając status [małego podatnika](obsidian://open?vault=ekonomia-baza-wiedzy&file=Ma%C5%82y%20podatnik) i tylko do dochodów spoza zysków kapitałowych – patrz [źródła przychodów w CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=%C5%B9r%C3%B3d%C5%82o%20przychod%C3%B3w%20w%20CIT). Niższa stawka oznacza mniejszą [tarczę podatkową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa) z tego samego odliczenia.
