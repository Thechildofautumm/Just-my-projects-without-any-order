---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Preferencyjna stawka CIT", "Źródło przychodów w CIT"]
źródło: ["[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Status małego podatnika"]
---
> [!abstract] Definicja
> Mały podatnik to podatnik, którego przychód ze sprzedaży brutto (z VAT) w poprzednim roku nie przekroczył równowartości 2 mln euro.

> [!info] Dane zależne od roku
> Kwoty limitów i stopy procentowe w tej notatce dotyczą 2026 r. – co roku sprawdź aktualne wartości (kurs euro, stopa referencyjna NBP).

## Wyjaśnienie
- przeliczenie: średni kurs NBP z pierwszego dnia roboczego października poprzedniego roku, zaokrąglenie do 1000 zł,
- **limit na 2026 r.: 8 517 000 zł**.

**Korzyści:**
- kwartalne zaliczki na podatek dochodowy,
- jednorazowe odpisy amortyzacyjne,
- stawka **9% CIT**.

## Przykład
Spółka z przychodami brutto 7,5 mln zł w 2025 r. jest w 2026 r. małym podatnikiem.

## Na egzaminie
> [!question] Pytanie testowe
> Czy przychód małego podatnika liczy się z VAT? **Tak – przychód ze sprzedaży brutto.**

> [!warning] Pułapka
> Dwa różne limity: status małego podatnika (przychód **brutto** z poprzedniego roku, kurs z października) i limit stawki 9% (bieżące przychody **bez VAT**, kurs ze stycznia; 2026: 8 431 000 zł).

## Zadania
Zadania do tego pojęcia: [[Podatki – czy spółka zapłaci 9% CIT]].

## Jak to się łączy
Status małego podatnika jest warunkiem [preferencyjnej stawki CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencyjna%20stawka%20CIT). Do limitu wlicza się także przychody z zysków kapitałowych – patrz [źródła przychodów w CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=%C5%B9r%C3%B3d%C5%82o%20przychod%C3%B3w%20w%20CIT).
