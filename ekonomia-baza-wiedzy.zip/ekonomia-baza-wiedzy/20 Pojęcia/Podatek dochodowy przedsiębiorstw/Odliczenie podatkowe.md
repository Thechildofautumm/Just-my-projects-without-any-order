---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Tarcza podatkowa"]
część-z: ["Preferencja podatkowa"]
źródło: ["[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Odliczenie od dochodu", "Odliczenie od podatku", "Ulga B+R", "Ulga prorodzinna"]
---
> [!abstract] Definicja
> Odliczenie podatkowe może być stosowane na I etapie – od dochodu lub podstawy opodatkowania – albo na II etapie – bezpośrednio od kwoty podatku; etap decyduje o wartości bodźca.

## Wyjaśnienie
| | I etap: od dochodu / podstawy | II etap: od podatku |
|---|---|---|
| przykład | ulga B+R, ulga z tytułu darowizny | ulga prorodzinna |
| oszczędność | **odliczenie × stawka** (tarcza) | **= odliczenie** |
| zależy od | stawki, wysokości dochodu, limitów | wysokości podatku |
| uwagi | | odliczenia zwrotne lub bezzwrotne |

![[p03_tarcza_podatkowa.png]]

## Przykład
Ulga prorodzinna: podatek wg skali 4 000 zł, dwoje dzieci → 1 112,04 × 2 = **2 224,08 zł oszczędności** (odliczenie od podatku = oszczędność).

## Na egzaminie
> [!question] Pytanie testowe
> Co da większą oszczędność: odliczenie 25 000 zł od dochodu przy 19% czy 25 000 zł od podatku? **Od podatku (25 000 vs 4 750 zł).**

## Zadania
Zadania do tego pojęcia: [[Podatki – ulga prorodzinna jako odliczenie od podatku]].

## Jak to się łączy
Odliczenie to techniczna forma [preferencji podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencja%20podatkowa) (ulgi). Wartość odliczenia od dochodu mierzy [tarcza podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa).
