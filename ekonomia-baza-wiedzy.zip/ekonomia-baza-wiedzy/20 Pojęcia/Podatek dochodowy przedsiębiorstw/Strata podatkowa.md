---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Rozliczanie straty podatkowej w czasie"]
wymaga: ["Dochód podatkowy"]
źródło: ["[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Strata ze źródła przychodów"]
---
> [!abstract] Definicja
> Strata podatkowa to nadwyżka kosztów uzyskania przychodów nad przychodami ze źródła; w CIT i PIT można ją rozliczać tylko w obrębie tego samego źródła przychodów.

## Wyjaśnienie
**CIT:** zyski kapitałowe i inne źródła – straty rozliczane tylko w ramach danego źródła.

**PIT:**
- strat z działalności gospodarczej nie odlicza się od przychodów z pracy czy działalności wykonywanej osobiście,
- kapitały pieniężne (zbycie udziałów, akcji, papierów wartościowych, instrumentów pochodnych) – straty rozliczane w czasie w obrębie źródła, nie z działalnością gospodarczą,
- odpłatne zbycie rzeczy i praw majątkowych – straty **nie** podlegają rozliczeniu.

**Kilka działalności:** strata ze **spółki transparentnej** (np. partnerskiej – opodatkowani są wspólnicy) może być rozliczona z dochodem z JDG w ramach źródła „działalność gospodarcza”; strata **spółki z o.o.** jest stratą spółki (CIT) i nie zmniejsza dochodu wspólnika z JDG.

**Inne daniny:** od podstawy składki zdrowotnej przedsiębiorcy nie odlicza się straty z lat ubiegłych; przy daninie solidarnościowej – po wyroku NSA z 19.07.2022 (II FSK 452/22) raczej tak.

## Przykład
Strata 200 000 ze spółki transparentnej (rozliczanej w PIT) i dochód z JDG 350 000 → łącznie 150 000; strata sp. z o.o. −200 000 → nie łączy się z dochodem JDG.

## Na egzaminie
> [!question] Pytanie testowe
> Czy stratę ze sprzedaży samochodu prywatnego (rzecz) można odliczyć od dochodu z pracy? **Nie.**

## Zadania
Zadania do tego pojęcia: [[Podatki – strata operacyjna a zysk kapitałowy]] i [[Podatki – strata spółki a dochód z JDG]].

## Jak to się łączy
Strata to ujemny [dochód podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Doch%C3%B3d%20podatkowy). Jak przenieść ją na kolejne lata, opisuje [rozliczanie straty podatkowej w czasie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Rozliczanie%20straty%20podatkowej%20w%20czasie).
