---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Koszt alternatywny", "Tarcza podatkowa"]
wymaga: ["Asymetria podatkowa finansowania"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["NID", "Notional interest deduction", "Allowance for corporate equity"]
---
> [!abstract] Definicja
> Hipotetyczne odsetki (NID, notional interest deduction) to odliczenie od podstawy opodatkowania „odsetek” od kapitału własnego – na wzór odsetek od długu – w celu zmniejszenia podatkowej dyskryminacji kapitału własnego.

> [!info] Dane zależne od roku
> Kwoty limitów i stopy procentowe w tej notatce dotyczą 2026 r. – co roku sprawdź aktualne wartości (kurs euro, stopa referencyjna NBP).

## Wyjaśnienie
**NID w Polsce (art. 15cb UPDOP):**
- podejście **przyrostowe**: od dopłat wniesionych przez właścicieli oraz zysku przekazanego na kapitał zapasowy lub rezerwowy,
- stopa: **stopa referencyjna NBP + 1 p.p.** (2026: 4,75%),
- limit: **250 000 zł** rocznie,
- brak przenoszenia niewykorzystanego NID na przyszłość (ale to samo odliczenie można ponowić w dwóch kolejnych latach),
- kapitał musi pozostać w firmie **minimum 3 lata**.

Inne nazwy: allowance for corporate equity. Stopa zwykle zbliżona do stopy wolnej od ryzyka.

![[p06_NID_limit.png]]

## Przykład
(Przykładowa stopa 5,75%): kapitał zapasowy +3 mln → 172 500 zł KUP; +5 mln → 287 500 → **250 000** (limit); +20 mln → 1 150 000 → **250 000**.

## Na egzaminie
> [!question] Pytanie otwarte
> Dlaczego mówimy o „hipotetycznych odsetkach” w realnym podatku? *Odp.: nikt ich nie płaci – to kalkulacyjny koszt kapitału własnego uznany za KUP, by zrównać kapitał własny z długiem.*

## Zadania
Zadania do tego pojęcia: [[Podatki – hipotetyczne odsetki od kapitału zapasowego]].

## Jak to się łączy
NID ma zniwelować [asymetrię podatkową finansowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Asymetria%20podatkowa%20finansowania). Ekonomicznie to uznanie w podatku [kosztu alternatywnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Koszt%20alternatywny) kapitału własnego – tego samego, który w mikroekonomii odróżnia zysk ekonomiczny od księgowego. NID tworzy [tarczę podatkową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa) także dla kapitału własnego.
