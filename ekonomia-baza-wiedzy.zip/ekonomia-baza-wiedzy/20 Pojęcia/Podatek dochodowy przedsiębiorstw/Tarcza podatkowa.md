---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Asymetria podatkowa finansowania", "Korzyść podatkowa"]
wymaga: ["Odliczenie podatkowe"]
źródło: ["[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]", "[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Osłona podatkowa", "Tax shield", "Tarcza odsetkowa"]
---
> [!abstract] Definicja
> Tarcza (osłona) podatkowa to wartość oszczędności podatkowej – o ile niższy jest podatek – powstałej dzięki odliczeniu od dochodu lub podstawy opodatkowania.

## Wyjaśnienie
$$\text{tarcza podatkowa} = \text{odliczenie od podstawy} \times \text{stawka podatku}$$

**Od czego zależy wysokość tarczy?**
1. od wartości odliczenia (cały koszt czy np. 200% kosztu?),
2. od wysokości dochodu (gdy dochód < odliczenie – czy ulga przepada, czy można ją zwrócić lub przenieść?),
3. od stawki podatkowej (9% czy 19%?),
4. od ewentualnych limitów ustawowych.

**Tarcza odsetkowa:** odsetki od długu są KUP → tarcza = odsetki × stawka CIT.

![[p04_dlug_vs_kapital.png]]

## Przykład
Odliczenie 25 000 zł: przy CIT 9% tarcza = **2 250 zł**, przy 19% = **4 750 zł**. Odsetki 300 000 zł przy 19% → tarcza odsetkowa **57 000 zł**.

## Na egzaminie
> [!question] Pytanie otwarte
> Wymień czynniki wpływające na wartość tarczy podatkowej i wyjaśnij wpływ każdego z nich.

> [!success]- Odpowiedź (szkic)
> (1) wartość odliczenia – im większe, tym większa tarcza; (2) wysokość dochodu – gdy dochód jest niższy niż odliczenie, część tarczy przepada lub przechodzi na kolejne lata; (3) stawka podatku – tarcza = odliczenie × stawka; (4) limity ustawowe – ograniczają kwotę odliczenia lub przyznają więcej niż 100% kosztu (np. B+R).

## Zadania
Zadania do tego pojęcia: [[Podatki – tarcza przy stawce 9% i 19%]].

Pojęcie przydaje się też w: [Podatki – dług czy kapitał własny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20d%C5%82ug%20czy%20kapita%C5%82%20w%C5%82asny).

## Jak to się łączy
Tarcza powstaje z [odliczenia podatkowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Odliczenie%20podatkowe) na I etapie. Tarcza na odsetkach jest źródłem [asymetrii podatkowej finansowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Asymetria%20podatkowa%20finansowania) – preferencji długu. Tarcza jest liczbową miarą [korzyści podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Korzy%C5%9B%C4%87%20podatkowa).
