---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Korzyść podatkowa", "Planowanie podatkowe"]
część-z: ["Strata podatkowa"]
źródło: ["[[Podatki – Straty podatkowe]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Odliczenie straty", "Carry forward", "Carry back"]
---
> [!abstract] Definicja
> Stratę ze źródła przychodów można odliczać od dochodu z tego źródła w kolejnych pięciu latach – maksymalnie 50% straty rocznie albo jednorazowo do 5 mln zł (art. 7 ust. 5 UPDOP, art. 9 ust. 3 UPDOF).

## Wyjaśnienie
| Metoda | Zasada |
|---|---|
| tradycyjna | przez 5 kolejnych lat, w żadnym roku więcej niż 50% straty |
| jednorazowa | w jednym z 5 lat do 5 000 000 zł; reszta w pozostałych latach, max 50% straty rocznie |

- odliczenie nie może przekroczyć dochodu danego roku,
- **wstecz (carry back)** – zwrot podatku za poprzednie lata; w czystej postaci brak w Polsce; wyjątek przy przejściu na estoński CIT (odliczenie od dochodu 2 lat przed przejściem, przy 4 latach na estońskim CIT),
- straty można odliczać już w zaliczkach miesięcznych.

![[p07_strata_metody.png]]

## Przykład
Strata 2025 = 3 mln, dochód 2026 = 9 mln: tradycyjnie **1,5 mln**, jednorazowo **3 mln**.
Strata 18 mln: tradycyjnie **9 mln** (50% straty, tu akurat cały dochód), jednorazowo **5 mln**.

## Na egzaminie
> [!question] Pytanie testowe
> Strata 8 mln zł, dochód w kolejnym roku 10 mln zł. Ile maksymalnie można odliczyć w tym roku? **Tradycyjnie 4 mln; jednorazowo 5 mln.**

## Zadania
Zadania do tego pojęcia: [[Podatki – rozliczenie straty 3 i 18 mln zł]].

## Jak to się łączy
To sposób wykorzystania [straty podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20podatkowa). Szybsze odliczenie zwiększa bieżącą [korzyść podatkową](obsidian://open?vault=ekonomia-baza-wiedzy&file=Korzy%C5%9B%C4%87%20podatkowa) (wartość pieniądza w czasie). Wybór metody to decyzja z zakresu [planowania podatkowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Planowanie%20podatkowe).
