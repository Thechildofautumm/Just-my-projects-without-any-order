---
typ: pojęcie
up: "[[MOC Podatek dochodowy przedsiębiorstw]]"
powiązane: ["Limit kosztów finansowania dłużnego"]
wymaga: ["Asymetria podatkowa finansowania"]
źródło: ["[[Podatki – Źródła finansowania a podatek dochodowy]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cienka kapitalizacja", "Thin capitalization"]
---
> [!abstract] Definicja
> Niedostateczna (cienka) kapitalizacja to finansowanie spółki w nadmiernym stopniu długiem, zwłaszcza pożyczkami od podmiotów powiązanych, w celu wykorzystania tarczy odsetkowej.

## Wyjaśnienie
Typowy schemat: spółka matka zamiast wnieść kapitał własny do spółki córki, udziela jej pożyczki → odsetki obniżają podstawę opodatkowania córki.

**Tradycyjne przepisy przeciw cienkiej kapitalizacji:**
- oparte na wskaźnikach struktury kapitału,
- dotyczą głównie odsetek od długu wewnętrznego,
- przykład – Polska przed 2015 r.: odsetki były KUP, jeśli zadłużenie wobec podmiotów powiązanych nie przekraczało **3-krotności kapitału zakładowego** (powiązanie: min. 25% udziału).

Wada: można je obejść, zastępując dług wewnętrzny zewnętrznym.

## Przykład
Spółka córka z kapitałem zakładowym 1 mln zł mogła przed 2015 r. zaliczać do KUP odsetki od pożyczek od matki do 3 mln zł zadłużenia.

## Na egzaminie
> [!question] Pytanie testowe
> Na czym opierały się tradycyjne reguły cienkiej kapitalizacji? **Na wskaźnikach struktury kapitału (relacji długu do kapitału).**

## Zadania
Pojęcie przydaje się też w: [Podatki – limit kosztów finansowania dłużnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20limit%20koszt%C3%B3w%20finansowania%20d%C5%82u%C5%BCnego).

## Jak to się łączy
Zjawisko wynika z [asymetrii podatkowej finansowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Asymetria%20podatkowa%20finansowania). Skuteczniejszą regułą przeciwdziałania jest [limit kosztów finansowania dłużnego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Limit%20koszt%C3%B3w%20finansowania%20d%C5%82u%C5%BCnego) oparty na EBITDA.
