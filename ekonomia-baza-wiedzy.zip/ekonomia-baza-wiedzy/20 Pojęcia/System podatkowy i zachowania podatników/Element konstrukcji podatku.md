---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Preferencja podatkowa", "Dochód podatkowy"]
część-z: ["Podatek"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Podmiot opodatkowania", "Przedmiot opodatkowania", "Podstawa opodatkowania", "Stawka podatkowa", "Skala podatkowa", "Płatnik", "Inkasent"]
---
> [!abstract] Definicja
> Elementy konstrukcji podatku to składniki, które musi określić ustawa: podmiot, przedmiot, podstawa opodatkowania, stawki (skala), preferencje oraz warunki zapłaty.

## Wyjaśnienie
| Element | Treść | Przykład |
|---|---|---|
| **podmiot czynny** | państwo lub samorząd uprawniony do poboru | gmina – podatek od nieruchomości |
| **podmiot bierny** | podatnik: osoba fizyczna, prawna, jednostka bez osobowości, podatkowa grupa kapitałowa | spółka z o.o. w CIT |
| przedmiot | stan faktyczny/prawny rodzący obowiązek | osiągnięcie dochodu, sprzedaż towarów, własność nieruchomości |
| podstawa | przedmiot ujęty ilościowo lub wartościowo | 1 zł dochodu, 1 m² |
| stawka | procentowa, kwotowa, mieszana; zbiór stawek z przedziałami = **skala** | 19% CIT; akcyza na papierosy: kwota + % ceny |
| preferencje | ulgi, zwolnienia, wyłączenia | ulga B+R |
| warunki zapłaty | bezpośrednio / przez **płatnika** (oblicza, pobiera, wpłaca) / przez **inkasenta** (pobiera, wpłaca); jednorazowo, ratalnie, zaliczkowo | PIT od wynagrodzeń – płatnikiem pracodawca |

Podatnik **formalny** (wskazany w ustawie) a **materialny** (ponosi rzeczywisty ciężar); źródło pokrycia: dochód lub majątek.

## Przykład
Podatek dochodowy przedsiębiorcy płacony jest zaliczkowo, podatek od nieruchomości – ratalnie, podatek od dywidendy – jednorazowo, pobierany u źródła.

## Na egzaminie
> [!question] Pytanie testowe
> Czym różni się płatnik od inkasenta? **Płatnik oblicza, pobiera i wpłaca podatek; inkasent tylko pobiera i wpłaca.**

## Jak to się łączy
Elementy konstrukcji opisują budowę każdego [podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek). Jednym z nich są [preferencje podatkowe](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencja%20podatkowa). W CIT podstawą opodatkowania jest [dochód podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Doch%C3%B3d%20podatkowy).
