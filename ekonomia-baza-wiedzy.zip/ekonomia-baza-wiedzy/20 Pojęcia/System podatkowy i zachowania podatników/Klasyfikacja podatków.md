---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Incydencja podatkowa", "System podatkowy w Polsce"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Podatek bezpośredni", "Podatek pośredni", "Podatek dochodowy", "Podatek majątkowy", "Podatek konsumpcyjny"]
---
> [!abstract] Definicja
> Podatki klasyfikuje się według tego, co jest opodatkowane (przychodowe, dochodowe, majątkowe, konsumpcyjne), kto faktycznie ponosi ciężar (bezpośrednie, pośrednie) i komu przypadają wpływy (państwowe, samorządowe, wspólne).

## Wyjaśnienie
```mermaid
flowchart TD
  K["Klasyfikacja podatków"] --> A["Co jest opodatkowane?"]
  K --> B["Kto ponosi ciężar?"]
  K --> C["Komu przypadają wpływy?"]
  A --> A1["przychodowe · dochodowe · majątkowe · konsumpcyjne"]
  B --> B1["bezpośrednie (ciężar na podatniku) · pośrednie (przerzucany na nabywcę)"]
  C --> C1["państwowe · samorządowe · wspólne"]
```

| Podatek | Przedmiot | Ciężar | Wpływy |
|---|---|---|---|
| PIT | dochodowy | bezpośredni | wspólny |
| CIT | dochodowy | bezpośredni | wspólny |
| VAT | konsumpcyjny | pośredni | państwowy |
| akcyza | konsumpcyjny | pośredni | państwowy |
| od nieruchomości | majątkowy | bezpośredni | lokalny |

## Przykład
VAT płaci formalnie sprzedawca, ale ekonomicznie ponosi go nabywca w cenie – dlatego jest podatkiem pośrednim.

## Na egzaminie
> [!question] Zadanie typowe
> Sklasyfikuj podatek od czynności cywilnoprawnych według trzech kryteriów.

> [!success]- Odpowiedź (szkic)
> Podatek od czynności cywilnoprawnych: przedmiot – majątkowy (opodatkowany jest obrót majątkiem, np. sprzedaż rzeczy, pożyczka); ciężar – ponosi go strona czynności (najczęściej kupujący), dlatego zwykle zalicza się go do bezpośrednich; wpływy – samorządowe (dochód gminy).

## Zadania
Zadania do tego pojęcia: [[Podatki – klasyfikacja wybranych podatków]].

## Jak to się łączy
Podział na podatki bezpośrednie i pośrednie wiąże się z przerzucalnością – patrz [incydencja podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Incydencja%20podatkowa). Klasyfikację stosujemy do podatków tworzących [system podatkowy w Polsce](obsidian://open?vault=ekonomia-baza-wiedzy&file=System%20podatkowy%20w%20Polsce).
