---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Interwencja państwa na rynku", "Elastyczność cenowa popytu", "Reakcja podatnika na opodatkowanie"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]", "[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: ["Przerzucalność podatku", "Podatnik w sensie materialnym"]
---
> [!warning] Do weryfikacji
> Część treści pochodzi spoza materiałów z zajęć (podręcznik lub opracowanie własne) – sprawdź z prowadzącym.

> [!abstract] Definicja
> Incydencja podatkowa to faktyczny rozkład ciężaru podatku – kto naprawdę go ponosi; przerzucalność to możliwość przesunięcia ciężaru z podatnika formalnego na inne podmioty.

## Wyjaśnienie
„Ostatecznie każdy podatek, niezależnie od konstrukcji, obciąża ludzi” (wykład).

- **podatnik formalny** – wskazany w ustawie; **materialny** – ponosi rzeczywisty ciężar,
- **przerzucenie do przodu** – na klientów w cenie sprzedaży,
- **przerzucenie do tyłu** – na dostawców w cenie nabycia, na pracowników w wynagrodzeniach.

*Mechanizm rynkowy (uzupełnienie teorią):* podatek przesuwa podaż; cena płacona przez nabywców rośnie, cena otrzymywana przez sprzedawców spada. Większą część ciężaru ponosi strona **mniej elastyczna**.

![[p02_incydencja_podatku.png]]

## Przykład
Akcyza na papierosy: popyt jest nieelastyczny (uzależnienie, brak substytutów), więc większość podatku przerzucana jest na palaczy w cenie.

## Na egzaminie
> [!question] Pytanie otwarte
> Od czego zależy, czy podatek nałożony na producentów zapłacą w praktyce konsumenci? *Odp.: od relacji elastyczności popytu i podaży – im mniej elastyczny popyt, tym większa część ciężaru na nabywcach.*

## Zadania
Pojęcie przydaje się też w: [Elektronika – podatek procentowy od ceny](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elektronika%20%E2%80%93%20podatek%20procentowy%20od%20ceny).

## Jak to się łączy
Incydencja to skutek [interwencji państwa na rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interwencja%20pa%C5%84stwa%20na%20rynku): podatek przesuwa podaż i zmienia cenę równowagi. Podział ciężaru zależy od [elastyczności cenowej popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20cenowa%20popytu). Przerzucenie podatku to jedna z [reakcji podatników na opodatkowanie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Reakcja%20podatnika%20na%20opodatkowanie).
