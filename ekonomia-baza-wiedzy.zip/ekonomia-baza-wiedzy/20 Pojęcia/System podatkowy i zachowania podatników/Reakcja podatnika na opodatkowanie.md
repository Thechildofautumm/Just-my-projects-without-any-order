---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Unikanie i uchylanie się od opodatkowania", "Incydencja podatkowa", "Elastyczność popytu", "Moralność podatkowa"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Opór podatkowy", "Przerzucenie podatku"]
---
> [!abstract] Definicja
> Reakcje podatników na opodatkowanie to sposoby dostosowania się do podatku: od powstrzymania się od działalności, przez dostosowanie i przerzucenie, po unikanie i uchylanie się.

## Wyjaśnienie
Podatki z racji przymusu wywołują **opór podatkowy**; nie ma prostej zależności między poziomem ciężaru podatkowego a wpływami do budżetu.

```mermaid
flowchart TD
  R["Reakcje na opodatkowanie"] --> A["powstrzymanie się od działalności opodatkowanej"]
  R --> B["wycofanie się z działalności"]
  R --> C["dostosowanie się do podatku"]
  R --> D["nadrobienie podatku (więcej pracy)"]
  R --> E["przerzucenie: do przodu (klienci) / do tyłu (dostawcy, pracownicy)"]
  R --> F["unikanie – legalne"]
  R --> G["uchylanie się – nielegalne (oszustwo)"]
```

## Przykład
Po wzroście akcyzy producent alkoholu podnosi cenę (przerzucenie do przodu) i negocjuje niższe ceny butelek (przerzucenie do tyłu).

## Na egzaminie
> [!question] Pytanie testowe
> Co oznacza przerzucenie podatku „wstecz”? **Na dostawców w cenie nabycia lub na pracowników w wynagrodzeniach.**

## Jak to się łączy
Najważniejsze formy ucieczki przed podatkiem to [unikanie i uchylanie się](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania). Przerzucenie podatku opisuje [incydencja podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Incydencja%20podatkowa). Siła reakcji (np. ograniczenie zakupów) zależy od [elastyczności popytu](obsidian://open?vault=ekonomia-baza-wiedzy&file=Elastyczno%C5%9B%C4%87%20popytu). Na wybór reakcji wpływa postawa wobec państwa – patrz [moralność podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Moralno%C5%9B%C4%87%20podatkowa).
