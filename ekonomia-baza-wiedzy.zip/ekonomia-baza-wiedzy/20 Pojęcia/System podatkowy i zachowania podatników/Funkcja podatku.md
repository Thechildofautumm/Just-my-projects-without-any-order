---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Podatek", "Preferencja podatkowa", "Interwencja państwa na rynku"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Funkcje podatków"]
---
> [!abstract] Definicja
> Funkcje podatków to cele, którym służy opodatkowanie: fiskalna, redystrybucyjna, alokacyjna, stabilizująca i informacyjna.

## Wyjaśnienie
| Funkcja | Cel |
|---|---|
| fiskalna | dostarczenie dochodów budżetowi (podstawowa) |
| redystrybucyjna | zmiana podziału dochodów (np. progresja) |
| alokacyjna | wpływ na wykorzystanie zasobów (zachęty, zniechęcanie) |
| stabilizująca | łagodzenie wahań koniunktury |
| informacyjna | dostarczanie danych o gospodarce i podatnikach |

Akcent zależy od podejścia: **liberalizm** – głównie funkcja fiskalna; **interwencjonizm** – także funkcje pozafiskalne.

## Przykład
Akcyza na papierosy pełni funkcję fiskalną i alokacyjną – przynosi wpływy i zniechęca do palenia.

## Na egzaminie
> [!question] Pytanie testowe
> Ulga podatkowa na B+R realizuje głównie funkcję… **alokacyjną (stymulacyjną).**

## Jak to się łączy
Funkcje odpowiadają na pytanie, po co pobierany jest [podatek](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek). Funkcje pozafiskalne realizują w praktyce [preferencje podatkowe](obsidian://open?vault=ekonomia-baza-wiedzy&file=Preferencja%20podatkowa) (ulgi, zwolnienia). Funkcja alokacyjna zmienia równowagę na rynku – patrz [interwencja państwa na rynku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Interwencja%20pa%C5%84stwa%20na%20rynku).
