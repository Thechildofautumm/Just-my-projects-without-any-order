---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Danina publiczna", "Funkcja podatku", "Element konstrukcji podatku", "Źródło prawa podatkowego"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]", "[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Cechy podatku", "Istota podatku"]
---
> [!abstract] Definicja
> Podatek to przymusowe, jednostronnie ustalane, bezzwrotne i nieodpłatne świadczenie pieniężne o charakterze ogólnym na rzecz władzy publicznej.

## Wyjaśnienie
**W sensie ekonomicznym:** transfer (przesunięcie) części PKB od gospodarstw domowych do władzy publicznej.

**W sensie prawnym (art. 6 Ordynacji podatkowej) – cechy:**

| Cecha | Znaczenie |
|---|---|
| przymus | władza może stosować środki przymusu |
| jednostronność ustalania | nie podlega negocjacjom |
| forma pieniężna | – |
| bezzwrotność | nie wraca do podatnika (nie dotyczy nadpłaty!) |
| nieodpłatność | brak bezpośredniego świadczenia wzajemnego (nieekwiwalentność) |
| ogólny charakter | dotyczy kategorii podmiotów, a nie konkretnej osoby |

## Przykład
Opłata skarbowa za wydanie dokumentu jest odpłatna (jest świadczenie wzajemne) – nie jest więc podatkiem, mimo że jest daniną publiczną.

## Na egzaminie
> [!question] Pytanie testowe
> Która cecha odróżnia podatek od opłaty? **Nieodpłatność (brak świadczenia wzajemnego).**

> [!warning] Pułapka
> Bezzwrotność nie oznacza, że nigdy nie dostaniemy pieniędzy z urzędu – nadpłata podatku podlega zwrotowi.

## Zadania
Pojęcie przydaje się też w: [Podatki – klasyfikacja wybranych podatków](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20klasyfikacja%20wybranych%20podatk%C3%B3w).

## Jak to się łączy
Podatek jest jednym z rodzajów [danin publicznych](obsidian://open?vault=ekonomia-baza-wiedzy&file=Danina%20publiczna). Po co państwo go pobiera, opisuje [funkcja podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20podatku), a z czego każdy podatek się składa – [elementy konstrukcji podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Element%20konstrukcji%20podatku). Zgodnie z art. 217 Konstytucji podatki nakłada się wyłącznie ustawą – patrz [źródła prawa podatkowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=%C5%B9r%C3%B3d%C5%82o%20prawa%20podatkowego).
