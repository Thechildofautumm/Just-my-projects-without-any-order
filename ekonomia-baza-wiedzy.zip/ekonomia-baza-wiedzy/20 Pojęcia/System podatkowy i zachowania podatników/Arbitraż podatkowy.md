---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Planowanie podatkowe", "Tarcza podatkowa"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Arbitraż"]
---
> [!abstract] Definicja
> Arbitraż podatkowy to wykorzystywanie różnic w opodatkowaniu – między podatnikami lub między strumieniami dochodu – w celu osiągnięcia korzyści podatkowej.

## Wyjaśnienie
| Rodzaj | Przykład |
|---|---|
| między podatnikami z różnych przedziałów skali | osoba A – PIT 12%, osoba B – PIT 32% |
| między strumieniami dochodu opodatkowanymi według różnych zasad | inwestycja w nieruchomość vs na giełdzie |

Zasada: **przychód** alokuj tam, gdzie stawka jest **niższa**; **koszt** – tam, gdzie stawka jest **wyższa** (tam daje większą tarczę).

## Przykład
Koszt 10 000 zł u osoby B (32%) obniża podatek o 3 200 zł, a u osoby A (12%) – tylko o 1 200 zł.

## Na egzaminie
> [!question] Pytanie testowe
> U kogo lepiej alokować koszt: przy stawce 12% czy 32%? **Przy 32% – tarcza jest większa.**

## Zadania
Zadania do tego pojęcia: [[Podatki – arbitraż przy stawkach 12% i 32%]].

## Jak to się łączy
Arbitraż to typowe narzędzie [planowania podatkowego](obsidian://open?vault=ekonomia-baza-wiedzy&file=Planowanie%20podatkowe). Opiera się na tym, że wartość [tarczy podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa) rośnie wraz ze stawką.
