---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Tarcza podatkowa", "Strata podatkowa"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]", "[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Oszczędność podatkowa"]
---
> [!abstract] Definicja
> Korzyść podatkowa to efekt, na który liczy podatnik unikający lub uchylający się od opodatkowania: niepowstanie lub obniżenie zobowiązania, nadpłata, zwrot albo strata do odliczenia.

## Wyjaśnienie
Formy korzyści podatkowej:
- niepowstanie zobowiązania podatkowego,
- obniżenie wysokości zobowiązania,
- powstanie lub podwyższenie nadpłaty,
- powstanie prawa do zwrotu podatku,
- powstanie lub zwiększenie **straty podatkowej**, odliczanej w przyszłości.

Działania te nie są „bezkosztowe” – koszty doradztwa, ryzyko sankcji, reputacja.

## Przykład
Odliczenie 10 000 zł kosztów przy stawce 19% daje korzyść podatkową 1 900 zł – to tarcza podatkowa.

## Na egzaminie
> [!question] Pytanie testowe
> Czy zwiększenie straty podatkowej jest korzyścią podatkową? **Tak – zmniejszy podatek w przyszłych latach.**

## Jak to się łączy
Miarą korzyści z odliczenia jest [tarcza podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Tarcza%20podatkowa). Zwiększenie [straty podatkowej](obsidian://open?vault=ekonomia-baza-wiedzy&file=Strata%20podatkowa) to korzyść odroczona w czasie.
