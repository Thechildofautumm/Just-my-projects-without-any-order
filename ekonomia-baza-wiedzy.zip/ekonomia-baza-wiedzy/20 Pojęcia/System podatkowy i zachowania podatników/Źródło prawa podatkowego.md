---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Podatek", "Unikanie i uchylanie się od opodatkowania"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Prawo podatkowe", "Ordynacja podatkowa"]
---
> [!abstract] Definicja
> Źródła prawa podatkowego to akty, z których wynikają normy podatkowe: Konstytucja, ustawy, ratyfikowane umowy międzynarodowe, rozporządzenia, akty prawa miejscowego, prawo UE oraz – praktycznie – orzecznictwo sądowe.

## Wyjaśnienie
| Źródło | Treść |
|---|---|
| Konstytucja, art. 217 | podmioty, przedmioty, stawki, ulgi, umorzenia i zwolnienia – **tylko w drodze ustawy** |
| ustawy podatkowe | np. ustawa o CIT (UPDOP), o PIT (UPDOF), Ordynacja podatkowa |
| umowy międzynarodowe (art. 91 Konstytucji) | umowy o unikaniu podwójnego opodatkowania; ratyfikowana za zgodą ustawy ma pierwszeństwo przed ustawą |
| rozporządzenia | wykonawcze, w granicach delegacji ustawowej |
| akty prawa miejscowego | np. uchwały rad gmin o stawkach podatku od nieruchomości |
| prawo UE | dyrektywy (np. ATAD 1 i 2 – przeciw unikaniu opodatkowania), transponowane do prawa krajowego |
| prawotwórstwo sądowe | orzeczenia sądów administracyjnych tworzą „linię orzeczniczą” |

## Przykład
Wyrok NSA z 15 maja 2025 r. (II FSK 163/25) wyjaśnił warunek „zatrudnienia przez 300 dni” przy estońskim CIT: liczy się łączna liczba dni pracy na pełnych etatach (np. 386 dni > 300), a nie jednoczesne zatrudnienie trzech osób przez 300 dni.

## Na egzaminie
> [!question] Pytanie testowe
> Czy minister może wprowadzić nowy podatek rozporządzeniem? **Nie – art. 217 Konstytucji wymaga ustawy.**

## Jak to się łączy
Wymóg ustawy z art. 217 dotyczy każdego [podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek). Granicę między legalnym unikaniem a uchylaniem się wyznacza treść przepisów i linia orzecznicza – patrz [unikanie i uchylanie się od opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania).
