---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Podatek", "System podatkowy w Polsce"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Opłata", "Cło", "Parapodatek"]
---
> [!abstract] Definicja
> Danina publiczna to obowiązkowe świadczenie na rzecz władzy publicznej; obejmuje podatki, opłaty, cła i parapodatki – o charakterze daniny decyduje jej istota, a nie nazwa.

## Wyjaśnienie
| Danina | Cecha wyróżniająca |
|---|---|
| podatek | nieodpłatny, ogólny, bezzwrotny |
| opłata | odpłatna – w zamian za konkretne świadczenie publiczne |
| cło | związana z przywozem/wywozem towarów przez granicę |
| parapodatek | danina pobierana na rzecz określonego celu lub podmiotu (np. składki) |

> [!warning] Nazwa nie przesądza
> „Opłata” może mieć cechy podatku i odwrotnie – trzeba badać istotę świadczenia.

## Przykład
Składki na ubezpieczenia społeczne nie są podatkiem, choć są obowiązkowe – zasilają określony fundusz (parapodatek).

## Na egzaminie
> [!question] Pytanie otwarte
> Wymień rodzaje danin publicznych i podaj po jednym przykładzie z Polski.

> [!success]- Odpowiedź (szkic)
> Podatek (np. PIT, VAT) – nieodpłatny, ogólny; opłata (np. opłata skarbowa) – za konkretne świadczenie publiczne; cło (np. cło przywozowe od towarów spoza UE); parapodatek (np. składki na ubezpieczenia społeczne). O charakterze daniny decyduje jej istota, nie nazwa.

## Jak to się łączy
[Podatek](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek) jest najważniejszą z danin. Opłaty, cła i parapodatki uzupełniają [system podatkowy w Polsce](obsidian://open?vault=ekonomia-baza-wiedzy&file=System%20podatkowy%20w%20Polsce).
