---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Klasyfikacja podatków", "Funkcja podatku"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Tax mix", "Podatki w Polsce"]
---
> [!abstract] Definicja
> System podatkowy to ogół podatków pobieranych w państwie; w Polsce najważniejsze fiskalnie są VAT, PIT, CIT i akcyza.

## Wyjaśnienie
**Wybrane podatki:** PIT, CIT, VAT, akcyza, od nieruchomości, od spadków i darowizn, od czynności cywilnoprawnych, rolny, leśny, od środków transportowych, ryczałt ewidencjonowany, karta podatkowa, tonażowy, od wydobycia kopalin, od niektórych instytucji finansowych, od sprzedaży detalicznej, od gier, wyrównawczy.

![[p01_tax_mix.png]]

**Podział PIT i CIT z samorządami** – nowy system: udział liczony od faktycznych dochodów podatników z danego terenu.

| JST | Udział w PIT | Udział w CIT |
|---|---|---|
| gmina | 7,0% | 1,6% |
| miasto na prawach powiatu | 8,6% | 2,2% |
| powiat | 2,0% | 1,7% |
| województwo | 0,35% | 2,3% |

## Przykład
Największe wpływy daje VAT (41% według MF za 2023 r.), czyli podatek konsumpcyjny i pośredni.

## Na egzaminie
> [!question] Pytanie testowe
> Który podatek ma największe znaczenie fiskalne w Polsce? **VAT.**

## Zadania
Pojęcie przydaje się też w: [Podatki – klasyfikacja wybranych podatków](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20klasyfikacja%20wybranych%20podatk%C3%B3w).

## Jak to się łączy
Każdy podatek w systemie można opisać według [klasyfikacji podatków](obsidian://open?vault=ekonomia-baza-wiedzy&file=Klasyfikacja%20podatk%C3%B3w). Struktura wpływów (tax mix) pokazuje, jak w praktyce realizowana jest fiskalna [funkcja podatków](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20podatku).
