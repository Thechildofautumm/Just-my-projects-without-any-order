---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Odliczenie podatkowe", "Unikanie i uchylanie się od opodatkowania"]
część-z: ["Element konstrukcji podatku"]
źródło: ["[[Podatki – Wprowadzenie do opodatkowania]]", "[[Podatki – Rodzaje odliczeń i tarcza podatkowa]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Ulga podatkowa", "Zwolnienie podatkowe", "Wyłączenie z opodatkowania", "Tax expenditures"]
---
> [!abstract] Definicja
> Preferencje podatkowe to ulgi, zwolnienia i wyłączenia, które w określonych sytuacjach zmniejszają obciążenie podatkowe lub wyłączają opodatkowanie.

## Wyjaśnienie
| Preferencja | Na czym polega | Przykład |
|---|---|---|
| **ulga** | ograniczenie podstawy, stawki lub kwoty podatku | IP Box, ulga B+R, ulga prorodzinna |
| **zwolnienie** | stan mieści się w ramach podatku, ale przepis wyłącza go z opodatkowania | zwolnienie z VAT ze względu na przychody |
| **wyłączenie** | „opodatkowaniu nie podlega” – zwykle bo objęty innym podatkiem | spadek wyłączony z PIT, opodatkowany podatkiem od spadków i darowizn |

**Tax expenditures** – koszty preferencji dla budżetu (utracone wpływy podatkowe).

## Przykład
Ulga mieszkaniowa: zwolnienie dochodu ze sprzedaży nieruchomości przed upływem 5 lat, jeśli trafi on „na cele mieszkaniowe” – spór, czy chodzi o własne potrzeby czy inwestycje.

## Na egzaminie
> [!question] Pytanie testowe
> Czym różni się zwolnienie od wyłączenia z opodatkowania? **Zwolnienie dotyczy stanu objętego podatkiem, ale zwolnionego przepisem; wyłączenie – stanu w ogóle nieobjętego danym podatkiem.**

## Zadania
Pojęcie przydaje się też w: [Podatki – ulga prorodzinna jako odliczenie od podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20ulga%20prorodzinna%20jako%20odliczenie%20od%20podatku).

## Jak to się łączy
Preferencje to jeden z [elementów konstrukcji podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Element%20konstrukcji%20podatku). Technicznie ulga działa jako [odliczenie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Odliczenie%20podatkowe) od dochodu albo od podatku. Korzystanie z preferencji to legalna forma [unikania opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania).
