---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Unikanie i uchylanie się od opodatkowania", "Arbitraż podatkowy", "Funkcja rachunkowości zarządczej"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]", "[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Strategia podatkowa", "Tax planning", "Optymalizacja podatkowa"]
---
> [!abstract] Definicja
> Planowanie podatkowe to uwzględnianie konsekwencji podatkowych w planowaniu finansowym (szerzej) albo prowadzenie interesów tak, by legalnie zminimalizować obciążenie (węziej: tax planning, tax structuring).

## Wyjaśnienie
| Ujęcie | Treść |
|---|---|
| szersze | skutki podatków dla rentowności, płynności, efektywności i wartości firmy |
| węższe | wykorzystanie dozwolonych prawnie możliwości minimalizacji podatku |

**Strategia podatkowa** jest częścią strategii finansowej, która jest elementem ogólnej strategii przedsiębiorstwa.

Przykładowe strategie (mały podatnik, 9% CIT): przesunięcie sprzedaży na kolejny rok, przyspieszenie kosztów (inwestycje), podział spółki (naturalny, inaczej GAAR), optymalizacja roku podatkowego; wybór metody rozliczania straty.

## Przykład
Spółka blisko limitu 2 mln euro przychodów negocjuje z kontrahentem przesunięcie części dostaw na styczeń, by zachować stawkę 9%.

## Na egzaminie
> [!question] Pytanie otwarte
> Umiejscow strategię podatkową w strategii przedsiębiorstwa i podaj dwa przykłady legalnego planowania.

> [!success]- Odpowiedź (szkic)
> Strategia podatkowa jest częścią strategii finansowej, a ta – strategii przedsiębiorstwa: podatki wpływają na rentowność, płynność i wartość firmy.
> Przykłady legalnego planowania: przesunięcie sprzedaży na kolejny rok, by zachować stawkę 9%; wybór metody rozliczenia straty; finansowanie długiem z uwzględnieniem tarczy odsetkowej i limitów.

## Zadania
Pojęcie przydaje się też w: [Podatki – arbitraż przy stawkach 12% i 32%](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20arbitra%C5%BC%20przy%20stawkach%2012%25%20i%2032%25), [Podatki – czy spółka zapłaci 9% CIT](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20czy%20sp%C3%B3%C5%82ka%20zap%C5%82aci%209%25%20CIT).

## Jak to się łączy
Planowanie to systematyczne, legalne [unikanie opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania), z zachowaniem jego granic. Typową techniką jest [arbitraż podatkowy](obsidian://open?vault=ekonomia-baza-wiedzy&file=Arbitra%C5%BC%20podatkowy). Uwzględnianie skutków podatkowych w planach i decyzjach to zadanie, które realizuje też [rachunkowość zarządcza](obsidian://open?vault=ekonomia-baza-wiedzy&file=Funkcja%20rachunkowo%C5%9Bci%20zarz%C4%85dczej) (planowanie, decyzje).
