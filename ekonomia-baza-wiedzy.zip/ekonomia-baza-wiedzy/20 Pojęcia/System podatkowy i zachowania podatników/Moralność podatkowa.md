---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Unikanie i uchylanie się od opodatkowania", "Podatek"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Mentalność podatkowa", "Postawy wobec podatków", "Szara strefa"]
---
> [!abstract] Definicja
> Moralność podatkowa to wewnętrzna akceptacja (lub jej brak) obowiązku podatkowego i zwierzchności państwa; mentalność podatkowa to ogólne nastawienie do podatków.

## Wyjaśnienie
**Postawy Polaków (PIE, Kiełczewska i Sawulski 2021):**
- 35% zadowolonych z płacenia podatków (w Finlandii 80%),
- 83% uważa podatki za zbyt wysokie, choć obciążenia są umiarkowane na tle innych krajów,
- respondenci szacują, że państwo marnuje 51% wydatków (39% po pokazaniu struktury wydatków),
- wydatki na emerytury i renty szacowane na 15% (w rzeczywistości ok. ⅓); administracja – ok. 5%,
- szara strefa ok. 23% PKB (Bank Światowy; średnia UE 21%).

**Powody lekceważenia obowiązków:** słaba świadomość państwowa, subiektywny ciężar podatku, poczucie niesprawiedliwości, niskie prawdopodobieństwo kontroli i kar, brak napiętnowania społecznego; historycznie – traktowanie władzy jako obcej.

## Przykład
Ponieważ podatek jest nieekwiwalentny, państwo wydaje się anonimowe – podatnik może uważać, że niezapłacenie podatku „nikomu nie szkodzi”.

## Na egzaminie
> [!question] Pytanie otwarte
> Od czego zależy moralność podatkowa? Wskaż czynniki specyficzne dla Polski.

> [!success]- Odpowiedź (szkic)
> Czynniki: świadomość państwowa, subiektywnie odczuwany ciężar podatku, poczucie sprawiedliwości systemu i sensowności wydatków, prawdopodobieństwo kontroli i kar, presja społeczna.
> Polska: niska akceptacja (35% zadowolonych z płacenia podatków), przekonanie o marnotrawstwie wydatków publicznych (szacunek 51%), duża szara strefa (ok. 23% PKB), historyczne traktowanie władzy jako obcej.

## Jak to się łączy
Niska moralność sprzyja [uchylaniu się od opodatkowania](obsidian://open?vault=ekonomia-baza-wiedzy&file=Unikanie%20i%20uchylanie%20si%C4%99%20od%20opodatkowania). Akceptację osłabia nieekwiwalentność, czyli jedna z cech [podatku](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatek).
