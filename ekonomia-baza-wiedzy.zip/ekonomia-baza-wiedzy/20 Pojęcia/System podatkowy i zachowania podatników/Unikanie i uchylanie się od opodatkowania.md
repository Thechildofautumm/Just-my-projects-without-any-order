---
typ: pojęcie
up: "[[MOC System podatkowy i zachowania podatników]]"
powiązane: ["Korzyść podatkowa", "Planowanie podatkowe"]
część-z: ["Reakcja podatnika na opodatkowanie"]
źródło: ["[[Podatki – Reakcje na opodatkowanie]]", "[[Podatki – Mały podatnik i obniżona stawka CIT]]"]
przedmiot: ["Podatki i strategie podatkowe"]
tags: ["typ/pojęcie", "status/gotowe"]
aliases: ["Unikanie opodatkowania", "Uchylanie się od opodatkowania", "Oszustwo podatkowe", "GAAR"]
---
> [!abstract] Definicja
> Unikanie opodatkowania to legalne obniżanie obciążeń przez korzystanie z możliwości oferowanych przez ustawodawcę; uchylanie się – zmniejszanie lub eliminowanie podatku z naruszeniem prawa.

## Wyjaśnienie
| | Unikanie | Uchylanie się |
|---|---|---|
| legalność | zgodne z prawem (granica nie zawsze klarowna) | z naruszeniem prawa |
| przykłady | ulgi (np. na dzieci), wybór formy opodatkowania (ryczałt, liniowy), wykorzystanie nieścisłości prawa, tworzenie fikcyjnych sytuacji | zatajenie źródeł przychodu, niezłożenie zeznania, fikcyjne koszty, nienależne ulgi, amortyzacja nieistniejących środków trwałych, fałszowanie ksiąg i faktur, fikcyjny eksport |

Przy agresywnych konstrukcjach zastosowanie ma **ogólna klauzula przeciwko unikaniu opodatkowania (GAAR)** – np. sztuczny podział spółki tylko dla stawki 9% CIT.

## Przykład
Niektóre kraje opodatkowują budynki dopiero po ukończeniu – stąd widoczne druty zbrojeniowe na dachach domów od dawna zamieszkałych (fikcyjna sytuacja „budowy w toku”).

## Na egzaminie
> [!question] Pytanie testowe
> Wybór ryczałtu zamiast skali podatkowej to… **unikanie opodatkowania (legalne).**

## Zadania
Pojęcie przydaje się też w: [Podatki – arbitraż przy stawkach 12% i 32%](obsidian://open?vault=ekonomia-baza-wiedzy&file=Podatki%20%E2%80%93%20arbitra%C5%BC%20przy%20stawkach%2012%25%20i%2032%25).

## Jak to się łączy
Obie formy to rodzaje [reakcji na opodatkowanie](obsidian://open?vault=ekonomia-baza-wiedzy&file=Reakcja%20podatnika%20na%20opodatkowanie). Ich celem jest [korzyść podatkowa](obsidian://open?vault=ekonomia-baza-wiedzy&file=Korzy%C5%9B%C4%87%20podatkowa). Legalne unikanie, prowadzone w sposób systematyczny, to [planowanie podatkowe](obsidian://open?vault=ekonomia-baza-wiedzy&file=Planowanie%20podatkowe).
