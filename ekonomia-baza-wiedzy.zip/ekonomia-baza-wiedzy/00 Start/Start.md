---
typ: start
tags: ["typ/start"]
aliases: ["Strona główna", "Home"]
---
Baza wiedzy z czterech przedmiotów: **mikroekonomii**, **ekonomii menedżerskiej**, **rachunkowości zarządczej** oraz **podatków i strategii podatkowych**. Wiedza jest podzielona na obszary tematyczne (MOC), a nie na przedmioty – te same pojęcia z różnych zajęć są w jednej notatce. Przedmiot każdej notatki widać we właściwości `przedmiot`.

## Obszary wiedzy
- [[MOC Podstawy gospodarowania i optymalizacja]] – rzadkość, koszt alternatywny, analiza marginalna i matematyczne metody optymalizacji decyzji.
- [[MOC Rynek, popyt i elastyczność]] – popyt, podaż, równowaga, elastyczności, przychody i ustalanie ceny.
- [[MOC Wybór konsumenta]] – od użyteczności i krzywych obojętności do krzywej popytu, krzywych Engla i efektów cenowych.
- [[MOC Produkcja i koszty]] – funkcja produkcji, optymalne zatrudnienie i kombinacja czynników, rodzaje kosztów, zysk ekonomiczny.
- [[MOC Struktury rynkowe i decyzje firmy]] – konkurencja doskonała, monopolistyczna, oligopol, monopol; decyzje produkcyjne i efektywność.
- [[MOC Rachunkowość zarządcza]] – istota, funkcje i organizacja rachunkowości zarządczej, rola i etyka kontrolera.
- [[MOC Rachunek kosztów]] – klasyfikacja i zachowanie kosztów, szacowanie funkcji kosztów, RKZ/RKP, marże, ABC i TDABC.
- [[MOC System podatkowy i zachowania podatników]] – istota i konstrukcja podatku, system podatkowy, reakcje podatników i planowanie podatkowe.
- [[MOC Podatek dochodowy przedsiębiorstw]] – CIT: źródła przychodów, mały podatnik, odliczenia i tarcza, straty, finansowanie a podatek.

## Nauka i powtórka
- [[MOC Pomoce do nauki]] – przewodniki po przedmiotach, wzory, słownik, schematy, fiszki, bank pytań, atlas wykresów i kanwy.

> [!tip] Jak się uczyć
> 1. Otwórz przewodnik przedmiotu i idź w kolejności wykładów.
> 2. W każdej notatce: definicja → wyjaśnienie → przykład → **Na egzaminie** → zadania.
> 3. Zadania rozwiązuj sam – rozwiązanie jest zwinięte.
> 4. Przed zaliczeniem: fiszki i bank pytań.
