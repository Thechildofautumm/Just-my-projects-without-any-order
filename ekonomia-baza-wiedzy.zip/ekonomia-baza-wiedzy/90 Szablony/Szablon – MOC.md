---
typ: moc
up: "[[Start]]"
tags: ["typ/moc"]
---
> [!abstract] Obszar
> Jedno zdanie o zakresie obszaru.

## Grupa pojęć
- (link do pojęcia) – jedno zdanie opisu.

## Zadania

## Powiązane obszary
- (link do MOC) – uzasadnienie (max 3).
