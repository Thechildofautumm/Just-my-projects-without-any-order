---
typ: zadanie
up: ""
przykład-z: []
powiązane: []
źródło: []
przedmiot: []
tags: ["typ/zadanie", "status/do-weryfikacji"]
---
## Treść

> [!success]- Rozwiązanie
> 1. 

## Jak to się łączy
To zadanie ćwiczy (link do pojęcia).
