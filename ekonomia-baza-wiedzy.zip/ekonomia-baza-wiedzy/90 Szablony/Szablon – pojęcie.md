---
typ: pojęcie
up: ""
powiązane: []
wymaga: []
część-z: []
przeciwieństwo: []
źródło: []
przedmiot: []
tags: ["typ/pojęcie", "status/do-weryfikacji"]
aliases: []
---
> [!abstract] Definicja
> Jedno zdanie.

## Wyjaśnienie

## Przykład

## Na egzaminie
> [!question] Pytanie testowe
> 

> [!warning] Pułapka
> 

## Jak to się łączy
Zdanie z linkiem wyjaśniające relację.
